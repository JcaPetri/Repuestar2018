-- ############################################################################################################################################
--  GENERA LOS PROCEDIMIENTOS ALMACENADOS PARA HACER EL ALTA, MODIFICACION, BAJA O RECUPERO DE LA RELACI�N ENTRE:
--	LOS PERFILES DE USUARIO (modulo acceso) y LOR PROCESOS DEFAULT DEL SISTEMA -- 
--	LOS ACCESO A LOS PROCESOS (modulo acceso) y LOS PROCESOS DEL SISTEMA -- 
--  CARGA LA TABLA [CPrGeTProcPerf]
-- ############################################################################################################################################
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- Determina la base de datos donde se trabajar�
USE [BDCtral]
GO

DECLARE	@return_value int
DECLARE @PARint1 AS uniqueidentifier
SET @PARint1 = NEWID()

	EXEC @return_value = [dbo].[CPrGePRelacAccesProcPerfilyProcesosABM]
		-- Determina acci�na realizar -- ALTA - MODIFICACION - BAJA - RECUPERO
			@PAR1 = 'ALTA'
		
		-- IDFkCPrGePProcPerf -- valor ID, debe ser �nico.
			,@PAR2 = @PARint1

		-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
			,@PAR3 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'			-- Espa�ol, por defecto
				--	ee954f5d-ca27-48a9-a23b-010788b18631	ITA	italiano
				--	b1268278-4eb3-4a93-8f67-0d425b767c65	ENG	english
				--	a455281d-76f5-4bad-8dbb-201c5928aaf8	FRA	fran�ais
				--	1048c13b-1cc9-4154-8b8b-64ca9ac9fe12	POR	portugu�s
				--	fb478ecc-85fe-4fc8-b792-caf8ecb921b1	ESP	espa�ol

		-- Codigo del Proceso Perfil	-- C�digo en letras del ID
			,@PAR4 = ''
	
		-- Descripci�n del Proceso Perfil -- Es la descripci�n del c�digo en letras.	
			,@PAR5 = ''
		
		-- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
			,@PAR6 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'					-- Habilitado

		-- ID de las Empresas disponibles del sistema
			,@PAR7 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'					-- BPM	Business Process Managment
--				-- DECLARE	@return_value int
--				-- EXEC @return_value = [dbo].[CDiccPCodxIdio] @PAR2 = 'EDCDB2BA-90EC-466E-B32D-B39F42E96E3F'
--					--	'56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'	BPM	Business Process Managment
--					--	'A5E49ED6-EFDD-4C43-955F-7F3616E39F99'	multiempresa	se aplica para los c�digos generales del sistema

		-- ID del tipo de relaci�n, esto determina con que tabla se relaciona. 
			,@PAR8 = '53721D2A-6973-42D5-A282-676FB646E343'	--	AccesoTGestEtaMot			perfil proceso default, es el proceso donde inicia el perfil de usuario agrupado
--				-- CProcTTipoRelacion		-- ID del tipo de relaci�n, esto determina con que tabla se relaciona. 
--					-- Ambito de Aplicaci�n			8AEBC8CD-5F8D-4C53-B3D1-28248D2C15DE	CProcTTipoRelacion	tabla con los tipos de relaciones en
--					--	DECLARE	@return_value int
--					--	EXEC	@return_value = [dbo].[CDiccPCodxIdio]
--					--			@PAR2 = N'8AEBC8CD-5F8D-4C53-B3D1-28248D2C15DE'		--	CProcTTipoRelacion	tabla con los tipos de relaciones entre modulo acceso y modulo procesos
--					-- Los c�digos de estas relaciones son:
--							-- Tipo de relaci�n entre el Perfil de Usuario y los Procesos Default que inicia cada usuario
--								--	'92CBE163-D12F-4662-B8F0-584174FB2843'	--	PerfProcDefault			perfil proceso default, es el proceso donde inicia el perfil de usuario agrupado
--
--							-- Tipo de relaci�n entre los Tipos de Acceso y los Procesos que puede abrir
--								--	'FB516B30-D823-4562-A32E-E45B4018FF72'	--	AccesoProcTProcesos		Relaciona el Acceso a los Procesos y los Procesos.
--								--	'53721D2A-6973-42D5-A282-676FB646E343'	--	AccesoTGestEtaMot		Relaciona el Acceso a los Procesos y los Procesos de Gestion Etapas Motivos.
--								--	'A7C62E22-B898-40FF-BF30-03FE128B3E03'	--	AccesoProcLogMan		Relaciona el Acceso a los Procesos y Logica Manual.
--								--	'D8DEC339-9733-4302-B604-C9B096EBAF40'	--	AccesoProcLogAut		Relaciona el Acceso a los Procesos y la Logica Automatica.
--
--					-- ACLARACION: el Perfil Empresa, ya esta relacionado dentro del M�dulo Acceso

		-- ID del c�digo del Proceso de Gestion, PrGeT Procesos, Gestion, LogAut, LogMan, esta info esta en las tablas con los ambitos de aplicaci�n que se detallan a continuaci�n.
			,@PAR9 AS VARCHAR(50)
--				-- ID del c�digo del Proceso de Gestion, PrGeT Procesos, Gestion, LogAut, LogMan, 
--				-- esta info esta en las tablas con los ambitos de aplicaci�n que se detallan a continuaci�n.
--				-- Procesos del Sistema, este surge de los siguientes procesos almacenados
--	--					DECLARE	@return_value int
--	--					DECLARE @Idi AS NVARCHAR(36)
--	--					DECLARE @Emp AS NVARCHAR(36)
--	--					SET @Idi = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'			-- Idioma elegido o por defecto = espa�ol
--	--					SET @Emp = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'			-- BPM	Business Process Managment
--	--					-- Procesos	[CDiccTCodigos] y [CDiccTCodxIdiomas]
--	--					EXEC @return_value = [dbo].[CPrGePProcesos] @PAR1 = @Idi, @PAR2 = @Emp
--	--
--	--					-- TGestion (combinaci�n de las Etapas y Motivos) [CPrGeTGestion]
--	--					EXEC @return_value = [dbo].[CPrGePGestion] @PAR1 = @Idi, @PAR2 = @Emp
--	--						 ,@PAR3 = 'EC3887CE-C7C1-4C53-A96D-621BD28A715D'	-- Proceso
--
--					-- Pagina Inicial Usuario An�nimo
--						--	'EC3887CE-C7C1-4C53-A96D-621BD28A715D'		--	PagIniUA	p�gina inicial del usurio an�nimo
--							--	'E2C1F05E-5169-41FB-8CCC-B7ACB76293E3'	--	TG-PagVis	visualiza la p�gina definida
--
--					--	L�gica Autom�tica del Proceso de Gesti�n [CPrGeTLogAut]
--						--	'79B264F7-05BA-46AE-B56F-3FAAD6F64861'	-- Login				Proceso para ingresar al sistema.	B2B4FFA6-A79A-4847-BA19-0036BFD4FF9D	TG-IngPte	Usuario pendiente de ingreso y no esta identificado
--						--	'B2B4FFA6-A79A-4847-BA19-0036BFD4FF9D'	-- TG-IngPte			Usuario pendiente de ingreso y no esta identificado
--						--	'4A283628-5D5E-45B6-BFFE-80591E5D3149'	-- TG-IngPte/UsuIne		Usuario inexistente.
--						--	'F65785C5-47FB-458F-A070-C0F4A25C8E83'	-- TG-UsuPte			Usuario identificado, pendiente de ingreso.
--						--	'1C8A1E56-A080-4187-AA3A-0208B8B58D80'	-- TG-UsuPte/UsuErr		Usuario identificado, tuvo error de logueo.
--						--	'1255E790-EBBE-4D64-AA1B-3AE776E71B4A'	-- TG-UsuBlo			Usuario bloqueado.
--						--	'83605861-8DFA-4FAB-87D3-22181A759D60'	-- TG-UsuIng			Usuario ingres�.

		-- Es el ID del Perfil [CPerfTPerfil] o Acceso a Proceso [CPerfTAccesoProcesos]
			,@PAR10 = 'AD07DDA5-0FCD-4AE7-9DFA-DAEC2B3F19E2'	--	AccProcAnonimo
--				-- Surge de ejecutar esta consulta
--				-- Ya que esta informaci�n esta en las tabla [CDiccTCodigos] y [CDiccTCodxIdiomas], 
--				-- los ambitos de aplicaci�n que se utilizan son:
--						--	69752B6B-9B31-402B-83DC-4E945DF7879C	CPerfTPerfil			tabla perfiles de usuarios agrupados
--						--	50E6A111-D9BE-4CF7-9115-69A1294EACAB	CPerfTAccesoProcesos	tabla acceso a los procesos del sistema	
--
--						-- Info del Acceso a los Procesos del Sistema
--			--			DECLARE	@return_value int
--			--			EXEC	@return_value = [dbo].[CPerfPAccesoProcesos]			-- Tabla 04 - [CDiccTCodigos] y [CDiccTCodxIdiomas], datos de los Perfiles que tienen las Empresas
--			--						@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--			--						,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
							-- Ejemplos de Acceso a Proceso
--								--	'AD07DDA5-0FCD-4AE7-9DFA-DAEC2B3F19E2'	--	AccProcAnonimo			acceso a los procesos del usuario no identificados
--								--	'F5897341-D898-4D23-9086-645C079162F5'	--	AccProcAteCliSalon		acceso a los procesos de atenci�n al cliente en el salon de ventas
--								--	'8091CCEC-2C14-434D-A989-08927D4F312C'	--	AccProcGral				acceso a los procesos generales del usuario validado.
--								--	'B4525BDD-105B-4EAD-AEC5-97DAB144D3FB'	--	AccProcRecepSalon		acceso a los proceso de atenci�n en el salon
--
--
--						-- Info de los Perfiles, para relacionar los submodulos Acceso a los Procesos y Usuario Agrupados
--			--			DECLARE	@return_value int
--			--			EXEC	@return_value = [dbo].[CPerfPPerfil]				-- Tabla 05 - [CDiccTCodigos] y [CDiccTCodxIdiomas], datos de las Agrupaciones de  Perfiles que tienen las Empresas. Se utiliza para vincular las agrupaciones de Usuarios.
--			--						@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--			--						,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
--							--	'05805405-C736-4FFD-9C3F-92ED912A46F4'	--	PA-Anonimo	perfil anonimo no identificado
--							--	'3E922EED-D9A7-4FC7-8450-F543C27F0CE8'	--	PV-Gcia	PostVenta acceso a los accesos gerenciales.
--							--	'0F52F251-C0C7-484B-A2A2-2B7AD0DBD434'	--	PV-Gral	PostVenta General.

		-- Define si se da el alta completo AltaCompleto o parcial (que el codigo esta creado y solo hay que cargar un nuevo idioma).	
			,@PAR11 = 'AltaCompleto'
