-- ############################################################################################################################################
--  GENERA LOS PROCEDIMIENTOS ALMACENADOS PARA HACER EL ALTA, MODIFICACION, BAJA O RECUPERO DE LA RELACI�N ENTRE:
--	LOS PERFILES DE USUARIO (modulo acceso) y LOR PROCESOS DEFAULT DEL SISTEMA -- 
--	LOS ACCESO A LOS PROCESOS (modulo acceso) y LOS PROCESOS DEL SISTEMA -- 
-- ############################################################################################################################################

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- Determina la base de datos donde se trabajar�
USE [BDCtral]
GO

-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 22/07/2017
-- Description:	Detalle de los c�digos ID, para el idioma elegido o el por defecto = espa�ol
-- =============================================
ALTER PROCEDURE [dbo].[CPrGePRelacAccesProcPerfilyProcesosABM]
	-- Add the parameters for the stored procedure here
	@PAR1 AS VARCHAR(50)	-- Determina acci�na realizar -- ALTA - MODIFICACION - BAJA - RECUPERO
	,@PAR2 AS VARCHAR(36)	-- IDFkCPrGePProcPerf -- valor ID, debe ser �nico.
	,@PAR3 AS VARCHAR(36) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'	-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
							-- ID del Idioma	-- Espa�ol, por defecto
	,@PAR4 AS VARCHAR(50)	-- Codigo del Proceso Perfil	-- C�digo en letras del ID
	,@PAR5 AS VARCHAR(25) 	-- Descripci�n del Proceso Perfil -- Es la descripci�n del c�digo en letras.
	,@PAR6 AS VARCHAR(36) 	-- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
	,@PAR7 AS VARCHAR(50)	-- ID de las Empresas disponibles del sistema
	,@PAR8 AS VARCHAR(50)	-- ID del tipo de relaci�n, esto determina con que tabla se relaciona. 
	,@PAR9 AS VARCHAR(50)	-- ID del c�digo del Proceso de Gestion, PrGeT Procesos, Gestion, LogAut, LogMan, esta info esta en las tablas con los ambitos de aplicaci�n que se detallan a continuaci�n.
	,@PAR10 AS VARCHAR(50)	-- Es el ID del Perfil [CPerfTPerfil] o Acceso a Proceso [CPerfTAccesoProcesos]
	,@PAR11 AS VARCHAR(50)	-- Define si se da el alta completo AltaCompleto o parcial (que el codigo esta creado y solo hay que cargar un nuevo idioma).

AS
BEGIN

	DECLARE @ProcID AS VARCHAR(36)		-- Define el ID del proceso, esto es cuando se carga TGestion, o Logica, hay que buscar el proceso Padre
	DECLARE @PARInt1 AS VARCHAR(36)		--	CProcTProcPerfil	tabla con la relaci�n entre el modulo acceso y el modulo de procesos
	-- Variables para obtener los valores del procedimiento almacenado de CGetErrorInfo
	DECLARE @RTADO_PROCALM AS VARCHAR(250)
	DECLARE @NOMB_PROCALM AS VARCHAR(250)
	DECLARE @FUNC_PROCALM AS VARCHAR(100)
	DECLARE @RTADO AS VARCHAR(250)
	DECLARE @REG_AFEC AS NUMERIC(18, 0)
	DECLARE @ERR_MESSAGE AS VARCHAR(250)
	DECLARE @ERR_NUMBER AS NUMERIC(18, 0)
	DECLARE @ERR_SEVERITY AS NUMERIC(18, 0)
	DECLARE @ERR_STATE AS NUMERIC(18, 0)
	DECLARE @ERR_LINE AS NUMERIC(18, 0)
	
	SET @NOMB_PROCALM = 'CDiccPCodxIdioABM'				-- Nombre del procedimiento almacenado.
	SET @PARInt1 = '65F1CBD0-9DA8-4980-8E6C-367A4432C70A'		--	CProcTProcPerfil	tabla con la relaci�n entre el modulo acceso y el modulo de procesos
	-- Ambito de Aplicaci�n
		-- Caso Alta: 
			-- codigo del ambito de aplicacion a donde se asignara el codigo.
				-- El ambito de aplicaci�n siempre es el mismo	
				-- Esta info se guarda en las tablas [CDiccTCodigos] y [CDiccTCodxIdiomas], bajo el ambito de aplicaci�n 
					-- '65F1CBD0-9DA8-4980-8E6C-367A4432C70A'		--	CProcTProcPerfil	tabla con la relaci�n entre el modulo acceso y el modulo de procesos
		-- Caso Modificaci�n: 
				-- El ambito de aplicaci�n siempre es el mismo	
				-- Esta info se guarda en las tablas [CDiccTCodigos] y [CDiccTCodxIdiomas], bajo el ambito de aplicaci�n 
					-- '65F1CBD0-9DA8-4980-8E6C-367A4432C70A'		--	CProcTProcPerfil	tabla con la relaci�n entre el modulo acceso y el modulo de procesos

	-- Variables para almacenar la tabla de c�digo por idioma
	DECLARE @TmpTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)

	-- Los pasos para dar de alta una nueva Relaci�n Proceso Perfil son:
	--	1.- Dar de alta el codigo en el sistema, esto se hace con el procedimiento almacenado CDiccPCodxIdioABM, 
	--		que esta incluido en el presente procedimiento
	--	2.- Como el ID y su codigo ya estan creados, solo debe ingresarlo a la tabla de CPrGeTProcPerf con el estado habilitado.
	--		por ello en este procedimiento, lo que hace es buscar el codigo ID y agregarlo a la tabla [CPrGeTProcPerf]
	--		La clave primaria se compone del ID de la tabla TCodigos, para los ambitos siguiente:
			-- [IDFkCDiccTCod_ProcPerf]						-- esta info se guarda en la tabla Ambito aplicaci�n: CProcTProcPerfil
					-- Esta info se guarda en las tablas [CDiccTCodigos] y [CDiccTCodxIdiomas], bajo el ambito de aplicaci�n '65F1CBD0-9DA8-4980-8E6C-367A4432C70A'		--	CProcTProcPerfil	tabla con la relaci�n entre el modulo acceso y el modulo de procesos
			-- [IDFkCDiccTCod_Empresa]						-- Empresa a la que esta asignada la relaci�n
			-- [IDFkCDiccTCod_CodProcTGestLog]						-- ID del Proceso, TGestion (combinaci�n del Proceso Etapa Motivo), Logica Manual, Logica Autom�tica, etc.
				-- aqu� va el ID de la tabla [CDiccTCodigos], este c�digo combinado con el CodRelac (que tiene el ambito de aplicaci�n), sale su descripci�n.
			-- [IDFkCDiccTCod_CPerfilAccProc]						-- ID del Perfil o del Acceso al Proceso
			-- [IDFkCDiccTCod_CodRelac]						-- ID del Tipo de relaci�n (esto define la tabla con la que se relaciona, puede ser el Proceso, el TGestion, etc.)
					--	DECLARE	@return_value int
					--	EXEC	@return_value = [dbo].[CDiccPCodxIdio]
					--			@PAR2 = N'8AEBC8CD-5F8D-4C53-B3D1-28248D2C15DE'		--	CProcTTipoRelacion	tabla con los tipos de relaciones entre modulo acceso y modulo procesos

				--	Relaci�n entre los perfiles/AccesoProcesos y los Procesos del Sistema.
				--	Un perfil debe estar asociado a: (Debe respetar esta jerarqu�a, si no es as�, se debe bloquear el cambio)
				--		un proceso, 
				--		un proceso Etapa Motivo, 
				--		una logica de proceso.
				--		una evento, etc
				-- Los c�digos de estas relaciones son:
						-- Tipo de relaci�n entre el Perfil de Usuario y los Procesos Default que inicia cada usuario
							--	92CBE163-D12F-4662-B8F0-584174FB2843	PerfProcDefault			perfil proceso default, es el proceso donde inicia el perfil de usuario agrupado

						-- Tipo de relaci�n entre los Tipos de Acceso y los Procesos que puede abrir
							--	FB516B30-D823-4562-A32E-E45B4018FF72	AccesoProcTProcesos		Relaciona el Acceso a los Procesos y los Procesos.
							--	53721D2A-6973-42D5-A282-676FB646E343	AccesoTGestEtaMot		Relaciona el Acceso a los Procesos y los Procesos de Gestion Etapas Motivos.
							--	A7C62E22-B898-40FF-BF30-03FE128B3E03	AccesoProcLogMan		Relaciona el Acceso a los Procesos y Logica Manual.
							--	D8DEC339-9733-4302-B604-C9B096EBAF40	AccesoProcLogAut		Relaciona el Acceso a los Procesos y la Logica Automatica.

				--	En una consulta se obtienen todos los derechos del usuario al sistema.
			-- un Proceso Perfil permite customizar, adaptar, el sistema seg�n el perfil que tenga el usuario.
			-- en el caso de la combinaci�n ProcEtaMot/Perfil, el vendedor puede ver una pagina, una logica distinta que al supervisor, o gerente. Tres perfiles distintos para la misma etapa motivo.

		-- Aclaraciones:
		--	La modificacion de nombre o descripcion, se hace con el procedimiento almacenado CDiccPCodxIdioABM
		--	Lo que se puede hacer con el ProcPerf es cambiarle el estado, Habilitado, Deshabilitado, Eliminado.

--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	-- Variables para realizar al ABM de la tabla [CPrGeTProcPerf], aqu� se pone que tipo de relaci�n se cargo, se debe:
--		-- Variables Etapa 1
--		DECLARE @PAR1 AS VARCHAR(50)	-- Determina acci�na realizar 
--			-- valores posibles: ALTA - MODIFICACION - BAJA - RECUPERO
--			-- Como estos valores son para todas las tablas e idiomas unicos siempre van los mismos
--		DECLARE @PAR2 AS VARCHAR(36)	-- IDFkTCodigos -- valor ID, debe ser �nico.
--			-- Caso Alta: valor nuevo se genera con el NewID()
--				-- primero se carga en la tabla GDicTCodigos y 
--				-- luego en la tabla GDicTCodIdiomas.
--			-- Caso Modificaci�n: 
--				-- con este valor ID se buscan los datos, luego si hay diferencias se modifica el valor
--				-- Si la diferencia es en el estado es simple, solo se cambia, IDFkCxIEstados.
--				-- Aclaraciones:
--					-- Las claves ID son la combinacion del IDFkTCodigos, el IDFkTIdioma, el IDFkTCodAmbAplic, y el Codigo, 
--					-- por lo tanto antes de modificar el dato debemos verificar que no se violen alguna de esta claves primarias
--					-- La Descripcion pueden estar repetidas para el mismo ambito
--		DECLARE @PAR3 AS VARCHAR(36)	-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
--			-- Caso Alta: 
--				-- codigo del idioma a donde se asignara el codigo.
--					--						ee954f5d-ca27-48a9-a23b-010788b18631	ITA
--					--						b1268278-4eb3-4a93-8f67-0d425b767c65	ENG
--					--						a455281d-76f5-4bad-8dbb-201c5928aaf8	FRA
--					--						1048c13b-1cc9-4154-8b8b-64ca9ac9fe12	POR
--					--						fb478ecc-85fe-4fc8-b792-caf8ecb921b1	ESP
--		DECLARE @PAR4 AS VARCHAR(250) 	-- Codigo de la combinaci�n Proceso Perfil -- Es el c�digo en letras.
--			-- Caso Alta:
--				-- Es un c�digo real que se visualiza, este c�digo debe ser �nico, para el ID, Idioma y Ambito de aplicaci�n.
--				-- surge de la combinaci�n de los c�digos de los Procesos/TGestion y los Perfiles.
--			-- Caso Modificaci�n:
--				-- Es un c�digo nuevo, ya que este c�digo debe ser �nico, se debe verificar que no haya duplicidad para el ID, Idioma y Ambito de aplicaci�n.
--
--		DECLARE @PAR5 AS VARCHAR(250) 	-- Descripci�n de la combinaci�n Proceso Perfil -- Es la descripci�n del c�digo en letras.
--			-- Caso Alta:
--				-- Es la descripci�n del c�digo real que se visualiza. Este valor debe ser menor de 250 caracteres.
--			-- Caso Modificaci�n:
--				-- Se modifica la descripci�n y no se debe hacer ninguna verificaci�n.
--
--		DECLARE @PAR6 AS VARCHAR(36) 	-- [IDFkTCodEst] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
--			-- Caso Alta:
--				-- Es un c�digo ID con las distintas opciones, estas pueden ser. Habilitado, Deshabilitado, Eliminado.
--					-- 6B0CD910-C127-4450-9865-15E9F4C287B4	EST	estados			EST	estados
--						-- EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0	DES	deshabilitado	EST	estados
--						-- 3749D6D8-EF8F-4C37-893A-BE7209239810	ELI	eliminado		EST	estados
--						-- C6FE2749-0CB8-49CD-97DF-03C299C0C6CF	HAB	habilitado		EST	estados
--			-- Caso Modificaci�n:
--				-- Se cambia el estado sin realizar verificaciones. en caso de que se recupere el c�digo, se debe verificar que no se infrinjan las reglas primarias.
--
--		DECLARE @PAR7 AS VARCHAR(36) 	-- [IDFkCodEmpresas] -- valor ID de la empresa a la que pertenece el Proceso, o la Etapa Motivo, o etc.
--			-- Caso Alta: Lista las empresas disponibles del sistema
--				-- DECLARE	@return_value int
--				-- EXEC @return_value = [dbo].[CDiccPCodxIdio] @PAR2 = 'EDCDB2BA-90EC-466E-B32D-B39F42E96E3F'
--					--	56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981	BPM	Business Process Managment
--					--	A5E49ED6-EFDD-4C43-955F-7F3616E39F99	multiempresa	se aplica para los c�digos generales del sistema
--
--
--		-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--		-- Comienza a cargar la info para las relaciones
--		-- EL [IDFkCDiccTCod_ProcPerf] es el c�digo que se acaba de generar @PAR2 AS VARCHAR(36)	-- IDFkTCodigos -- valor ID, debe ser �nico.
--
--		-- [IDFkCDiccTCod_CodRelac]	-- Tipo de Relaci�n.
--		DECLARE @PAR8 AS VARCHAR(36)	
--			-- CProcTTipoRelacion		-- ID del tipo de relaci�n, esto determina con que tabla se relaciona. 
--					-- Ambito de Aplicaci�n			8AEBC8CD-5F8D-4C53-B3D1-28248D2C15DE	CProcTTipoRelacion	tabla con los tipos de relaciones en
--					--	DECLARE	@return_value int
--					--	EXEC	@return_value = [dbo].[CDiccPCodxIdio]
--					--			@PAR2 = N'8AEBC8CD-5F8D-4C53-B3D1-28248D2C15DE'		--	CProcTTipoRelacion	tabla con los tipos de relaciones entre modulo acceso y modulo procesos
--
--					--	Relaci�n entre los perfiles/AccesoProcesos y los Procesos del Sistema.
--					--	Un perfil debe estar asociado a: (Debe respetar esta jerarqu�a, si no es as�, se debe bloquear el cambio)
--					--		un proceso, 
--					--		un proceso Etapa Motivo, 
--					--		una logica de proceso.
--					--		una evento, etc
--					-- Los c�digos de estas relaciones son:
--							-- Tipo de relaci�n entre el Perfil de Usuario y los Procesos Default que inicia cada usuario
--								--	92CBE163-D12F-4662-B8F0-584174FB2843	PerfProcDefault			perfil proceso default, es el proceso donde inicia el perfil de usuario agrupado
--
--							-- Tipo de relaci�n entre los Tipos de Acceso y los Procesos que puede abrir
--								--	FB516B30-D823-4562-A32E-E45B4018FF72	AccesoProcTProcesos		Relaciona el Acceso a los Procesos y los Procesos.
--								--	53721D2A-6973-42D5-A282-676FB646E343	AccesoTGestEtaMot		Relaciona el Acceso a los Procesos y los Procesos de Gestion Etapas Motivos.
--								--	A7C62E22-B898-40FF-BF30-03FE128B3E03	AccesoProcLogMan		Relaciona el Acceso a los Procesos y Logica Manual.
--								--	D8DEC339-9733-4302-B604-C9B096EBAF40	AccesoProcLogAut		Relaciona el Acceso a los Procesos y la Logica Automatica.
--
--					-- ACLARACION: el Perfil Empresa, ya esta relacionado dentro del M�dulo Acceso
--
--		-- [IDFkCDiccTCod_CodProcTGestLog]	-- ID del c�digo del Proceso de Gestion, PrGeT Procesos, Gestion, LogAut, LogMan, 
--		DECLARE @PAR9 AS VARCHAR(36)				
--	--		DECLARE	@return_value int
--	--		EXEC	@return_value = [dbo].[CDiccPCodxIdio] 
--	--				@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'					-- Idioma elegido o por defecto = espa�ol
--	--				,@PAR2 = NULL	--	'69752B6B-9B31-402B-83DC-4E945DF7879C'		-- Ambito de Aplicaci�n
--	--				,@PAR3 = NULL	--	'56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
--
--			-- esta info esta en las tablas con los ambitos de aplicaci�n que se detallan a continuaci�n.
--				--	92E0AC56-18AC-4FE2-B679-C59CBA5DDC0D	CProcTProcesos	tabla con los c�digos de los procesos
--				--	2F768D8E-7CC2-4350-8F30-04CD25219336	CProcTEtaMot	tabla con los c�digos de Gesti�n Etapa Motivo
--				--	6B68C306-FB5E-49CA-9C17-4D3BD7D7F422	CProcTLogAut	tabla con la logica autom�tica de los procesos.
--				--	F39F73F5-BFB8-411A-AD5A-3787CEDFF515	CProcTLogMan	tabla con la logica de los procesos
--
--
--		-- [IDFkCDiccTCod_CPerfilAccProc]			-- Es el ID del Perfil [CPerfTPerfil] o Acceso a Proceso [CPerfTAccesoProcesos]
--		DECLARE @PAR10 AS VARCHAR(36)				-- 50E6A111-D9BE-4CF7-9115-69A1294EACAB		CPerTPerfiles		tabla perfiles del sistema
--		-- Surge de ejecutar esta consulta
--		-- Ya que esta informaci�n esta en las tabla [CDiccTCodigos] y [CDiccTCodxIdiomas], 
--		-- los ambitos de aplicaci�n que se utilizan son:
--				--	69752B6B-9B31-402B-83DC-4E945DF7879C	CPerfTPerfil			tabla perfiles de usuarios agrupados
--				--	50E6A111-D9BE-4CF7-9115-69A1294EACAB	CPerfTAccesoProcesos	tabla acceso a los procesos del sistema	
--
--				-- Info del Acceso a los Procesos del Sistema
--	--			DECLARE	@return_value int
--	--			EXEC	@return_value = [dbo].[CPerfPAccesoProcesos]			-- Tabla 04 - [CDiccTCodigos] y [CDiccTCodxIdiomas], datos de los Perfiles que tienen las Empresas
--	--						@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	--						,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
--						--	AD07DDA5-0FCD-4AE7-9DFA-DAEC2B3F19E2	AccProcAnonimo	acceso a los procesos del usuario no identificados
--						--	F5897341-D898-4D23-9086-645C079162F5	AccProcAteCliSalon	acceso a los procesos de atenci�n al cliente en el salon de ventas
--						--	8091CCEC-2C14-434D-A989-08927D4F312C	AccProcGral	acceso a los procesos generales del usuario validado.
--						--	B4525BDD-105B-4EAD-AEC5-97DAB144D3FB	AccProcRecepSalon	acceso a los proceso de atenci�n en el salon
--
--
--				-- Info de los Perfiles, para relacionar los submodulos Acceso a los Procesos y Usuario Agrupados
--	--			DECLARE	@return_value int
--	--			EXEC	@return_value = [dbo].[CPerfPPerfil]				-- Tabla 05 - [CDiccTCodigos] y [CDiccTCodxIdiomas], datos de las Agrupaciones de  Perfiles que tienen las Empresas. Se utiliza para vincular las agrupaciones de Usuarios.
--	--						@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	--						,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
--					--	05805405-C736-4FFD-9C3F-92ED912A46F4	PA-Anonimo	perfil anonimo no identificado
--					--	3E922EED-D9A7-4FC7-8450-F543C27F0CE8	PV-Gcia	PostVenta acceso a los accesos gerenciales.
--					--	0F52F251-C0C7-484B-A2A2-2B7AD0DBD434	PV-Gral	PostVenta General.
--
--		DECLARE @PAR11 AS VARCHAR(50)					-- Define si se da el alta completo o parcial (que el codigo esta creado y solo hay que cargar un nuevo idioma).
--
--
--	-- Valores de las variables para generar las prueba del funcionamiento de las consultas.
--	--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	--	-- SETEO DE LAS VARIABLES PARA EL ALTA DE UN CODIGO Y SUS DESCRIPCIONES
--			SET @PAR1 = 'ALTA'													-- ALTA - MODIFICACION - BAJA - RECUPERO
--			SET @PAR2 = NEWID()													-- ID del codigo, debe ser �nico
--			SET @PAR3 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'					-- ID del Idioma	-- Espa�ol		
--	--				ee954f5d-ca27-48a9-a23b-010788b18631	ITA	italiano
--	--				b1268278-4eb3-4a93-8f67-0d425b767c65	ENG	english
--	--				a455281d-76f5-4bad-8dbb-201c5928aaf8	FRA	fran�ais
--	--				1048c13b-1cc9-4154-8b8b-64ca9ac9fe12	POR	portugu�s
--	--				fb478ecc-85fe-4fc8-b792-caf8ecb921b1	ESP	espa�ol
--
--
--			-- Valores se determinan al final de cargar los par�metros
--			-- El @PAR4 y @PAR5, se define de la combinaci�n del C�digo de Proceso y C�digo de Perfil, 
--			-- estas variables se declaran m�s adelante
--
--			-- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
--			SET @PAR6 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'					-- Habilitado
--
--
--	--	<<<<<<<<	CAMBIAR VARIABLE	>>>>>>>>>>>>
--			-- Lista las empresas disponibles del sistema
--			SET @PAR7 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'					-- BPM	Business Process Managment
--				-- DECLARE	@return_value int
--				-- EXEC @return_value = [dbo].[CDiccPCodxIdio] @PAR2 = 'EDCDB2BA-90EC-466E-B32D-B39F42E96E3F'
--					--	'56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'	BPM	Business Process Managment
--					--	'A5E49ED6-EFDD-4C43-955F-7F3616E39F99'	multiempresa	se aplica para los c�digos generales del sistema
--
--			-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--			-- Comienza a cargar la info para las relaciones, lo primero que se define es el tipo de relaci�n entre el Modulo de Acceso y Modulo Procesos
--			-- con que tabla sera la relaci�n del perfil (TProcesos, TGestion, TLogAut, TLogMan, etc).
--
--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	-- IMPORTANTE !!!!!	-- Se debe asegurar la coherencia entre: [IDFkCDiccTCod_CodRelac], el [IDFkCDiccTCod_CodProcTGestLog] y el [IDFkCDiccTCod_CPerfilAccProc]
--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--			-- [IDFkCDiccTCod_CodRelac]		-- ID del tipo de relaci�n, esto determina con que tabla se relaciona. 
--			SET @PAR8 = '53721D2A-6973-42D5-A282-676FB646E343'	--	AccesoTGestEtaMot			perfil proceso default, es el proceso donde inicia el perfil de usuario agrupado
--				-- CProcTTipoRelacion		-- ID del tipo de relaci�n, esto determina con que tabla se relaciona. 
--					-- Ambito de Aplicaci�n			8AEBC8CD-5F8D-4C53-B3D1-28248D2C15DE	CProcTTipoRelacion	tabla con los tipos de relaciones en
--					--	DECLARE	@return_value int
--					--	EXEC	@return_value = [dbo].[CDiccPCodxIdio]
--					--			@PAR2 = N'8AEBC8CD-5F8D-4C53-B3D1-28248D2C15DE'		--	CProcTTipoRelacion	tabla con los tipos de relaciones entre modulo acceso y modulo procesos
--					-- Los c�digos de estas relaciones son:
--							-- Tipo de relaci�n entre el Perfil de Usuario y los Procesos Default que inicia cada usuario
--								--	'92CBE163-D12F-4662-B8F0-584174FB2843'	--	PerfProcDefault			perfil proceso default, es el proceso donde inicia el perfil de usuario agrupado
--
--							-- Tipo de relaci�n entre los Tipos de Acceso y los Procesos que puede abrir
--								--	'FB516B30-D823-4562-A32E-E45B4018FF72'	--	AccesoProcTProcesos		Relaciona el Acceso a los Procesos y los Procesos.
--								--	'53721D2A-6973-42D5-A282-676FB646E343'	--	AccesoTGestEtaMot		Relaciona el Acceso a los Procesos y los Procesos de Gestion Etapas Motivos.
--								--	'A7C62E22-B898-40FF-BF30-03FE128B3E03'	--	AccesoProcLogMan		Relaciona el Acceso a los Procesos y Logica Manual.
--								--	'D8DEC339-9733-4302-B604-C9B096EBAF40'	--	AccesoProcLogAut		Relaciona el Acceso a los Procesos y la Logica Automatica.
--
--					-- ACLARACION: el Perfil Empresa, ya esta relacionado dentro del M�dulo Acceso
--
--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	-- IMPORTANTE !!!!!	-- Se debe asegurar la coherencia entre: [IDFkCDiccTCod_CodRelac], el [IDFkCDiccTCod_CodProcTGestLog] y el [IDFkCDiccTCod_CPerfilAccProc]
--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--			-- [IDFkCDiccTCod_CodProcTGestLog]		-- ID del c�digo del Proceso de Gestion, PrGeT Procesos, Gestion, LogAut, LogMan, esta info esta en las tablas con los ambitos de aplicaci�n que se detallan a continuaci�n.
--			SET @PAR9 = 'B2B4FFA6-A79A-4847-BA19-0036BFD4FF9D'	-- TG-IngPte			Usuario pendiente de ingreso y no esta identificado
--				-- ID del c�digo del Proceso de Gestion, PrGeT Procesos, Gestion, LogAut, LogMan, 
--				-- esta info esta en las tablas con los ambitos de aplicaci�n que se detallan a continuaci�n.
--				-- Procesos del Sistema, este surge de los siguientes procesos almacenados
--	--					DECLARE	@return_value int
--	--					DECLARE @Idi AS NVARCHAR(36)
--	--					DECLARE @Emp AS NVARCHAR(36)
--	--					SET @Idi = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'			-- Idioma elegido o por defecto = espa�ol
--	--					SET @Emp = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'			-- BPM	Business Process Managment
--	--					-- Procesos	[CDiccTCodigos] y [CDiccTCodxIdiomas]
--	--					EXEC @return_value = [dbo].[CPrGePProcesos] @PAR1 = @Idi, @PAR2 = @Emp
--	--
--	--					-- TGestion (combinaci�n de las Etapas y Motivos) [CPrGeTGestion]
--	--					EXEC @return_value = [dbo].[CPrGePGestion] @PAR1 = @Idi, @PAR2 = @Emp
--	--						 ,@PAR3 = 'EC3887CE-C7C1-4C53-A96D-621BD28A715D'	-- Proceso
--
--					-- Pagina Inicial Usuario An�nimo
--						--	'EC3887CE-C7C1-4C53-A96D-621BD28A715D'		--	PagIniUA	p�gina inicial del usurio an�nimo
--							--	'E2C1F05E-5169-41FB-8CCC-B7ACB76293E3'	--	TG-PagVis	visualiza la p�gina definida
--
--					--	L�gica Autom�tica del Proceso de Gesti�n [CPrGeTLogAut]
--						--	'79B264F7-05BA-46AE-B56F-3FAAD6F64861'	-- Login				Proceso para ingresar al sistema.	B2B4FFA6-A79A-4847-BA19-0036BFD4FF9D	TG-IngPte	Usuario pendiente de ingreso y no esta identificado
--						--	'B2B4FFA6-A79A-4847-BA19-0036BFD4FF9D'	-- TG-IngPte			Usuario pendiente de ingreso y no esta identificado
--						--	'4A283628-5D5E-45B6-BFFE-80591E5D3149'	-- TG-IngPte/UsuIne		Usuario inexistente.
--						--	'F65785C5-47FB-458F-A070-C0F4A25C8E83'	-- TG-UsuPte			Usuario identificado, pendiente de ingreso.
--						--	'1C8A1E56-A080-4187-AA3A-0208B8B58D80'	-- TG-UsuPte/UsuErr		Usuario identificado, tuvo error de logueo.
--						--	'1255E790-EBBE-4D64-AA1B-3AE776E71B4A'	-- TG-UsuBlo			Usuario bloqueado.
--						--	'83605861-8DFA-4FAB-87D3-22181A759D60'	-- TG-UsuIng			Usuario ingres�.
--
--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	-- IMPORTANTE !!!!!	-- Se debe asegurar la coherencia entre: [IDFkCDiccTCod_CodRelac], el [IDFkCDiccTCod_CodProcTGestLog] y el [IDFkCDiccTCod_CPerfilAccProc]
--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--			-- [IDFkCDiccTCod_CPerfilAccProc]		-- Es el ID del Perfil [CPerfTPerfil] o Acceso a Proceso [CPerfTAccesoProcesos]
--			SET @PAR10 = 'AD07DDA5-0FCD-4AE7-9DFA-DAEC2B3F19E2'	--	AccProcAnonimo
--
--				-- Surge de ejecutar esta consulta
--				-- Ya que esta informaci�n esta en las tabla [CDiccTCodigos] y [CDiccTCodxIdiomas], 
--				-- los ambitos de aplicaci�n que se utilizan son:
--						--	69752B6B-9B31-402B-83DC-4E945DF7879C	CPerfTPerfil			tabla perfiles de usuarios agrupados
--						--	50E6A111-D9BE-4CF7-9115-69A1294EACAB	CPerfTAccesoProcesos	tabla acceso a los procesos del sistema	
--
--						-- Info del Acceso a los Procesos del Sistema
--			--			DECLARE	@return_value int
--			--			EXEC	@return_value = [dbo].[CPerfPAccesoProcesos]			-- Tabla 04 - [CDiccTCodigos] y [CDiccTCodxIdiomas], datos de los Perfiles que tienen las Empresas
--			--						@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--			--						,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
--								--	'AD07DDA5-0FCD-4AE7-9DFA-DAEC2B3F19E2'	--	AccProcAnonimo			acceso a los procesos del usuario no identificados
--								--	'F5897341-D898-4D23-9086-645C079162F5'	--	AccProcAteCliSalon		acceso a los procesos de atenci�n al cliente en el salon de ventas
--								--	'8091CCEC-2C14-434D-A989-08927D4F312C'	--	AccProcGral				acceso a los procesos generales del usuario validado.
--								--	'B4525BDD-105B-4EAD-AEC5-97DAB144D3FB'	--	AccProcRecepSalon		acceso a los proceso de atenci�n en el salon
--
--
--						-- Info de los Perfiles, para relacionar los submodulos Acceso a los Procesos y Usuario Agrupados
--			--			DECLARE	@return_value int
--			--			EXEC	@return_value = [dbo].[CPerfPPerfil]				-- Tabla 05 - [CDiccTCodigos] y [CDiccTCodxIdiomas], datos de las Agrupaciones de  Perfiles que tienen las Empresas. Se utiliza para vincular las agrupaciones de Usuarios.
--			--						@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--			--						,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
--							--	'05805405-C736-4FFD-9C3F-92ED912A46F4'	--	PA-Anonimo	perfil anonimo no identificado
--							--	'3E922EED-D9A7-4FC7-8450-F543C27F0CE8'	--	PV-Gcia	PostVenta acceso a los accesos gerenciales.
--							--	'0F52F251-C0C7-484B-A2A2-2B7AD0DBD434'	--	PV-Gral	PostVenta General.
--
--			-- Codigo del Proceso Perfil	-- C�digo en letras del ID
--			SET @PAR4 = 'AP - PerfAno/TG-IngPte'		-- Este c�digo surge de la combinaci�n del C�digo de Proceso y C�digo de Perfil
--
--			-- Descripci�n del Proceso Perfil -- Es la descripci�n del c�digo en letras.
--			SET @PAR5 = 'acceso procesos del perfil an�nimo al inicio del proceso de login'
--
--			-- Define si se da el alta completo o parcial (que el codigo esta creado y solo hay que cargar un nuevo idioma).
--			SET @PAR11 = 'AltaCompleto'


		-- Aqu� busca para cargar siempre el Proceso due�o de la TGestion y TLogAut y TLogMan
		-- Proceso para la relaci�n PP PerfProc
		SET @ProcID = CASE WHEN @PAR8 = 'FB516B30-D823-4562-A32E-E45B4018FF72' THEN @PAR9 ELSE NULL END
		-- Proceso para la relaci�n AccesoTGestEtaMot
			-- Consulta donde obtiene el proceso de la TGestion (EtapaMotivo)
			DECLARE @Pr AS NVARCHAR(36)
			SET @Pr = (SELECT TOP 1 [IDFkTCodProc] FROM [BDCtral].[dbo].[CPrGeTGestion] WHERE [IDFKTCodEtaMot] = @PAR9)
			SET @ProcID = CASE WHEN @ProcID IS NULL THEN  @Pr
--								CASE WHEN @PAR8 = '53721D2A-6973-42D5-A282-676FB646E343'  
--									THEN @Pr
--								ELSE NULL END
							ELSE @ProcID END

--		SELECT -- Tabla [CDiccTCodigos] y [CDiccTCodxIdiomas]
--				@PAR1 AS 'P01_Acc', @PAR2 AS 'P02_IDFkTCodigos', @PAR3 AS 'P03_IDFkTIdioma', @PARInt1 AS 'P04_IDFkTCodAmbAplic'
--				, @PAR4 AS 'P05_ProcPerfilCod', @PAR5 AS 'P06_ProcPerfilCodDesc'
--				, @PAR6 AS 'P07_IDFkTCodEst', @PAR7 AS 'P08_IDFkCodEmpresas'
--				-- Tabla [CPrGeTProcPerf]
--				, @PAR8 AS 'P09_IDFkCDiccTCod_CodRelac'
--				, @PAR9 AS 'P10_IDFkCDiccTCod_CodProcTGestLog'
--				, @PAR10 AS 'P11_IDFkCDiccTCod_CPerfil', @PAR11 AS 'P12_TipoAlta'
--				, @ProcID AS 'Proceso'


	-- La validaci�n deber�a hacer una consulta y verificar si ese perfil tiene la estructura anterior de Empresa, Proceso, TGestion, TLogAut y TLosMan
	-- si no es as� pone a null la variable y da msg de error
	-- La Empresa tiene habilitado el perfil?
	-- El Procesos tiene habilitado el perfil?


-- Pasos antes de hacer ABM de los datos:
	-- Etapa 1: Primero verificar que con el cambio no se infrinja ninguna clave primaria
	-- Etapa 2: 
			-- 1: Si el resultado es que se infrinje, no realizar el cambio e informar al usuario
			-- 2: Si es todo OK, se realiza el cambio. Para hacer esto se hace una transacci�n para asegurar la integridad del cambio.	

	IF @PAR1 = 'ALTA'
	BEGIN
		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		-- ##############################################################################################################################################
		-- INICIO -- ALTA DE CODIGO Y SUS DESCRIPCIONES
		-- ##############################################################################################################################################
		
		SET @FUNC_PROCALM = 'Alta'		-- Funcion dentro del procedimiento almacenado.

		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		-- Para agregar un nuevo C�digo, se debe:
			-- Clave Primaria: IDC�digo [IDFkTCodigos], IDIdiomas [IDFkTIdioma], IDAmbitoAplicaci�n [IDFkTCodAmbAplic], C�digo Unico [Codigo]
			-- Los otros campos pueden tener cualquier valor, no se validan.

			-- Aclaraci�n: La combinaci�n m�s ID del Ambito de Aplicaci�n, por lo tanto para un idioma, puede haber dos c�digos iguales, pero cada uno para un ambito de aplicaci�n diferente.

		-- Etapa 1: Verifica Clave Primaria: que el codigo que se quiere agregar ya no este creado, para ese idioma y �mbito de aplicaci�n.
			-- Si alguno de los valores son encontrados, la variable @PAR2 se pone a NULL
			SELECT @PAR2 = NULL
			  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH(NOLOCK)
			WHERE [IDFkTIdioma] = @PAR3 AND [IDFkTCodAmbAplic] = @PARInt1 AND [Codigo] = @PAR4
				-- Clave Primaria: Idioma, AmbitoAplicaci�n, C�digo.
			--		SELECT @PAR2

		-- Etapa 2: 
				-- 1: Si el C�digo infringe la clave primaria, no hace el cambio e informa al usuario
			IF @PAR2 IS NULL
				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
				BEGIN
					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
					SET @RTADO = 'ERR' 
					SET @REG_AFEC = 0
					SET @ERR_MESSAGE = 'El c�digo ingresado ya esta utilizado para ese idioma y �mbito de aplicaci�n.'
					SET @ERR_NUMBER = 0
					SET @ERR_SEVERITY = 0
					SET @ERR_STATE = 0
					SET @ERR_LINE = 0
				END
			ELSE
				-- 2: Si es todo OK, se realiza el cambio.
				BEGIN TRY
				BEGIN TRANSACTION;
				-- Inserta el codigo en las tablas. 
					
					IF @PAR11 = 'AltaCompleto' 
						-- PRIMERO en la tabla [CDiccTCodigos]
						BEGIN
								INSERT INTO [BDCtral].[dbo].[CDiccTCodigos]
										   ([ID]
										   ,[IDFkCodEmpresas]
										   ,[IDFkCodEstados]
										   ,[TCodigosFechaModif])
								 SELECT @PAR2		-- ID del codigo, debe ser �nico
										,@PAR7		-- ID de la empresa a la que se le asigna el proceso
										,@PAR6		-- ID del estado del c�digo.
										,GETDATE()	-- Fecha y Hora del Cambio.
							GOTO ContinuaAlta
						END
					ELSE				
	ContinuaAlta:
						-- SEGUNDO en la tabla [CDiccTCodxIdiomas]
						BEGIN
							INSERT INTO [BDCtral].[dbo].[CDiccTCodxIdiomas]
									   ([IDFkTCodigos]
									   ,[IDFkTIdioma]
									   ,[IDFkTCodAmbAplic]
									   ,[Codigo]
									   ,[Descripcion]
									   ,[IDFkCxIEstados]
									   ,[TCodxIdioFechaModif])
								 SELECT @PAR2		-- ID del codigo, debe ser �nico
										,@PAR3		-- ID del Idioma
										,@PARInt1		-- ID del Ambito de Aplicaci�n del C�digo
										,@PAR4		-- C�digo, debe ser �nico
										,@PAR5		-- Descripcion del codigo
										,@PAR6		-- ID del estado del c�digo.
										,GETDATE()	-- Fecha de carga

							-- TERCERO debe cargar la tabla [CPrGeTProcPerf]
								INSERT INTO [BDCtral].[dbo].[CPrGeTProcPerf]
										   ([IDFkCDiccTCod_ProcPerf]
										   ,[IDFkCDiccTCod_Empresa]
										   ,[IDFkCDiccTCod_CodProc]
										   ,[IDFkCDiccTCod_CodProcTGestLog]
										   ,[IDFkCDiccTCod_CPerfilAccProc]
										   ,[IDFkCDiccTCod_CodRelac]
										   ,[IDFkCDiccTCod_CodEst]
										   ,[TProcPerfFecha])
								 SELECT @PAR2		-- [IDFkCDiccTCod_ProcPerf]			-- IDFkTCodigos -- valor ID, debe ser �nico.
										,@PAR7		-- [IDFkCDiccTCod_Empresa]			-- ID de la empresa a la que se le asigna el proceso
										,@ProcID	-- [IDFkCDiccTCod_CodProc]			-- ID del Proceso afectado
										,@PAR9		-- [IDFkCDiccTCod_CodProcTGestLog]			-- ID del c�digo del Proceso de Gestion, PrGeT Procesos, Gestion, LogAut, LogMan,
										,@PAR10		-- [IDFkCDiccTCod_CPerfilAccProc]			-- Es el ID del perfil que tiene el Usuario, por defecto tiene PerfInic
										,@PAR8		-- [IDFkCDiccTCod_CodRelac]			-- ID del tipo de relaci�n, esto determina con que tabla se relaciona.
										,@PAR6		-- [IDFkCDiccTCod_CodEst]			-- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
										,GETDATE()
						END

					-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
					BEGIN
						-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
						SET @RTADO = 'OK' 
						SET @REG_AFEC = 1
						SET @ERR_MESSAGE = 'Se cargo la informacion solicitada.'
						SET @ERR_NUMBER = 0
						SET @ERR_SEVERITY = 0
						SET @ERR_STATE = 0
						SET @ERR_LINE = 0
					END
				
					-- Si el procedimiento es exitoso, confirma la operaci�n.
					COMMIT TRANSACTION;
				END TRY
				-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
				BEGIN CATCH

					-- Ejecuta el Procedimiento Almacenado para obtener el error.
					EXECUTE [dbo].[CGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT

					-- Como la operaci�n fall�, se deshacen las modificaciones.
					ROLLBACK TRANSACTION;

					-- Por las dudas se elimana el registro con el ID generado.
					DELETE FROM [BDCtral].[dbo].[CDiccTCodigos] WHERE [ID] = @PAR2
					DELETE FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] WHERE [IDFkTCodigos] = @PAR2
					DELETE FROM [BDCtral].[dbo].[CPrGeTGestion] WHERE [IDFKTCodEtaMot] = @PAR2 AND [IDFkTCodProc] = @PAR8 AND [IDFkTCodEtapa] = @PAR10 AND [IDFkTCodMotivo] = @PAR11

					-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
					SET @RTADO = 'ERR'
					SET @REG_AFEC = 0
				END CATCH;

		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		-- ##############################################################################################################################################
		-- FINAL -- ALTA DE CODIGO Y SUS DESCRIPCIONES
		-- ##############################################################################################################################################
		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	END

END

---- ##############################################################################################################################################
---- MUESTRA EL RESULTADO DEL PROCEDIMIENTO ALMACENADO
---- Envia el resultado: Nombre Proc Alm | Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
----SET @RTADO_PROCALM = @NOMB_PROCALM + '|' + @FUNC_PROCALM + '|' + @RTADO + '|' + CAST(@REG_AFEC AS VARCHAR(10)) + '|' + @ERR_MESSAGE + '|' + CAST(@ERR_NUMBER AS VARCHAR(10)) + '|' + CAST(@ERR_SEVERITY AS VARCHAR(10)) + '|' + CAST(@ERR_STATE AS VARCHAR(10)) + '|' + CAST(@ERR_LINE AS VARCHAR(10))
----SELECT @RTADO_PROCALM			-- Muestra el resulado en una unica columna
--SELECT @NOMB_PROCALM AS ProcAlm_Nomb, @FUNC_PROCALM AS ProcAlm_Funcion, @RTADO AS ProcAlm_Rtado, @REG_AFEC AS ProcAlm_RegAfec, @ERR_MESSAGE AS ProcAlm_Mensaje, @ERR_NUMBER AS ProcAlm_ErrNum, @ERR_SEVERITY AS ProcAlm_ErrSeveridad, @ERR_STATE AS ProcAlm_ErrEstado, @ERR_LINE AS ProcAlm_ErrLinea
