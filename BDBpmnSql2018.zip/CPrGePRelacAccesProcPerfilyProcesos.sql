set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

USE [BDCtral]
GO

-- ====================================================
-- Author:		Juan Carlos Petri
-- Create date: 30/09/2018
-- Description:	Detalle de los Procesos y sus Perfiles
-- ====================================================

ALTER PROCEDURE [dbo].[CPrGePProcPerf]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(36) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 NVARCHAR(36) = NULL		-- Empresa
	,@PAR3 NVARCHAR(36) = NULL		-- Perfil
	,@PAR4 NVARCHAR(36) = NULL		-- CodProcTGestLog
	,@PAR5 NVARCHAR(36) = NULL		-- ID del Tipo de Relaci�n

AS
BEGIN

--	DECLARE @PAR1 NVARCHAR(36)	-- Idioma elegido o por defecto = espa�ol
--	DECLARE @PAR2 NVARCHAR(36)	-- Empresa
--	DECLARE @PAR3 NVARCHAR(36)	-- Perfil
--	DECLARE @PAR4 NVARCHAR(36)	-- CodProcTGestLog
--	DECLARE @PAR5 NVARCHAR(36)	-- ID del Tipo de Relaci�n
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR2 = NULL	-- '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
--	SET @PAR3 = 'AD07DDA5-0FCD-4AE7-9DFA-DAEC2B3F19E2'		-- PerfAnonimo	perfil anonimo para usuarios no identificados
--				--	'F5897341-D898-4D23-9086-645C079162F5'		-- PerfInic		Perfil de inicio, tiene acceso a las funciones basicas sin necesidad de validar el usuario.
--	SET @PAR4 = NULL	--	'E2C1F05E-5169-41FB-8CCC-B7ACB76293E3'			-- TG-PagVis	visualiza la p�gina definida 
--	SET @PAR5 = NULL	--	'53721D2A-6973-42D5-A282-676FB646E343'	--	AccesoTGestEtaMot

	DECLARE @TmpTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)

	-- Inserta en la tabla temporal la informaci�n de los c�digos seg�n el idioma elegido
	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1


--	SELECT * FROM @TmpTCodxIdi

	-- Muestra la logica de los Procesos de Gestion
		SELECT PP.[IDFkCDiccTCod_ProcPerf]
					,CxI2.[Codigo] AS [ProcPerfCod]
					,CxI2.[Descripcion] AS [ProcPerDesc]
				,PP.[IDFkCDiccTCod_CodRelac]
					,CxI1.[Codigo] AS [RelaCod]
					,CxI1.[Descripcion] AS [RelaDesc]
				,PP.[IDFkCDiccTCod_Empresa]
					,CxI7.[Codigo] AS [EmpCod]
					,CxI7.[Descripcion] AS [EmpDesc]
				,PP.[IDFkCDiccTCod_CodProc]
					,CxI8.[Codigo] AS [ProcCod]
					,CxI8.[Descripcion] AS [ProcDesc]
				,PP.[IDFkCDiccTCod_CodProcTGestLog] AS [CodProcTGestLog]
					,CxI3.[Codigo] AS [CodProcTGestLogCod]
					,CxI3.[Descripcion] AS [CodProcTGestLogDesc]
				,PP.[IDFkCDiccTCod_CPerfilAccProc]
					,CxI5.[Codigo] AS [PerfCod]
					,CxI5.[Descripcion] AS [PerfDesc]
				,PP.[IDFkCDiccTCod_CodEst]
					,CxI6.[Codigo] AS [ProcPerfEstCod]
					,CxI6.[Descripcion] AS [ProcPerfEstDesc]
				,PP.[TProcPerfFecha]
		  FROM [BDCtral].[dbo].[CPrGeTProcPerf] AS PP WITH(NOLOCK) 
				LEFT OUTER JOIN @TmpTCodxIdi AS CxI1			-- Tabla asociada, Tipo de Relaci�n entre los Proceso y los Perfiles.
					ON PP.[IDFkCDiccTCod_CodRelac] = CxI1.[IDFkTCodigos]
				LEFT OUTER JOIN @TmpTCodxIdi AS CxI2			-- C�digo de Proceso Perfil
					ON PP.[IDFkCDiccTCod_ProcPerf] = CxI2.[IDFkTCodigos]
				LEFT OUTER JOIN @TmpTCodxIdi AS CxI8			-- C�digo de Proceso Perfil
					ON PP.[IDFkCDiccTCod_CodProc] = CxI8.[IDFkTCodigos]
				LEFT OUTER JOIN @TmpTCodxIdi AS CxI3			-- C�digo del Proceso, TGesti�n, etc.
					ON PP.[IDFkCDiccTCod_CodProcTGestLog] = CxI3.[IDFkTCodigos]
				LEFT OUTER JOIN @TmpTCodxIdi AS CxI5			-- C�digo de Perfil
					ON PP.[IDFkCDiccTCod_CPerfilAccProc] = CxI5.[IDFkTCodigos]
				LEFT OUTER JOIN @TmpTCodxIdi AS CxI6			-- C�digo de Estado
					ON PP.[IDFkCDiccTCod_CodEst] = CxI6.[IDFkTCodigos]
				LEFT OUTER JOIN @TmpTCodxIdi AS CxI7			-- C�digo de la Empresa
					ON PP.[IDFkCDiccTCod_Empresa] = CxI7.[IDFkTCodigos]
		WHERE PP.[IDFkCDiccTCod_Empresa] = CASE WHEN @PAR2 IS NULL THEN PP.[IDFkCDiccTCod_Empresa] ELSE @PAR2 END
			AND PP.[IDFkCDiccTCod_CPerfilAccProc] = CASE WHEN @PAR3 IS NULL THEN PP.[IDFkCDiccTCod_CPerfilAccProc] ELSE @PAR3 END
			AND PP.[IDFkCDiccTCod_CodProcTGestLog] = CASE WHEN @PAR4 IS NULL THEN PP.[IDFkCDiccTCod_CodProcTGestLog] ELSE @PAR4 END
			AND PP.[IDFkCDiccTCod_CodRelac] = CASE WHEN @PAR5 IS NULL THEN PP.[IDFkCDiccTCod_CodRelac] ELSE @PAR5 END

END

---- Detalle los Procesos y sus Perfiles
--DECLARE	@return_value int
--EXEC @return_value = [dbo].[CPrGePProcPerf] 
--		@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--		,@PAR2 = NULL	-- '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
--		, @PAR3 = NULL
--				--	'AD07DDA5-0FCD-4AE7-9DFA-DAEC2B3F19E2'		-- PerfAnonimo	perfil anonimo para usuarios no identificados
--				--	'F5897341-D898-4D23-9086-645C079162F5'		-- PerfInic		Perfil de inicio, tiene acceso a las funciones basicas sin necesidad de validar el usuario.
--		, @PAR4 = NULL	--	'e2c1f05e-5169-41fb-8ccc-b7acb76293e3'	--	TG-PagVis	visualiza la p�gina definida
