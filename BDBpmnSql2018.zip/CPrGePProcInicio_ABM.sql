-- ###############################################################################################################################3
--  GENERA LOS PROCEDIMIENTOS ALMACENADOS PARA HACER EL ALTA, MODIFICACION, BAJA O RECUPERO DEL INICIO DE LOS PROCESOS -- 
-- ###############################################################################################################################3

-- Los pasos para dar de alta un nuevo proceso son:
--	1.- Primero se ejecuta la consulta con los procesos disponibles y sus Etapas y Motivos
--	2.- Luego se carga la informaci�n del Proceso y Su EtapaMotivo


-- Define que se trabaja con al Base de Datos
USE [BDCtral]
GO

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Variables para realizar al ABM, se debe:
	-- Variables Etapa 1
	DECLARE @PAR1 AS VARCHAR(50)	-- Determina acci�na realizar 
					-- valores posibles: ALTA - MODIFICACION - BAJA - RECUPERO
					-- Como estos valores son para todas las tablas e idiomas unicos siempre van los mismos
	DECLARE @PAR2 AS VARCHAR(50)	-- [IDFkGDicTCodProc] Proceso -- ID, debe ser �nico.
	DECLARE @PAR3 AS VARCHAR(50)	-- [IDFKTCodEtaMotInicio] -- TGestion -- Etapa Motivo
	DECLARE @PAR4 AS VARCHAR(36) 	-- [IDFkGDicTCodEst] ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
		-- Caso Alta:
			-- Es un c�digo ID con las distintas opciones, estas pueden ser. Habilitado, Deshabilitado.
				-- 6B0CD910-C127-4450-9865-15E9F4C287B4	EST	estados			EST	estados	Ambito de Aplicacion
					-- EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0	DES	deshabilitado	EST	estados
					-- C6FE2749-0CB8-49CD-97DF-03C299C0C6CF	HAB	habilitado		EST	estados
				-- No se puede eliminar ya que habria que eliminar todas las relaciones de las tablas.
		-- Caso Modificaci�n:
			-- Se cambia el estado sin realizar verificaciones. en caso de que se recupere el c�digo, se debe verificar que no se infrinjan las reglas primarias.
	
	-- Variables internas del procedimiento almacenado	
		DECLARE @RTADOCLAVEID AS VARCHAR(36)

	-- Variables para obtener los valores del procedimiento almacenado de CGetErrorInfo
		DECLARE @RTADO_PROCALM AS VARCHAR(250)
		DECLARE @NOMB_PROCALM AS VARCHAR(250)
		DECLARE @FUNC_PROCALM AS VARCHAR(100)
		DECLARE @RTADO AS VARCHAR(250)
		DECLARE @REG_AFEC AS NUMERIC(18, 0)
		DECLARE @ERR_MESSAGE AS VARCHAR(250)
		DECLARE @ERR_NUMBER AS NUMERIC(18, 0)
		DECLARE @ERR_SEVERITY AS NUMERIC(18, 0)
		DECLARE @ERR_STATE AS NUMERIC(18, 0)
		DECLARE @ERR_LINE AS NUMERIC(18, 0)
		
		SET @NOMB_PROCALM = 'CPrGePProcInicioBM'				-- Nombre del procedimiento almacenado.

-- Valores de las variables para generar las prueba del funcionamiento de las consultas.
--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	-- SETEO DE LAS VARIABLES PARA EL ALTA DE UN CODIGO Y SUS DESCRIPCIONES

	-- Determinacion de los Procesos y su TGestion (EtapayMotivo)
	--	DECLARE	@return_value int
	--	DECLARE @Idio AS NVARCHAR(36)
	--	DECLARE @Emp AS NVARCHAR(36)
	--	SET @Idio = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'			-- Idioma elegido o por defecto = espa�ol
	--	SET @Emp = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'			-- BPM	Business Process Managment
	--
	--	EXEC @return_value = [dbo].[CPrGePProcesos] 
	--			@PAR1 = @Idio			-- Idioma elegido o por defecto = espa�ol
	--			,@PAR2 = @Emp			-- BPM	Business Process Managment
	--
	--	DECLARE @Proc AS NVARCHAR(36)
	--	SET @Proc = 'EC3887CE-C7C1-4C53-A96D-621BD28A715D'
	--
	--		EXEC @return_value = [dbo].[CPrGePGestion] 
	--			@PAR1 = @Idio		-- Idioma elegido o por defecto = espa�ol
	--			,@PAR2 = @Emp		-- Empresa	BPM	Business Process Managment
	--			,@PAR3 = @Proc		-- Proceso

		-- Con la informaci�n de las consultas anteriores carga los datos
		SET @PAR1 = 'ALTA'													-- Accion a realizar
		SET @PAR2 = 'EC3887CE-C7C1-4C53-A96D-621BD28A715D'					-- ID del proceso, debe ser �nico
		SET @PAR3 = 'E2C1F05E-5169-41FB-8CCC-B7ACB76293E3'					-- ID del PGestion EtapaMotivo
		SET @PAR4 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'					-- Estado Habilitado
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- Pasos antes de hacer ABM de los datos:
	-- Etapa 1: Primero verificar que con el cambio no se infrinja ninguna clave primaria, que el proceso no este ya dado de alta.
	-- Etapa 2: 
			-- 1: Si el resultado es que se infrinje, no realizar el cambio e informar al usuario
			-- 2: Si es todo OK, se realiza el cambio. Para hacer esto se hace una transacci�n para asegurar la integridad del cambio.	

IF @PAR1 = 'ALTA'
BEGIN
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- ##############################################################################################################################################
	-- INICIO -- ALTA DE LOS PROCESOS
	-- ##############################################################################################################################################
	
	SET @FUNC_PROCALM = 'Alta'		-- Funcion dentro del procedimiento almacenado.

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Para agregar un nuevo C�digo, se debe:
		-- Clave Primaria: verificar que no se infrinja la Clave Primaria (duplicidad).

	-- Etapa 1: Verifica Clave Primaria: que el codigo que se quiere agregar ya no este creado, para ese idioma y �mbito de aplicaci�n.
		-- Si el Proceso es encontrado, la variable @RTADOCLAVEID se pone a TRUE.
		SET @RTADOCLAVEID = 'FALSE'
		SELECT @RTADOCLAVEID = 'TRUE'
		  FROM [BDCtral].[dbo].[CPrGeTProcInicio] AS CPi WITH(NOLOCK)
		WHERE [IDFkGDicTCodProc] = @PAR2
				AND [IDFKTCodEtaMotInicio] = @PAR3
		-- Clave Primaria: IDFkGDicTCodProc Y IDFKTCodEtaMotInicio
		--		SELECT @PAR2 AS 'P02_Proc', @PAR3 AS 'P03_TGestion', @RTADOCLAVEID AS 'RTADOCLAVEID'

	-- Etapa 2: 
			-- 1: Si el C�digo infringe la clave primaria, no hace el cambio e informa al usuario
		IF @RTADOCLAVEID = 'TRUE'
			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			BEGIN
				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
				SET @RTADO = 'ERR' 
				SET @REG_AFEC = 0
				SET @ERR_MESSAGE = 'El proceso ya esta ingresado.'
				SET @ERR_NUMBER = 0
				SET @ERR_SEVERITY = 0
				SET @ERR_STATE = 0
				SET @ERR_LINE = 0
			END
		ELSE
			-- 2: Si es todo OK, se realiza el cambio.
			BEGIN TRY
			BEGIN TRANSACTION;
			-- Inserta el codigo en las tablas. 
				-- Consulta para ingresar el valor
					BEGIN
						INSERT INTO [BDCtral].[dbo].[CPrGeTProcInicio]
								   ([IDFkGDicTCodProc]
								   ,[IDFKTCodEtaMotInicio]
								   ,[IDFkGDicTCodEst]
								   ,[TProcesosFechaModif])
							 SELECT @PAR2		-- ID del proceso, debe ser �nico
									,@PAR3		-- ID del PGestion, Etapa Motivo
									,@PAR4		-- ID del estado del proceso.
									,GETDATE()		-- Momento del cambio.
					END
				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
				BEGIN
					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
					SET @RTADO = 'OK' 
					SET @REG_AFEC = 1
					SET @ERR_MESSAGE = 'Se cargo el proceso exitosamente.'
					SET @ERR_NUMBER = 0
					SET @ERR_SEVERITY = 0
					SET @ERR_STATE = 0
					SET @ERR_LINE = 0
				END
			
				-- Si el procedimiento es exitoso, confirma la operaci�n.
				COMMIT TRANSACTION;
			END TRY
			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
			BEGIN CATCH

				-- Ejecuta el Procedimiento Almacenado para obtener el error.
				EXECUTE [dbo].[CGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT

				-- Como la operaci�n fall�, se deshacen las modificaciones.
				ROLLBACK TRANSACTION;

				-- Por las dudas se elimana el registro con el ID generado.
				DELETE FROM [BDCtral].[dbo].[CPrGeTProcesos] WHERE [IDFkGDicTCodProc] = @PAR3		-- Se cambia la consulta
				
				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				SET @RTADO = 'ERR'
				SET @REG_AFEC = 0
			END CATCH;

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- ##############################################################################################################################################
	-- FINAL -- ALTA DE LOS PROCESOS
	-- ##############################################################################################################################################
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
END

-- ##############################################################################################################################################
-- MUESTRA EL RESULTADO DEL PROCEDIMIENTO ALMACENADO
-- Envia el resultado: Nombre Proc Alm | Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
--SET @RTADO_PROCALM = @NOMB_PROCALM + '|' + @FUNC_PROCALM + '|' + @RTADO + '|' + CAST(@REG_AFEC AS VARCHAR(10)) + '|' + @ERR_MESSAGE + '|' + CAST(@ERR_NUMBER AS VARCHAR(10)) + '|' + CAST(@ERR_SEVERITY AS VARCHAR(10)) + '|' + CAST(@ERR_STATE AS VARCHAR(10)) + '|' + CAST(@ERR_LINE AS VARCHAR(10))
--SELECT @RTADO_PROCALM			-- Muestra el resultado en una unica columna
SELECT @NOMB_PROCALM AS ProcAlm_Nomb, @FUNC_PROCALM AS ProcAlm_Funcion, @RTADO AS ProcAlm_Rtado, @REG_AFEC AS ProcAlm_RegAfec, @ERR_MESSAGE AS ProcAlm_Mensaje, @ERR_NUMBER AS ProcAlm_ErrNum, @ERR_SEVERITY AS ProcAlm_ErrSeveridad, @ERR_STATE AS ProcAlm_ErrEstado, @ERR_LINE AS ProcAlm_ErrLinea


DECLARE	@return_value int
EXEC @return_value = [dbo].[CPrGePProcInicio] 
	@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- Empresa


-- ##############################################################################################################################################^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- El GO va al final del procedimiento
GO
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################

