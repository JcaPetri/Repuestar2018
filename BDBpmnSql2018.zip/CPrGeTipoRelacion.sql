set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- Determina la base de datos donde se trabajar�
USE [BDCtral]
GO

-- =============================================
-- Author: Juan Petri
-- Create date: 06/01/2018
-- Description:	Lista los Etapas Vigentes 
-- =============================================
CREATE PROCEDURE [dbo].[CPrGeTipoRelacion]
	@PAR1 AS NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Determina el idioma, por defecto es Espa�ol

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- #################################################################################################################################
	-- Muestra los tipos de relaciones entre el M�dulo de Acceso y el M�dulo Procesos
	-- se origina en la BDCtral, de la combinaci�n de la tabla GDicTCodigos y GDicTDescIdiomas.
	-- para filtrarlos de los otros elementos, el �mbito de aplicaci�n es la tabla CProcTTipoRelacion
	-- IMPORTANTE: es la misma consulta que EXEC @return_value = [dbo].[CDiccPCodxIdio], 
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Toma los c�digos con su descripci�n seg�n el idioma elegido
--		DECLARE @PAR1 NVARCHAR(50) 
--		SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'			-- Idioma elegido o por defecto = espa�ol

		DECLARE @PARInt1 NVARCHAR(50) 
		SET @PARInt1 = '8AEBC8CD-5F8D-4C53-B3D1-28248D2C15DE'		--	CProcTTipoRelacion	tabla con los tipos de relaciones en

		DECLARE @TmpTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
		(
			[IDFkTCodigos] [uniqueidentifier] NOT NULL,
			[IDFkTIdioma] [uniqueidentifier] NOT NULL,
			[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
			[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
			[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
			[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
		)
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		INSERT INTO @TmpTCodxIdi
			SELECT CxI.[IDFkTCodigos]
				  ,CxI.[IDFkTIdioma]
				  ,CxI.[IDFkTCodAmbAplic]
				  ,CxI.[Codigo]
				  ,CxI.[Descripcion]
				  ,Idi.[CodIdioma] AS IdiCod
				  ,Idi.[DescIdioma] AS Idioma
			  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
					INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
						ON CxI.[IDFkTIdioma] = Idi.[ID]
			WHERE Idi.[ID] = @PAR1				-- Idioma elegido

		-- Muestra los c�digos con su descripci�n por cada idioma
		SELECT Cod.[IDFkCodEmpresas]
				,Cd03.[Codigo] AS [CodigoEmpresa]
				,Cd03.[Descripcion] AS [CodDescEmpresa]
				,Cod.[ID] AS [IDFkTCodigos]
				,Cd01.[Codigo]
				,Cd01.[Descripcion]
				,Cd01.[IDFkTCodAmbAplic]
				,Cd02.[Codigo] AS [CodigoAmbitoAplic]
				,Cd02.[Descripcion] AS [CodDescAmbitoAplic]
				,Cd01.[IDFkTIdioma]
				,Cd01.CodIdioma AS [IdiomaCod]
				,Cd01.DescIdioma AS [IdiomaDesc]
		FROM [BDCtral].[dbo].[CDiccTCodigos] AS Cod WITH (NOLOCK)
			INNER JOIN @TmpTCodxIdi AS Cd01			-- Detalle del C�digo
				ON Cod.[ID] = Cd01.[IDFkTCodigos]
			INNER JOIN @TmpTCodxIdi AS Cd02			-- Detalle del Ambito de Aplicaci�n
				ON Cd01.[IDFkTCodAmbAplic] = Cd02.[IDFkTCodigos]
			LEFT OUTER JOIN @TmpTCodxIdi AS Cd03			-- Empresa Asignada
				ON Cod.[IDFkCodEmpresas] = Cd03.[IDFkTCodigos]
		WHERE Cd01.[IDFkTCodAmbAplic] = CASE WHEN @PARInt1 IS NULL THEN Cd01.[IDFkTCodAmbAplic] ELSE @PARInt1 END		-- Ambito de Aplicaci�n

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- #################################################################################################################################

END

-- Info de los tipos de relaciones entre el M�dulo de Acceso y el M�dulo Procesos
-- es la misma consulta que EXEC @return_value = [dbo].[CDiccPCodxIdio], 
-- pero el ambito de aplicaci�n es fijo '8AEBC8CD-5F8D-4C53-B3D1-28248D2C15DE'		--	CProcTTipoRelacion	tabla con los tipos de relaciones entre modulo acceso y modulo procesos
--DECLARE	@return_value int
--EXEC @return_value = [dbo].[CPrGeTipoRelacion] 
--		@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'			-- Idioma elegido o por defecto = espa�ol
