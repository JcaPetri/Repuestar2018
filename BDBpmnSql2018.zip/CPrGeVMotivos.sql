-- #################################################################################################################################
-- Muestra la tabla de los motivos posibles de un proceso.
-- se origina en la BDCtral, de la combinaci�n de la tabla GDicTCodigos y GDicTDescIdiomas.
-- para filtrarlos de los otros elementos, el �mbito de aplicaci�n es la tabla Motivos.
-- Luego en la base de procesos se deben asignar estos motivos a cada proceso que se necesite.
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

USE [BDCtral]
GO

-- Toma los c�digos con su descripci�n seg�n el idioma elegido
	DECLARE @PAR1 NVARCHAR(50) 
	DECLARE @PAR2 NVARCHAR(50) 
	SET @PAR1 = N'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	SET @PAR2 = NULL		-- Ambito de Aplicaci�n Proceos -- o por defecto = NULL

	-- Si pongo el ambito de aplicaci�n espec�fico, luego no tengo los valores generales como estado
	-- N'92e0ac56-18ac-4fe2-b679-c59cba5ddc0d'

	DECLARE @TmpTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDTCodigos] [uniqueidentifier] NOT NULL,
		[IDTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)

	-- Inserta en la tabla temporal la informaci�n de los c�digos seg�n el idioma elegido
	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1
				AND
			  CxI.[IDFkTCodAmbAplic] = CASE WHEN @PAR2 IS NULL THEN CxI.[IDFkTCodAmbAplic] ELSE @PAR2 END

--SELECT * FROM @TmpTCodxIdi
--ORDER BY [Codigo]
	-- Defini 
	SET @PAR2 = 'CF0EF997-B52A-42A2-BD70-E12EFB00A724'		-- GProcTMotivos

-- Resultado
	SELECT  CASE WHEN [IDFkTCodAmbAplic] = [IDTCodigos] THEN [IDTCodigos] ELSE [IDFkTCodAmbAplic] END AS [AmbAplic]
		, [IDTCodigos]
--		, [IDTIdioma]
		, [Codigo]
		, [Descripcion]
		, [CodIdioma]
		, [DescIdioma] 
	 FROM @TmpTCodxIdi
--	WHERE [Codigo] = 'CMP COB'
	WHERE ([IDTCodigos] = @PAR2				-- '%GProc%'
			OR [IDFkTCodAmbAplic] = @PAR2)	-- '%GProcTEtapas%'
		   AND [IDTCodigos] <> @PAR2		-- Hace que no aparezca el Item GProcTEtapas	tabla con los c�digos de las Etapas
	ORDER BY [Codigo]
GO

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- #################################################################################################################################
