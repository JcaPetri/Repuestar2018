set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- Determina la base de datos donde se trabajar�
USE [BDCtral]
GO

DECLARE	@return_value int
DECLARE @Idi AS NVARCHAR(36)
DECLARE @Emp AS NVARCHAR(36)

--######################################################################################################################################################################
-- Info de los Procesos disponibles para una Empresa determinada.
-- IMPORTANTE: es la misma consulta que EXEC @return_value = [dbo].[CDiccPCodxIdio], 
-- es la misma consulta que EXEC @return_value = [dbo].[CDiccPCodxIdio], 
-- pero el ambito de aplicaci�n es fijo '92E0AC56-18AC-4FE2-B679-C59CBA5DDC0D'			-- CProcTProcesos	tabla con los c�digos de los procesos
DECLARE	@return_value int
EXEC @return_value = [dbo].[CPrGePProcesos] 
		@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'			-- Idioma elegido o por defecto = espa�ol
		,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'			-- BPM	Business Process Managment

--######################################################################################################################################################################
-- Info de las Etapas disponibles para los procesos de una Empresa determinada.
-- IMPORTANTE: es la misma consulta que EXEC @return_value = [dbo].[CDiccPCodxIdio], 
-- es la misma consulta que EXEC @return_value = [dbo].[CDiccPCodxIdio], 
-- pero el ambito de aplicaci�n es fijo 'ADA29ADB-4B38-4610-B1FE-29AFE5B57317'		-- GProcTEtapas
DECLARE	@return_value int
EXEC @return_value = [dbo].[CPrGePEtapas] 
		@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'			-- Idioma elegido o por defecto = espa�ol
		,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'			-- BPM	Business Process Managment

--######################################################################################################################################################################
-- Info de los Motivos disponibles para los procesos de una Empresa determinada.
-- IMPORTANTE: es la misma consulta que EXEC @return_value = [dbo].[CDiccPCodxIdio], 
-- es la misma consulta que EXEC @return_value = [dbo].[CDiccPCodxIdio], 
-- pero el ambito de aplicaci�n es fijo 'CF0EF997-B52A-42A2-BD70-E12EFB00A724'		-- GProcTMotivos
DECLARE	@return_value int
EXEC @return_value = [dbo].[CPrGePMotivos] 
		@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'			-- Idioma elegido o por defecto = espa�ol
		,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'			-- BPM	Business Process Managment


--######################################################################################################################################################################
-- Info de las Gestion de los procesos, para una Empresa determinada
-- surge de la combinaci�n de las Etapas y Motivos.
DECLARE	@return_value int
EXEC @return_value = [dbo].[CPrGePGestion] 
	@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- Empresa	BPM	Business Process Managment
	,@PAR3 = '79B264F7-05BA-46AE-B56F-3FAAD6F64861'	--	Login										-- Proceso

	--	'79B264F7-05BA-46AE-B56F-3FAAD6F64861'	--	Login	Proceso para ingresar al sistema.
	--	'EC3887CE-C7C1-4C53-A96D-621BD28A715D'	--	PagIniUA	p�gina inicial del usurio an�nimo

--######################################################################################################################################################################
-- Info de la TGestionEtapaMotivo de inicio de los proceso del sistema.
-- cada proceso solo puede tener una sola EtapaMotivo de Inicio.
-- Para una Empresa determinada, especifica la TGestion Etapa Motivo que inicia el proceso elegido
--DECLARE	@return_value int
EXEC @return_value = [dbo].[CPrGePProcInicio] 
	@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- Empresa


--######################################################################################################################################################################
---- Info de la Logica Manual de los Procesos
---- DECLARE	@return_value int
--EXEC @return_value = [dbo].[CPrGePLogica] 
--	@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol


--######################################################################################################################################################################
---- Info de la Logica Automatica de los Procesos
--DECLARE	@return_value int
--EXEC @return_value = [dbo].[CPrGePLogAut] 
--	@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol



--######################################################################################################################################################################
-- Info de los tipos de relaciones entre el M�dulo de Acceso y el M�dulo Procesos
-- es la misma consulta que EXEC @return_value = [dbo].[CDiccPCodxIdio], 
-- pero el ambito de aplicaci�n es fijo '8AEBC8CD-5F8D-4C53-B3D1-28248D2C15DE'		--	CProcTTipoRelacion	tabla con los tipos de relaciones entre modulo acceso y modulo procesos
--DECLARE	@return_value int
EXEC @return_value = [dbo].[CPrGeTipoRelacion] 
		@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'			-- Idioma elegido o por defecto = espa�ol


--######################################################################################################################################################################
-- Detalle los Procesos y sus Perfiles
DECLARE	@return_value int
EXEC @return_value = [dbo].[CPrGePProcPerf] 
		-- Idioma elegido o por defecto = espa�ol
			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		
		-- BPM	Business Process Managment
			,@PAR2 = NULL	--	'56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		
		-- PerfInic		Perfil de inicio, tiene acceso a las funciones basicas sin necesidad de validar el usuario.
			, @PAR3 = NULL	--	'AD07DDA5-0FCD-4AE7-9DFA-DAEC2B3F19E2'	-- PerfAnonimo	perfil anonimo para usuarios no identificados	
					--	'F5897341-D898-4D23-9086-645C079162F5'		
		-- ID del TProceso, o del TGestionEtapaMotivo, o TLogicaAutomatica, o TLogicaManual. Esto se vincula con el tipo de vinculo
			, @PAR4 = NULL	--	'e2c1f05e-5169-41fb-8ccc-b7acb76293e3'	--	TG-PagVis	visualiza la p�gina definida
		-- ID del Tipo de Relaci�n
			, @PAR5 = '53721D2A-6973-42D5-A282-676FB646E343'	--	AccesoTGestEtaMot	
					--	Lista los tipos de relaci�n entre el M�dulo de Acceso y el M�dulo de Procesos.
				--		DECLARE	@return_value int
				--		EXEC @return_value = [dbo].[CPrGeTipoRelacion] 
				--				@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'			-- Idioma elegido o por defecto = espa�ol
							-- Cada tipo de relaci�n es una tabla del sistema
								--	'A7C62E22-B898-40FF-BF30-03FE128B3E03'	--	AccesoProcLogMan
								--	'8AEBC8CD-5F8D-4C53-B3D1-28248D2C15DE'	--	CProcTTipoRelacion
								--	'92CBE163-D12F-4662-B8F0-584174FB2843'	--	PerfProcDefault
								--	'53721D2A-6973-42D5-A282-676FB646E343'	--	AccesoTGestEtaMot
								--	'D8DEC339-9733-4302-B604-C9B096EBAF40'	--	AccesoProcLogAut
								--	'FB516B30-D823-4562-A32E-E45B4018FF72'	--	AccesoProcTProcesos


--######################################################################################################################################################################
--	Camino desde el Usuario hasta la P�gina que se debe abrir
--######################################################################################################################################################################

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	P�gina Inicial que abre un Perfil
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para una Empresa y un Usuario determinado, especifica la p�gina inicial que deber� abrir.
-- va desde el Usuario, al Grupo de Usuarios, luego va a los Perfiles, 
-- Ya con el perfil busca la p�gina Default que tiene asociada.
--DECLARE	@return_value int
EXEC @return_value = [dbo].[CPrGePUsuAPagInic] 
	@PAR1 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- Empresa		--	BPM	Business Process Managment
	,@PAR2 = 'D3AE6446-4D7B-474B-ACF0-E9A75A233BC6'		-- Usuario		--	An�nimo

---- Trae la p�gina Web asociada a la Empresa y Usuario seleccionado
--DECLARE	@return_value int
--EXEC	@return_value = [dbo].[CIntfPUsu]
--		@PAR1 = N'B1E3B2FA-A308-41BC-BF59-7664A6380CE3'

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	P�gina Inicial que abre un Proceso -- La EtapaMotivo TGestion inicial surge de la tabla [CPrGeTProcInicio]
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para una Empresa y un Usuario determinado, especifica la p�gina inicial que deber� abrir.
-- va desde el Usuario, al Grupo de Usuarios, luego va a los Perfiles, 
-- Ya con el perfil busca la p�gina Default que tiene asociada.
--DECLARE	@return_value int
EXEC @return_value = [dbo].[CPrGePUsuAPagProcInic] 
	@PAR1 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- Empresa		--	BPM	Business Process Managment
	,@PAR2 =	'D3AE6446-4D7B-474B-ACF0-E9A75A233BC6'		-- Usuario		--	ANONIMO
	,@PAR3 =	'79B264F7-05BA-46AE-B56F-3FAAD6F64861'		-- Proceso		--	Login	Proceso para ingresar al sistema.


-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	P�gina de un Proceso -- Para un proceso se abre la p�gina seg�n la EtapaMotivo en la que est�
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para una Empresa y un Usuario determinado, especifica la p�gina a abrir en funci�n de la EtapaMotivo que deba abrir
--DECLARE	@return_value int
EXEC @return_value = [dbo].[CPrGePUsuAPagProcInterno] 
	@PAR1 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- Empresa		--	BPM	Business Process Managment
	,@PAR2 = 'D3AE6446-4D7B-474B-ACF0-E9A75A233BC6'		-- Usuario		--	ANONIMO
	,@PAR3 = '79B264F7-05BA-46AE-B56F-3FAAD6F64861'		-- Proceso		--	Login	Proceso para ingresar al sistema.
	,@PAR4 = 'B2B4FFA6-A79A-4847-BA19-0036BFD4FF9D'		-- CProcTEtaMot	--	IngPte	Usuario pendiente de ingreso y no esta identificado


-- En la consulta CPrGePUsuAPagWebs_Control.sql, ayuda para determinar que variables cargar en las distintas tablas.

-- Procedimiento almacenado [CPrGePRelacAccesProcPerfilyProcesos_ABM]
-- Sentencia SQL para ejecutar el procedimiento almacenado CPrGePRelacAccesProcPerfilyProcesos_ABM_Ejec.SQL


