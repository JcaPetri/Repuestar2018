set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- Determina la base de datos donde se trabajar�
USE [BDCtral]
GO

-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 22/07/2017
-- Description:	Detalle de los c�digos ID, para el idioma elegido o el por defecto = espa�ol
-- =============================================
ALTER PROCEDURE [dbo].[CPrGePGestion]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 NVARCHAR(50) = NULL										-- Empresa	BPM	Business Process Managment
	,@PAR3 NVARCHAR(50) = NULL										-- Proceso
AS
BEGIN

--	DECLARE @PAR1 NVARCHAR(50) 
--	DECLARE @PAR2 NVARCHAR(50) 
--	DECLARE @PAR3 NVARCHAR(50) 
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- Empresa	BPM	Business Process Managment
--	SET @PAR3 = NULL										-- Proceso

	DECLARE @TmpTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)

	-- Inserta en la tabla temporal la informaci�n de los c�digos seg�n el idioma elegido
	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1

	-- Muestra Procesos de Gestion
	SELECT TC.[IDFkCodEmpresas]
			,CxI6.[Codigo] AS [EmpCod]
			,CxI6.[Descripcion] AS [EmpDesc]
			,CPG.[IDFkTCodProc]
			,CxI1.[Codigo] AS [ProcCod]
			,CxI1.[Descripcion] AS [ProcDesc]
			,CPG.[IDFKTCodEtaMot]
			,CxI2.[Codigo] AS [EtaMotCod]
			,CxI2.[Descripcion] AS [EtaMotDesc]
			,CPG.[IDFkTCodEtapa]
			,CxI3.[Codigo] AS [EtaCod]
			,CxI3.[Descripcion] AS [EtaDesc]
			,CPG.[IDFkTCodMotivo]
			,CxI4.[Codigo] AS [MotCod]
			,CxI4.[Descripcion] AS [MotDesc]
			,CPG.[IDFkTCodEst]
			,CxI5.[Codigo] AS [EstCod]
			,CxI5.[Descripcion] AS [EstDesc]
			,CPG.[TGestionFechaModif]
	  FROM [BDCtral].[dbo].[CPrGeTGestion] AS CPG WITH (NOLOCK)
		INNER JOIN @TmpTCodxIdi AS CxI1			-- Proceso
			ON CPG.[IDFkTCodProc] = CxI1.[IDFkTCodigos]
		INNER JOIN @TmpTCodxIdi AS CxI2			-- EtapaMotivo
			ON CPG.[IDFKTCodEtaMot] = CxI2.[IDFkTCodigos]
		INNER JOIN @TmpTCodxIdi AS CxI3			-- Etapa
			ON CPG.[IDFkTCodEtapa] = CxI3.[IDFkTCodigos]
		LEFT OUTER JOIN @TmpTCodxIdi AS CxI4			-- Motivo aqu� es Left Outer Join, para que traiga todos los Proceso que no tienen motivos de demora
			ON CPG.[IDFkTCodMotivo] = CxI4.[IDFkTCodigos]
		INNER JOIN @TmpTCodxIdi AS CxI5			-- Estado Gestion
			ON CPG.[IDFkTCodEst] = CxI5.[IDFkTCodigos]
		INNER JOIN [BDCtral].[dbo].[CDiccTCodigos] AS TC WITH (NOLOCK)
			ON CPG.[IDFkTCodProc] = TC.[ID]
				INNER JOIN @TmpTCodxIdi AS CxI6			-- Empresa Asignada
					ON TC.[IDFkCodEmpresas] = CxI6.[IDFkTCodigos]
	WHERE TC.[IDFkCodEmpresas] = CASE WHEN @PAR2 IS NULL THEN TC.[IDFkCodEmpresas] ELSE @PAR2 END 
		AND CPG.[IDFkTCodProc] = CASE WHEN @PAR3 IS NULL THEN CPG.[IDFkTCodProc] ELSE @PAR3 END

 END



-- Info de las Gestion de los procesos, para una Empresa determinada
-- surge de la combinaci�n de las Etapas y Motivos.
--DECLARE	@return_value int
--EXEC @return_value = [dbo].[CPrGePGestion] 
--	@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- Empresa	BPM	Business Process Managment
--	,@PAR3 = NULL										-- Proceso


