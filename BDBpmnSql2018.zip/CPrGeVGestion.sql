-- #################################################################################################################################
-- Muestra la tabla de los procesos.
-- se origina en la BDGral, de la combinaci�n de la tabla GDicTCodigos y GDicTDescIdiomas.
-- para filtrarlos de los otros elementos, el �mbito de aplicaci�n es la tabla procesos.
-- de esta forma cada proceso puede tener un c�digo y una descripci�n por cada idioma.
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

USE [BDCtral]
GO

	DECLARE @PAR1 NVARCHAR(50) 
	DECLARE @PAR2 NVARCHAR(50) 
	DECLARE @PAR3 NVARCHAR(50) 
	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	SET @PAR2 = NULL										-- Ambito de Aplicaci�n elegido o por defecto = NULL
	SET @PAR3 = NULL										-- Proceso

	DECLARE @TmpTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)

	-- Inserta en la tabla temporal la informaci�n de los c�digos seg�n el idioma elegido
	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1
				AND
			  CxI.[IDFkTCodAmbAplic] = CASE WHEN @PAR2 IS NULL THEN CxI.[IDFkTCodAmbAplic] ELSE @PAR2 END

	-- Muestra Procesos de Gestion
	SELECT CPG.[IDFkTCodProc]
			, Cd01.[Codigo]
			, Cd01.[Descripcion]
			, CPG.[IDFKTCodEtaMot]
			, Cd02.[Codigo]
			, Cd02.[Descripcion]
			, CPG.[IDFkTCodEtapa]
			, Cd03.[Codigo]
			, Cd03.[Descripcion]
			, CPG.[IDFkTCodMotivo]
			, Cd04.[Codigo]
			, Cd04.[Descripcion]
			, CPG.[IDFkTCodEst]
			, Cd05.[Codigo]
			, Cd05.[Descripcion]
			, CPG.[TGestionFechaModif]
	  FROM [BDCtral].[dbo].[CPrGeTGestion] AS CPG WITH (NOLOCK)
		INNER JOIN @TmpTCodxIdi AS Cd01			-- Proceso
			ON CPG.[IDFkTCodProc] = Cd01.[IDFkTCodigos]
		INNER JOIN @TmpTCodxIdi AS Cd02			-- EtapaMotivo
			ON CPG.[IDFKTCodEtaMot] = Cd02.[IDFkTCodigos]
		INNER JOIN @TmpTCodxIdi AS Cd03			-- Etapa
			ON CPG.[IDFkTCodEtapa] = Cd03.[IDFkTCodigos]
		LEFT OUTER JOIN @TmpTCodxIdi AS Cd04			-- Motivo
			ON CPG.[IDFkTCodMotivo] = Cd04.[IDFkTCodigos]
		INNER JOIN @TmpTCodxIdi AS Cd05			-- Estado Gestion
			ON CPG.[IDFkTCodEst] = Cd05.[IDFkTCodigos]
	WHERE CPG.[IDFkTCodProc] = CASE WHEN @PAR3 IS NULL THEN CPG.[IDFkTCodProc] ELSE @PAR3 END
