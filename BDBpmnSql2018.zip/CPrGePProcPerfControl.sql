set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

USE [BDCtral]
GO

-- ====================================================
-- Author:		Juan Carlos Petri
-- Create date: 30/09/2018
-- Description:	Detalle de los Procesos y sus Perfiles
-- ====================================================
--
ALTER PROCEDURE [dbo].[CPrGePProcPerfControl]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(36) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 NVARCHAR(36) = NULL		-- Empresa
	,@PAR3 NVARCHAR(36) = NULL		-- Usuario
	,@PAR4 NVARCHAR(36) = NULL		-- Proceso
	,@PAR5 NVARCHAR(36) = NULL		-- ID del Tipo de Relaci�n

AS
BEGIN
--######################################################################################################################################################################
-- MUESTRA PARA TABLA TPROCESOS la info de la tabla CPrGeTProcPerf
-- Segundo - Relaci�n Usuario - Pagina
--######################################################################################################################################################################

-- Busca determinar que falta en la l�gica del Usuario hasta la P�gina Web, para determinar porqu� no encuentra la p�gina
--	DECLARE @PAR1 AS NVARCHAR(36)		-- Idioma elegido o por defecto = espa�ol
--	DECLARE @PAR2 AS NVARCHAR(36)		-- Empresa
--	DECLARE @PAR3 AS NVARCHAR(36)		-- Usuario
--	DECLARE @PAR4 AS NVARCHAR(36)		-- Proceso
--	DECLARE @PAR5 AS NVARCHAR(36)		-- AccesoTGestEtaMot	Relaciona el Acceso a los Procesos y los Procesos de Gestion Etapas Motivos.
--
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- Empresa		--	BPM	Business Process Managment
--	SET @PAR3 =	'D3AE6446-4D7B-474B-ACF0-E9A75A233BC6'		-- Usuario		--	ANONIMO
--		-- SELECT * FROM [BDCtral].[dbo].[CUsuTUsuarios]
--			--	'3CFC4638-33A7-45B9-B55E-B80A6FE8114D'	-- Usuario		--	JPETRI
--			--	'82B45787-57A9-4E3D-9669-D3C3ADB30A0D'	-- Usuario		--	LPAGNONE
--			--	'A10F3B50-5482-43E4-A0BB-EDFDBE7E6F5C'	-- Usuario		--	NOPOVIN
--			--	'D3AE6446-4D7B-474B-ACF0-E9A75A233BC6'	-- Usuario		--	ANONIMO
--
--	SET @PAR4 =	'79B264F7-05BA-46AE-B56F-3FAAD6F64861'		-- Proceso		--	Login	Proceso para ingresar al sistema.
----			DECLARE	@return_value int
----			EXEC @return_value = [dbo].[CPrGePProcesos] 
----					@PAR2 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'			-- Idioma elegido o por defecto = espa�ol
----					,@PAR3 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'			-- BPM	Business Process Managment
--
--			--	'79B264F7-05BA-46AE-B56F-3FAAD6F64861'		-- Proceso		Login		Proceso para ingresar al sistema.
--			--	'EC3887CE-C7C1-4C53-A96D-621BD28A715D'		-- Proceso		PagIniUA	p�gina inicial del usurio an�nimo
--
--	SET @PAR5 = '53721D2A-6973-42D5-A282-676FB646E343'	-- AccesoTGestEtaMot Relaciona el Acceso a los Procesos y los Procesos de Gestion Etapas Motivos.
--

	-- Variables internas del procedimiento
	DECLARE @PARInt1 AS NVARCHAR(36)		-- TipoTabla
	DECLARE @PARInt2 AS NVARCHAR(36)		-- Estado
	SET @PARInt1 = '50E6A111-D9BE-4CF7-9115-69A1294EACAB'	-- TipoTabla	--	CPerfTAccesoProcesos	tabla acceso a los procesos del sistema
	SET @PARInt2 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'	-- Estado	-- Habilitado

		DECLARE @TmpTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
		(
			[IDFkTCodigos] [uniqueidentifier] NOT NULL,
			[IDFkTIdioma] [uniqueidentifier] NOT NULL,
			[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
			[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
			[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
			[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
		)
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		INSERT INTO @TmpTCodxIdi
			SELECT CxI.[IDFkTCodigos]
				  ,CxI.[IDFkTIdioma]
				  ,CxI.[IDFkTCodAmbAplic]
				  ,CxI.[Codigo]
				  ,CxI.[Descripcion]
				  ,Idi.[CodIdioma] AS IdiCod
				  ,Idi.[DescIdioma] AS Idioma
			  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
					INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
						ON CxI.[IDFkTIdioma] = Idi.[ID]
			WHERE Idi.[ID] = @PAR1	-- Determina el idioma, por defecto es Espa�ol
		
--		SELECT * FROM @TmpTCodxIdi

	-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	--	Verifica la relaci�n entre la tabla de [CPrGeTProcPerf], 
	SELECT 'Tabla CPrGeTProcPerf' AS 'Tabla'
		  ,PP.[IDFkCDiccTCod_CodRelac]				-- Esta OK
		  ,CxI6.[Codigo] AS [TipoRelacionCod]
		  ,PP.[IDFkCDiccTCod_Empresa]				-- Esta OK
		  ,CxI2.[Codigo] AS [EmpCod]
		  ,PP.[IDFkCDiccTCod_CPerfilAccProc]		-- Esta OK
		  ,CxI5.[Codigo] AS [PerfilAccesoProcesosCod]
		  ,PP.[IDFkCDiccTCod_CodProc]				-- Esta OK
		  ,CxI3.[Codigo] AS [ProcCod]
		  ,PP.[IDFkCDiccTCod_CodProcTGestLog]		-- Esta OK
		  ,CxI4.[Codigo] AS [TProcGestLogCod]
--			  ,PP.[IDFkCDiccTCod_CodEst]				-- Esta OK
--			  ,CxI7.[Codigo] AS [EstadoCod]
--			  ,PP.[TProcPerfFecha]
		  ,PP.[IDFkCDiccTCod_ProcPerf]
		  ,CxI1.[Codigo] AS [ProcPerfCod]
		  ,'Tabla CPrGeTProcInicio' AS 'Tabla'
			--	con los procesos [CPrGeTProcInicio] tiene la informaci�n de cual es la EtapaMotivo que inicia el proceso
				--		si no esta en esta tabla, puede ser porque son momentos intermedios y no son inicio de proceso.
				--		pero debe tener una asociaci�n con una interfaz para que pueda abrirse cuando lo busca el proceso.
				-- Para ejecutar las etapas intermedias, no es necesaria esta tabla, entonces la consulta debe traer la EtapaMotivo
				
				-- Por lo tanto para abrir procesos iniciales, la relaci�n con esta tabla es de INNER JOIN
				-- para ejecutar procesos intermedios, no debe haber relaci�n con esta tabla.
		  ,TPI.[IDFkGDicTCodProc]
		  ,CxI8.[Codigo] AS [ProcCod]
		  ,TPI.[IDFKTCodEtaMotInicio]
		  ,CxI9.[Codigo] AS [TGestionEtaMotInicioCod]
--			  ,TPI.[IDFkGDicTCodEst]
--			  ,TPI.[TProcesosFechaModif]
		  ,'Tabla CPrGeTProcPerfIntUsu' AS 'Tabla'
			--	con los procesos [CPrGeTProcPerfIntUsu] tiene la asociaci�n a las p�ginas Webs, 
			-- aqu� puede ser que puede que no tenga relaci�n con CPrGeTProcInicio, ya que no es una etapa inicial del proceso, pero
			-- pero si tiene una pagina para abrir.
		  ,PIU.[IDFkCDiccTCod_ProcPerf]
		  ,CxI10.[Codigo] AS [ProcPerfCod]
		  ,PIU.[IDFkCIntfTObjCod_IntUsu]
		  ,OCxI1.[Codigo] AS [IntUsuCod]
	  FROM [BDCtral].[dbo].[CPrGeTProcPerf] AS PP WITH(NOLOCK)
			LEFT OUTER JOIN @TmpTCodxIdi AS CxI1
				ON PP.[IDFkCDiccTCod_ProcPerf] = CxI1.[IDFkTCodigos]
			LEFT OUTER JOIN @TmpTCodxIdi AS CxI2
				ON PP.[IDFkCDiccTCod_Empresa] = CxI2.[IDFkTCodigos]
			LEFT OUTER JOIN @TmpTCodxIdi AS CxI3
				ON PP.[IDFkCDiccTCod_CodProc] = CxI3.[IDFkTCodigos]
			LEFT OUTER JOIN @TmpTCodxIdi AS CxI4
				ON PP.[IDFkCDiccTCod_CodProcTGestLog] = CxI4.[IDFkTCodigos]
			LEFT OUTER JOIN @TmpTCodxIdi AS CxI5
				ON PP.[IDFkCDiccTCod_CPerfilAccProc] = CxI5.[IDFkTCodigos]
			LEFT OUTER JOIN @TmpTCodxIdi AS CxI6
				ON PP.[IDFkCDiccTCod_CodRelac] = CxI6.[IDFkTCodigos]
			LEFT OUTER JOIN @TmpTCodxIdi AS CxI7
				ON PP.[IDFkCDiccTCod_CodEst] = CxI7.[IDFkTCodigos]
			-- El Proceso Inicio debe ser igual al Proceso y EtapaMotivo
			LEFT OUTER JOIN	
					[BDCtral].[dbo].[CPrGeTProcInicio] AS TPI WITH(NOLOCK)
						ON PP.[IDFkCDiccTCod_CodProc] = TPI.[IDFkGDicTCodProc]
								AND
							PP.[IDFkCDiccTCod_CodProcTGestLog] = TPI.[IDFKTCodEtaMotInicio]
--								AND
--							PP.[IDFkCDiccTCod_CodProc] = CASE WHEN @PAR4 IS NULL THEN PP.[IDFkCDiccTCod_CodProc] ELSE @PAR4 END	
					LEFT OUTER JOIN @TmpTCodxIdi AS CxI8
						ON TPI.[IDFkGDicTCodProc] = CxI8.[IDFkTCodigos]
					LEFT OUTER JOIN @TmpTCodxIdi AS CxI9
						ON TPI.[IDFKTCodEtaMotInicio] = CxI9.[IDFkTCodigos]
		-- Proceso a abrir
			LEFT OUTER JOIN 
					[BDCtral].[dbo].[CPrGeTProcPerfIntUsu] AS PIU WITH(NOLOCK)
						ON PP.[IDFkCDiccTCod_ProcPerf] = PIU.[IDFkCDiccTCod_ProcPerf]
					LEFT OUTER JOIN @TmpTCodxIdi AS CxI10
						ON PIU.[IDFkCDiccTCod_ProcPerf] = CxI10.[IDFkTCodigos]
					LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTObjCodxIdio] AS OCxI1 WITH(NOLOCK)
						ON PIU.[IDFkCIntfTObjCod_IntUsu] = OCxI1.[IDFkTCIntfTObjCod_CodxIdio]
	WHERE [IDFkCDiccTCod_Empresa] =  @PAR2			-- Empresa
		AND [IDFkCDiccTCod_CodEst] = @PARInt2		-- Estado
		AND [IDFkCDiccTCod_CodRelac] = @PAR5		-- Tipo de Relaci�n, define la tabla con que se trabaja
	ORDER BY PP.[IDFkCDiccTCod_Empresa], PP.[IDFkCDiccTCod_CPerfilAccProc]
END
--
---- Detalle los Procesos y sus Perfiles
--DECLARE	@return_value int
--EXEC @return_value = [dbo].[CPrGePProcPerfControl] 
--		@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--		,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- Empresa		--	BPM	Business Process Managment
--		,@PAR3 = 'D3AE6446-4D7B-474B-ACF0-E9A75A233BC6'		-- Usuario		--	ANONIMO
--			-- SELECT * FROM [BDCtral].[dbo].[CUsuTUsuarios]
--				--	'3CFC4638-33A7-45B9-B55E-B80A6FE8114D'	-- Usuario		--	JPETRI
--				--	'82B45787-57A9-4E3D-9669-D3C3ADB30A0D'	-- Usuario		--	LPAGNONE
--				--	'A10F3B50-5482-43E4-A0BB-EDFDBE7E6F5C'	-- Usuario		--	NOPOVIN
--				--	'D3AE6446-4D7B-474B-ACF0-E9A75A233BC6'	-- Usuario		--	ANONIMO
--		,@PAR4 = '79B264F7-05BA-46AE-B56F-3FAAD6F64861'		-- Proceso		--	Login	Proceso para ingresar al sistema.
----			DECLARE	@return_value int
----			EXEC @return_value = [dbo].[CPrGePProcesos] 
----					@PAR2 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'			-- Idioma elegido o por defecto = espa�ol
----					,@PAR3 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'			-- BPM	Business Process Managment
--		,@PAR5 = '53721D2A-6973-42D5-A282-676FB646E343'	-- AccesoTGestEtaMot Relaciona el Acceso a los Procesos y los Procesos de Gestion Etapas Motivos.
