set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go



-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 27/09/2018
-- Description:	Detalle de los c�digos ID, para el idioma elegido o el por defecto = espa�ol
-- =============================================
ALTER PROCEDURE [dbo].[CPrGePLogAutAcciones]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 NVARCHAR(50) = NULL

AS
BEGIN

--	DECLARE @PAR1 NVARCHAR(50) 
--	DECLARE @PAR2 NVARCHAR(50) 
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR2 NVARCHAR(50) = NULL
	-- Proceso Estado Motivo -- Login
		--	B2B4FFA6-A79A-4847-BA19-0036BFD4FF9D	TG-IngPte			El usuario esta pendiente de ingreso y no esta ide
		--	4A283628-5D5E-45B6-BFFE-80591E5D3149	TG-IngPte/UsuIne	El usuario es inexistente.
		--	F65785C5-47FB-458F-A070-C0F4A25C8E83	TG-UsuPte			El usuario identificado, esta pendiente de ingreso
		--	1C8A1E56-A080-4187-AA3A-0208B8B58D80	TG-UsuPte/UsuErr	El usuario identificado, tuvo error de logueo.
		--	1255E790-EBBE-4D64-AA1B-3AE776E71B4A	TG-UsuBlo			Usuario bloqueado.
		--	83605861-8DFA-4FAB-87D3-22181A759D60	TG-UsuIng			Usuario ingres�.


	DECLARE @TmpTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)

	-- Inserta en la tabla temporal la informaci�n de los c�digos seg�n el idioma elegido
	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1
--				AND
--			  CxI.[IDFkTCodAmbAplic] = '2F768D8E-7CC2-4350-8F30-04CD25219336'		-- CProcTEtaMot		tabla con los c�digos de Gesti�n Etapa Motivo
	
--	SELECT * FROM @TmpTCodxIdi

	-- Muestra la Validaci�n de la logica de los Procesos de Gestion
	SELECT [IDFkTCodProLogAut]
			,Cd01.[Codigo]
			,Cd01.[Descripcion]
		  ,[IDFkTCodProLogValiRtado]
			,Cd02.[Codigo]
			,Cd02.[Descripcion]
		  ,[IDFkTCodProLogAcc]
			,Cd03.[Codigo]
			,Cd03.[Descripcion]
		  ,[ProLogAccOrden]
		  ,[IDFkTCodAccTipo]
			,Cd04.[Codigo]
			,Cd04.[Descripcion]
		  ,[IDFkTCodAccParametro]
		  ,[IDFkTCodEst]
			,Cd05.[Codigo]
			,Cd05.[Descripcion]
		  ,[TLogAutAccFecha]
	  FROM [BDCtral].[dbo].[CPrGeTLogAutAcciones] AS PLAA WITH(NOLOCK)
			INNER JOIN @TmpTCodxIdi AS Cd01			-- Proceso Logica Autom�tica
					ON PLAA.[IDFkTCodProLogAut] = Cd01.[IDFkTCodigos]
			INNER JOIN @TmpTCodxIdi AS Cd02			-- Resultado de la Validaci�n
					ON PLAA.[IDFkTCodProLogValiRtado] = Cd02.[IDFkTCodigos]
			INNER JOIN @TmpTCodxIdi AS Cd03			-- Acci�n
					ON PLAA.[IDFkTCodProLogAcc] = Cd03.[IDFkTCodigos]
			INNER JOIN @TmpTCodxIdi AS Cd04			-- Acci�n Tipo
					ON PLAA.[IDFkTCodAccTipo] = Cd04.[IDFkTCodigos]
			INNER JOIN @TmpTCodxIdi AS Cd05			-- Tipo de comparaci�n
					ON PLAA.[IDFkTCodEst] = Cd05.[IDFkTCodigos]
	WHERE [IDFkTCodProLogAut] = CASE WHEN @PAR2 IS NULL THEN [IDFkTCodProLogAut] ELSE @PAR2 END
	ORDER BY [IDFkTCodProLogAut]

 END







