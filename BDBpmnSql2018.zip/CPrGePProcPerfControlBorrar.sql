set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

USE [BDCtral]
GO

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Muestra la relaci�n entre los Perfiles y las distintas tablas de procesos
	-- De Perfiles al Procesos Default
	DECLARE	@return_value int
	EXEC @return_value = [dbo].[CPrGePProcPerf] 
			-- Idioma elegido o por defecto = espa�ol
				@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		
			-- BPM	Business Process Managment
				,@PAR2 ='56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
			-- PerfInic		Perfil de inicio, tiene acceso a las funciones basicas sin necesidad de validar el usuario.
				, @PAR3 = NULL	--	'AD07DDA5-0FCD-4AE7-9DFA-DAEC2B3F19E2'	-- PerfAnonimo	perfil anonimo para usuarios no identificados	
						--	'F5897341-D898-4D23-9086-645C079162F5'		
			-- ID del TProceso, o del TGestionEtapaMotivo, o TLogicaAutomatica, o TLogicaManual. Esto se vincula con el tipo de vinculo
				, @PAR4 = NULL	--	'e2c1f05e-5169-41fb-8ccc-b7acb76293e3'	--	TG-PagVis	visualiza la p�gina definida
			-- ID del Tipo de Relaci�n
				, @PAR5 = '92CBE163-D12F-4662-B8F0-584174FB2843'	--	PerfProcDefault

	-- De Acceso a Procesos a la Tabla de Procesos
--	DECLARE	@return_value int
	EXEC @return_value = [dbo].[CPrGePProcPerf] 
			-- Idioma elegido o por defecto = espa�ol
				@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		
			-- BPM	Business Process Managment
				,@PAR2 ='56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
			-- PerfInic		Perfil de inicio, tiene acceso a las funciones basicas sin necesidad de validar el usuario.
				, @PAR3 = NULL	--	'AD07DDA5-0FCD-4AE7-9DFA-DAEC2B3F19E2'	-- PerfAnonimo	perfil anonimo para usuarios no identificados	
						--	'F5897341-D898-4D23-9086-645C079162F5'		
			-- ID del TProceso, o del TGestionEtapaMotivo, o TLogicaAutomatica, o TLogicaManual. Esto se vincula con el tipo de vinculo
				, @PAR4 = NULL	--	'e2c1f05e-5169-41fb-8ccc-b7acb76293e3'	--	TG-PagVis	visualiza la p�gina definida
			-- ID del Tipo de Relaci�n
				, @PAR5 = 'FB516B30-D823-4562-A32E-E45B4018FF72'	--	AccesoProcTProcesos

	-- De Acceso a Procesos a la Tabla de AccesoTGestEtaMot
--	DECLARE	@return_value int
	EXEC @return_value = [dbo].[CPrGePProcPerf] 
			-- Idioma elegido o por defecto = espa�ol
				@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		
			-- BPM	Business Process Managment
				,@PAR2 ='56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
			-- PerfInic		Perfil de inicio, tiene acceso a las funciones basicas sin necesidad de validar el usuario.
				, @PAR3 = NULL	--	'AD07DDA5-0FCD-4AE7-9DFA-DAEC2B3F19E2'	-- PerfAnonimo	perfil anonimo para usuarios no identificados	
						--	'F5897341-D898-4D23-9086-645C079162F5'		
			-- ID del TProceso, o del TGestionEtapaMotivo, o TLogicaAutomatica, o TLogicaManual. Esto se vincula con el tipo de vinculo
				, @PAR4 = NULL	--	'e2c1f05e-5169-41fb-8ccc-b7acb76293e3'	--	TG-PagVis	visualiza la p�gina definida
			-- ID del Tipo de Relaci�n
				, @PAR5 = '53721D2A-6973-42D5-A282-676FB646E343'	--	AccesoTGestEtaMot

	-- De Acceso a Procesos a la Tabla de AccesoProcLogMan
--	DECLARE	@return_value int
	EXEC @return_value = [dbo].[CPrGePProcPerf] 
			-- Idioma elegido o por defecto = espa�ol
				@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		
			-- BPM	Business Process Managment
				,@PAR2 ='56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
			-- PerfInic		Perfil de inicio, tiene acceso a las funciones basicas sin necesidad de validar el usuario.
				, @PAR3 = NULL	--	'AD07DDA5-0FCD-4AE7-9DFA-DAEC2B3F19E2'	-- PerfAnonimo	perfil anonimo para usuarios no identificados	
						--	'F5897341-D898-4D23-9086-645C079162F5'		
			-- ID del TProceso, o del TGestionEtapaMotivo, o TLogicaAutomatica, o TLogicaManual. Esto se vincula con el tipo de vinculo
				, @PAR4 = NULL	--	'e2c1f05e-5169-41fb-8ccc-b7acb76293e3'	--	TG-PagVis	visualiza la p�gina definida
			-- ID del Tipo de Relaci�n
				, @PAR5 = 'A7C62E22-B898-40FF-BF30-03FE128B3E03'	--	AccesoProcLogMan

	-- De Acceso a Procesos a la Tabla de AccesoProcLogAut
--	DECLARE	@return_value int
	EXEC @return_value = [dbo].[CPrGePProcPerf] 
			-- Idioma elegido o por defecto = espa�ol
				@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		
			-- BPM	Business Process Managment
				,@PAR2 ='56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
			-- PerfInic		Perfil de inicio, tiene acceso a las funciones basicas sin necesidad de validar el usuario.
				, @PAR3 = NULL	--	'AD07DDA5-0FCD-4AE7-9DFA-DAEC2B3F19E2'	-- PerfAnonimo	perfil anonimo para usuarios no identificados	
						--	'F5897341-D898-4D23-9086-645C079162F5'		
			-- ID del TProceso, o del TGestionEtapaMotivo, o TLogicaAutomatica, o TLogicaManual. Esto se vincula con el tipo de vinculo
				, @PAR4 = NULL	--	'e2c1f05e-5169-41fb-8ccc-b7acb76293e3'	--	TG-PagVis	visualiza la p�gina definida
			-- ID del Tipo de Relaci�n
				, @PAR5 = 'D8DEC339-9733-4302-B604-C9B096EBAF40'	--	AccesoProcLogAut

