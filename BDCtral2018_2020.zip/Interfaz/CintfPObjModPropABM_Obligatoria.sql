-- #########################################################################################################################################################
--  GENERA LOS PROCEDIMIENTOS PARA DAR DE ALTA LAS PROPIEDADES OBLIGATORIAS DE LOS ELEMENTOS -- 
-- #########################################################################################################################################################

-- Este proceso se ejecuta dentro del CintfPObjModABM_Hijos.sql, y tiene como objetivo insertar las propiedades obligatorias delos elementos.
-- de esta manera se reduce los pasos para dar de alta a los elementos

-- Define que se trabaja con al Base de Datos
USE [BDCtral]
GO

	DECLARE	@return_value int
--	EXEC @return_value = [dbo].[CIntfPObjConPropResu]

	DECLARE @PAR5 AS VARCHAR(36)		-- [IDFkTIntCodObj] -- codigo ID del Objeto (Elemento o Estilo) que se insertar� en la p�gina.
		-- Caso Alta: 
--			DECLARE	@return_value int
--			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR4 = N'AEFEA6F0-CC81-41AB-AD12-354A484273DA'		-- Ambito Aplicaci�n Elemento
--			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR4 = N'ABEDD291-3991-4A47-8AEB-82580BF6BA8C'		-- Ambito Aplicaci�n Estilos
	SET @PAR5 = '4BFD72B4-D915-413D-A9AF-3B93D448E543'

	DECLARE @TmpTObjConProp TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
		(
 			-- [ID] [uniqueidentifier] NULL,
			[IDFkTCIntfTObjCod_ObjCod] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
			[ObjCodigo] [nvarchar](50) COLLATE Modern_Spanish_CI_AS NULL,
			[IDFkTCIntfTObjCodProp] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
			[ObjCodValor] [nvarchar](255) COLLATE Modern_Spanish_CI_AS NULL,
			[IDFkTCIntfTObjCod_ObjCodProp] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
			[ObjCodPropValor] [nvarchar](255) COLLATE Modern_Spanish_CI_AS NULL,
			[ObjCodPropOrden] [int] NULL,
			[ObjCodPropValorWeb] [nvarchar](255) COLLATE Modern_Spanish_CI_AS NULL,
			[IDFkCDiccTCod_PropTipo] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
			[ObjPropTipo] [nvarchar](50) COLLATE Modern_Spanish_CI_AS NULL,
			[IDFkCDiccTCod_ObjCodPropEstado] [uniqueidentifier] NULL
	--		[ObjCodPropFechaModif] [datetime] NULL
		)
			
	INSERT INTO @TmpTObjConProp EXEC @return_value = [dbo].[CIntfPObjConPropResu]

	-- SELECT * FROM @TmpTObjConProp

	-- Inserta las propiedades Obligatorias
	INSERT INTO [BDCtral].[dbo].[CIntfTObjModProp]
			   ([ID]
			   ,[IDFkCIntfTObjMod_ObjModID]
			   ,[IDFkCintfTObjCodProp_ObjModProp]
			   ,[ObjModCodPropValor]
			   ,[ObjModCodPropOrden]
			   ,[IDFkCDiccTCod_ObjModPropEst]
			   ,[ObjModPropFechaModif])
	SELECT NEWID() AS [ID]							-- [ID] unico del objeto modelo propiedad
			, [IDFkTCIntfTObjCod_ObjCod]			-- [ID] tabla [IDFkCIntfTObjMod_ObjModID]-- codigo ID �nico del objeto al que se le asignar�la propiedad.
--			, [ObjCodigo]
--			, [IDFkTCIntfTObjCodProp]
--			, [ObjCodValor]
			, [IDFkTCIntfTObjCod_ObjCodProp]		-- [ID] tabla [IDFkCintfTObjCodProp_ObjModProp] -- valor ID �nico de la Propiedad
			, [ObjCodPropValor]						-- [ObjModCodPropValor] -- valor del Objeto
			, [ObjCodPropOrden]						-- [ObjModCodPropOrden] -- orden en que se armara el TAG
--			, [ObjCodPropValorWeb]
--			, [IDFkCDiccTCod_PropTipo]
--			, [ObjPropTipo]
			, [IDFkCDiccTCod_ObjCodPropEstado]		-- [IDFkCDiccTCod_ObjModPropEst] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
			, GETDATE()								-- [ObjModPropFechaModif] -- Fecha de Modificaci�n
	FROM @TmpTObjConProp
		WHERE [IDFkTCIntfTObjCod_ObjCod] = @PAR5
				AND
			[IDFkCDiccTCod_PropTipo] = 'CC9699C0-B646-427E-B545-7AAFB23D5B95'


