set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO
SELECT IUO.[ID]
      ,IUO.[IntUsuObjCodUnico]
      ,IUO.[IntUsuObjCodUsuUnico]
      ,IUO.[IntUsuObjCodDescFuncion]
      ,IUO.[IDFkCDiccTCod_UsuObjEst]
      ,IUO.[UsuObjFechaModif]
      ,IUO.[IDFkCIntfTObjCod_UsuObjCod]
	  ,OCxI.[Codigo] AS [IntObjCodigo]
	  ,OCxI.[Descripcion] AS [IntObjDescripcion]
  FROM [BDCtral].[dbo].[CIntfTUsuObj] AS IUO WITH(NOLOCK)
	INNER JOIN [BDCtral].[dbo].[CIntfTObjCodxIdio] AS OCxI WITH(NOLOCK)
		ON IUO.[IDFkCIntfTObjCod_UsuObjCod] = OCxI.[IDFkTCIntfTObjCod_CodxIdio]
				AND 
			'FB478ECC-85FE-4FC8-B792-CAF8ECB921B1' = OCxI.IDFkTCDiccTIdio_Idioma
