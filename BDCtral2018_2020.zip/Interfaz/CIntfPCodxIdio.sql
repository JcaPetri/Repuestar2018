set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO
-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 03/10/2018
-- Description:	Detalle de los c�digos ID, para el idioma elegido o el por defecto = espa�ol
-- =============================================
ALTER PROCEDURE [dbo].[CIntfPCodxIdio]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 NVARCHAR(50) = NULL										-- Ambito de Aplicaci�n elegido o por defecto = NULL
AS
BEGIN

	DECLARE @TmpTObjCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO @TmpTObjCodxIdi
		SELECT CxI.[IDFkTCIntfTObjCod_CodxIdio]
			  ,CxI.[IDFkTCDiccTIdio_Idioma]
			  ,CxI.[IDFkTCIntfTObjCod_AmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CIntfTObjCodxIdio] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTCDiccTIdio_Idioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1				-- Idioma elegido
				AND
			  CxI.[IDFkTCIntfTObjCod_AmbAplic] = CASE WHEN @PAR2 IS NULL THEN CxI.[IDFkTCIntfTObjCod_AmbAplic] ELSE @PAR2 END		-- Ambito de Aplicaci�n

	-- Muestra los c�digos con su descripci�n por cada idioma
	SELECT [ID] AS [IDFkTCIntfObjCod]
			, Cd01.[Codigo] AS [ObjCod]
			, Cd01.[Descripcion] AS [ObjCodDesc]
			, Cd01.[IDFkTCodAmbAplic] AS [IDFkTCIntfTObjCod_AmbAplic]
			, Cd02.[Codigo] AS [ObjCodAmbAplic]
			, Cd02.[Descripcion] AS [ObjCodAmbAplicDesc]
			, Cd01.[IDFkTIdioma] AS [IDFkTCDiccTIdio_ObjCodIdioma]
			, Cd01.CodIdioma AS [ObjCodIdioma]
			, Cd01.DescIdioma AS [ObjCodIdiomaDesc]
	FROM [BDCtral].[dbo].[CIntfTObjCod] AS Cod WITH (NOLOCK)
		INNER JOIN @TmpTObjCodxIdi AS Cd01			-- Detalle del C�digo
			ON Cod.[ID] = Cd01.[IDFkTCodigos]
		INNER JOIN @TmpTObjCodxIdi AS Cd02			-- Detalle del Ambito de Aplicaci�n
			ON Cd01.[IDFkTCodAmbAplic] = Cd02.[IDFkTCodigos]
	WHERE Cd01.[IDFkTCodAmbAplic] = CASE WHEN @PAR2 IS NULL THEN Cd01.[IDFkTCodAmbAplic] ELSE @PAR2 END
	ORDER BY Cd02.[Codigo], Cd01.[Codigo]
END




--	DECLARE	@return_value int
--	EXEC	@return_value = [dbo].[CIntfPCodxIdio]






