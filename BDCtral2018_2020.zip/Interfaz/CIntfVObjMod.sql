set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO
SELECT IOM.[ID]
      ,IOM.[IDFkCIntfTObjCod_ObjMod]
      ,IOM.[ObjModCodUnico]
      ,IOM.[ObjModCodDescFuncion]
      ,IOM.[IDFkCDiccTCod_ObjModEst]
      ,IOM.[ObjModFechaModif]
	  ,OCxI.[Codigo] AS [IntObjCodigo]
	  ,OCxI.[Descripcion] AS [IntObjDescripcion]
  FROM [BDCtral].[dbo].[CIntfTObjMod] AS IOM WITH(NOLOCK)
	INNER JOIN [BDCtral].[dbo].[CIntfTObjCodxIdio] AS OCxI WITH(NOLOCK)
		ON IOM.[IDFkCIntfTObjCod_ObjMod] = OCxI.[IDFkTCIntfTObjCod_CodxIdio]
				AND 
			'FB478ECC-85FE-4FC8-B792-CAF8ECB921B1' = OCxI.IDFkTCDiccTIdio_Idioma


