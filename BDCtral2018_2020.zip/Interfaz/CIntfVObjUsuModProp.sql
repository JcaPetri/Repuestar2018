set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO
-- Propiedades de los Objetos
SELECT [ID]
	  ,[IDFkTCIntfTObjCod_ObjCod] AS [IDFkCIntfTObjCod]
	  ,[IDFkTCIntfTObjCod_ObjCodProp] AS [IDFkCintfTObjCodProp]
	  ,[ObjCodPropValor] AS [ObjCodPropValor]
	  ,[ObjCodPropOrden] AS [ObjCodPropOrden]
	  ,[ObjCodPropValorWeb] AS [ObjCodPropValorWeb]
	  ,[IDFkCDiccTCod_ObjCodPropEstado] AS [IDFkCDiccTCod]
	  ,[ObjCodPropFechaModif] AS [ObjPropFechaModif]
  FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK) 
UNION ALL
-- Propiedades de los Objetos del Usuario
SELECT [ID]
      ,[IDFkCIntfTUsuObj_UsuObj] AS [IDFkCIntfTObjCod]
      ,[IDFkCintfTObjCodProp_UsuObjProp] AS [IDFkCintfTObjCodProp]
      ,[UsuObjCodPropValor] AS [ObjCodPropValor]
      ,[UsuObjCodPropOrden] AS [ObjCodPropOrden]
	  ,NULL AS [ObjCodPropValorWeb]
      ,[IDFkCDiccTCod_UsuObjPropEst] AS [IDFkCDiccTCod]
      ,[UsuObjPropFechaModif] AS [ObjPropFechaModif]
  FROM [BDCtral].[dbo].[CIntfTUsuObjProp]
UNION ALL
-- Propiedades de los Objetos Modelos
SELECT [ID]
	  ,[IDFkCIntfTObjMod_ObjModID] AS [IDFkCIntfTObjCod]
	  ,[IDFkCintfTObjCodProp_ObjModProp] AS [IDFkCintfTObjCodProp]
	  ,[ObjModCodPropValor] AS [ObjCodPropValor]
	  ,[ObjModCodPropOrden] AS [ObjCodPropOrden]
	  ,NULL AS [ObjCodPropValorWeb]
	  ,[IDFkCDiccTCod_ObjModPropEst] AS [IDFkCDiccTCod]
	  ,[ObjModPropFechaModif] AS [ObjPropFechaModif]
  FROM [BDCtral].[dbo].[CIntfTObjModProp] WITH(NOLOCK)
