USE [BDCtral]
GO
	DECLARE	@return_value int

-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<< Consulta 01 >>>
-- Detalle los Objetos Modelos disponibles, para el modulo Central Interfaz Objetos
-- surge de la combinaci�n de las tablas [CIntfTObjCod] y [CIntfTObjCodxIdio]
--	DECLARE	@return_value int
	DECLARE @PARIdioma NVARCHAR(50) 		-- Idioma elegido o por defecto = espa�ol
	DECLARE @PARAmbAplic NVARCHAR(50)		-- Ambito de Aplicaci�n elegido o por defecto = NULL
	SET @PARIdioma = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	SET @PARAmbAplic = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	-- Ambito de Aplicaci�n Objetos Modelos

--		EXEC @return_value = [dbo].[CIntfPCodxIdio]	@PAR1 = @PARIdioma, 	@PAR2 = @PARAmbAplic

	-- Aqu� se elige el Padre que se va a mostrar, toda la estructura

	--	5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D	EncPag001	encabezado de la p�gina
	--	57504A29-9F06-41B2-896C-81D5A57E37BF	EstWeb001	Estructura de la p�gina Web hasta el Body
	--	B890DD58-58BA-4DA3-8A0C-70422298A88D	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
	--	6EFA0E33-F537-4861-A35F-10ECB328FB74	PiePag001	pie de la p�gina

-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<< Consulta 02 >>>
-- Detalle la Estructura de los Objetos Modelos disponibles, para el modulo Central Interfaz Objetos
-- No muestra el ID Padre, ya que como este no tiene propiedades [CIntfTObjModProp], Este ID Padre esta en la tabla [CIntfTObjCod] y [CIntfTObjCodxIdio]
--	DECLARE	@return_value int
	DECLARE @TempObjModBucleID TABLE
		(
			[EstOrd] [bigint] NULL,
			[ArbolID] [uniqueidentifier] NULL,
			[ArbolDesc] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[ArbPadreID] [uniqueidentifier] NULL,
			[IDFkCIntfTObjModArb] [uniqueidentifier] NOT NULL,
			[ArbolNivel] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[IDFkCIntfTObjCod] [uniqueidentifier] NULL,
			[IntfTObjCod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[IDFkCIntfTObjMod] [uniqueidentifier] NULL,
			[ObjModCodUnico] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[ObjModCodDescFuncion] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
			[ArbItemNivel] [smallint] NULL,
			[ArbItemOrd] [smallint] NULL,
			[IDTagOpen] [varchar](36) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[TagOpen] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[IDTagClose] [varchar](36) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[TagClose] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL
		)

	DECLARE @PARPadreID AS VARCHAR(36)
	SET @PARPadreID = '5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D'			-- ID del Padre que a trabajar, este es el ID de la p�gina a agregar
	-- Valores surgen de la Consulta 01

	INSERT INTO @TempObjModBucleID EXEC @return_value = [dbo].[CintfPObjModBucleID] 
			@PAR1 = @PARPadreID					-- ID de la Tabla [CIntfTObjCod], la descripci�n est� en la tabla [CIntfTObjCodxIdio].
			, @PAR2 = @PARIdioma				-- Idioma elegido o por defecto = espa�ol
			, @PAR3 = @PARAmbAplic				-- Ambito de Aplicaci�n Objetos Modelos
--		SELECT * FROM @TempObjModBucleID
		-- NO estan sus propiedades.

---- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
---- <<< Consulta 03 >>>
---- Ahora inserta en la Tabla [CIntfTObjModArbWeb], la estructura Web. Solo los ID, no inserta la descripci�n y/o contenido
	DELETE FROM [BDCtral].[dbo].[CIntfTObjModArbEst]
		  WHERE [ArbolID] = @PARPadreID

			INSERT INTO [BDCtral].[dbo].[CIntfTObjModArbEst]
					   ([EstOrd]
					   ,[ArbolID]
					   ,[ArbolDesc]
					   ,[ArbPadreID]
					   ,[IDFkCIntfTObjModArb]
					   ,[ArbolNivel]
					   ,[IDFkCIntfTObjCod]
					   ,[IntfTObjCod]
					   ,[IDFkCIntfTObjMod]
					   ,[ObjModCodUnico]
					   ,[ObjModCodDescFuncion]
					   ,[ArbItemNivel]
					   ,[ArbItemOrd]
					   ,[IDFkCIntfTObjCod_TagOpen]
					   ,[TagOpenCod]
					   ,[IDFkCIntfTObjCod_TagClose]
					   ,[TagCloseCod])
					SELECT [EstOrd]
							,[ArbolID]
							,[ArbolDesc]
							,[ArbPadreID]
							,[IDFkCIntfTObjModArb]
							,[ArbolNivel]
							,[IDFkCIntfTObjCod]
							,[IntfTObjCod]
							,[IDFkCIntfTObjMod]
							,[ObjModCodUnico]
							,[ObjModCodDescFuncion]
							,[ArbItemNivel]
							,[ArbItemOrd]
							,[IDTagOpen]
							,[TagOpen]
							,[IDTagClose]
							,[TagClose]
					FROM @TempObjModBucleID

SELECT * FROM [BDCtral].[dbo].[CIntfTObjModArbEst]