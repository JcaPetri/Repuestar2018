-- #########################################################################################################################################################
--  GENERA LOS PROCEDIMIENTOS ALMACENADOS PARA HACER EL ALTA, MODIFICACION, BAJA O RECUPERO DEL OBJETO MODELO -- 
-- #########################################################################################################################################################
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- Determina la base de datos donde se trabajar�
USE [BDCtral]
GO

-- ===================================================
-- Author: Juan Petri
-- Create date: 18/12/2018
-- Description:	Crea Nuevos Elementos HTML
-- ===================================================

--	-- Lista la estructura de la p�gina inicial
--		DECLARE	@return_value int
--		EXEC	@return_value = [dbo].[CintfPUsuObjArbBucleIDEstInic] 
----					@PAR1 = 'B1E3B2FA-A308-41BC-BF59-7664A6380CE3'		--	PagInic001	p�gina inicial
--					@PAR1 = '9A01BFBA-6DFE-4BFA-AFD3-6A8F4044B97B'		--	PagInic002	pagina segunda
----					@PAR1 = 'E98AF295-714B-494C-A11D-87BAEABA16FF'	--	PrLgIU01	Proceso Login Interfaz Usuario ING-PTE
--					,@PAR2 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma Espa�ol	

--		-- Detalle de los objetos Modelos
--		DECLARE	@return_value int
--		EXEC	[dbo].[CintfPObjModBucleID]
--					@PAR1 = '57504A29-9F06-41B2-896C-81D5A57E37BF'	--	EstWeb1121
--				--	EstWeb1121	Estructura pagina modelo	'57504A29-9F06-41B2-896C-81D5A57E37BF'
--				--	EncPag1123	encabezado de pagina		'5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D'
--				--	PiePag1122	seccion pie pagina			'6EFA0E33-F537-4861-A35F-10ECB328FB74'
--
--	-- Lista la estructura de la p�gina, reemplazando los Objetos Modelos
--		DECLARE	@return_value int
--		EXEC	@return_value = [dbo].[CintfPUsuObjArbBucleID] 
--					@PAR1 = 'B1E3B2FA-A308-41BC-BF59-7664A6380CE3'		--	PagInic001	p�gina inicial
--					,@PAR2 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma Espa�ol	


-- ================================================================================================================================================
	DECLARE	@return_value int
	DECLARE @PARint1 AS uniqueidentifier		-- ID Nuevo de la tabla [CIntfTUsuObj]
	DECLARE @PARint2 AS uniqueidentifier		-- ID Nuevo de la tabla [CIntfTUsuObjArb]
	DECLARE @PARIdio AS NVARCHAR(36)			-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito

	SET @PARint1 = NEWID()
	SET @PARint2 = NEWID()

	-- Determina la Pagina Web que se trabajar�
	DECLARE @PagWeb AS NVARCHAR(36)							-- Pagina del Usuario
	SET @PagWeb = '2F1FF3F6-64E4-42ED-ABA9-5FE661219ED4'	--	PrLgIU05	Proceso Login Interfaz Usuario Usu-Blo

	--DECLARE	@return_value int
	--EXEC	@return_value = [dbo].[CIntfPCodxIdio]
	--			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	--			-- Ambito de Aplicaci�n elegido o por defecto = NULL
	--			,@PAR2 = '7C2D7297-34DE-4F10-8F70-ACD26E5AFB04'		--	PagWeb	contiene las pagina web de la aplicacion.

			-- [ID] de [CIntfPCodxIdio]
			--	'B1E3B2FA-A308-41BC-BF59-7664A6380CE3'	--	PagInic001	p�gina inicial
			--	'9A01BFBA-6DFE-4BFA-AFD3-6A8F4044B97B'	--	PagInic002	pagina segunda
			--	'7C2D7297-34DE-4F10-8F70-ACD26E5AFB04'	--	PagWeb	contiene las pagina web de la aplicacion.
			--	'E98AF295-714B-494C-A11D-87BAEABA16FF'	--	PrLgIU01	Proceso Login Interfaz Usuario ING-PTE
			--	'DEC88ABC-DDDB-41CB-9FD6-CF8A2B1A0AB5'	--	PrLgIU02	Proceso Login Interfaz Usuario ING-PTE/USU-INE
			--	'3A716834-0693-46B9-A5DE-0410E1E9F0FE'	--	PrLgIU03	Proceso Login Interfaz Usuario Usu-Pte
			--	'9BBC17F5-42CC-44F2-8D8D-FF481523C30F'	--	PrLgIU04	Proceso Login Interfaz Usuario Usu-Pte/Usu-Err
			--	'2F1FF3F6-64E4-42ED-ABA9-5FE661219ED4'	--	PrLgIU05	Proceso Login Interfaz Usuario Usu-Blo

	-- Define las variables que se cambian
	-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
	SET @PARIdio = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma Espa�ol	

	-- Ejecuta el Procedimiento Almacenado
	EXEC @return_value = [dbo].[CintfPUsuObjABM_Hijos]
		-- SETEO DE LAS VARIABLES PARA EL ALTA DE UN CODIGO Y SUS DESCRIPCIONES
			-- ALTA - MODIFICACION - BAJA - RECUPERO
				@PAR1 = 'ALTA'					

			-- [IDFkTCDiccTIdio_Idioma], codigo ID �nico del objeto al que se le asignar�la propiedad.
				,@PAR2 = @PARIdio				

			-- Ambito de Aplicaci�n
				,@PAR3 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	--	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
					-- Los principales son:
--						'AEFEA6F0-CC81-41AB-AD12-354A484273DA'	--	Ele		contiene los elementos de la pagina
--						'B890DD58-58BA-4DA3-8A0C-70422298A88D'	--	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.

					-- Consulta para ver los ambitos de aplicaci�n			
						--	DECLARE	@return_value int
						--	EXEC	@return_value = [dbo].[CIntfPAmbAplic]

			-- ID Nuevo de la tabla [CIntfTUsuObj]
				,@PAR4 = @PARint1		
	
			-- [IDFkTIntCodObj] -- codigo ID del Objeto (Elemento o Estilo) que se insertar� en la p�gina.
				,@PAR5 = '57504A29-9F06-41B2-896C-81D5A57E37BF'		--	EstWeb001	Estructura de la p�gina Web hasta el Body	
				-- El valor se determina de las siguientes consultas:
--				DECLARE	@return_value int
--				-- Ambito Aplicaci�n Elemento
--					EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'AEFEA6F0-CC81-41AB-AD12-354A484273DA'
--						--  @PAR5
--						--	EE8E9BBA-E7FD-40AA-A97F-9A085126B841	<body>			cuerpo de la pagina
--						--	8BA11A28-67B7-4A15-B2E2-E5A30FCCB8FE	<br>			salto de pagina
--						--	CBC7CCD2-6825-4288-A1EE-07C83D57FE97	<div>			seccion de pagina
--						--	F9DA8C8E-925D-4C2A-BF1C-EA363BEB3D41	<doctype>		tipo de documento
--						--	4E3F5983-416B-47C5-918E-C7B4910C017F	<form>			formulario
--						--	6A20FFB1-EF83-46AC-9DDA-9C37096B489D	<h1>			titulo h1
--						--	66C2E055-CB9B-41FC-AD33-E5DF741CE7A8	<h2>			titulo h2
--						--	116D43EC-D0FF-4915-B878-099A2ABE4EC6	<h3>			titulo h3
--						--	DCF47D44-133A-4865-ADC0-57869979F845	<h4>			titulo h4
--						--	C8BC46DE-7EA5-40F7-849C-8E381698CB93	<h5>			titulo h5
--						--	FF6D64CD-B3CC-48D4-9409-634C25D9CA96	<h6>			titulo h6
--						--	BEF7DACA-65E9-4662-89C8-35BC84274009	<head>			encabezado a nivel pagina
--						--	E31EC871-F1C8-48F5-9C34-77326C46BB4D	<html>			hepertext markup languages
--						--	EF69A94B-5C69-430C-A066-B6336A153A05	<inputcheck>	opcion de chequeo
--						--	13C46A05-262C-48C4-BD29-7A5D0BB91D22	<inputpass>		ingreso de password
--						--	CC3414AF-7742-4AFD-8EDA-E8D00130A553	<inputsubmit>	boton de env�o
--						--	5432E780-F1C7-4D2E-B4C6-53DD7A9D729D	<inputtext>		campo de ingreso
--						--	4BFD72B4-D915-413D-A9AF-3B93D448E543	<label>			texto
--						--	CCD03587-4CFE-4088-A699-6F8E8AD31088	<link>			permite vincular un archivo externo o documento
--						--	75A8EA76-C0A0-4DA1-A07F-1E1FF1514043	<meta>			especificaciones de la p�gina
--						--	CB0D1A8F-E833-41E1-9272-173A230C9D78	<p>				parrafo
--						--	A96324E5-B360-4D6D-9486-4DFD63565F70	<page>			pagina web
--						--	5CE0D99D-230B-4C90-A5FF-C3FD6D37F095	<script>		script relacionados a la p�gina
--						--	7E7703AF-582E-45E5-BB60-3D5735E37379	<title>			es el t�tulo de la lengueta de la p�gina

--				--	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
--					EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'B890DD58-58BA-4DA3-8A0C-70422298A88D'	
--						--	@PAR5
--						--	'5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D'	--	EncPag001	encabezado de la p�gina
--						--	'57504A29-9F06-41B2-896C-81D5A57E37BF'	--	EstWeb001	Estructura de la p�gina Web hasta el Body
--						--	'6EFA0E33-F537-4861-A35F-10ECB328FB74'	--	PiePag001	pie de la p�gina

--				-- Ambito Aplicaci�n Estilos	
--					EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'ABEDD291-3991-4A47-8AEB-82580BF6BA8C'		

			-- [IntUsuObjCodUnico] -- codigo unico del Objeto (Elemento o Estilo).
				,@PAR6 = NULL			-- Por defecto es null y el c�digo es autom�tico	

			-- [CodigoWeb] para PagWeb -- siempre debe ser incorporado, la abreviatura sin numeros					
				,@PAR7 = NULL

			-- [IntUsuObjCodDescFuncion] -- descripci�n de la funci�n de ese Objeto (Elemento o Estilo) en la p�gina.
				,@PAR8 = 'estructura pagina modelo'		

			-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			-- Informaci�n para cargar la estructura Arbol, O SEA D�nde va el Objeto en la P�gina.
			-- ID Nuevo de la tabla [CIntfTUsuObjArb]
				,@PAR9 = @PARint2	

			-- [IDPadre]		es el ID del Padre
				,@PAR10 = 'D995FD19-CC38-48A7-81E3-5191AE0826E0'	--	PrLgIU05	Proceso Login Interfaz Usuario Usu-Blo
				-- ID del Padre, este valor es manual
				-- 1.- En el caso que es el Padre Inicial, el ID viene de la tabla [CIntfTUsuObjArb], pero para ello se debe buscar primero la tabla [CIntfTObjCod] y [CIntfTObjCodxIdio]
						-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
						-- Toma el valor ID de la tabla [CIntfTUsuObjArb]
						--	PADRES ID -- Lista las P�ginas Disponibles.
						--		toma la informaci�n la tabla PagWeb y con eso busca el ID del Padre de la tabla [CIntfTUsuObjArb]
						--	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
						--	SELECT UOA.[ID]
						--	--	,UOA.[ItemNivel]
						--	--	,UOA.[ItemOrd]
						--	--	,UOA.[IDFkCIntfTUsuObj]
						--	,PW.[Codigo]
						--	,PW.[Descripcion]
						--	--	,PW.[CodigoWeb]
						--	,UOA.[IDFkCIntfTUsuObjArb_PadreID]
						--	FROM [BDCtral].[dbo].[CIntfTUsuObjArb] AS UOA
						--			INNER JOIN (
						--						SELECT [IDFkTCIntfTObjCod_CodxIdio]
						--								  ,[IDFkTCDiccTIdio_Idioma]
						--								  ,[IDFkTCIntfTObjCod_AmbAplic]
						--								  ,[Codigo]
						--								  ,[Descripcion]
						--								  ,[CodigoWeb]
						--								  ,[IDFkCDiccTCod_ObjCodxIdioEst]
						--								  ,[ObjCodxIdioFechaModif]
						--								  ,Idi.[CodIdioma] AS IdiCod
						--								  ,Idi.[DescIdioma] AS Idioma
						--							  FROM [BDCtral].[dbo].[CIntfTObjCodxIdio] AS CxI WITH (NOLOCK) 
						--									INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
						--										ON CxI.[IDFkTCDiccTIdio_Idioma] = Idi.[ID]
						--												AND
						--											CxI.[IDFkTCIntfTObjCod_AmbAplic] = '7C2D7297-34DE-4F10-8F70-ACD26E5AFB04'		-- PagWeb	contiene las pagina web de la aplicacion.
						--												AND
						--											Idi.[ID] = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
						--							WHERE [IDFkTCIntfTObjCod_CodxIdio] <> CxI.[IDFkTCIntfTObjCod_AmbAplic]
						--						) AS PW 
						--					ON UOA.[IDFkCIntfTUsuObj] = PW.[IDFkTCIntfTObjCod_CodxIdio]
						--	ORDER BY PW.[Codigo]

								-- Principales resultados
								-- ID de la tabla [CIntfTUsuObjArb]
								--	'B75F9DF1-E5FD-45E5-8B69-A7A5BAF3FADE'	--	PagInic001	p�gina inicial						
								--	'846D1275-75EB-4A35-868B-82F124711879'	--	PagInic002	pagina segunda
								--	'CF510FAC-8B2A-460D-B5BA-4D4782B3456C'	--	PrLgIU01	Proceso Login Interfaz Usuario ING-PTE
								--	'B8893921-743D-4D59-9BDF-CA9AD0BCB879'	--	PrLgIU02	Proceso Login Interfaz Usuario ING-PTE/USU-INE
								--	'2BFEFD42-796E-48BE-87CE-4FDA760371CF'	--	PrLgIU03	Proceso Login Interfaz Usuario Usu-Pte
								--	'C08B4454-D98C-408A-99B5-D868394DDBEF'	--	PrLgIU04	Proceso Login Interfaz Usuario Usu-Pte/Usu-Err
								--	'D995FD19-CC38-48A7-81E3-5191AE0826E0'	--	PrLgIU05	Proceso Login Interfaz Usuario Usu-Blo


				-- 2.- En el caso de que otro elemento sea el padre, hay que buscar el ID, para incorporarlo como padre,
					--  esta infor se saca de la siguiente consulta, hacer la consulta: 
					-- <<< Procedimiento Almacenado 09 [CintfPUsuObjArbBucleIDEstInic] >>>
					-- Muestra la estructura de una p�gina sin la incorporaci�n de los Objetos Modelos si los tuviera
					-- as� se puede definir el objeto Padre si se guiere insertar un Elemento y ObjModelo
	--					DECLARE	@return_value int
	--					DECLARE @PagPadre AS NVARCHAR(36)
	--				--	SET @PagPadre = '9A01BFBA-6DFE-4BFA-AFD3-6A8F4044B97B'	-- 	PagInic002	pagina segunda
	--					SET @PagPadre = 'B1E3B2FA-A308-41BC-BF59-7664A6380CE3'	--	PagInic001	p�gina inicial
	--					EXEC	@return_value = [dbo].[CintfPUsuObjArbBucleIDEstInic]  @PAR1 = @PagPadre

					-- [IDFkCIntfTUsuObjArb] esta es la columna del Padre ID
			
			-- [IDFkCxIEstados] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
				,@PAR11 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'	--		HAB	habilitado		EST	estados
					-- 'EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0'	--		DES	deshabilitado	EST	estados
					-- '3749D6D8-EF8F-4C37-893A-BE7209239810'	--		ELI	eliminado		EST	estados
					-- 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'	--		HAB	habilitado		EST	estados

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- Ya finalizada la estructura de la p�gina, ejecuta el procedimiento almacenado [CintfPUsuObjArbWebABM]
-- Esto inserta en la tabla [CIntfTUsuObjArbWeb] la pagina web finalizada
	EXEC	@return_value = [dbo].[CintfPUsuObjArbWebABM] @PAR1 = @PagWeb

	-- ####################################################################################################################################################################
	--	Muestra los resultados de la Estructura Inicial, sin reemplazar los Objetos Modelos
	--DECLARE	@return_value int
	EXEC	@return_value = [dbo].[CintfPUsuObjArbBucleIDEstInic] 
				@PAR1 = @PagWeb	-- Pagina Padre Inicial
				,@PAR2 = @PARIdio		-- Idioma Espa�ol

	-- Muestra la estructura Final para la Pagina del Usuario
	-- Consulta con la informaci�n relevante para ejecutar la p�gina web
	-- surge de la consulta [CIntfTUsuObjArbWeb] vinculada con las Propiedades de los elementos que surgen de la vista [CIntfVObjUsuModProp]
		--DECLARE	@return_value int
		EXEC	@return_value = [dbo].[CIntfPUsu] @PAR1 = @PagWeb	-- Pagina Padre Inicial
