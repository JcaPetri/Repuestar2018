set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO
SELECT UO.[ID] AS [IDUsuObj]
      ,UO.[IDFkCIntfTObjCod_UsuObjCod]
      ,UO.[IntUsuObjCodUnico]
      ,UO.[IntUsuObjCodUsuUnico]
      ,UO.[IntUsuObjCodDescFuncion]
      ,UO.[IDFkCDiccTCod_UsuObjEst]
      ,UO.[UsuObjFechaModif]
	  ,UOP.[ID] AS [IDFkCIntfTUsuObjProp]
--      ,UOP.[IDFkTIntfUsuObj]
      ,UOP.[IDFkCintfTObjCodProp_UsuObjProp]
	  ,OCP.[IDFkTCIntfTObjCod_ObjCodProp]
	  ,OCxI.[Codigo]
	  ,OCxI.[IDFkTCIntfTObjCod_AmbAplic]
      ,UOP.[UsuObjCodPropValor]
      ,UOP.[UsuObjCodPropOrden]
      ,UOP.[IDFkCDiccTCod_UsuObjPropEst]
      ,UOP.[UsuObjPropFechaModif]
  FROM [BDCtral].[dbo].[CIntfTUsuObj] AS UO WITH(NOLOCK)
	LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTUsuObjProp] AS UOP WITH(NOLOCK)
		ON UO.[ID] = UOP.[IDFkCIntfTUsuObj_UsuObj]
			INNER JOIN [BDCtral].[dbo].[CintfTObjCodProp] AS OCP WITH(NOLOCK)
				ON UOP.[IDFkCintfTObjCodProp_UsuObjProp] = OCP.[ID]
					INNER JOIN [BDCtral].[dbo].[CIntfTObjCodxIdio] AS OCxI WITH(NOLOCK)
						ON OCP.[IDFkTCIntfTObjCod_ObjCodProp] = OCxI.[IDFkTCIntfTObjCod_CodxIdio]
ORDER BY UO.[ID]
