set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


USE [BDCtral]
GO

-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 18/10/2018
-- Description:	Detalle de los c�digos ID, para el idioma elegido o el por defecto = espa�ol
-- =============================================
ALTER PROCEDURE [dbo].[CIntfPObjConPropResu]
	-- Add the parameters for the stored procedure here
	@PAR1 AS NVARCHAR(36) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 AS NVARCHAR(36) = NULL			-- IDFkCIntfTObjCod, es el elemento que tiene las propiedades
AS
BEGIN

--	DECLARE @PAR1 NVARCHAR(36) 
--	DECLARE @PAR1 NVARCHAR(36) 
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR2 = '116D43EC-D0FF-4915-B878-099A2ABE4EC6'		-- ID del elemento <h3>

	DECLARE @TmpTObjCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCIntfTObjCod_CodxIdio] [uniqueidentifier] NOT NULL,
		[IDFkTCDiccTIdio_Idioma] [uniqueidentifier] NOT NULL,
		[IDFkTCIntfTObjCod_AmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO @TmpTObjCodxIdi
		SELECT CxI.[IDFkTCIntfTObjCod_CodxIdio]
			  ,CxI.[IDFkTCDiccTIdio_Idioma]
			  ,CxI.[IDFkTCIntfTObjCod_AmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CIntfTObjCodxIdio] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTCDiccTIdio_Idioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1				-- Idioma elegido

--	SELECT * FROM @TmpTObjCodxIdi

	-- Muestra los c�digos con su descripci�n por cada idioma
	SELECT 
--			Cod.[ID] AS [IDFkTCIntfTObjCod_CodxIdio]
--			, Cd01.[IDFkTCIntfTObjCod_CodxIdio]
--			, Cd01.[Descripcion]
--			, Cd01.[IDFkTCIntfTObjCod_AmbAplic]
--			Cd02.[Codigo] AS [CodigoAmbitoAplic]
--			, Cd02.[Descripcion] AS [CodDescAmbitoAplic]
--			, Cd01.[IDFkTCDiccTIdio_Idioma]
--			, Cd01.CodIdioma AS [IdiomaCod]
--			, Cd01.DescIdioma AS [IdiomaDesc]
		  COP.[IDFkTCIntfTObjCod_ObjCod]
			, Cd03.[Codigo]
--			, Cd03.[Descripcion]
		  ,COP.[IDFkTCIntfTObjCod_ObjCodProp]
			, Cd04.[Codigo]
--			, Cd04.[Descripcion]
		  ,COP.[ID] AS [IDFkCintfTObjCodProp]
		  ,COP.[ObjCodPropValor]
		  ,COP.[ObjCodPropOrden]
		  ,COP.[ObjCodPropValorWeb]
		  ,COP.[IDFkCDiccTCod_PropTipo]
		  ,CxI.[Codigo] AS [PropTipo]
--		  ,CxI.[Descripcion] AS [PropTipoDesc]
		  ,COP.[IDFkCDiccTCod_ObjCodPropEstado]
	FROM [BDCtral].[dbo].[CIntfTObjCod] AS Cod WITH (NOLOCK)
		LEFT OUTER JOIN @TmpTObjCodxIdi AS Cd01			-- Detalle del C�digo
			ON Cod.[ID] = Cd01.[IDFkTCIntfTObjCod_CodxIdio]
		LEFT OUTER JOIN @TmpTObjCodxIdi AS Cd02			-- Detalle del Ambito de Aplicaci�n
			ON Cd01.[IDFkTCIntfTObjCod_AmbAplic] = Cd02.[IDFkTCIntfTObjCod_CodxIdio]
		LEFT OUTER JOIN [BDCtral].[dbo].[CintfTObjCodProp] AS COP WITH(NOLOCK)
				ON Cod.[ID] = COP.[IDFkTCIntfTObjCod_ObjCod]
			LEFT OUTER JOIN @TmpTObjCodxIdi AS Cd03			-- Detalle del C�digo
				ON COP.[IDFkTCIntfTObjCod_ObjCod] = Cd03.[IDFkTCIntfTObjCod_CodxIdio]
			LEFT OUTER JOIN @TmpTObjCodxIdi AS Cd04			-- Detalle del Ambito de Aplicaci�n
				ON COP.[IDFkTCIntfTObjCod_ObjCodProp] = Cd04.[IDFkTCIntfTObjCod_CodxIdio]
			LEFT OUTER JOIN [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH(NOLOCK)		-- Detalle del Tipo de Propiedad, si es obligatoria o no
				ON COP.[IDFkCDiccTCod_PropTipo] = CxI.[IDFkTCodigos]
						AND
					'F88BE042-527E-4FC1-A2EC-88572D3BA5C3' = CxI.[IDFkTCodAmbAplic]	-- Ambito de aplicaci�n CIntfPropTipo	tabla con los tipos de propiedades, si la misma es obligatoria y opcional.
						AND 
					@PAR1 = CxI.[IDFkTIdioma]		-- Idioma Elegido

	WHERE (Cd01.[IDFkTCIntfTObjCod_AmbAplic] = 'ABEDD291-3991-4A47-8AEB-82580BF6BA8C' OR Cd01.[IDFkTCIntfTObjCod_AmbAplic] = 'AEFEA6F0-CC81-41AB-AD12-354A484273DA')
			AND Cod.[ID] <> Cd01.[IDFkTCIntfTObjCod_AmbAplic]
			AND COP.[IDFkTCIntfTObjCod_ObjCod] = CASE WHEN @PAR2 IS NULL THEN COP.[IDFkTCIntfTObjCod_ObjCod] ELSE @PAR2 END
	ORDER BY Cd02.[IDFkTCIntfTObjCod_CodxIdio], Cd01.[IDFkTCIntfTObjCod_CodxIdio], COP.ObjCodPropOrden


END

--- <<< Procedimiento Almacenado 03.5 [CIntfPObjConPropResu] >>>
-- Es lo mismo pero muestra algunos campos
-- el mismo esta en el archivo ### Sentencia SQL CIntfPObjConPropResu.sql ###
--	DECLARE	@return_value int
--	EXEC	@return_value = [dbo].[CIntfPObjConPropResu]
--			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--			,@PAR2 = '6A20FFB1-EF83-46AC-9DDA-9C37096B489D'		-- IDFkCIntfTObjCod, es el elemento que tiene las propiedades, surge de la consutla [CintfPObjModBucleIDProp]
