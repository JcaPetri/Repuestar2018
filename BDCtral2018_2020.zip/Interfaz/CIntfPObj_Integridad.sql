set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO

-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 16/10/2018
-- Description:	Detalle de los c�digos [CIntfTUsuObj], para el idioma elegido o el por defecto = espa�ol
--				aqui se muestra la info de los elementos que forman parte de la estructuras arbol.
-- =============================================
-- Verifica que todos los ObjModelos esten inclu�dos dentro de alguna estructura.
SELECT OM.[ID]
      ,OM.[IDFkCIntfTObjCod_ObjMod]
      ,OM.[ObjModCodUnico]
      ,OM.[ObjModCodDescFuncion]
      ,OM.[IDFkCDiccTCod_ObjModEst]
      ,OM.[ObjModFechaModif]
	  ,OMA.[ID]
  FROM [BDCtral].[dbo].[CIntfTObjMod] AS OM WITH(NOLOCK)
	LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTObjModArb] AS OMA WITH(NOLOCK)
		ON OM.[ID] = OMA.[IDFkCIntfTObjMod]
WHERE OMA.[ID] IS NULL

--DELETE FROM [BDCtral].[dbo].[CIntfTObjMod]

-- Verifica que los Objetos Modelos Arbol, est�n en la tabla de ObjModelos
SELECT OMA.[ID]
	  ,OMA.[IDFkCIntfTObjModArb_PadreID]
	  ,OMA.[ItemNivel]
	  ,OMA.[ItemOrd]
	  ,OMA.[IDFkCIntfTObjMod]
	  ,CASE WHEN OM.[ID] IS NULL THEN OC.[ID] ELSE OM.[ID] END AS OM
  FROM [BDCtral].[dbo].[CIntfTObjModArb] AS OMA WITH(NOLOCK)
	-- Los valores de ItemNivel y ItemOrden iguales a 1, son los Padres que no se cargan en la tabla [CIntfTObjModArb], sino en la tabla [CIntfTObjCod]
	LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTObjMod] AS OM WITH(NOLOCK)
		ON OMA.[IDFkCIntfTObjMod] = OM.[ID]
	-- Los Objetos Padres, estan en la tabla [CIntfTObjCod] y [CIntfTObjCodxIdio]
	LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTObjCod] AS OC WITH(NOLOCK)
		ON OMA.[IDFkCIntfTObjMod] = OC.[ID]
WHERE CASE WHEN OM.[ID] IS NULL THEN OC.[ID] ELSE OM.[ID] END IS NULL

--DELETE FROM [BDCtral].[dbo].[CIntfTObjModArb]
--SELECT * FROM [BDCtral].[dbo].[CIntfTObjModArb] AS OMA WITH(NOLOCK)
--WHERE [IDFkCIntfTObjModArb_PadreID] = '39E09A6F-8B92-41D5-B703-69CFB6AB0067'

--SELECT [ID]
--      ,[IDFkCIntfTObjMod_ObjModID]
--      ,[IDFkCintfTObjCodProp_ObjModProp]
--      ,[ObjModCodPropValor]
--      ,[ObjModCodPropOrden]
--      ,[IDFkCDiccTCod_ObjModPropEst]
--      ,[ObjModPropFechaModif]
--  FROM [BDCtral].[dbo].[CIntfTObjModProp]

--DELETE FROM [BDCtral].[dbo].[CIntfTObjModProp]

---- Los objetos modelos que est�n en esta tabla, vienen de la tabla [CIntfTObjCod] ya que son ObjMod
--SELECT [ID]
--      ,[IDFkCIntfTObjCod_UsuObjCod]
--      ,[IntUsuObjCodUnico]
--      ,[IntUsuObjCodUsuUnico]
--      ,[IntUsuObjCodDescFuncion]
--      ,[IDFkCDiccTCod_UsuObjEst]
--      ,[UsuObjFechaModif]
--  FROM [BDCtral].[dbo].[CIntfTUsuObj]

--DELETE FROM [BDCtral].[dbo].[CIntfTUsuObj]