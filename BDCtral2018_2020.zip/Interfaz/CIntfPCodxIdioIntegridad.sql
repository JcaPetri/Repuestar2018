set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

USE [BDCtral]
GO

-- Verifica la Integridad de la tabla [CIntfTObjCod]
SELECT OB.[ID]
      ,OB.[IDFkCDiccTCod_ObjCodUbic]
      ,OB.[IDFkCDiccTCod_ObjCodEst]
      ,OB.[ObjCodFechaModif]
  FROM [BDCtral].[dbo].[CIntfTObjCod] AS OB WITH(NOLOCK)
	LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTObjCodxIdio] AS OCI WITH(NOLOCK)
		ON OB.[ID] = OCI.[IDFkTCIntfTObjCod_CodxIdio]
WHERE OCI.[IDFkTCIntfTObjCod_CodxIdio] IS NULL

--DELETE FROM [BDCtral].[dbo].[CIntfTObjCod] 
--	FROM [BDCtral].[dbo].[CIntfTObjCod] AS OB 
--		LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTObjCodxIdio] AS OCI
--			ON OB.[ID] = OCI.[IDFkTCIntfTObjCod_CodxIdio]
--WHERE OCI.[IDFkTCIntfTObjCod_CodxIdio] IS NULL


-- Verifica la Integridad de la tabla [CIntfTObjCodxIdio]
SELECT [IDFkTCIntfTObjCod_CodxIdio]
      ,[IDFkTCDiccTIdio_Idioma]
      ,[IDFkTCIntfTObjCod_AmbAplic]
      ,[Codigo]
      ,[Descripcion]
      ,[IDFkCDiccTCod_ObjCodxIdioEst]
      ,[ObjCodxIdioFechaModif]
  FROM [BDCtral].[dbo].[CIntfTObjCodxIdio] AS OCI WITH(NOLOCK)
	LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTObjCod] AS OB WITH(NOLOCK)
		ON OCI.[IDFkTCIntfTObjCod_CodxIdio] = OB.[ID]
WHERE OB.[ID] IS NULL


SELECT COUNT(*) AS Q FROM [BDCtral].[dbo].[CIntfTObjCod] AS OB WITH(NOLOCK)
SELECT COUNT(*) AS Q FROM [BDCtral].[dbo].[CIntfTObjCodxIdio] AS OCI WITH(NOLOCK)


SELECT * FROM [BDCtral].[dbo].[CIntfTObjCod] AS OB WITH(NOLOCK)
SELECT * FROM [BDCtral].[dbo].[CIntfTObjCodxIdio] AS OCI WITH(NOLOCK)
