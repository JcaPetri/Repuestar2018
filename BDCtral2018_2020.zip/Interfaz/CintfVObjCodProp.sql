set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO
SELECT [ID]
      ,[IDFkTCIntfTObjCod_ObjCod]
      ,[IDFkTCIntfTObjCod_ObjCodProp]
      ,[ObjCodPropValor]
      ,[ObjCodPropOrden]
      ,[ObjCodPropValorWeb]
      ,[IDFkCDiccTCod_ObjCodPropEstado]
      ,[ObjCodPropFechaModif]
  FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK)
ORDER BY [ObjCodPropValor], [ObjCodPropOrden]
