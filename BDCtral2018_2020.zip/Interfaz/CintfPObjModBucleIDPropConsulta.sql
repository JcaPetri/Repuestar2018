set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO

 DECLARE @return_value int
 DECLARE @PARInt01 AS VARCHAR(36)	-- IDFkTIdioma -- codigo del idioma para ese codigo
 DECLARE @PARInt02 AS VARCHAR(36)	-- Ambito de Aplicaci�n elegido o por defecto = NULL
 DECLARE @PARInt03 AS VARCHAR(36)	-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
	SET @PARInt01 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'	-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
	SET @PARInt02 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	-- Ambito de Aplicaci�n elegido o por defecto = NULL
	SET @PARInt03 = '57504A29-9F06-41B2-896C-81D5A57E37BF'	-- Padre Inicial de toda la estructura, sale de la vista [CIntfVCodigos]
--					SELECT [IDgdicTCodigos], [Codigo], [Descripcion]
--					  FROM [BDCtral].[dbo].[CIntfVCodigos]
--					WHERE [IDFkTCIntfTObjCod_AmbAplic] = 'b890dd58-58ba-4da3-8a0c-70422298a88d'
--							AND [IDFkTCDiccTIdio_Idioma] = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'

						--	6EFA0E33-F537-4861-A35F-10ECB328FB74	PiePag001	pie de la p�gina
						--	5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D	EncPag001	encabezado de la p�gina
						--	B890DD58-58BA-4DA3-8A0C-70422298A88D	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
						--	57504A29-9F06-41B2-896C-81D5A57E37BF	EstWeb001	Estructura de la p�gina Web hasta el Body
	EXEC	@return_value = [dbo].[CintfPObjModBucleIDProp] 
			@PAR1 = @PARInt01			-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
			, @PAR2 = @PARInt02			-- Ambito de Aplicaci�n elegido o por defecto = NULL
			, @PAR3 = @PARInt03			-- Padre ID General


--SELECT * FROM [BDCtral].[dbo].[CIntfTObjMod] AS OM WITH(NOLOCK)
--SELECT * FROM [BDCtral].[dbo].[CIntfTObjModArb] AS OMA WITH(NOLOCK)
--SELECT * FROM [BDCtral].[dbo].[CIntfTObjModProp] AS OMP  WITH(NOLOCK)
