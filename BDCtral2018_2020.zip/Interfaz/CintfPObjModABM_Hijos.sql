-- #########################################################################################################################################################
--  GENERA LOS PROCEDIMIENTOS ALMACENADOS PARA HACER EL ALTA, MODIFICACION, BAJA O RECUPERO DE LA LOS OBJETOS WEB -- 

-- ################################################################################################################################
-- ################################################################################################################################
-- Trabaja con la tabla [CIntfObjMod], [CIntfObjModArb]
-- Para armar el objeto:
--			1.- Insertar el elemento en la tabla [CIntfObjMod]
--			2.- Insertar en la tabla [CIntfObjModArb], la ubicaci�n del elemento en la estructura Padre / Hijo
-- ################################################################################################################################

USE [BDCtral]
GO

-- Ambitos de aplicaci�n donde est�n cargados los Elemento, Estilos y Propiedades.
--DECLARE	@return_value int
--EXEC	@return_value = [dbo].[CIntfPAmbAplic]

--	ABEDD291-3991-4A47-8AEB-82580BF6BA8C	Css		contiene todos los estilos posibles de la pagina y los elementos
--	AEFEA6F0-CC81-41AB-AD12-354A484273DA	Ele		contiene los elementos de la pagina
--	9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B	Pro		contiene las propiedades de la pagina, elementos y estilos
--	b890dd58-58ba-4da3-8a0c-70422298a88d	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO

DECLARE	@return_value int

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Variables para realizar al ABM, se debe:
	-- Variables Etapa 1
	DECLARE @PAR1 AS VARCHAR(50)	-- Determina acci�na realizar 
		-- valores posibles: ALTA - MODIFICACION - BAJA - RECUPERO
		-- Como estos valores son para todas las tablas e idiomas unicos siempre van los mismos

	DECLARE @PAR2 AS VARCHAR(36)	-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
		-- Caso Alta: 
			-- codigo del idioma a donde se asignara el codigo.
				--						ee954f5d-ca27-48a9-a23b-010788b18631	ITA
				--						b1268278-4eb3-4a93-8f67-0d425b767c65	ENG
				--						a455281d-76f5-4bad-8dbb-201c5928aaf8	FRA
				--						1048c13b-1cc9-4154-8b8b-64ca9ac9fe12	POR
				--						fb478ecc-85fe-4fc8-b792-caf8ecb921b1	ESP
		-- Caso Modificaci�n:
			-- Codigo del idioma, a que idioma se asigna ese codigo. 
			-- Primero se debe verificar que para ese idioma no este utilizado el codigo, no se debe haber utilizado, si es as� no se genera la modificaci�n

	DECLARE @PAR3 AS VARCHAR(36)	-- IDFkTCodAmbAplic -- codigo del ambito de aplicacion.
		-- Caso Alta: 
			-- codigo del modulo o ambito de aplicacion a donde se asignara el codigo.
				-- Algunos ambitos de aplicaci�n			
				--	DECLARE	@return_value int
				--	EXEC	@return_value = [dbo].[CIntfPAmbAplic]
					--	ABEDD291-3991-4A47-8AEB-82580BF6BA8C	Css	contiene todos los estilos posibles de la pagina y los elementos
					--	AEFEA6F0-CC81-41AB-AD12-354A484273DA	Ele	contiene los elementos de la pagina
					--	9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B	Pro	contiene las propiedades de la pagina, elementos y estilos

	DECLARE @PAR4 AS VARCHAR(36)	-- [ID] -- valor ID, debe ser �nico.
		-- Caso Alta: valor nuevo se genera con el NewID()
			-- este valor es el ID unico del Objeto en la p�gina, 
		-- Caso Modificaci�n: 

	DECLARE @PAR5 AS VARCHAR(36)		-- [IDFkTIntCodObj] -- codigo ID del Objeto (Elemento o Estilo) que se insertar� en la p�gina.
		-- Caso Alta: 
--			DECLARE	@return_value int
--			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR4 = N'AEFEA6F0-CC81-41AB-AD12-354A484273DA'		-- Ambito Aplicaci�n Elemento
--			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR4 = N'ABEDD291-3991-4A47-8AEB-82580BF6BA8C'		-- Ambito Aplicaci�n Estilos
		-- Caso Modificaci�n:

	DECLARE @PAR6 AS NVARCHAR(250)		-- [IntUsuObjCodUsuUnico] -- codigo unico del Objeto ingresado por el usuario.
		-- Caso Alta: 
			-- Este c�digo se carga manualmente. Aqu� hay que verificar que el mismo no este cargado dos veces.
		-- Caso Modificaci�n: 

	DECLARE @PAR7 AS NVARCHAR(250)		-- [IntUsuObjCodUnico] -- codigo unico del Objeto (Elemento o Estilo).
		-- Caso Alta: 
			-- Este c�digo se carga autom�ticamente, con un n�mero ascendente, dependiendo del nivel y cantidad de elementos similares en la p�gina.
		-- Caso Modificaci�n:

	DECLARE @PAR8 AS NVARCHAR(250) 		-- [IntUsuObjCodDescFuncion] -- descripci�n de la funci�n de ese Objeto (Elemento o Estilo) en la p�gina.
		-- Caso Alta:
			-- Valor asignado por el usuario
		-- Caso Modificaci�n:

	DECLARE @PAR9 AS VARCHAR(36)		-- [ID] de la tabla CIntfTUsuObjArb -- codigo ID de la instancia del Objeto (Elemento o Estilo) insertado en la tabla [CIntfTObjModArb].
		-- Caso Alta: 
			-- Este valor surge de NewID()
		-- Caso Modificaci�n:

	DECLARE @PAR10 AS VARCHAR(36)		-- [IDPadre]		es el ID del Padre, Este surge de la columna anterior. En el caso inicial cuando se crea una nueva p�gina el ID = IDPadre.
		-- Caso Alta: 
			-- En el caso de que sea Page, el ID = IDPadre
		-- Caso Modificaci�n:

	DECLARE @PAR11 AS INT		-- [ItemNivel]		es el nivel del arbol que tiene el objeto. En el caso inicial = 1
		-- Caso Alta: 
			-- Surge de la consulta sobre el nivel

	DECLARE @PAR12 AS INT		-- [ItemOrd]		es el orden dentro del Item Nivel.
		-- Caso Alta: 
			-- Surge de la consulta sobre el orden dentro del nivel. Le agrega un valor.

	DECLARE @PAR13 AS VARCHAR(36)		-- [IDFkCIntfTUsuObj]		es el ID del objeto que se inserto en la Tabla TUsuObj. Este no es el ID del Objeto de la tabla TObjCod.
		-- Caso Alta: 
			-- Para este caso es el mismo del objeto @PAR4


	DECLARE @PAR14 AS VARCHAR(36) 			-- [IDFkCxIEstados] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
		-- Caso Alta:
			-- Es un c�digo ID con las distintas opciones, estas pueden ser. Habilitado, Deshabilitado, Eliminado.
				-- 6B0CD910-C127-4450-9865-15E9F4C287B4	EST	estados			EST	estados
					-- EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0	DES	deshabilitado	EST	estados
					-- 3749D6D8-EF8F-4C37-893A-BE7209239810	ELI	eliminado		EST	estados
					-- C6FE2749-0CB8-49CD-97DF-03C299C0C6CF	HAB	habilitado		EST	estados
		-- Caso Modificaci�n:
			-- Se cambia el estado sin realizar verificaciones. en caso de que se recupere el c�digo, se debe verificar que no se infrinjan las reglas primarias.

	-- Tabla para tomar los valores de las propiedades de los elementos.
	DECLARE @TmpTObjConProp TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
		(
 			-- [ID] [uniqueidentifier] NULL,
			[IDFkTCIntfTObjCod_ObjCod] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
			[ObjCodigo] [nvarchar](50) COLLATE Modern_Spanish_CI_AS NULL,
			[IDFkTCIntfTObjCodProp] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
			[ObjCodValor] [nvarchar](255) COLLATE Modern_Spanish_CI_AS NULL,
			[IDFkTCIntfTObjCod_ObjCodProp] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
			[ObjCodPropValor] [nvarchar](255) COLLATE Modern_Spanish_CI_AS NULL,
			[ObjCodPropOrden] [int] NULL,
			[ObjCodPropValorWeb] [nvarchar](255) COLLATE Modern_Spanish_CI_AS NULL,
			[IDFkCDiccTCod_PropTipo] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
			[ObjPropTipo] [nvarchar](50) COLLATE Modern_Spanish_CI_AS NULL,
			[IDFkCDiccTCod_ObjCodPropEstado] [uniqueidentifier] NULL
	--		[ObjCodPropFechaModif] [datetime] NULL
		)
			
	INSERT INTO @TmpTObjConProp EXEC @return_value = [dbo].[CIntfPObjConPropResu]
	--	SELECT * FROM @TmpTObjConProp

	DECLARE @ValVar AS VARCHAR(50)
	SET @ValVar = 'VAL'

	-- Variables para obtener los valores del procedimiento almacenado de CGetErrorInfo
		DECLARE @RTADO_PROCALM AS VARCHAR(250)
		DECLARE @NOMB_PROCALM AS VARCHAR(250)
		DECLARE @FUNC_PROCALM AS VARCHAR(100)
		DECLARE @RTADO AS VARCHAR(250)
		DECLARE @REG_AFEC AS NUMERIC(18, 0)
		DECLARE @ERR_MESSAGE AS VARCHAR(250)
		DECLARE @ERR_NUMBER AS NUMERIC(18, 0)
		DECLARE @ERR_SEVERITY AS NUMERIC(18, 0)
		DECLARE @ERR_STATE AS NUMERIC(18, 0)
		DECLARE @ERR_LINE AS NUMERIC(18, 0)
		
		SET @NOMB_PROCALM = 'CintfPUsuObjABM'				-- Nombre del procedimiento almacenado.

-- Valores de las variables para generar las prueba del funcionamiento de las consultas.
--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- SETEO DE LAS VARIABLES PARA EL ALTA DE UN CODIGO Y SUS DESCRIPCIONES
		SET @PAR1 = 'ALTA'													-- ALTA - MODIFICACION - BAJA - RECUPERO
		SET @PAR2 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'					-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito

		-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		-- Crea los elementos asignados al objeto -- Tabla [CIntfTObjMod]
		-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		SET @PAR3 = 'AEFEA6F0-CC81-41AB-AD12-354A484273DA'					-- Ele	contiene los elementos de la pagina
				--	ABEDD291-3991-4A47-8AEB-82580BF6BA8C	Css			contiene todos los estilos posibles de la pagina y los elementos
				--	AEFEA6F0-CC81-41AB-AD12-354A484273DA	Ele			contiene los elementos de la pagina
				--	9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B	Pro			contiene las propiedades de la pagina, elementos y estilos
				--	b890dd58-58ba-4da3-8a0c-70422298a88d	ObjMod		contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.

		SET @PAR4 = NEWID()													-- [ID] -- valor ID, debe ser �nico.
		SET @PAR5 = 'B99E0185-49D6-4D9E-89AE-DAA8C754D9A3'					-- [IDFkTIntCodObj] -- codigo ID del Objeto (Elemento o Estilo) al que se insertar� en la p�gina.
--			DECLARE	@return_value int
--			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'AEFEA6F0-CC81-41AB-AD12-354A484273DA'		-- Ambito Aplicaci�n Elemento
--			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'ABEDD291-3991-4A47-8AEB-82580BF6BA8C'		-- Ambito Aplicaci�n Estilos
				--	B99E0185-49D6-4D9E-89AE-DAA8C754D9A3	<a>	etiqueta que define un hiperv�nculo, que se utiliza para enlazar de una p�gina a otra. El atributo m�s importante del elemento <a> es el atributo href, que indica el destino del enlace
				--	62F38F66-AF19-4F62-98D2-5CCCCBB63125	<article>	etiqueta especifica contenido independiente, Un art�culo deber�a tener sentido por s� mismo y deber�a ser posible distribuirlo independientemente del resto del sitio
				--	DEC3F05F-E7C3-476F-BEAA-F2FE3A79BC99	<aside>	etiqueta define alg�n contenido aparte del contenido en el que se encuentra, pero este debe estar relacionado con el contenido que lo rodea
				--	EE8E9BBA-E7FD-40AA-A97F-9A085126B841	<body>	cuerpo de la pagina
				--	8BA11A28-67B7-4A15-B2E2-E5A30FCCB8FE	<br>	salto de pagina
				--	CBC7CCD2-6825-4288-A1EE-07C83D57FE97	<div>	seccion de pagina
				--	F9DA8C8E-925D-4C2A-BF1C-EA363BEB3D41	<doctype>	tipo de documento
				--	60F2A98E-23BC-4BFF-9C13-9FE3D922C4D9	<footer>	pie de p�gina
				--	4E3F5983-416B-47C5-918E-C7B4910C017F	<form>	formulario
				--	6A20FFB1-EF83-46AC-9DDA-9C37096B489D	<h1>	titulo h1
				--	66C2E055-CB9B-41FC-AD33-E5DF741CE7A8	<h2>	titulo h2
				--	116D43EC-D0FF-4915-B878-099A2ABE4EC6	<h3>	titulo h3
				--	DCF47D44-133A-4865-ADC0-57869979F845	<h4>	titulo h4
				--	C8BC46DE-7EA5-40F7-849C-8E381698CB93	<h5>	titulo h5
				--	FF6D64CD-B3CC-48D4-9409-634C25D9CA96	<h6>	titulo h6
				--	BEF7DACA-65E9-4662-89C8-35BC84274009	<head>	encabezado a nivel pagina
				--	79362741-DB66-4010-B494-9697786D8AA6	<header>	representa un contenedor para contenido introductorio o un conjunto de enlaces de navegaci�n
				--	E31EC871-F1C8-48F5-9C34-77326C46BB4D	<html>	hepertext markup languages
				--	EF69A94B-5C69-430C-A066-B6336A153A05	<inputcheck>	opcion de chequeo
				--	13C46A05-262C-48C4-BD29-7A5D0BB91D22	<inputpass>	ingreso de password
				--	CC3414AF-7742-4AFD-8EDA-E8D00130A553	<inputsubmit>	boton de env�o
				--	5432E780-F1C7-4D2E-B4C6-53DD7A9D729D	<inputtext>	campo de ingreso
				--	4BFD72B4-D915-413D-A9AF-3B93D448E543	<label>	texto
				--	CB6255ED-613B-4636-A971-2A2466CBC16E	<li>	etiqueta que define un elemento de la lista, se usa en listas ordenadas (<ol>), listas desordenadas (<ul>) y en listas de men� (<menu>)
				--	CCD03587-4CFE-4088-A699-6F8E8AD31088	<link>	permite vincular un archivo externo o documento
				--	75A8EA76-C0A0-4DA1-A07F-1E1FF1514043	<meta>	especificaciones de la p�gina
				--	9C4DD333-995B-4856-AB05-CBCEA7CBED31	<nav>	etiqueta que define un conjunto de enlaces de navegaci�n
				--	D16482D8-9D50-4A2B-BD3F-654CF56864AA	<ol>	etiqueta que define una lista ordenada. Una lista ordenada puede ser num�rica o alfab�tica. Use la etiqueta <li> para definir los elementos de la lista
				--	CB0D1A8F-E833-41E1-9272-173A230C9D78	<p>	parrafo
				--	A96324E5-B360-4D6D-9486-4DFD63565F70	<page>	pagina web
				--	5CE0D99D-230B-4C90-A5FF-C3FD6D37F095	<script>	script relacionados a la p�gina
				--	46BC5283-24AA-4B11-88F8-30D29AB09297	<section>	define las secciones de un documento, como cap�tulos, encabezados, pies de p�gina o cualquier otra secci�n del documento
				--	7E7703AF-582E-45E5-BB60-3D5735E37379	<title>	es el t�tulo de la lengueta de la p�gina
				--	EEA070F1-6BB2-41CB-BB3D-AD49549EB186	<ul>	etiqueta que define una lista desordenada (con vi�etas), Use la etiqueta <ul> junto con la etiqueta <li> para crear listas

		-- Este c�digo es autom�tico, ya que no se puede repetir cuando se hace la p�gina web.
		SELECT @PAR6 = CxI.[CodigoWeb]					-- [IntUsuObjCodUnico] -- codigo unico del Objeto (Elemento o Estilo).
		  FROM [BDCtral].[dbo].[CIntfTObjCod] AS OC WITH(NOLOCK)
			 INNER JOIN [BDCtral].[dbo].[CIntfTObjCodxIdio] AS CxI WITH(NOLOCK)
					ON OC.[ID] = CxI.[IDFkTCIntfTObjCod_CodxIdio] 
							AND
						@PAR2 = CxI.[IDFkTCDiccTIdio_Idioma]
							AND
						@PAR3 = CxI.[IDFkTCIntfTObjCod_AmbAplic]
			WHERE OC.[ID] = @PAR5

		SET @PAR7 = NULL --	'INTUSU01'					-- [IntUsuObjCodUsuUnico] -- codigo unico del Objeto ingresado por el usuario.
					--	Si el usuario no incorpor� un c�digo, se pone null
	
		SET @PAR8 = 'vinculo'					-- [IntUsuObjCodDescFuncion] -- descripci�n de la funci�n de ese Objeto (Elemento o Estilo) en la p�gina.

-- ##################################################################################################
-- Hay un error, inserta los valores y deja con inconsistencias la base de datos
-- ##################################################################################################

--		SELECT @PAR1, @PAR2, @PAR3, @PAR4, @PAR5, @PAR6, @PAR8 

		-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		-- Crea la Estructura Arbol -- Tabla [CIntfTObjModArb]
		-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		-- Informaci�n para cargar la estructura Arbol, O SEA D�nde va el Objeto en la P�gina.
		-- [ID]				de la tabla CIntfTUsuObjArb
		SET @PAR9 = NEWID()													-- C�digo ID unico del Objeto dentro de la estructura arbol
			
		-- [IDPadre]		es el ID del Padre, Este surge de la columna anterior. En el caso inicial cuando se crea una nueva p�gina el ID = IDPadre.
		-- Determinar el IDPadre		ID de la tabla [CIntfTObjMod]

		-- ID del Padre, este valor es manual
		SET @PAR10 = '0EC1BCD9-29EE-4598-80C6-EC939EFD37F4'	--	ID del Padre, de la tabla [CIntfTObjModArb]	
		-- 1.- En el caso que es el Padre Inicial, el ID viene de la tabla [CIntfTObjCod] y [CIntfTObjCodxIdio]
			-- se pueden ver los distintos Objetos en la consulta siguiente
			-- Detalle de los Objetos Modelos, Son los Padres
--					SELECT [IDgdicTCodigos], [Codigo], [Descripcion]
--					  FROM [BDCtral].[dbo].[CIntfVCodigos]
--					WHERE [IDFkTCIntfTObjCod_AmbAplic] = 'b890dd58-58ba-4da3-8a0c-70422298a88d'
--							AND [IDFkTCDiccTIdio_Idioma] = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'
						--	6EFA0E33-F537-4861-A35F-10ECB328FB74	PiePag001	pie de la p�gina
						--	5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D	EncPag001	encabezado de la p�gina
						--	B890DD58-58BA-4DA3-8A0C-70422298A88D	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
						--	57504A29-9F06-41B2-896C-81D5A57E37BF	EstWeb001	Estructura de la p�gina Web hasta el Body

		-- 2.- En el caso de que otro elemento sea el padre, hay que buscar el ID, para incorporarlo como padre,
			--  esta infor se saca de la siguiente consulta, hacer la consulta del bucle.
--				SELECT OMA.[ID]
--				--      ,OMA.[IDFkCIntfTObjMod]
--					  ,[ObjModCodUnico]
--					  ,[ObjModCodDescFuncion]
--					  ,OMA.[ItemNivel]
--					  ,OMA.[ItemOrd]
--				  FROM [BDCtral].[dbo].[CIntfTObjModArb] AS OMA WITH(NOLOCK)
--					INNER JOIN [BDCtral].[dbo].[CIntfTObjMod] AS OM WITH(NOLOCK)
--						ON OMA.[IDFkCIntfTObjMod] = OM.[ID]
--				ORDER BY OMA.[ItemNivel]
--					  ,OMA.[ItemOrd]

	
		-- [ItemNivel]		es el nivel del arbol que tiene el objeto. En el caso inicial = 1
		DECLARE @PADNIVEL AS INT		-- Padre Nivel
		DECLARE @PADITEMORD AS INT		-- Padre Orden

		SELECT @PADNIVEL = MAX([ItemNivel]), @PADITEMORD = MAX([ItemOrd])
		  FROM [BDCtral].[dbo].[CIntfTObjModArb]
		WHERE [ID] = @PAR10
		
		SET @PAR11 = CASE WHEN @PADNIVEL IS NULL THEN 1 ELSE @PADNIVEL + 1 END
		SET @PADNIVEL = CASE WHEN @PADNIVEL IS NULL THEN 0 ELSE @PADNIVEL END

		SET @PADITEMORD = CASE WHEN @PADITEMORD IS NULL THEN 0 ELSE @PADITEMORD END

--		SELECT @PAR10 AS [PAR10], @PADNIVEL AS [PadNivel], @PADITEMORD AS [PadItemOrd]
		
		-- [ItemOrd]		es el orden dentro del Item Nivel.
		DECLARE @HIJOITEMORD AS INT
		SELECT @HIJOITEMORD = MAX([ItemOrd])
		  FROM [BDCtral].[dbo].[CIntfTObjModArb]
		WHERE ([ID] <> [IDFkCIntfTObjModArb_PadreID]) AND [IDFkCIntfTObjModArb_PadreID] = @PAR10

		SET @PAR12 = CASE WHEN @HIJOITEMORD IS NULL THEN 1 ELSE @HIJOITEMORD + 1 END
		SET @HIJOITEMORD = CASE WHEN @HIJOITEMORD IS NULL THEN 0 ELSE @HIJOITEMORD END

--		SELECT @PADNIVEL AS [PadNivel], @PADITEMORD AS [PadItemOrd], @HIJOITEMORD AS [HijoItemOrd]

		-- Le asigna el Nivel y Orden al nombre �nico del objeto
		-- Para cargar este valor debe tener el Nivel del Padre, a esto se le agrega el valor.
		SET @PAR6 = @PAR6 + CAST(@PADNIVEL AS VARCHAR(3))  + CAST(@PADITEMORD AS VARCHAR(3)) + CAST(@PAR11 AS VARCHAR(3)) + CAST(@PAR12  AS VARCHAR(3))

		-- [IDFkCIntfTUsuObj]		es el ID del objeto que se inserto en la Tabla TUsuObj. Este no es el ID del Objeto de la tabla TObjCod.
		SET @PAR13 = @PAR4					-- Para este caso es el mismo del objeto @PAR4

		SET @PAR14 = 'c6fe2749-0cb8-49cd-97df-03c299c0c6cf'					-- [IDFkCxIEstados] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado

--			SELECT @PAR1 AS 'P01_Accion', @PAR2 AS 'P02_Idioma', @PAR3 AS 'P03_AmbAplic', @PAR4 AS 'P04_IDCintfObjMod', @PAR5 AS 'P05_IDFkTIntCodObj', @PAR6 AS 'P06_IntUsuObjCodUnico', @PAR7 AS 'P07_[IntUsuObjCodUsuUnico', @PAR8 AS 'P08_IntUsuObjCodDescFuncion', @PAR9 AS 'P09_IDCIntfTObjModArb', @PAR10 AS 'P10_IDPadre', @PAR11 AS 'P11_ItemNivel', @PAR12 AS 'P12_ItemOrden', @PAR13 AS 'P13_IDFkCIntfTUsuObj', @PAR14 AS 'P14_IDFkCxIEstados'

		SET @ValVar = CASE WHEN @PAR1 IS NULL THEN 'Err' 
							WHEN @PAR2 IS NULL THEN 'Err' 
							WHEN @PAR3 IS NULL THEN 'Err' 
							WHEN @PAR4 IS NULL THEN 'Err' 
							WHEN @PAR5 IS NULL THEN 'Err' 
							WHEN @PAR6 IS NULL THEN 'Err' 
--							WHEN @PAR7 IS NULL THEN 'Err'		-- No se utiliza
							WHEN @PAR8 IS NULL THEN 'Err' 
							WHEN @PAR9 IS NULL THEN 'Err' 
							WHEN @PAR10 IS NULL THEN 'Err' 
							WHEN @PAR11 IS NULL THEN 'Err' 
							WHEN @PAR12 IS NULL THEN 'Err' 
							WHEN @PAR13 IS NULL THEN 'Err' 
							WHEN @PAR14 IS NULL THEN 'Err' 
							ELSE @ValVar 
						END
--		SELECT @ValVar

--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	-- SETEO DE LAS VARIABLES PARA LA MODIFICACION DE UN CODIGO Y SUS DESCRIPCIONES
--		SET @PAR1 = 'MODIFICACION'											-- ALTA - MODIFICACION - BAJA - RECUPERO
--		SET @PAR4 = 'ABE14F0E-8DF7-4492-9DB9-77199807D80A'					-- ID del codigo, debe ser �nico
--		SET @PAR5 = 'FB478ECC-85FE-4FC8-B792-CAF8ECB921B1'					-- ID del Idioma	-- Espa�ol		
--		SET @PAR6 = '528CEED9-D2B3-4CB5-8116-01BDAD455C83'					-- ID del Ambito de Aplicaci�n del C�digo -- Usuarios	
--		SET @PAR8 = 'PPVTGTIA'													-- C�digo, debe ser �nico
--		SET @PAR14 = 'personal postventa garantia'												-- Descripcion del codigo
--		SET @PAR14 = 'c6fe2749-0cb8-49cd-97df-03c299c0c6cf'					-- Habilitado
--		SET @PAR14 = 'AltaCompleto'

---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- Valores de las variables para agregarle al codigo ID, solo el Codigo por Idioma nuevo. No agrega el cogido porque ya existe para un idioma.
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	-- SETEO DE LAS VARIABLES PARA EL ALTA DE UN CODIGO Y SUS DESCRIPCIONES
--		SET @PAR1 = 'ALTA'												-- ALTA - MODIFICACION - BAJA - RECUPERO
--		SET @PAR4 = '3749D6D8-EF8F-4C37-893A-BE7209239810'					-- ID del codigo, este ya es un codigo generado
--		SET @PAR5 = 'b1268278-4eb3-4a93-8f67-0d425b767c65'					-- ID del Idioma
----				ee954f5d-ca27-48a9-a23b-010788b18631	ITA	italiano
----				b1268278-4eb3-4a93-8f67-0d425b767c65	ENG	english
----				a455281d-76f5-4bad-8dbb-201c5928aaf8	FRA	fran�ais
----				1048c13b-1cc9-4154-8b8b-64ca9ac9fe12	POR	portugu�s
----				fb478ecc-85fe-4fc8-b792-caf8ecb921b1	ESP	espa�ol
--		SET @PAR6 = '6B0CD910-C127-4450-9865-15E9F4C287B4'					-- ID del Ambito de Aplicaci�n del C�digo -- Usuarios	
--		SET @PAR8 = 'REM'													-- C�digo, debe ser �nico
--		SET @PAR14 = 'removed'													-- Descripcion del codigo
--		SET @PAR14 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'					-- Habilitado
--		SET @PAR14 = 'SoloCodxIdio'
--
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- Pasos antes de hacer ABM de los datos:
	-- Etapa 1: Primero verificar que con el cambio no se infrinja ninguna clave primaria
	-- Etapa 2: 
			-- 1: Si el resultado es que se infrinje, no realizar el cambio e informar al usuario
			-- 2: Si es todo OK, se realiza el cambio. Para hacer esto se hace una transacci�n para asegurar la integridad del cambio.	

IF @PAR1 = 'ALTA'
BEGIN
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- ##############################################################################################################################################
	-- INICIO -- ALTA DE CODIGO Y SUS DESCRIPCIONES
	-- ##############################################################################################################################################
	
	SET @FUNC_PROCALM = 'Alta'		-- Funcion dentro del procedimiento almacenado.

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Para agregar un nuevo C�digo, se debe:
		-- Aqu� hay ciertos elementos que en una pagina no se pueden duplicar.
		-- Esta validaci�n hay que hacerla luego.
		-- Los otros campos pueden tener cualquier valor, no se validan.

		-- Aclaraci�n: La combinaci�n m�s ID del Ambito de Aplicaci�n, por lo tanto para un idioma, puede haber dos c�digos iguales, pero cada uno para un ambito de aplicaci�n diferente.

	-- Etapa 1: Verifica Clave Primaria: que el objeto creado puede tener solamente una propiedad una sola vez
		-- Si alguno de los valores son encontrados, la variable @PAR4 se pone a NULL
--		SELECT @PAR4 = NULL
--		  FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK)
--		WHERE [IDFkTObjCod] = @PAR5 AND [IDFkTCodObjProp] = @PAR6
			-- Clave Primaria: -- IDFkTObjCod, IDFkTCodObjProp.
		--		SELECT @PAR4

	-- Etapa 2: 
			-- 1: Si el C�digo infringe la clave primaria, no hace el cambio e informa al usuario
		IF @PAR4 IS NULL OR @ValVar = 'Err'
			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			BEGIN
				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
				SET @RTADO = 'ERR' 
				SET @REG_AFEC = 0
				SET @ERR_MESSAGE = 'Error al intentar cargar la informaci�n.'
				SET @ERR_NUMBER = 0
				SET @ERR_SEVERITY = 0
				SET @ERR_STATE = 0
				SET @ERR_LINE = 0
			END
		ELSE
			-- 2: Si es todo OK, se realiza el cambio.
			BEGIN TRY
			BEGIN TRANSACTION;
			-- Inserta el codigo en las tablas. 
				
				-- PRIMERO en la tabla [CIntfTObjMod]		Inserta los objetos de la p�gina
				BEGIN
					INSERT INTO [BDCtral].[dbo].[CIntfTObjMod]
							   ([ID]
							   ,[IDFkCIntfTObjCod_ObjMod]
							   ,[ObjModCodUnico]
							   ,[ObjModCodDescFuncion]
							   ,[IDFkCDiccTCod_ObjModEst]
							   ,[ObjModFechaModif])
					SELECT @PAR4				-- [ID] -- valor ID, debe ser �nico.
							, @PAR5				-- [IDFkCIntfTObjCod_ObjMod]	-- codigo ID del Objeto (Elemento o Estilo) que se insertar� en la p�gina.
							, @PAR6				-- [ObjModCodUnico]				-- codigo unico del Objeto (Elemento o Estilo).
							, @PAR8				-- [ObjModCodDescFuncion]		-- descripci�n de la funci�n de ese Objeto (Elemento o Estilo) en la p�gina.
							, @PAR14			-- [IDFkCDiccTCod_ObjModEst]	-- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
							, GETDATE()			-- [ObjModFechaModif]			-- Fecha de Modificaci�n

				-- SEGUNDO en la tabla [CIntfTObjModArb]		Inserta el nivel y orden de los objetos
					INSERT INTO [BDCtral].[dbo].[CIntfTObjModArb]
							   ([ID]
							   ,[IDFkCIntfTObjModArb_PadreID]
							   ,[ItemNivel]
							   ,[ItemOrd]
							   ,[IDFkCIntfTObjMod])
					 SELECT @PAR9						-- C�digo ID unico del Objeto dentro de la estructura arbol
							,@PAR10						-- [IDPadre]				es el ID del Padre.
							,@PAR11						-- [ItemNivel]				es el nivel del arbol que tiene el objeto. En el caso inicial = 1
							,@PAR12						-- [ItemOrd]				es el orden dentro del Item Nivel.
							,@PAR13						-- [IDFkCIntfTObjMod]		es el ID del objeto que se inserto en la Tabla CIntfTObjMod.


				-- TERCERO en la tabla [CIntfTObjModProp]
					-- Inserta las propiedades Obligatorias
					INSERT INTO [BDCtral].[dbo].[CIntfTObjModProp]
							   ([ID]
							   ,[IDFkCIntfTObjMod_ObjModID]
							   ,[IDFkCintfTObjCodProp_ObjModProp]
							   ,[ObjModCodPropValor]
							   ,[ObjModCodPropOrden]
							   ,[IDFkCDiccTCod_ObjModPropEst]
							   ,[ObjModPropFechaModif])
					SELECT NEWID() AS [ID]							-- [ID] unico del objeto modelo propiedad
							, @PAR4									-- [ID] tabla [IDFkCIntfTObjMod_ObjModID] -- codigo ID �nico del objeto que se esta insertando
--							, [IDFkTCIntfTObjCod_ObjCod]			-- [ID] tabla [IDFkCIntfTObjMod_ObjModID]-- codigo ID �nico del objeto al que se le asignar�la propiedad.
				--			, [ObjCodigo]
				--			, [IDFkTCIntfTObjCodProp]
				--			, [ObjCodValor]
							, [IDFkTCIntfTObjCod_ObjCodProp]		-- [ID] tabla [IDFkCintfTObjCodProp_ObjModProp] -- valor ID �nico de la Propiedad
							, [ObjCodPropValor]						-- [ObjModCodPropValor] -- valor del Objeto
							, [ObjCodPropOrden]						-- [ObjModCodPropOrden] -- orden en que se armara el TAG
				--			, [ObjCodPropValorWeb]
				--			, [IDFkCDiccTCod_PropTipo]
				--			, [ObjPropTipo]
							, [IDFkCDiccTCod_ObjCodPropEstado]		-- [IDFkCDiccTCod_ObjModPropEst] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
							, GETDATE()								-- [ObjModPropFechaModif] -- Fecha de Modificaci�n
					FROM @TmpTObjConProp
						WHERE [IDFkTCIntfTObjCod_ObjCod] = @PAR5
								AND
							[IDFkCDiccTCod_PropTipo] = 'CC9699C0-B646-427E-B545-7AAFB23D5B95'
					
--				-- CUARTO en la tabla [CIntfTObjModArbEst]
--					EXEC @return_value = [dbo].[CIntfTObjModArbEstABM] 
--						@PAR1 = @PAR2		-- Idioma elegido o por defecto = espa�ol
--						,@PAR2 = @PAR10		-- [IDPadre] es el ID del Padre.
--
--				-- QUINTO en la tabla [CIntfTObjModArbWeb]
--					EXEC	@return_value = [dbo].[CintfPObjModArbWebABM]
--								@PAR1 = @PAR10		-- [IDPadre] es el ID del Padre.
--								,@PAR2 = @PAR2		-- Idioma elegido o por defecto = espa�ol

				END
				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
				BEGIN
					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
					SET @RTADO = 'OK' 
					SET @REG_AFEC = 1
					SET @ERR_MESSAGE = 'Se cargo la informacion solicitada.'
					SET @ERR_NUMBER = 0
					SET @ERR_SEVERITY = 0
					SET @ERR_STATE = 0
					SET @ERR_LINE = 0
				END
			
				-- Si el procedimiento es exitoso, confirma la operaci�n.
				COMMIT TRANSACTION;
			END TRY
			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
			BEGIN CATCH

				-- Ejecuta el Procedimiento Almacenado para obtener el error.
				EXECUTE [dbo].[CGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT

				-- Como la operaci�n fall�, se deshacen las modificaciones.
				ROLLBACK TRANSACTION;

				-- Por las dudas se elimana el registro con el ID generado.
				DELETE FROM [BDCtral].[dbo].[CIntfTObjMod] WHERE [ID] = @PAR4
				DELETE FROM [BDCtral].[dbo].[CIntfTObjModArb] WHERE [ID] = @PAR9
				DELETE FROM [BDCtral].[dbo].[CIntfTObjModProp] WHERE [IDFkCIntfTObjMod_ObjModID] = @PAR4

				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				SET @RTADO = 'ERR'
				SET @REG_AFEC = 0
			END CATCH;

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- ##############################################################################################################################################
	-- FINAL -- ALTA DE CODIGO Y SUS DESCRIPCIONES
	-- ##############################################################################################################################################
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
END
--
--
--ELSE 
--IF @PAR1 = 'MODIFICACION'
--BEGIN
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- ##############################################################################################################################################
---- INICIO	-- MODIFICACION DE CODIGO Y SUS DESCRIPCIONES
---- ##############################################################################################################################################
--	
--	SET @FUNC_PROCALM = 'Modificacion'		-- Funcion dentro del procedimiento almacenado.
--
--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	-- Para modificar un nuevo C�digo, se debe:
--		-- Clave Primaria: IDC�digo [IDFkTIntCodigos], IDIdiomas [IDFkTIdioma], IDAmbitoAplicaci�n [IDFkTCodAmbAplic], C�digo Unico [Codigo]
--		-- Los otros campos pueden tener cualquier valor, no se validan.
--
--		-- Aclaraci�n: La combinaci�n m�s ID del Ambito de Aplicaci�n, por lo tanto para un idioma, puede haber dos c�digos iguales, pero cada uno para un ambito de aplicaci�n diferente.
--
--	-- Etapa 1: Verifica Clave Primaria: que el objeto creado puede tener solamente una propiedad una sola vez
--		-- Si alguno de los valores son encontrados, la variable @PAR4 se pone a NULL
----		SELECT @PAR4 = NULL
----		  FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK)
----		WHERE [IDFkTObjCod] = @PAR5 AND [IDFkTCodObjProp] = @PAR6
--			-- Clave Primaria: -- IDFkTObjCod, IDFkTCodObjProp.
--		--		SELECT @PAR4
--
--	-- Etapa 2: 
--			-- Si el codigo ya esta utilizado, infrinje la clave primaria, no hace los cambios e informa al usuario.
--		IF @PAR4 IS NULL
--			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
--			BEGIN
--				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
--				SET @RTADO = 'ERR' 
--				SET @REG_AFEC = 0
--				SET @ERR_MESSAGE = 'El Objeto ingresado ya tiene asignado esa propiedad.'
--				SET @ERR_NUMBER = 0
--				SET @ERR_SEVERITY = 0
--				SET @ERR_STATE = 0
--				SET @ERR_LINE = 0
--			END
--		ELSE
--			-- 2: Si es todo OK, se realiza el cambio.
--			BEGIN TRY
--			BEGIN TRANSACTION;
--				-- Modifica el codigo en la tabla. Le puede cambiar el idioma, ambito de aplicacion, el codigo, su descripcion y el estado.
----				UPDATE [BDCtral].[dbo].[CintfTObjCodProp]
----				   SET [IDFkTObjCod] = @PAR5
----					  ,[IDFkTCodObjProp] = @PAR6
----					  ,[IntObjValor] = @PAR8
----					  ,[IntObjOrden] = @PAR14
----					  ,[IDFkCxIEstados] = @PAR14
----					  ,[TObjCodProFechaModif] = GETDATE()
----				 WHERE [ID] = @PAR4
--
--				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
--				BEGIN
--					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
--					SET @RTADO = 'OK' 
--					SET @REG_AFEC = 1
--					SET @ERR_MESSAGE = 'Se modific� la informacion solicitada.'
--					SET @ERR_NUMBER = 0
--					SET @ERR_SEVERITY = 0
--					SET @ERR_STATE = 0
--					SET @ERR_LINE = 0
--				END
--			
--				-- Si el procedimiento es exitoso, confirma la operaci�n.
--				COMMIT TRANSACTION;
--			END TRY
--			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
--			BEGIN CATCH
--
--				-- Ejecuta el Procedimiento Almacenado para obtener el error.
--				EXECUTE [dbo].[CGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT
--
--				-- Como la operaci�n fall�, se deshacen las modificaciones.
--				ROLLBACK TRANSACTION;
--
--				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
--				SET @RTADO = 'ERR'
--				SET @REG_AFEC = 0
--			END CATCH;
--
---- ##############################################################################################################################################
---- FINAL	-- MODIFICACION DE CODIGO Y SUS DESCRIPCIONES
---- ##############################################################################################################################################
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--END
--
--ELSE
--IF @PAR1 = 'BAJA'
--BEGIN
---- ##############################################################################################################################################
---- INICIO	-- BAJA DE CODIGO Y SUS DESCRIPCIONES
---- ##############################################################################################################################################
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	SET @FUNC_PROCALM = 'Baja'		-- Funcion dentro del procedimiento almacenado.
--
--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	-- Para dar de baja un C�digo, se debe:
--		-- Cambiar solo el estado. No se elimina ya que puede afectar las relaciones asociadas.
--	-- Etapa 1: verifica que el codigo ya no est� dado de baja.
----		SELECT @PAR4 = NULL		-- Si alguno de los valores son encontrados, la variable @PAR4 se pone a NULL
----		  FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK)
----		WHERE [IDFkCxIEstados] = '3749D6D8-EF8F-4C37-893A-BE7209239810'		-- ELI	eliminado		EST	estados
--		-- Si encuentra el registro quiere decir que el c�digo ya esta dado de baja.
--		--		SELECT @PAR4
--
--	-- Etapa 2: 
--			-- 1: Si el codigo ya esta dado de baja, no hace nada, solo le informa al usuario.
--		IF @PAR4 IS NULL
--			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
--			BEGIN
--				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
--				SET @RTADO = 'ERR' 
--				SET @REG_AFEC = 0
--				SET @ERR_MESSAGE = 'El c�digo ingresado ya esta dado de baja.'
--				SET @ERR_NUMBER = 0
--				SET @ERR_SEVERITY = 0
--				SET @ERR_STATE = 0
--				SET @ERR_LINE = 0
--			END
--		ELSE
--			-- 2: El c�digo esta para darle de baja, procede a hacerlo.
--			BEGIN TRY
--			BEGIN TRANSACTION;
--				-- Elimina el codigo en la tabla. Para ello le agrega la leyenda '-ELI', si supera la cantidad de d�gitos permitidos del campo, le reduce el c�digo original.
--				-- el c�digo no se elimina, pero al ponerle -ELI, el codigo anterior se puede usar nuevamente
----				UPDATE [BDCtral].[dbo].[CintfTObjCodProp]
----				   SET [IntObjValor] = CASE WHEN LEN ([IntObjValor] + '-ELI') >= 54 THEN (SUBSTRING([IntObjValor], 1, 50) + '-ELI') ELSE [IntObjValor] + '-ELI' END			-- Le pone la leyenda que el c�digo esta eliminado.
----						,[IDFkCxIEstados] = @PAR14			-- Le pone el estado de eliminado.
----				WHERE [ID] = @PAR4
--
--				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
--				BEGIN
--					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
--					SET @RTADO = 'OK' 
--					SET @REG_AFEC = 1
--					SET @ERR_MESSAGE = 'Se elimin� el c�digo indicado.'
--					SET @ERR_NUMBER = 0
--					SET @ERR_SEVERITY = 0
--					SET @ERR_STATE = 0
--					SET @ERR_LINE = 0
--				END
--			
--				-- Si el procedimiento es exitoso, confirma la operaci�n.
--				COMMIT TRANSACTION;
--			END TRY
--			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
--			BEGIN CATCH
--				-- Ejecuta el Procedimiento Almacenado para obtener el error.
--				EXECUTE [dbo].[CGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT
--
--				-- Como la operaci�n fall�, se deshacen las modificaciones.
--				ROLLBACK TRANSACTION;
--
--				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
--				SET @RTADO = 'ERR'
--				SET @REG_AFEC = 0
--			END CATCH;
--
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- ##############################################################################################################################################
---- FINAL	-- BAJA DE CODIGO Y SUS DESCRIPCIONES
---- ##############################################################################################################################################
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--END
--
--ELSE
--IF @PAR1 = 'RECUPERO'
--BEGIN
---- ##############################################################################################################################################
---- INICIO	-- RECUPERO DE CODIGO Y SUS DESCRIPCIONES
---- ##############################################################################################################################################
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	SET @FUNC_PROCALM = 'Recupero'		-- Funcion dentro del procedimiento almacenado.
--
--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	-- Para recuperar un C�digo, se debe:
--		-- Cambiar solo el estado. Ya que no se elimina, solo se debe verificar que ese c�digo que vuelve a funcionar, 
--		-- no est� utilizado y por ende infrinja la regla primaria.
--		-- Clave Primaria: IDC�digo [IDFkTIntCodigos], IDIdiomas [IDFkTIdioma], IDAmbitoAplicaci�n [IDFkTCodAmbAplic], C�digo Unico [Codigo]
--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--
--	-- Etapa 1: verifica que el codigo est� dado de baja, si no es as� le informa al usuario.
----		SELECT @PAR4 = NULL		-- Si alguno de los valores son encontrados, la variable @PAR4 se pone a NULL
----		  FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK)
----		WHERE [ID] = @PAR4													-- ID del c�digo.
----				AND [IDFkCxIEstados] <> '3749D6D8-EF8F-4C37-893A-BE7209239810'			-- Estado Eliminado
--		--		SELECT @PAR4
--
--		-- Etapa 2: 
--				-- 1: Si el codigo NO esta dado de baja, no hace nada y le informa al usuario.
--		IF @PAR4 IS NULL
--			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
--			BEGIN
--				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
--				SET @RTADO = 'ERR' 
--				SET @REG_AFEC = 0
--				SET @ERR_MESSAGE = 'El c�digo ingresado no est� dado de baja.'
--				SET @ERR_NUMBER = 0
--				SET @ERR_SEVERITY = 0
--				SET @ERR_STATE = 0
--				SET @ERR_LINE = 0
--			END
--		ELSE
--
--		-- Etapa 3: Ya sabemos que el c�digo esta dado de baja. Verificamos que no infrinja la clave primaria.
--				-- Clave Primaria: IDC�digo [IDFkTIntCodigos], IDIdiomas [IDFkTIdioma], IDAmbitoAplicaci�n [IDFkTCodAmbAplic], C�digo Unico [Codigo]
--		-- Aclaraci�n:
--				-- Ahora verificamos si el valor que tiene el c�digo, fue utilizado por alg�n c�digo activo.
--				-- Si el c�digo esta repetido, le agrega la palabra 'REC-' valor ID, y si no tiene espacio, le reduce el c�digo original. De esta manera no se duplica nunca el c�digo.
--				-- el usuario luego debe modificar el c�digo indicado.
----		SELECT @PAR8 = NULL
----		  FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK)
----		WHERE [IDFkTObjCod] = @PAR5 AND [IDFkTCodObjProp] = @PAR6		-- Primero verifica que no se infrinja la clave primaria: C�digoID - Idioma - Ambito Aplicacion - C�digo
--		-- Si el codigo ya esta utilizado agrega el c�digo m�s una leyenda de 4 caracteres y le cambia el estado a habilitado.
--		--		SELECT @PAR8
--
--		-- Etapa 4: Si el codigo ya esta utilizado, Verifica el OK con el c�digo modificado
--		IF @PAR8 IS NULL
--			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
--			BEGIN
----				-- Como el c�digo ya esta utilizado, le pone el ID al C�digo para que no haya forma de duplicidad.
----				SELECT @PAR8 = SUBSTRING([IDFkTObjCod], 1, 18) + @PAR4
----					FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK)
----				WHERE [ID] <> @PAR4
----				GOTO HaceCambio
----				-- Ya le realizo a la variable que tiene el c�digo, ahora lo implementa en la transacci�n.
--			END
--		ELSE
--HaceCambio:
--			BEGIN TRY
--			BEGIN TRANSACTION;
--				-- Modifica el codigo en la tabla. Le puede cambiar el idioma, ambito de aplicacion, el codigo, su descripcion y el estado.
--
--				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
--				BEGIN
--					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
--					SET @RTADO = 'OK' 
--					SET @REG_AFEC = 1
--					SET @ERR_MESSAGE = 'Se recuper� el c�digo indicado.'
--					SET @ERR_NUMBER = 0
--					SET @ERR_SEVERITY = 0
--					SET @ERR_STATE = 0
--					SET @ERR_LINE = 0
--				END
--			
--				-- Si el procedimiento es exitoso, confirma la operaci�n.
--				COMMIT TRANSACTION;
--			END TRY
--			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
--			BEGIN CATCH
--
--				-- Ejecuta el Procedimiento Almacenado para obtener el error.
--				EXECUTE [dbo].[CGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT
--
--				-- Como la operaci�n fall�, se deshacen las modificaciones.
--				ROLLBACK TRANSACTION;
--
--				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
--				SET @RTADO = 'ERR'
--				SET @REG_AFEC = 0
--			END CATCH;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- FINAL	-- RECUPERO DE CODIGO Y SUS DESCRIPCIONES
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--END


-- ##############################################################################################################################################
-- MUESTRA EL RESULTADO DEL PROCEDIMIENTO ALMACENADO
-- Envia el resultado: Nombre Proc Alm | Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
--SET @RTADO_PROCALM = @NOMB_PROCALM + '|' + @FUNC_PROCALM + '|' + @RTADO + '|' + CAST(@REG_AFEC AS VARCHAR(10)) + '|' + @ERR_MESSAGE + '|' + CAST(@ERR_NUMBER AS VARCHAR(10)) + '|' + CAST(@ERR_SEVERITY AS VARCHAR(10)) + '|' + CAST(@ERR_STATE AS VARCHAR(10)) + '|' + CAST(@ERR_LINE AS VARCHAR(10))
--SELECT @RTADO_PROCALM			-- Muestra el resulado en una unica columna
SELECT @NOMB_PROCALM AS ProcAlm_Nomb, @FUNC_PROCALM AS ProcAlm_Funcion, @RTADO AS ProcAlm_Rtado, @REG_AFEC AS ProcAlm_RegAfec, @ERR_MESSAGE AS ProcAlm_Mensaje, @ERR_NUMBER AS ProcAlm_ErrNum, @ERR_SEVERITY AS ProcAlm_ErrSeveridad, @ERR_STATE AS ProcAlm_ErrEstado, @ERR_LINE AS ProcAlm_ErrLinea
 
-- DECLARE @return_value int
 DECLARE @PARInt01 AS VARCHAR(36)	-- IDFkTIdioma -- codigo del idioma para ese codigo
 DECLARE @PARInt02 AS VARCHAR(36)	-- Ambito de Aplicaci�n elegido o por defecto = NULL
 DECLARE @PARInt03 AS VARCHAR(36)	-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
	SET @PARInt01 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'			-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
			-- Idioma espa�ol por defecto
	SET @PARInt02 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'			-- Ambito de Aplicaci�n elegido o por defecto = NULL
			-- ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
	SET @PARInt03 = '5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D'			-- Padre Inicial de toda la estructura, sale de la vista [CIntfVCodigos]
--					SELECT [IDgdicTCodigos], [Codigo], [Descripcion]
--					  FROM [BDCtral].[dbo].[CIntfVCodigos]
--					WHERE [IDFkTCIntfTObjCod_AmbAplic] = 'b890dd58-58ba-4da3-8a0c-70422298a88d'
--							AND [IDFkTCDiccTIdio_Idioma] = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'

						--	6EFA0E33-F537-4861-A35F-10ECB328FB74	PiePag001	pie de la p�gina
						--	5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D	EncPag001	encabezado de la p�gina
						--	B890DD58-58BA-4DA3-8A0C-70422298A88D	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
						--	57504A29-9F06-41B2-896C-81D5A57E37BF	EstWeb001	Estructura de la p�gina Web hasta el Body
	EXEC	@return_value = [dbo].[CintfPObjModBucleIDProp] 
			@PAR1 = @PARInt01			-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
			, @PAR2 = @PARInt02			-- Ambito de Aplicaci�n elegido o por defecto = NULL
			, @PAR3 = @PARInt03			-- Padre ID General



-- ##############################################################################################################################################^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- El GO va al final del procedimiento
GO
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################

--
---- Elimina Datos de las tablas
--DECLARE @PAR1 AS VARCHAR(36)
--SET @PAR1 = '86973F44-7CD4-4FE1-9342-DFCD0C2A345D'		-- ID de la Tabla [CIntfTObjMod]
--
--DELETE FROM [BDCtral].[dbo].[CIntfTObjMod] WHERE [ID] = @PAR1
--DELETE FROM [BDCtral].[dbo].[CIntfTObjModArb] WHERE [IDFkCIntfTObjMod] = @PAR1
		


