-- #########################################################################################################################################################
--  GENERA LOS PROCEDIMIENTOS ALMACENADOS PARA HACER EL ALTA, MODIFICACION, BAJA O RECUPERO DE LOS CODIGOS Y SUS DESCRIPCIONES DE LA INTERFAZ DE USUARIOS -- 
-- #########################################################################################################################################################

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- Determina la base de datos donde se trabajar�
USE [BDCtral]
GO

-- ===================================================
-- Author: Juan Petri
-- Create date: 26/11/2018
-- Description:	Ejecuta el Procedimiento Almacenado [CIntfPCodxIdioABM]
-- ===================================================

	DECLARE	@return_value int
	DECLARE @PARint1 AS uniqueidentifier
	DECLARE @PARint2 AS uniqueidentifier
	DECLARE @PARint3 AS uniqueidentifier
	SET @PARint1 = NEWID()
	SET @PARint2 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'	-- ID del Idioma	-- Espa�ol, por defecto
				--	ee954f5d-ca27-48a9-a23b-010788b18631	ITA	italiano
				--	b1268278-4eb3-4a93-8f67-0d425b767c65	ENG	english
				--	a455281d-76f5-4bad-8dbb-201c5928aaf8	FRA	fran�ais
				--	1048c13b-1cc9-4154-8b8b-64ca9ac9fe12	POR	portugu�s
				--	fb478ecc-85fe-4fc8-b792-caf8ecb921b1	ESP	espa�ol	
	SET @PARint3 = 'AEFEA6F0-CC81-41AB-AD12-354A484273DA'	--	Ele					contiene los elementos de la pagina.
					--	'EBFEF35D-D9F8-4116-953D-0E2ED4341E6E'	--	CIntfObjTipo		tabla con los tipos de objetos de la interfaz de usuario.
					--	'C3133A27-4F21-4793-B186-4A640AB2AE52'	--	CIntfObjUbic		determina si el objeto va dentro intag o fuera del tag outtag.
					--	'EBFEF35D-D9F8-4116-953D-0E2ED4341E6E'	--	CIntfObjTipo		tabla con los tipos de objetos de la interfaz de usuario.
					--	'C3133A27-4F21-4793-B186-4A640AB2AE52'	--	CIntfObjUbic		determina si el objeto va dentro intag o fuera del tag outtag.
					--	'ABEDD291-3991-4A47-8AEB-82580BF6BA8C'	--	Css					contiene todos los estilos posibles de la pagina y los elementos.
					--	'AEFEA6F0-CC81-41AB-AD12-354A484273DA'	--	Ele					contiene los elementos de la pagina.
					--	'9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B'	--	Pro					contiene las propiedades de la pagina, elementos y estilos.
					--	'540C0AB8-CFCA-4346-AC40-D159787DAEA2'	--	UsuObj				contiene las descripciones de los usuarios objetos que forman parte de las objetos.
					--	'B890DD58-58BA-4DA3-8A0C-70422298A88D'	--	ObjMod				contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
					--	'7C2D7297-34DE-4F10-8F70-ACD26E5AFB04'	--	PagWeb				contiene las pagina web de la aplicacion.

	-- Ejecuta Procedimiento Almacenado [CIntfPCodxIdioABM], para agregar un codigo en el M�dulo de Acceso
	EXEC @return_value = [dbo].[CIntfPCodxIdioABM]
			-- ALTA - MODIFICACION - BAJA - RECUPERO
				@PAR1 = 'ALTA'					

			-- ID del codigo, debe ser �nico IDFkTCIntfTObjCod_CodxIdio
				,@PAR2 = @PARint1

			-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
				,@PAR3 = @PARint2
		
			-- IDFkTCodAmbAplic del Ambito de Aplicaci�n del C�digo
			,@PAR4 = @PARint3
			-- Codigo -- C�digo en letras del ID
			,@PAR5 = '<footer>' 	--	Valor que tiene la propiedad [CodObjPropValor].

			-- Descripci�n -- Es la descripci�n del c�digo en letras.
			,@PAR6 = 'pie de p�gina'

			-- CodigoWeb -- C�digo que sale como ID para armar la p�gina web. [CodigoWeb]
			,@PAR7 = 'footer' 	

			--	[IDFkCDiccTCod_ObjCodUbic]	determina si el objeto va dentro intag o fuera del tag outtag
			,@PAR8 = '00ECF783-C3C7-4178-8E8A-F83AE2EE7872'		
					--	DECLARE	@return_value int
					--	EXEC	@return_value = [dbo].[CDiccPCodxIdio]	@PAR2 = N'C3133A27-4F21-4793-B186-4A640AB2AE52'
						--	A745CCC2-262B-4F2A-B6AB-EAD4BCCA3CFA	intag			valores dentro del tag
						--	00ECF783-C3C7-4178-8E8A-F83AE2EE7872	outtag			valores fuera del tag
						--  DCDF7DF1-14A0-4C31-ACB4-9B0A176406E3	no aplica		no aplica clasificacion.

			-- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
			,@PAR9 = '00ECF783-C3C7-4178-8E8A-F83AE2EE7872'		
				-- Es un c�digo ID con las distintas opciones, estas pueden ser. Habilitado, Deshabilitado, Eliminado.
				-- Ejecute esta consulta y estar�n los estados disponibles. Los mismos son para todo el sistema por eso es multiempresa
--							DECLARE	@return_value int
--							EXEC	@return_value = [dbo].[CDiccPCodxIdio] 
--									@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--									,@PAR2 = '6B0CD910-C127-4450-9865-15E9F4C287B4'		-- AmbitoApicaci�n EST	estados
--									,@PAR3 = 'A5E49ED6-EFDD-4C43-955F-7F3616E39F99'		-- multiempresa	se aplica para los c�digos generales del sistema
										-- 'EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0'	--		DES		deshabilitado
										-- '3749D6D8-EF8F-4C37-893A-BE7209239810'	--		ELI		eliminado
										-- 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'	--		HAB		habilitado

			-- tipo de Alta	'AltaCompleto'
			,@PAR10 = 'AltaCompleto'		
		

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- #################################################################################################################################
-- Info de los Elementos HTML que forman parte de las paginas web
--	DECLARE	@return_value int
	EXEC	@return_value = [dbo].[CIntfPCodxIdio]
			@PAR1 = @PARint2		-- Idioma elegido o por defecto = espa�ol
			-- Ambito de Aplicaci�n elegido o por defecto = NULL
			,@PAR2 = @PARint3	--	Ambito de Aplicacion