set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO

-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 16/10/2018
-- Description:	Muestra los Usuarios Objetos creados. Aqu� pueden insertarse Elementos y Objetos Modelos.
-- en el caso de que se inserten elementos, sus propiedades est�n en la tabla CIntfTUsuObjProp
-- en el caso de que se inserten Objetos Modelos, sus propiedades est�n dentro de las tablas de las estructura ObjMod.
-- Informaci�n surge de la tabla [CIntfTObjCodxIdio], [CDiccTCodxIdiomas] y [CIntfTObjCodxIdio]
-- =============================================

ALTER PROCEDURE [dbo].[CIntfPUsuObj]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol

AS
BEGIN

--	DECLARE @PAR1 NVARCHAR(50) 
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol

-- Tabla con la Informaci�n del Diccionario [CDiccTCodxIdiomas]
	DECLARE @TmpTCodxIdi TABLE	-- Codigos x Idiomas -- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)

--	 Inserta en la tabla temporal la informaci�n de los c�digos seg�n el idioma elegido
	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1

-- Tabla con la Informaci�n de los Objetos [CIntfTObjCodxIdio]
	DECLARE @TmpTIntObjCodxIdi TABLE	-- Codigos x Idiomas -- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTIntCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [nvarchar](55) COLLATE Modern_Spanish_CI_AS,  -- NOT NULL,
		[Descripcion] [nvarchar](255) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodigoWeb] [nvarchar](50) COLLATE Modern_Spanish_CI_AS NULL,
		[IDFkCxIUsuObjEstado] [uniqueidentifier] NULL,
		[TCodxIdioFechaModif] [datetime] NULL, 
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)

--	 Inserta en la tabla temporal la informaci�n de los c�digos seg�n el idioma elegido
	INSERT INTO @TmpTIntObjCodxIdi
		SELECT IDFkTCIntfTObjCod_CodxIdio
			  ,IDFkTCDiccTIdio_Idioma
			  ,IDFkTCIntfTObjCod_AmbAplic
			  ,[Codigo]
			  ,[Descripcion]
			  ,[CodigoWeb]
			  ,IDFkCDiccTCod_ObjCodxIdioEst
			  ,[ObjCodxIdioFechaModif]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CIntfTObjCodxIdio] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTCDiccTIdio_Idioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1

--	SELECT * FROM @TmpTCodxIdi
--	SELECT * FROM @TmpTIntObjCodxIdi

		SELECT IUO.[ID] AS [IDFkCIntfTUsuObj]
			  ,IUO.[IntUsuObjCodUnico]
			  ,IUO.[IntUsuObjCodUsuUnico]
			  ,IUO.[IntUsuObjCodDescFuncion]
			  ,IUO.[IDFkCDiccTCod_UsuObjEst]
			  ,CxI.[Codigo] AS [UsuObjEst]
			  ,CxI.[Descripcion] AS [UsuObjEstDesc]
			  ,IUO.[UsuObjFechaModif]
			  ,IUO.[IDFkCIntfTObjCod_UsuObjCod]
			  ,OCxI01.[Codigo] AS [IntfTObjCod]
			  ,OCxI01.[Descripcion] AS [IntfTObjCodDesc]
		  FROM [BDCtral].[dbo].[CIntfTUsuObj] AS IUO WITH(NOLOCK)
			INNER JOIN @TmpTCodxIdi AS CxI
				ON IUO.[IDFkCDiccTCod_UsuObjEst] = CxI.[IDFkTCodigos]
						AND 
					@PAR1 = CxI.[IDFkTIdioma]
			INNER JOIN @TmpTIntObjCodxIdi AS OCxI01
				ON IUO.[IDFkCIntfTObjCod_UsuObjCod] = OCxI01.[IDFkTIntCodigos]
						AND 
					@PAR1 = OCxI01.[IDFkTIdioma]

--	 Borra Tablas Temporales
		IF OBJECT_ID('@TmpTCodxIdi') IS NOT NULL
		BEGIN
		DROP TABLE [BDCtral].[dbo].[@TmpTCodxIdi];
		END

		IF OBJECT_ID('@TmpTIntObjCodxIdi') IS NOT NULL
		BEGIN
		DROP TABLE [BDCtral].[dbo].[@TmpTIntObjCodxIdi];
		END

END


--	DECLARE	@return_value int
--	EXEC	@return_value = [dbo].[CIntfPUsuObj] @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'
