USE [BDCtral]
GO
	DECLARE	@return_value int

-- *************************
-- CREA LAS PAGINAS WEB
-- *************************
-- #################################################################################################################################################################
-- Muestra las p�ginas Web disponibles
-- Esto surgen de ejecutar el <<< Procedimiento Almacenado 02 [CIntfPCodxIdio] >>>
DECLARE	@return_value int
EXEC	@return_value = [dbo].[CIntfPCodxIdio]
			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
			-- Ambito de Aplicaci�n elegido o por defecto = NULL
			,@PAR2 = '7C2D7297-34DE-4F10-8F70-ACD26E5AFB04'		--	PagWeb	contiene las pagina web de la aplicacion.

-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- <<< Procedimiento Almacenado 15 [CintfPUsuObjArbBucleIDEstInic] >>>
-- Muestra la estructura de una p�gina Web
	DECLARE	@return_value int
	DECLARE @Pag AS NVARCHAR(36)
--	SET @Pag = '9A01BFBA-6DFE-4BFA-AFD3-6A8F4044B97B'	-- 	PagInic002	pagina segunda
	SET @Pag = 'B1E3B2FA-A308-41BC-BF59-7664A6380CE3'	--	PagInic001	p�gina inicial
	EXEC	@return_value = [dbo].[CintfPUsuObjArbBucleIDEstInic]  @PAR1 = @Pag


	-- #################################################################################################################################################################
	-- PRIMERO: Crea las nuevas P�ginas Web
	-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	-- <<< Sentencia SQL 10 CintfPUsuObjABM_Padre_Ejec.sql >>>
		-- Las variables que se modifican son 10 pero las mas comunes son:
		--		@PAR5 = C�digo de la p�gina. Para un �mbito de aplicaci�n este c�digo no se puede repetir.
		--		@PAR6 = Descripci�n de la p�gina.
		--		@PAR7 = C�digo Web, que es el nombre de la pagina abreviada.-- [CodigoWeb] C�digo que sale como ID para armar la p�gina web.
		
		-- Algunos ejemplos de p�ginas webs, para el proceso de Login en sus distintas etapas.
			--	E98AF295-714B-494C-A11D-87BAEABA16FF	PrLgIU01	Proceso Login Interfaz Usuario ING-PTE
			--	DEC88ABC-DDDB-41CB-9FD6-CF8A2B1A0AB5	PrLgIU02	Proceso Login Interfaz Usuario ING-PTE/USU-INE
			--	3A716834-0693-46B9-A5DE-0410E1E9F0FE	PrLgIU03	Proceso Login Interfaz Usuario Usu-Pte
			--	9BBC17F5-42CC-44F2-8D8D-FF481523C30F	PrLgIU04	Proceso Login Interfaz Usuario Usu-Pte/Usu-Err
			--	2F1FF3F6-64E4-42ED-ABA9-5FE661219ED4	PrLgIU05	Proceso Login Interfaz Usuario Usu-Blo

	-- #################################################################################################################################################################
	-- SEGUNDO: Carga los elementos que forman las P�ginas Web
	-- ===================================================================================================================================================================
	-- <<< Sentencia SQL 11 CintfPUsuObjABM_Hijos.sql >>>
		-- Ejecutando el CintfPUsuObjABM_Hijos, carga los elementos u Objetos Modelos a las p�ginas
		-- Trabaja con la tabla [CIntfTUsuObj], [CIntfTUsuObjArb] y [CIntfTUsuObjProp]
		-- Para armar el objeto:
		--			1.- Insertar el elemento en la tabla [CIntfTUsuObj]
		--			2.- Insertar en la tabla [CIntfTUsuObjArb], la ubicaci�n del elemento en la estructura Padre / Hijo
		--			3.- Insertar en la tabla [CIntfTUsuObjProp], las propiedades obligatorias del elemento
		-- Dependiendo el tipo de Objeto si es o no contenedor de otros objetos, es el nivel que le da a los elemento.
		-- El objeto Page, es el primer elemento, todos los otros estan dentro de la pagina.

		-- Se 14 variables pero las claves son:
		--					@PAR1 = ALTA - MODIFICACION - BAJA - RECUPERO
		--					@PAR2 = Idioma Elegido
		-- Crea los elementos asignados al objeto -- Tabla [CIntfTObjMod]
		--					@PAR3 = ambito de aplicaci�n, 
		--													se utiliza 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	--	ObjMod		contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
		--													se utiliza 'AEFEA6F0-CC81-41AB-AD12-354A484273DA'	--	Ele			contiene los elementos de la pagina
		--					@PAR4 = NEWID()	-- [ID] -- valor ID del nuevo Objeto [CIntfTUsuObj], debe ser �nico.
		--					@PAR5 = codigo ID del Objeto -- [IDFkTIntCodObj] codigo ID del Objeto (Elemento u Objeto Modelo) que se insertar� en la p�gina.
									-- Elementos
		--							DECLARE	@return_value int
		--							EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D' -- N'AEFEA6F0-CC81-41AB-AD12-354A484273DA'		-- Ambito Aplicaci�n Elemento
		--										-- Objetos Modelos 
		--							DECLARE	@return_value int
		--							EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'B890DD58-58BA-4DA3-8A0C-70422298A88D'		-- Ambito Aplicaci�n ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.

		--					@PAR6 = C�digo del elemento. Este se genera autom�ticamente con el nombre codigo unico web (tabla [CIntfTObjCodxIdio]) y el nivel donde esta el elemento.
		--					@PAR7 = NO se utiliza.-- [IntUsuObjCodUsuUnico] -- codigo unico del Objeto ingresado por el usuario.
		--					@PAR8 = Descripci�n de la funci�n espec�fica del elemento dentro de la estructura Usuario Objeto.
		-- Crea la Estructura Arbol -- Tabla [CIntfTUsuObjArb]
		--					@PAR9 = C�digo ID unico del Objeto dentro de la estructura arbol
		--					@PAR10 = ID del Padre, este valor es manual:
									-- 1.- En el caso que es el Padre Inicial, el ID viene de la tabla [CIntfTObjCod] y [CIntfTObjCodxIdio]
									-- 2.- En el caso de que otro elemento sea el padre, hay que buscar el ID, para incorporarlo como padre,
		--					@PAR11 = [ItemNivel] es el nivel del arbol que tiene el objeto. En el caso inicial = 1
		--					@PAR12 = [ItemOrd] es el orden dentro del Item Nivel.
		--					@PAR13 = es el ID del objeto que se inserto en la Tabla [IDFkCIntfTUsuObj]. Este no es el ID del Objeto de la tabla TObjCod.
		--					@PAR14 = 'c6fe2749-0cb8-49cd-97df-03c299c0c6cf'					-- [IDFkCxIEstados] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado


	-- #################################################################################################################################################################
	-- TERCERO: Carga las propiedades Opcionales a los Elementos cargados
	-- ===================================================================================================================================================================
	-- <<< Sentencia SQL 12 CintfPUsuObjPropABM.sql >>>
		-- Ahora hay que dar de alta las propiedades espec�ficas de los elementos. 
		-- Trabaja con la tabla [CIntfUsuObj], [CIntfUsuObjArb]
		-- Se 7 variables pero las claves son:
		--					@PAR1 = ALTA - MODIFICACION - BAJA - RECUPERO
		--					@PAR2 = NEWID()		[ID] tabla [CIntfTUsuObj]-- codigo ID �nico del objeto al que se le asignar�la propiedad.
		--					@PAR3 = [IDFkTIntCodObj] -- codigo ID del ObjetoID que tiene la propiedad.
		--					@PAR4 = [ID] tabla [CintfTObjCodProp] -- valor ID �nico de la Propiedad
		--					@PAR5 = [ObjModCodPropValor] Como este valor lo puede colocar el usuario, se carga, si es NULL, se pone el de la tabla
		--					@PAR6 = [ObjModCodPropOrden] orden en que se armara el TAG, surge de una consulta de la tabla [CintfVObjCodProp]
		--					@PAR7 = Estado del elemento, Habilitado, Deshabilitado, Baja

-- =======================================================================================================================================================================
--	Resultado Final
-- =======================================================================================================================================================================
-- <<< Procedimiento Almacenado 18 [CintfPUsuObjArbWebABM] >>>
-- Ya finalizada la estructura de la p�gina, ejecuta el procedimiento almacenado [CintfPUsuObjArbWebABM]
-- Esto inserta en la tabla [CIntfTUsuObjArbWeb] la pagina web finalizada
	DECLARE	@return_value int
	DECLARE @Pag AS NVARCHAR(36)
	SET @Pag = 'B1E3B2FA-A308-41BC-BF59-7664A6380CE3'	--	PagInic001	p�gina inicial
--	SET @Pag = '9A01BFBA-6DFE-4BFA-AFD3-6A8F4044B97B'	--	PagInic002	pagina segunda
	EXEC	@return_value = [dbo].[CintfPUsuObjArbWebABM] @PAR1 = @Pag

-- =======================================================================================================================================================================
-- <<< Procedimiento Almacenado 19 [CIntfPUsu] >>>
-- Consulta con la informaci�n relevante para ejecutar la p�gina web
-- surge de la consulta [CIntfTUsuObjArbWeb] vinculada con las Propiedades de los elementos que surgen de la vista [CIntfVObjUsuModProp]
--DECLARE	@return_value int
EXEC	@return_value = [dbo].[CIntfPUsu] @PAR1 = @Pag

