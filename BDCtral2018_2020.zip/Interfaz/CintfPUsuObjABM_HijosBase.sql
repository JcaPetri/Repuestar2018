-- #########################################################################################################################################################
--  GENERA LOS PROCEDIMIENTOS ALMACENADOS PARA HACER EL ALTA, MODIFICACION, BAJA O RECUPERO DE LA INTERFAZ DE USUARIOS -- 

-- ################################################################################################################################
-- ################################################################################################################################
-- Trabaja con la tabla [CIntfTUsuObj], [CIntfTUsuObjArb] y [CIntfTUsuObjProp]
-- Para armar el objeto:
--			1.- Insertar el Objeto en la P�gina, ya realizado con el procedimiento CintfPUsuObjABM_Padre.sql
--			2.- Insertar la estructura del objeto
--			3.- Insertar la propiedades del objeto
-- Dependiendo el tipo de Objeto si es o no contenedor de otros objetos, es el nivel que le da a los elemento.
-- El objeto Page, es el primer elemento, todos los otros estan dentro de la pagina.
-- ################################################################################################################################

USE [BDCtral]
GO

---- Ambitos de aplicaci�n donde est�n cargados los Elemento, Estilos y Propiedades.
--DECLARE	@return_value int
--EXEC	@return_value = [dbo].[CIntfPAmbAplic]

--	ABEDD291-3991-4A47-8AEB-82580BF6BA8C	Css			contiene todos los estilos posibles de la pagina y los elementos
--	AEFEA6F0-CC81-41AB-AD12-354A484273DA	Ele			contiene los elementos de la pagina
--	9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B	Pro			contiene las propiedades de la pagina, elementos y estilos
--	B890DD58-58BA-4DA3-8A0C-70422298A88D	ObjMod		contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.


SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO

DECLARE	@return_value int

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Variables para realizar al ABM, se debe:
	-- Variables Etapa 1
	DECLARE @PAR1 AS VARCHAR(50)	-- Determina acci�na realizar 
		-- valores posibles: ALTA - MODIFICACION - BAJA - RECUPERO
		-- Como estos valores son para todas las tablas e idiomas unicos siempre van los mismos

	DECLARE @PAR2 AS VARCHAR(36)	-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
		-- Caso Alta: 
			-- codigo del idioma a donde se asignara el codigo.
				--						ee954f5d-ca27-48a9-a23b-010788b18631	ITA
				--						b1268278-4eb3-4a93-8f67-0d425b767c65	ENG
				--						a455281d-76f5-4bad-8dbb-201c5928aaf8	FRA
				--						1048c13b-1cc9-4154-8b8b-64ca9ac9fe12	POR
				--						fb478ecc-85fe-4fc8-b792-caf8ecb921b1	ESP
		-- Caso Modificaci�n:
			-- Codigo del idioma, a que idioma se asigna ese codigo. 
			-- Primero se debe verificar que para ese idioma no este utilizado el codigo, no se debe haber utilizado, si es as� no se genera la modificaci�n

	DECLARE @PAR3 AS VARCHAR(36)	-- Ambitos de aplicaci�n, para obtener el @PAR6 = [IntUsuObjCodUnico]
		-- Caso Alta: 
			-- codigo del modulo o ambito de aplicacion a donde se asignara el codigo.
				-- Algunos ambitos de aplicaci�n			
				--	DECLARE	@return_value int
				--	EXEC	@return_value = [dbo].[CIntfPAmbAplic]
					--	ABEDD291-3991-4A47-8AEB-82580BF6BA8C	Css		contiene todos los estilos posibles de la pagina y los elementos
					--	AEFEA6F0-CC81-41AB-AD12-354A484273DA	Ele		contiene los elementos de la pagina
					--	9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B	Pro		contiene las propiedades de la pagina, elementos y estilos
					--	B890DD58-58BA-4DA3-8A0C-70422298A88D	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
					--	7C2D7297-34DE-4F10-8F70-ACD26E5AFB04	PagWeb	contiene las pagina web de la aplicacion.

	DECLARE @PAR4 AS VARCHAR(36)	-- [ID] -- valor ID del nuevo Objeto [CIntfTUsuObj], debe ser �nico.
		-- Caso Alta: valor nuevo se genera con el NewID()
			-- este valor es el ID unico del Objeto en la p�gina, 
		-- Caso Modificaci�n: 

	DECLARE @PAR5 AS VARCHAR(36)		-- [IDFkTIntCodObj] -- codigo ID del Objeto (Elemento o Estilo) que se insertar� en la p�gina.
		-- Caso Alta: 
--			DECLARE	@return_value int
--			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'AEFEA6F0-CC81-41AB-AD12-354A484273DA'		-- Ambito Aplicaci�n Elemento
--			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'ABEDD291-3991-4A47-8AEB-82580BF6BA8C'		-- Ambito Aplicaci�n Estilos
--			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'B890DD58-58BA-4DA3-8A0C-70422298A88D'		--	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.

		-- Caso Modificaci�n:

	DECLARE @PAR6 AS NVARCHAR(250)		-- [IntUsuObjCodUsuUnico] -- codigo unico del Objeto ingresado por el usuario.
		-- Caso Alta: 
			-- Este c�digo se carga manualmente. Aqu� hay que verificar que el mismo no este cargado dos veces.
		-- Caso Modificaci�n: 

	DECLARE @PAR7 AS NVARCHAR(250)		-- [IntUsuObjCodUnico] -- codigo unico del Objeto (Elemento o Estilo).
		-- Caso Alta: 
			-- Este c�digo se carga autom�ticamente, con un n�mero ascendente, dependiendo del nivel y cantidad de elementos similares en la p�gina.
		-- Caso Modificaci�n:

	DECLARE @PAR8 AS NVARCHAR(250) 		-- [IntUsuObjCodDescFuncion] -- descripci�n de la funci�n de ese Objeto (Elemento o Estilo) en la p�gina.
		-- Caso Alta:
			-- Valor asignado por el usuario
		-- Caso Modificaci�n:

	-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	-- Informaci�n para cargar la estructura Arbol, O SEA D�nde va el Objeto en la P�gina.
	DECLARE @PAR9 AS VARCHAR(36)		-- [ID] de la tabla CIntfTUsuObjArb -- codigo ID de la instancia del Objeto (Elemento o Estilo) insertado en la tabla [CIntfTUsuObjArb].
		-- Caso Alta: 
			-- Este valor surge de NewID()
		-- Caso Modificaci�n:

	DECLARE @PAR10 AS VARCHAR(36)		-- [IDPadre]		es el ID del Padre
		-- Caso Alta: 
		-- ID del Padre, este valor es manual
			-- 1.- En el caso que es el Padre Inicial, el ID viene de la tabla [CIntfTObjCod] y [CIntfTObjCodxIdio]
				-- se pueden ver los distintos Objetos PagWeb en la consulta siguiente
				-- Detalle de las Paginas Web, son los Padres
					---- Lista las P�ginas Disponibles
--						DECLARE	@return_value int
--						EXEC	@return_value = [dbo].[CIntfPCodxIdio]
--								@PAR2 = N'7C2D7297-34DE-4F10-8F70-ACD26E5AFB04'		-- PagWeb	contiene las pagina web de la aplicacion.
--						-- El Ambito de Aplicaci�n es PagWeb
					-- B1E3B2FA-A308-41BC-BF59-7664A6380CE3			PagInic001			p�gina inicial
			-- 2.- En el caso de que otro elemento sea el padre, hay que buscar el ID, para incorporarlo como padre,
				--  esta infor se saca de la siguiente consulta, hacer la consulta:
				--	si el resultado es nulo, quiere decir que ese Padre No tiene ning�n hijo
--					SELECT UOA.[ID]
--					--      ,OMA.[IDFkCIntfTUsuObj]
--						  ,UO.[IntUsuObjCodUnico]
--						  ,UO.[IntUsuObjCodDescFuncion]
--						  ,UOA.[ItemNivel]
--						  ,UOA.[ItemOrd]
--					  FROM [BDCtral].[dbo].[CIntfTUsuObjArb] AS UOA WITH(NOLOCK)
--						INNER JOIN [BDCtral].[dbo].[CIntfTUsuObj] AS UO WITH(NOLOCK)
--							ON UOA.[IDFkCIntfTUsuObj] = UO.[ID]
--					WHERE UOA.[IDFkCIntfTUsuObjArb_PadreID] = 'B1E3B2FA-A308-41BC-BF59-7664A6380CE3'
--					ORDER BY UOA.[ItemNivel]
--						  ,UOA.[ItemOrd]
	
		-- Caso Modificaci�n:

	DECLARE @PAR11 AS INT		-- [ItemNivel]		es el nivel del arbol que tiene el objeto. En el caso inicial = 1
		-- Caso Alta: 
			-- Surge de la consulta sobre el nivel

	DECLARE @PAR12 AS INT		-- [ItemOrd]		es el orden dentro del Item Nivel.
		-- Caso Alta: 
			-- Surge de la consulta sobre el orden dentro del nivel. Le agrega un valor.

	DECLARE @PAR13 AS VARCHAR(36)		-- [IDFkCIntfTUsuObj]		es el ID del objeto que se inserto en la Tabla TUsuObj. Este no es el ID del Objeto de la tabla TObjCod.
		-- Caso Alta: 
			-- Para este caso es el mismo del objeto @PAR4


	DECLARE @PAR14 AS VARCHAR(36) 			-- [IDFkCxIEstados] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
		-- Caso Alta:
			-- Es un c�digo ID con las distintas opciones, estas pueden ser. Habilitado, Deshabilitado, Eliminado.
				-- 6B0CD910-C127-4450-9865-15E9F4C287B4	EST	estados			EST	estados
					-- EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0	DES	deshabilitado	EST	estados
					-- 3749D6D8-EF8F-4C37-893A-BE7209239810	ELI	eliminado		EST	estados
					-- C6FE2749-0CB8-49CD-97DF-03C299C0C6CF	HAB	habilitado		EST	estados
		-- Caso Modificaci�n:
			-- Se cambia el estado sin realizar verificaciones. en caso de que se recupere el c�digo, se debe verificar que no se infrinjan las reglas primarias.

	-- Tabla para tomar los valores de las propiedades de los elementos.
		DECLARE @TmpTObjConProp TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
			(
 				-- [ID] [uniqueidentifier] NULL,
				[IDFkTCIntfTObjCod_ObjCod] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
				[ObjCodigo] [nvarchar](50) COLLATE Modern_Spanish_CI_AS NULL,
				[IDFkTCIntfTObjCodProp] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
				[ObjCodValor] [nvarchar](255) COLLATE Modern_Spanish_CI_AS NULL,
				[IDFkTCIntfTObjCod_ObjCodProp] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
				[ObjCodPropValor] [nvarchar](255) COLLATE Modern_Spanish_CI_AS NULL,
				[ObjCodPropOrden] [int] NULL,
				[ObjCodPropValorWeb] [nvarchar](255) COLLATE Modern_Spanish_CI_AS NULL,
				[IDFkCDiccTCod_PropTipo] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
				[ObjPropTipo] [nvarchar](50) COLLATE Modern_Spanish_CI_AS NULL,
				[IDFkCDiccTCod_ObjCodPropEstado] [uniqueidentifier] NULL
		--		[ObjCodPropFechaModif] [datetime] NULL
			)
				
		INSERT INTO @TmpTObjConProp EXEC @return_value = [dbo].[CIntfPObjConPropResu]
	--	SELECT * FROM @TmpTObjConProp

	DECLARE @ValVar AS VARCHAR(50)
	SET @ValVar = 'VAL'

	-- Variables para obtener los valores del procedimiento almacenado de CGetErrorInfo
		DECLARE @RTADO_PROCALM AS VARCHAR(250)
		DECLARE @NOMB_PROCALM AS VARCHAR(250)
		DECLARE @FUNC_PROCALM AS VARCHAR(100)
		DECLARE @RTADO AS VARCHAR(250)
		DECLARE @REG_AFEC AS NUMERIC(18, 0)
		DECLARE @ERR_MESSAGE AS VARCHAR(250)
		DECLARE @ERR_NUMBER AS NUMERIC(18, 0)
		DECLARE @ERR_SEVERITY AS NUMERIC(18, 0)
		DECLARE @ERR_STATE AS NUMERIC(18, 0)
		DECLARE @ERR_LINE AS NUMERIC(18, 0)
		
		SET @NOMB_PROCALM = 'CintfPUsuObjABM_Hijos'				-- Nombre del procedimiento almacenado.

-- Valores de las variables para generar las prueba del funcionamiento de las consultas.
--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- SETEO DE LAS VARIABLES PARA EL ALTA DE UN CODIGO Y SUS DESCRIPCIONES
	-- Tipo Acci�n
		SET @PAR1 = 'ALTA'													-- ALTA - MODIFICACION - BAJA - RECUPERO
	-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
		SET @PAR2 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'					
	-- Ambito de Aplicaci�n
		SET @PAR3 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	--	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
--				-- Algunos ambitos de aplicaci�n			
--					DECLARE	@return_value int
--					EXEC	@return_value = [dbo].[CIntfPAmbAplic]
--						'AEFEA6F0-CC81-41AB-AD12-354A484273DA'	--	Ele		contiene los elementos de la pagina
--						'B890DD58-58BA-4DA3-8A0C-70422298A88D'	--	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.

					-- Borrar --	ABEDD291-3991-4A47-8AEB-82580BF6BA8C	Css		contiene todos los estilos posibles de la pagina y los elementos
					-- Borrar --	9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B	Pro		contiene las propiedades de la pagina, elementos y estilos
					-- Borrar --	7C2D7297-34DE-4F10-8F70-ACD26E5AFB04	PagWeb	contiene las pagina web de la aplicacion.

	-- [ID] -- valor ID del nuevo Objeto [CIntfTUsuObj], debe ser �nico.
		SET @PAR4 = NEWID()													
	-- [IDFkTIntCodObj] -- codigo ID del Objeto (Elemento u Objeto Modelo) que se insertar� en la p�gina.
		SET @PAR5 = '5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D'	--	EncPag001	encabezado de la p�gina	(Esto es un Objeto Modelo)	
			-- Elementos
--			DECLARE	@return_value int
--			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = 'AEFEA6F0-CC81-41AB-AD12-354A484273DA'	--	Ele		contiene los elementos de la pagina

				--  @PAR5
				--	EE8E9BBA-E7FD-40AA-A97F-9A085126B841	<body>			cuerpo de la pagina
				--	8BA11A28-67B7-4A15-B2E2-E5A30FCCB8FE	<br>			salto de pagina
				--	CBC7CCD2-6825-4288-A1EE-07C83D57FE97	<div>			seccion de pagina
				--	F9DA8C8E-925D-4C2A-BF1C-EA363BEB3D41	<doctype>		tipo de documento
				--	4E3F5983-416B-47C5-918E-C7B4910C017F	<form>			formulario
				--	6A20FFB1-EF83-46AC-9DDA-9C37096B489D	<h1>			titulo h1
				--	66C2E055-CB9B-41FC-AD33-E5DF741CE7A8	<h2>			titulo h2
				--	116D43EC-D0FF-4915-B878-099A2ABE4EC6	<h3>			titulo h3
				--	DCF47D44-133A-4865-ADC0-57869979F845	<h4>			titulo h4
				--	C8BC46DE-7EA5-40F7-849C-8E381698CB93	<h5>			titulo h5
				--	FF6D64CD-B3CC-48D4-9409-634C25D9CA96	<h6>			titulo h6
				--	BEF7DACA-65E9-4662-89C8-35BC84274009	<head>			encabezado a nivel pagina
				--	E31EC871-F1C8-48F5-9C34-77326C46BB4D	<html>			hepertext markup languages
				--	EF69A94B-5C69-430C-A066-B6336A153A05	<inputcheck>	opcion de chequeo
				--	13C46A05-262C-48C4-BD29-7A5D0BB91D22	<inputpass>		ingreso de password
				--	CC3414AF-7742-4AFD-8EDA-E8D00130A553	<inputsubmit>	boton de env�o
				--	5432E780-F1C7-4D2E-B4C6-53DD7A9D729D	<inputtext>		campo de ingreso
				--	4BFD72B4-D915-413D-A9AF-3B93D448E543	<label>			texto
				--	CCD03587-4CFE-4088-A699-6F8E8AD31088	<link>			permite vincular un archivo externo o documento
				--	75A8EA76-C0A0-4DA1-A07F-1E1FF1514043	<meta>			especificaciones de la p�gina
				--	CB0D1A8F-E833-41E1-9272-173A230C9D78	<p>				parrafo
				--	A96324E5-B360-4D6D-9486-4DFD63565F70	<page>			pagina web
				--	5CE0D99D-230B-4C90-A5FF-C3FD6D37F095	<script>		script relacionados a la p�gina
				--	7E7703AF-582E-45E5-BB60-3D5735E37379	<title>			es el t�tulo de la lengueta de la p�gina

			-- Objetos Modelos 
--			DECLARE	@return_value int
--			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'B890DD58-58BA-4DA3-8A0C-70422298A88D'		-- Ambito Aplicaci�n ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
					--	@PAR5
					--	'5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D'	--	EncPag001	encabezado de la p�gina
					--	'57504A29-9F06-41B2-896C-81D5A57E37BF'	--	EstWeb001	Estructura de la p�gina Web hasta el Body
					--	'6EFA0E33-F537-4861-A35F-10ECB328FB74'	--	PiePag001	pie de la p�gina

	-- [IntUsuObjCodUnico] -- codigo unico del Objeto (Elemento o Estilo).
		SELECT @PAR6 = CxI.[CodigoWeb]					
		  FROM [BDCtral].[dbo].[CIntfTObjCod] AS OC WITH(NOLOCK)
			 INNER JOIN [BDCtral].[dbo].[CIntfTObjCodxIdio] AS CxI WITH(NOLOCK)
					ON OC.[ID] = CxI.[IDFkTCIntfTObjCod_CodxIdio] 
							AND
						@PAR2 = CxI.[IDFkTCDiccTIdio_Idioma]
							AND
						(@PAR3 = CxI.[IDFkTCIntfTObjCod_AmbAplic]	
							OR 
						'B890DD58-58BA-4DA3-8A0C-70422298A88D' = CxI.[IDFkTCIntfTObjCod_AmbAplic])
			WHERE OC.[ID] = @PAR5

	-- [IntUsuObjCodUsuUnico] -- codigo unico del Objeto ingresado por el usuario.
		SET @PAR7 = NULL --	'INTUSU01'					
					--	Si el usuario no incorpor� un c�digo, se pone null
	
	-- [IntUsuObjCodDescFuncion] -- descripci�n de la funci�n de ese Objeto (Elemento o Estilo) en la p�gina.
		SET @PAR8 = 'encabezado de pagina'				

--		SELECT @PAR1, @PAR2, @PAR3, @PAR4, @PAR5, @PAR6, @PAR7, @PAR8 

		-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		-- Informaci�n para cargar la estructura Arbol, O SEA D�nde va el Objeto en la P�gina.
		-- [ID]				de la tabla CIntfTUsuObjArb
		SET @PAR9 = NEWID()													-- C�digo ID unico del Objeto dentro de la estructura arbol
			
		-- [IDPadre]		es el ID del Padre
		SET @PAR10 = 'DABAE216-AE6B-44AD-AC68-F1F2A8C0E150'			
		-- ID del Padre, este valor es manual
			-- 1.- En el caso que es el Padre Inicial, el ID viene de la tabla [CIntfTObjCod] y [CIntfTObjCodxIdio]
				-- se pueden ver los distintos Objetos PagWeb en la consulta siguiente
				-- Detalle de las Paginas Web, son los Padres
					---- Lista las P�ginas Disponibles
--						DECLARE	@return_value int
--						EXEC	@return_value = [dbo].[CIntfPCodxIdio]
--								@PAR2 = N'7C2D7297-34DE-4F10-8F70-ACD26E5AFB04'		-- PagWeb	contiene las pagina web de la aplicacion.
--						-- El Ambito de Aplicaci�n es PagWeb
						--	B1E3B2FA-A308-41BC-BF59-7664A6380CE3	PagInic001	p�gina inicial
						--	9A01BFBA-6DFE-4BFA-AFD3-6A8F4044B97B	PagInic002	pagina segunda

			-- 2.- En el caso de que otro elemento sea el padre, hay que buscar el ID, para incorporarlo como padre,
				--  esta infor se saca de la siguiente consulta, hacer la consulta:

				-- <<< Procedimiento Almacenado 09 [CintfPUsuObjArbBucleIDEstInic] >>>
				-- Muestra la estructura de una p�gina sin la incorporaci�n de los Objetos Modelos si los tuviera
				-- as� se puede definir el objeto Padre si se guiere insertar un Elemento y ObjModelo
--					DECLARE	@return_value int
--					DECLARE @Pag AS NVARCHAR(36)
--				--	SET @Pag = '9A01BFBA-6DFE-4BFA-AFD3-6A8F4044B97B'	-- 	PagInic002	pagina segunda
--					SET @Pag = 'B1E3B2FA-A308-41BC-BF59-7664A6380CE3'	--	PagInic001	p�gina inicial
--					EXEC	@return_value = [dbo].[CintfPUsuObjArbBucleIDEstInic]  @PAR1 = @Pag

				-- [IDFkCIntfTUsuObjArb] esta es la columna del Padre ID

		-- [ItemNivel]		es el nivel del arbol que tiene el objeto. En el caso inicial = 1
		DECLARE @PADNIVEL AS INT		-- Padre Nivel
		DECLARE @PADITEMORD AS INT		-- Padre Orden

		SELECT @PADNIVEL = MAX([ItemNivel]), @PADITEMORD = MAX([ItemOrd])
		  FROM [BDCtral].[dbo].[CIntfTUsuObjArb]
		WHERE [ID] = @PAR10
		SET @PAR11 = CASE WHEN @PADNIVEL IS NULL THEN 1 ELSE @PADNIVEL + 1 END
		SET @PADNIVEL = CASE WHEN @PADNIVEL IS NULL THEN 0 ELSE @PADNIVEL END

		-- [ItemOrd]		es el orden dentro del Item Nivel.
		DECLARE @HIJOITEMORD AS INT
		SELECT @HIJOITEMORD = MAX([ItemOrd])
		  FROM [BDCtral].[dbo].[CIntfTUsuObjArb]
		WHERE ([ID] <> [IDFkCIntfTUsuObjArb_PadreID]) AND [IDFkCIntfTUsuObjArb_PadreID] = @PAR10

		SET @PAR12 = CASE WHEN @HIJOITEMORD IS NULL THEN 1 ELSE @HIJOITEMORD + 1 END
		SET @HIJOITEMORD = CASE WHEN @HIJOITEMORD IS NULL THEN 0 ELSE @HIJOITEMORD END

--		SELECT @PADNIVEL, @PADITEMORD, @HIJOITEMORD

		-- Le asigna el Nivel y Orden al nombre �nico del objeto
		-- Para cargar este valor debe tener el Nivel del Padre, a esto se le agrega el valor.
		SET @PAR6 = @PAR6 + CAST(@PADNIVEL AS VARCHAR(3))  + CAST(@PADITEMORD AS VARCHAR(3)) + CAST(@PAR11 AS VARCHAR(3)) + CAST(@PAR12  AS VARCHAR(3))

		-- [IDFkCIntfTUsuObj]		es el ID del objeto que se inserto en la Tabla TUsuObj. Este no es el ID del Objeto de la tabla TObjCod.
		SET @PAR13 = @PAR4					-- Para este caso es el mismo del objeto @PAR4

	-- [IDFkCxIEstados] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
		SET @PAR14 = 'c6fe2749-0cb8-49cd-97df-03c299c0c6cf'					

--		SELECT @PAR1 AS 'P01_TipoMod', @PAR2 AS 'P02_IDIdioma', @PAR3 AS 'P03_IDAmbApl', @PAR4 AS 'P04_IDCIntUsuObj'
--			, @PAR5 AS 'P05_IDFkTIntCodObj'
--			, @PAR6 AS 'P06_IntUsuObjCodUnico', @PAR7 AS 'P07_IDCodUsuUnico'
--			, @PAR8 AS 'P08_CodDescFuncion', @PAR9 AS 'P09_IDUsuObjArb', @PAR10 AS 'P10_IDPadre'
--			, @PAR11 AS 'P11_IDNivel', @PAR12 AS 'P12_IDOrden'
--			, @PAR13 AS 'P13_IDFkCIntfTUsuObj'		-- Igual a @PAR4
--			, @PAR14 AS 'P14_IDEstado'

		SET @ValVar = CASE WHEN @PAR1 IS NULL THEN 'Err' 
							WHEN @PAR2 IS NULL THEN 'Err' 
							WHEN @PAR3 IS NULL THEN 'Err' 
							WHEN @PAR4 IS NULL THEN 'Err' 
							WHEN @PAR5 IS NULL THEN 'Err' 
							WHEN @PAR6 IS NULL THEN 'Err' 
--							WHEN @PAR7 IS NULL THEN 'Err'		-- No se utiliza
							WHEN @PAR8 IS NULL THEN 'Err' 
							WHEN @PAR9 IS NULL THEN 'Err' 
							WHEN @PAR10 IS NULL THEN 'Err' 
							WHEN @PAR11 IS NULL THEN 'Err' 
							WHEN @PAR12 IS NULL THEN 'Err' 
							WHEN @PAR13 IS NULL THEN 'Err' 
							WHEN @PAR14 IS NULL THEN 'Err' 
							ELSE @ValVar 
						END
--		SELECT @ValVar

---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- Pasos antes de hacer ABM de los datos:
	-- Etapa 1: Primero verificar que con el cambio no se infrinja ninguna clave primaria
	-- Etapa 2: 
			-- 1: Si el resultado es que se infrinje, no realizar el cambio e informar al usuario
			-- 2: Si es todo OK, se realiza el cambio. Para hacer esto se hace una transacci�n para asegurar la integridad del cambio.	

IF @PAR1 = 'ALTA'
BEGIN
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- ##############################################################################################################################################
	-- INICIO -- ALTA DE CODIGO Y SUS DESCRIPCIONES
	-- ##############################################################################################################################################
	
	SET @FUNC_PROCALM = 'Alta'		-- Funcion dentro del procedimiento almacenado.

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Para agregar un nuevo C�digo, se debe:
		-- Aqu� hay ciertos elementos que en una pagina no se pueden duplicar.
		-- Esta validaci�n hay que hacerla luego.
		-- Los otros campos pueden tener cualquier valor, no se validan.

		-- Aclaraci�n: La combinaci�n m�s ID del Ambito de Aplicaci�n, por lo tanto para un idioma, puede haber dos c�digos iguales, pero cada uno para un ambito de aplicaci�n diferente.

	-- Etapa 1: Verifica Clave Primaria: que el objeto creado puede tener solamente una propiedad una sola vez
		-- Si alguno de los valores son encontrados, la variable @PAR4 se pone a NULL
--		SELECT @PAR4 = NULL
--		  FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK)
--		WHERE [IDFkTObjCod] = @PAR5 AND [IDFkTCodObjProp] = @PAR6
			-- Clave Primaria: -- IDFkTObjCod, IDFkTCodObjProp.
		--		SELECT @PAR4

	-- Etapa 2: 
			-- 1: Si el C�digo infringe la clave primaria, no hace el cambio e informa al usuario
		IF @PAR4 IS NULL OR @ValVar = 'Err'
			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			BEGIN
				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
				SET @RTADO = 'ERR' 
				SET @REG_AFEC = 0
				SET @ERR_MESSAGE = 'El Objeto ingresado ya tiene asignado esa propiedad.'
				SET @ERR_NUMBER = 0
				SET @ERR_SEVERITY = 0
				SET @ERR_STATE = 0
				SET @ERR_LINE = 0
			END
		ELSE
			-- 2: Si es todo OK, se realiza el cambio.
			BEGIN TRY
			BEGIN TRANSACTION;
			-- Inserta el codigo en las tablas. 
				
				-- PRIMERO en la tabla [CIntfTUsuObj]		Inserta los objetos de la p�gina
				BEGIN
				INSERT INTO [BDCtral].[dbo].[CIntfTUsuObj]
						   ([ID]
						   ,[IDFkCIntfTObjCod_UsuObjCod]
						   ,[IntUsuObjCodUnico]
						   ,[IntUsuObjCodUsuUnico]
						   ,[IntUsuObjCodDescFuncion]
						   ,[IDFkCDiccTCod_UsuObjEst]
						   ,[UsuObjFechaModif])
				SELECT @PAR4				-- [ID] -- valor ID del nuevo Objeto [CIntfTUsuObj], debe ser �nico.
						, @PAR5				-- [IDFkCIntfTObjCod] -- codigo ID del Objeto (Elemento o Estilo) que se insertar� en la p�gina.
						, @PAR6				-- [IntUsuObjCodUnico] -- codigo unico del Objeto (Elemento o Estilo).
						, @PAR7				-- [IntUsuObjCodUsuUnico] -- codigo unico del Objeto ingresado por el usuario.
						, @PAR8				-- [IntUsuObjCodDescFuncion] -- descripci�n de la funci�n de ese Objeto (Elemento o Estilo) en la p�gina.
						, @PAR14			-- [IDFkCDiccTCod_UsuObjEst] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
						, GETDATE()

				-- SEGUNDO en la tabla [CIntfTUsuObjArb]		Inserta el nivel y orden de los objetos
					INSERT INTO [BDCtral].[dbo].[CIntfTUsuObjArb]
							   ([ID]
							   ,[IDFkCIntfTUsuObjArb_PadreID]
							   ,[ItemNivel]
							   ,[ItemOrd]
							   ,[IDFkCIntfTUsuObj])
					 SELECT @PAR9						-- C�digo ID unico del Objeto dentro de la estructura arbol
							,@PAR10						-- [IDPadre]		es el ID del Padre, Este surge de la columna anterior. En el caso inicial cuando se crea una nueva p�gina el ID = IDPadre.
							,@PAR11						-- [ItemNivel]		es el nivel del arbol que tiene el objeto. En el caso inicial = 1
							,@PAR12						-- [ItemOrd]		es el orden dentro del Item Nivel.
							,@PAR13						-- [IDFkCIntfTUsuObj]		es el ID del objeto que se inserto en la Tabla TUsuObj. Este no es el ID del Objeto de la tabla TObjCod.

				-- TERCERO en la tabla [CIntfTUsuObjProp]
					-- Inserta las propiedades Obligatorias
					INSERT INTO [BDCtral].[dbo].[CIntfTUsuObjProp]
							   ([ID]
							   ,[IDFkCIntfTUsuObj_UsuObj]
							   ,[IDFkCintfTObjCodProp_UsuObjProp]
							   ,[UsuObjCodPropValor]
							   ,[UsuObjCodPropOrden]
							   ,[IDFkCDiccTCod_UsuObjPropEst]
							   ,[UsuObjPropFechaModif])
					SELECT NEWID() AS [ID]							-- [ID] unico del objeto modelo propiedad
							, [IDFkTCIntfTObjCod_ObjCod]			-- [ID] tabla [IDFkCIntfTObjMod_ObjModID]-- codigo ID �nico del objeto al que se le asignar�la propiedad.
				--			, [ObjCodigo]
				--			, [IDFkTCIntfTObjCodProp]
				--			, [ObjCodValor]
							, [IDFkTCIntfTObjCod_ObjCodProp]		-- [ID] tabla [IDFkCintfTObjCodProp_ObjModProp] -- valor ID �nico de la Propiedad
							, [ObjCodPropValor]						-- [ObjModCodPropValor] -- valor del Objeto
							, [ObjCodPropOrden]						-- [ObjModCodPropOrden] -- orden en que se armara el TAG
				--			, [ObjCodPropValorWeb]
				--			, [IDFkCDiccTCod_PropTipo]
				--			, [ObjPropTipo]
							, [IDFkCDiccTCod_ObjCodPropEstado]		-- [IDFkCDiccTCod_ObjModPropEst] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
							, GETDATE()								-- [ObjModPropFechaModif] -- Fecha de Modificaci�n
					FROM @TmpTObjConProp
						WHERE [IDFkTCIntfTObjCod_ObjCod] = @PAR5
								AND
							[IDFkCDiccTCod_PropTipo] = 'CC9699C0-B646-427E-B545-7AAFB23D5B95'



				END
				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
				BEGIN
					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
					SET @RTADO = 'OK' 
					SET @REG_AFEC = 1
					SET @ERR_MESSAGE = 'Se cargo la informacion solicitada.'
					SET @ERR_NUMBER = 0
					SET @ERR_SEVERITY = 0
					SET @ERR_STATE = 0
					SET @ERR_LINE = 0
				END
			
				-- Si el procedimiento es exitoso, confirma la operaci�n.
				COMMIT TRANSACTION;
			END TRY
			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
			BEGIN CATCH

				-- Ejecuta el Procedimiento Almacenado para obtener el error.
				EXECUTE [dbo].[CGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT

				-- Como la operaci�n fall�, se deshacen las modificaciones.
				ROLLBACK TRANSACTION;

				-- Por las dudas se elimana el registro con el ID generado.
				DELETE FROM [BDCtral].[dbo].[CIntfTUsuObj] WHERE [ID] = @PAR4
				DELETE FROM [BDCtral].[dbo].[CIntfTUsuObjArb] WHERE [ID] = @PAR9

				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				SET @RTADO = 'ERR'
				SET @REG_AFEC = 0
			END CATCH;

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- ##############################################################################################################################################
	-- FINAL -- ALTA DE CODIGO Y SUS DESCRIPCIONES
	-- ##############################################################################################################################################
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
END

-- ##############################################################################################################################################
-- MUESTRA EL RESULTADO DEL PROCEDIMIENTO ALMACENADO
-- Envia el resultado: Nombre Proc Alm | Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
--SET @RTADO_PROCALM = @NOMB_PROCALM + '|' + @FUNC_PROCALM + '|' + @RTADO + '|' + CAST(@REG_AFEC AS VARCHAR(10)) + '|' + @ERR_MESSAGE + '|' + CAST(@ERR_NUMBER AS VARCHAR(10)) + '|' + CAST(@ERR_SEVERITY AS VARCHAR(10)) + '|' + CAST(@ERR_STATE AS VARCHAR(10)) + '|' + CAST(@ERR_LINE AS VARCHAR(10))
--SELECT @RTADO_PROCALM			-- Muestra el resulado en una unica columna
SELECT @NOMB_PROCALM AS ProcAlm_Nomb, @FUNC_PROCALM AS ProcAlm_Funcion, @RTADO AS ProcAlm_Rtado, @REG_AFEC AS ProcAlm_RegAfec, @ERR_MESSAGE AS ProcAlm_Mensaje, @ERR_NUMBER AS ProcAlm_ErrNum, @ERR_SEVERITY AS ProcAlm_ErrSeveridad, @ERR_STATE AS ProcAlm_ErrEstado, @ERR_LINE AS ProcAlm_ErrLinea

---- DECLARE	@return_value int
--EXEC	@return_value = [dbo].[CintfPUsuObjBucleID] @PAR3 = 'B1E3B2FA-A308-41BC-BF59-7664A6380CE3'

-- ##############################################################################################################################################^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- El GO va al final del procedimiento
GO
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################

--
---- Elimina Datos de las tablas
--DECLARE @PAR1 AS VARCHAR(36)
--SET @PAR1 = 'd8ba7047-05b8-40d3-9702-fa7e9c3e87ea'		-- ID de la Tabla [CIntfTUsuObj]
--
--DELETE FROM [BDCtral].[dbo].[CIntfTUsuObj] WHERE [ID] = @PAR1
--DELETE FROM [BDCtral].[dbo].[CIntfTUsuObjArb] WHERE [IDFkCIntfTUsuObj] = @PAR1
--		


