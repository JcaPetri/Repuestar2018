-- #########################################################################################################################################################
--  GENERA LOS PROCEDIMIENTOS ALMACENADOS PARA HACER EL ALTA, MODIFICACION, BAJA O RECUPERO DE LOS CODIGOS Y SUS DESCRIPCIONES DE LA INTERFAZ DE USUARIOS -- 
-- #########################################################################################################################################################

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- Determina la base de datos donde se trabajar�
USE [BDCtral]
GO

-- ===================================================
-- Author: Juan Petri
-- Create date: 26/11/2018
-- Description:	Crea nuevas propiedades para los elementos
-- ===================================================

	-- #################################################################################################################################
	-- Para una p�gina Web - Crea los elementos que se utilizar�n
	-- para ello ejecuta el procedimiento almacenado [CIntfPCodxIdioABM]
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

		DECLARE	@return_value int
		DECLARE @PARint1 AS uniqueidentifier
		SET @PARint1 = NEWID()

		EXEC @return_value = [dbo].[CIntfPCodxIdioABM]
				@PAR1 = 'ALTA'					-- ALTA - MODIFICACION - BAJA - RECUPERO
				,@PAR2 = @PARint1				-- ID del codigo, debe ser �nico
				,@PAR3 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'					-- ID del Idioma	-- Espa�ol		
						--	ee954f5d-ca27-48a9-a23b-010788b18631	ITA	italiano
						--	b1268278-4eb3-4a93-8f67-0d425b767c65	ENG	english
						--	a455281d-76f5-4bad-8dbb-201c5928aaf8	FRA	fran�ais
						--	1048c13b-1cc9-4154-8b8b-64ca9ac9fe12	POR	portugu�s
						--	fb478ecc-85fe-4fc8-b792-caf8ecb921b1	ESP	espa�ol
				,@PAR4 = '9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B'	--	Pro	contiene las propiedades de la pagina, elementos y estilos
					-- IDFkTCodAmbAplic -- codigo del ambito de aplicacion.
						-- siempre va el mismo --	Pro	contiene las propiedades de la pagina, elementos y estilos

					-- Para determinar los ambitos de aplicaci�n para una empresa ejecutar la siguiente consulta:
--					DECLARE	@return_value int
--					EXEC	@return_value = [dbo].[CIntfPAmbAplic]
--								@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol

				,@PAR5 = 'aside' 	-- Codigo -- C�digo en letras del ID debe ser �nico para el �mbito de aplicaci�n

				,@PAR6 = 'etiqueta define alg�n contenido aparte del contenido en el que se encuentra, pero este debe estar relacionado con el contenido que lo rodea' 	-- Descripci�n -- Es la descripci�n del c�digo en letras.

				,@PAR7 = '' 	-- CodigoWeb -- C�digo en letras que se utiliza para armar la p�gina web.

				,@PAR8 = 'A745CCC2-262B-4F2A-B6AB-EAD4BCCA3CFA'	--	[IDFkCDiccTCod_ObjCodUbic]	determina si el objeto va dentro intag o fuera del tag outtag
						--	DECLARE	@return_value int
						--	EXEC	@return_value = [dbo].[CDiccPCodxIdio]	@PAR2 = N'C3133A27-4F21-4793-B186-4A640AB2AE52'
							--	A745CCC2-262B-4F2A-B6AB-EAD4BCCA3CFA	intag			valores dentro del tag
							--	00ECF783-C3C7-4178-8E8A-F83AE2EE7872	outtag			valores fuera del tag
							--  DCDF7DF1-14A0-4C31-ACB4-9B0A176406E3	no aplica		no aplica clasificacion

				,@PAR9 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'		--	HAB		habilitado 	-- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
				--		-- Caso Alta:
				--			-- Es un c�digo ID con las distintas opciones, estas pueden ser. Habilitado, Deshabilitado, Eliminado.
							-- Ejecute esta consulta y estar�n los estados disponibles. Los mismos son para todo el sistema por eso es multiempresa
--							DECLARE	@return_value int
--							EXEC	@return_value = [dbo].[CDiccPCodxIdio] 
--									@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--									,@PAR2 = '6B0CD910-C127-4450-9865-15E9F4C287B4'		-- AmbitoApicaci�n EST	estados
--									,@PAR3 = 'A5E49ED6-EFDD-4C43-955F-7F3616E39F99'		-- multiempresa	se aplica para los c�digos generales del sistema
										-- 'EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0'	--		DES		deshabilitado
										-- '3749D6D8-EF8F-4C37-893A-BE7209239810'	--		ELI		eliminado
										-- 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'	--		HAB		habilitado
				,@PAR10 = 'AltaCompleto'	-- tipo de Alta	'AltaCompleto'

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- #################################################################################################################################

		-- Info de las Propiedades de los Elementos HTML que forman parte de las paginas web
		-- aqu� esta el detalle de los elementos ingresados
--		DECLARE	@return_value int
		EXEC	@return_value = [dbo].[CIntfPCodxIdio]
					@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
					-- Ambito de Aplicaci�n elegido o por defecto = NULL
					,@PAR2 = '9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B'		--	Pro	contiene las propiedades de la pagina, elementos y estilos

