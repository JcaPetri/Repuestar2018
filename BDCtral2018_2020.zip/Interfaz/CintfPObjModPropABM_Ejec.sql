-- #########################################################################################################################################################
--  GENERA LOS PROCEDIMIENTOS ALMACENADOS PARA HACER EL ALTA, MODIFICACION, BAJA O RECUPERO DE LOS CODIGOS Y SUS DESCRIPCIONES DE LA INTERFAZ DE USUARIOS -- 
-- #########################################################################################################################################################

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- Determina la base de datos donde se trabajar�
USE [BDCtral]
GO

-- ===================================================
-- Author: Juan Petri
-- Create date: 26/11/2018
-- Description:	Crea Nuevos Elementos HTML
-- ===================================================
	DECLARE	@return_value int
	DECLARE @PARint1 AS uniqueidentifier		-- ID Nuevo
	DECLARE @PARint2 AS NVARCHAR(36)			-- [IDFkCIntfTObjMod]
	DECLARE @PARObjMod AS NVARCHAR(36)			-- Objeto Modelo Padre
	DECLARE @PARIdio AS NVARCHAR(36)			-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito

	SET @PARint1 = NEWID()
	SET @PARObjMod = '5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D'	--	EncPag001	encabezado de la p�gina
			--	'6EFA0E33-F537-4861-A35F-10ECB328FB74'	--	PiePag001	pie de la p�gina
			--	'B890DD58-58BA-4DA3-8A0C-70422298A88D'	--	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
			--	'57504A29-9F06-41B2-896C-81D5A57E37BF'	--	EstWeb001	Estructura de la p�gina Web hasta el Body
	SET @PARIdio = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito

		-- #################################################################################################################################
		-- Determina el Objeto Modelo al que se le insertar� la Propiedad
		-- para ello ejecuta el <<< Procedimiento Almacenado 06 [CintfPObjModBucleID] >>>
		-- el mismo esta en el archivo ### Sentencia SQL CintfPObjModBucleID.sql ###
		-- Hace el bucle de la Vista [dbo].[CintfVObjModCodArb], que tiene la info del [CIntfTObjModArb] y el Padre surge de la tabla [CIntfTObjCod] y [CIntfTObjCodxIdio]
		-- el resultado es la estructura del Objeto Modelo, seg�n HTML
--				EXEC	@return_value = [dbo].[CintfPObjModBucleIDProp] 
--						@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--						,@PAR2 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'		-- Ambito de Aplicaci�n elegido o por defecto = ObjMod
--						,@PAR3 = @PARObjMod		--	Objeto Modelo Padre

	-- La columna que se toma es la [IDFkCIntfTObjMod]
	SET @PARint2 = '229CE0BE-5DDB-4648-850F-5AA44DB1785D'
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

		EXEC @return_value = [dbo].[CintfPObjModPropABM]
			-- ALTA - MODIFICACION - BAJA - RECUPERO
				@PAR1 = 'ALTA'					

			-- [ID] Valor Unico de la Tabla CIntfTObjModProp
				,@PAR2 = @PARint1				

			-- [ID] tabla [CIntfTObjMod]  -- codigo ID �nico del objeto al que se le asignar�la propiedad.
				,@PAR3 = @PARint2				

			-- [ID] tabla [CintfTObjCodProp] -- valor ID �nico de la Propiedad que esta asociada al Objeto. 
					--	No es el ID de la propiedad de la tabla [CIntfTObjCod], sino el ID de la tabla [CintfTObjCodProp], 
					--	o sea de la propiedad asignada.
				,@PAR4 = '59D0497A-775C-4BC3-8599-ABD270647D52'	
					-- La columan [IDFkCintfTObjCodProp] de la consulta es igual al @PAR4, que es el valor de la propiedad para ese objeto
					-- �l @PAR3 es el ObjetoModelo, el @PAR4 es la Codigo de la Propiedad del Objeto
--					DECLARE	@return_value int
--					EXEC	@return_value = [dbo].[CIntfPObjConPropResu]
--							@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--							,@PAR2 = 'B99E0185-49D6-4D9E-89AE-DAA8C754D9A3'		-- IDFkCIntfTObjCod, es el elemento que tiene las propiedades, surge de la consutla [CintfPObjModBucleIDProp]

			--  Como este valor lo puede colocar el usuario, se carga, si es NULL, se pone el de la tabla
				,@PAR5 = 'svlindex?TPA=API&IDEmp=56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981&IDUsu=D3AE6446-4D7B-474B-ACF0-E9A75A233BC6&IDPro=79B264F7-05BA-46AE-B56F-3FAAD6F64861' 	-- Codigo -- C�digo en letras del ID debe ser �nico para el �mbito de aplicaci�n

			-- [IDFkCDiccTCod_ObjModPropEst] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
				,@PAR6 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'		--	HAB		habilitado 	-- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
				--		-- Caso Alta:
				--			-- Es un c�digo ID con las distintas opciones, estas pueden ser. Habilitado, Deshabilitado, Eliminado.
							-- Ejecute esta consulta y estar�n los estados disponibles. Los mismos son para todo el sistema por eso es multiempresa
--							DECLARE	@return_value int
--							EXEC	@return_value = [dbo].[CDiccPCodxIdio] 
--									@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--									,@PAR2 = '6B0CD910-C127-4450-9865-15E9F4C287B4'		-- AmbitoApicaci�n EST	estados
--									,@PAR3 = 'A5E49ED6-EFDD-4C43-955F-7F3616E39F99'		-- multiempresa	se aplica para los c�digos generales del sistema
										-- 'EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0'	--		DES		deshabilitado
										-- '3749D6D8-EF8F-4C37-893A-BE7209239810'	--		ELI		eliminado
										-- 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'	--		HAB		habilitado

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- #################################################################################################################################

		-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		-- <<< Procedimiento Almacenado 07 [CintfPObjModBucleIDProp] >>>
		-- el mismo esta en el archivo ### Sentencia SQL CintfPObjModBucleIDProp.sql ###
		-- Muestra el Objeto Modelo y sus propiedades.
		-- surge de la uni�n: del procedimiento almacenado [CintfPObjModBucleID] donde esta la informaci�n de la estructura arbol del elemento y
		--					del procedimiento almacena [CIntfPObjModProp] donde esta la informaci�n de las propiedades de cada elemento.
		-- <<< Sentencia SQL 06 CintfPObjModBucleIDPropConsulta.sql >>>
		-- Muestra el resultado para un Padre General de la estructura.
		EXEC	@return_value = [dbo].[CintfPObjModBucleIDProp] 
					@PAR1 = @PARIdio
					, @PAR2 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	--	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
					, @PAR3 = @PARObjMod

---- Para ver un ObjMod en particular
--DECLARE	@return_value int
--EXEC	@return_value = [dbo].[CintfPObjModBucleIDProp] 
--@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
--, @PAR2 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	--	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
--, @PAR3 = '5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D'	--	EncPag001	encabezado de la p�gina
