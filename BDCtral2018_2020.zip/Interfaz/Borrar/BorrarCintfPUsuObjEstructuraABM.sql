-- ###############################################################################################################################3
-- PARTES - Carga la Tabla [CIntfTUsuObjArbTbl] con la estructura de un Padre.
-- ###############################################################################################################################3
USE [BDCtral]
GO

--^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- Lista los padres posibles
--SELECT UOA.[ID]
--      ,UOA.[IDPadre]
--      ,UOA.[ItemNivel]
--      ,UOA.[ItemOrd]
--      ,UOA.[IDFkCIntfTUsuObj]
--	  ,UO.[IntUsuCodUnico]
--	  ,UO.[IntUsuDescFuncion]
--  FROM [BDCtral].[dbo].[CIntfTUsuObjArb] AS UOA WITH(NOLOCK) 
--		INNER JOIN [BDCtral].[dbo].[CIntfTUsuObj] AS UO WITH(NOLOCK)
--			ON UOA.[IDFkCIntfTUsuObj] = UO.[ID]
--WHERE UOA.[IDFkCIntfTUsuObj] = 'A3C3DA85-E8C0-4EDA-AF5B-21A740ED8E35'		-- C�digo del Objeto de P�ginas

	
--^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	DECLARE @PAR1 AS VARCHAR(36)				-- Valor Buscado, es el ID del Padre
	DECLARE @PAR2 AS VARCHAR(36)				-- [IDFkCxIEstados] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado

	SET @PAR1 = '40924F56-D311-4690-A911-512A67C0F312'						-- Valor Buscado, es el ID del Padre
				--	40924F56-D311-4690-A911-512A67C0F312		pag0011
	SET @PAR2 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF' 	--	HAB		habilitado		EST	estados
			-- Es un c�digo ID con las distintas opciones, estas pueden ser. Habilitado, Deshabilitado, Eliminado.
				-- 6B0CD910-C127-4450-9865-15E9F4C287B4	EST	estados			EST	estados
					-- 'EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0' 	--	DES		deshabilitado	EST	estados
					-- '3749D6D8-EF8F-4C37-893A-BE7209239810' 	--	ELI		eliminado		EST	estados
					-- 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF' 	--	HAB		habilitado		EST	estados

-- Genera una tabla temporaria para insertar los resultados
	DECLARE @TmpCodArb TABLE
	(
		[Arbol] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ArbolID] [uniqueidentifier] NULL,
		[ArbolDesc] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[IDFKUsuObjArb] [uniqueidentifier] NOT NULL,
		[ArbPadreID] [uniqueidentifier] NULL,
		[ArbItemNivel] [smallint] NULL,
		[ArbItemOrd] [smallint] NULL,
		[IDFkCIntfTUsuObj] [uniqueidentifier] NULL,
		[IntUsuCodUnico] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[IntUsuDescFuncion] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[IDFkTIntCodObj] [uniqueidentifier] NULL
	)

	DECLARE @RC int		-- Determina si la consulta tiene valores

	-- Ejecuta el procedimiento almacenado, inserta los datos en la Tabla Temporaria
	-- @PAR1 = Idioma
	-- @ID = ID es el valor buscado, codigo del Arbol
	INSERT INTO @TmpCodArb EXECUTE @RC = [dbo].[CintfPUsuObjBucleID] @PAR3 = @PAR1 
	-- SELECT @RC


-- Elimina el ID que se insertar�
DELETE FROM [BDCtral].[dbo].[CIntfTUsuObjArbTbl] WHERE [ArbolID] = @PAR1

-- Inserta el Resultado en la Tabla Arbol donde est� el resultado de las relaciones
INSERT INTO [BDCtral].[dbo].[CIntfTUsuObjArbTbl]
           ([Arbol]
           ,[ArbolID]
           ,[ArbolDesc]
           ,[IDFKUsuObjArb]
           ,[ArbPadreID]
           ,[ArbItemNivel]
           ,[ArbItemOrd]
           ,[IDFkCIntfTUsuObj]
           ,[IntUsuCodUnico]
           ,[IntUsuDescFuncion]
		   ,[IDFkTIntCodObj]
           ,[IDFkCxIEstados]
           ,[ArbolFechaModif])
	SELECT AP.[Arbol]
			,AP.[ArbolID]
			,AP.[ArbolDesc]
			,AP.[IDFKUsuObjArb]
			,AP.[ArbPadreID]
			,AP.[ArbItemNivel]
			,AP.[ArbItemOrd]
			,AP.[IDFkCIntfTUsuObj]
			,AP.[IntUsuCodUnico]
			,AP.[IntUsuDescFuncion]
			,AP.[IDFkTIntCodObj]
			,@PAR2
			,GETDATE()
	 FROM @TmpCodArb AS AP
	 ORDER BY [Arbol]


-- Resultado de la Tabla
SELECT [Arbol]
      ,[ArbolID]
      ,[ArbolDesc]
      ,[IDFKUsuObjArb]
      ,[ArbPadreID]
      ,[ArbItemNivel]
      ,[ArbItemOrd]
      ,[IDFkCIntfTUsuObj]
      ,[IntUsuCodUnico]
      ,[IntUsuDescFuncion]
	  ,[IDFkTIntCodObj]
      ,[IDFkCxIEstados]
      ,[ArbolFechaModif]
  FROM [BDCtral].[dbo].[CIntfTUsuObjArbTbl] WITH(NOLOCK)
WHERE [ArbolID] = @PAR1
ORDER BY [Arbol]
