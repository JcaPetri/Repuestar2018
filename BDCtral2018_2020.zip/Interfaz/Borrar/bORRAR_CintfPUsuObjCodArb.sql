set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO
--
-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 03/10/2018
-- Description:	Detalle de los c�digos ID, para el idioma elegido o el por defecto = espa�ol
-- =============================================
CREATE PROCEDURE [dbo].[CintfPUsuObjCodArb]
--	 Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(50) = NULL										-- Valor ID
	,@PAR2 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'	-- Idioma elegido o por defecto = espa�ol
	,@PAR3 NVARCHAR(50) = NULL										-- Valor del Padre ID
AS
BEGIN

--	DECLARE @PAR1 NVARCHAR(50)		-- Valor ID
--	DECLARE @PAR2 NVARCHAR(50)		-- Idioma elegido o por defecto = espa�ol
--	DECLARE @PAR3 NVARCHAR(50)		-- Valor del Padre ID
--
--	SET @PAR1 = NULL										-- Valor ID
--	SET @PAR2 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR3 = 'b1e3b2fa-a308-41bc-bf59-7664a6380ce3'		-- Valor del Padre ID

	SELECT UOA.[ID] 
		  ,UOA.[IDFkCIntfTUsuObjArb_PadreID]
		  ,UOA.[ItemNivel]
		  ,UOA.[ItemOrd]
		  ,UOA.[IDFkCIntfTUsuObj]
		  ,CASE WHEN UO.[IDFkCIntfTObjCod_UsuObjCod] IS NULL THEN CxI.[IDFkTCIntfTObjCod_CodxIdio] ELSE UO.[IDFkCIntfTObjCod_UsuObjCod] END AS [IDFkCIntfTObjCod_UsuObjCod]
		  ,CASE WHEN UO.[IntUsuObjCodUnico] IS NULL THEN CxI.[Codigo] ELSE UO.[IntUsuObjCodUnico] END AS [IntUsuObjCodUnico]
		  ,CASE WHEN UO.[IntUsuObjCodDescFuncion] IS NULL THEN CxI.[Descripcion] ELSE UO.[IntUsuObjCodDescFuncion] END AS [IntUsuObjCodDescFuncion]
		  ,CASE WHEN UO.[IDFkCDiccTCod_UsuObjEst] IS NULL THEN CxI.[IDFkCDiccTCod_ObjCodxIdioEst] ELSE UO.[IDFkCDiccTCod_UsuObjEst] END AS [IDFkCDiccTCod_UsuObjEst]
	  FROM [BDCtral].[dbo].[CIntfTUsuObjArb] AS UOA WITH (NOLOCK) 
		LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTUsuObj] AS UO WITH (NOLOCK) 
			ON UOA.[IDFkCIntfTUsuObj] = UO.[ID]
		LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTObjCodxIdio] AS CxI WITH (NOLOCK) 
			ON UOA.[ID] = CxI.[IDFkTCIntfTObjCod_CodxIdio]
				AND @PAR2 = CxI.[IDFkTCDiccTIdio_Idioma]
				AND ('ABEDD291-3991-4A47-8AEB-82580BF6BA8C' = CxI.[IDFkTCIntfTObjCod_AmbAplic]		-- Css		contiene todos los estilos posibles de la pagina y los elementos
							OR
						'AEFEA6F0-CC81-41AB-AD12-354A484273DA' = CxI.[IDFkTCIntfTObjCod_AmbAplic]	-- Ele		contiene los elementos de la pagina
							OR
						'B890DD58-58BA-4DA3-8A0C-70422298A88D' = CxI.[IDFkTCIntfTObjCod_AmbAplic]	-- ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
							OR 
						'7C2D7297-34DE-4F10-8F70-ACD26E5AFB04' = CxI.[IDFkTCIntfTObjCod_AmbAplic])	-- PagWeb	contiene las pagina web de la aplicacion.
	  WHERE UOA.[ID] = CASE WHEN @PAR1 IS NULL THEN UOA.[ID] ELSE @PAR1 END
			AND UOA.[IDFkCIntfTUsuObjArb_PadreID] = CASE WHEN @PAR3 IS NULL THEN UOA.[IDFkCIntfTUsuObjArb_PadreID] ELSE @PAR3 END

END


--	DECLARE	@return_value int
--	EXEC	@return_value = [dbo].[CintfPUsuObjCodArb]
--
