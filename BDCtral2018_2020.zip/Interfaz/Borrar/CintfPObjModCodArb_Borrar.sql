set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO

-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 03/10/2018
-- Description:	Detalle de los c�digos ID, para el idioma elegido o el por defecto = espa�ol
-- =============================================
ALTER PROCEDURE [dbo].[CintfPObjModCodArb]
--	 Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'	-- Idioma elegido o por defecto = espa�ol
	,@PAR2 NVARCHAR(50) = NULL										-- Valor del Padre ID
	,@PAR3 NVARCHAR(50) = NULL										-- Valor ID
AS
BEGIN

--	DECLARE @PAR1 NVARCHAR(50)		-- Idioma elegido o por defecto = espa�ol
--	DECLARE @PAR2 NVARCHAR(50)		-- Valor del Padre ID
--	DECLARE @PAR3 NVARCHAR(50)		-- Valor ID
--
--	SET @PAR1 = 'FB478ECC-85FE-4FC8-B792-CAF8ECB921B1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR2 = NULL		-- Valor del Padre ID
--	SET @PAR3 = NULL										-- Valor ID


----	SET @PAR1 = '57504A29-9F06-41B2-896C-81D5A57E37BF'		-- Valor del Padre ID
--	SET @PAR3 = NULL

	SELECT OMA.[ID] 
		  ,OMA.[IDFkCIntfTObjModArb_PadreID]
		  ,OMA.[ItemNivel]
		  ,OMA.[ItemOrd]
		  ,OMA.[IDFkCIntfTObjMod]
		  ,CASE WHEN OM.[IDFkCIntfTObjCod_ObjMod] IS NULL THEN CxI2.[IDFkTCIntfTObjCod_CodxIdio] ELSE OM.[IDFkCIntfTObjCod_ObjMod] END AS [IDFkCIntfTObjCod_ObjMod]
		  ,CASE WHEN OM.[ObjModCodUnico] IS NULL THEN CxI2.[Codigo] ELSE OM.[ObjModCodUnico] END AS [ObjModCodUnico]
		  ,CASE WHEN OM.[ObjModCodDescFuncion] IS NULL THEN CxI2.[Descripcion] ELSE OM.[ObjModCodDescFuncion] END AS [ObjModCodDescFuncion]
		  ,CASE WHEN OM.[IDFkCDiccTCod_ObjModEst] IS NULL THEN CxI2.[IDFkCDiccTCod_ObjCodxIdioEst] ELSE OM.[IDFkCDiccTCod_ObjModEst] END AS [IDFkCDiccTCod_ObjModEst]
		  ,CASE WHEN CxI1.[IDFkTCDiccTIdio_Idioma] IS NULL THEN CxI2.[IDFkTCDiccTIdio_Idioma] ELSE CxI1.[IDFkTCDiccTIdio_Idioma] END AS [IDFkTCDiccTIdio_Idioma]
	  FROM [BDCtral].[dbo].[CIntfTObjModArb] AS OMA WITH (NOLOCK)
		-- Primero: trae la info de los Elementos que componen el Arbol
		LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTObjMod] AS OM WITH (NOLOCK) 
			ON OMA.[IDFkCIntfTObjMod] = OM.[ID]
				LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTObjCodxIdio] AS CxI1 WITH (NOLOCK) 
					ON OM.[IDFkCIntfTObjCod_ObjMod] = CxI1.[IDFkTCIntfTObjCod_CodxIdio]
						AND @PAR1 = CxI1.[IDFkTCDiccTIdio_Idioma]
						AND	'AEFEA6F0-CC81-41AB-AD12-354A484273DA' = CxI1.[IDFkTCIntfTObjCod_AmbAplic]		--	Ele		contiene los elementos de la pagina
		-- Segundo: trae la info de los Objetos Modelos que componen el Arbol
		-- Como los Objetos Modelos, no estan en la tabla [CIntfTObjMod], con el vinculo anterior no trae la informaci�n en detalle
		-- es por ello, que aqu� se vincula directamente con la tabla [CIntfTObjCodxIdio] donde si esta la informaci�n.
		-- la �nica variable que puede cambiar es el idioma, los �mbitos de aplicaci�n ya est�n predefinidos, por el ObjMod
		LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTObjCodxIdio] AS CxI2 WITH (NOLOCK) 
			ON OMA.[IDFkCIntfTObjMod] = CxI2.[IDFkTCIntfTObjCod_CodxIdio]
				AND @PAR1 = CxI2.[IDFkTCDiccTIdio_Idioma]
				AND 'B890DD58-58BA-4DA3-8A0C-70422298A88D' = CxI2.[IDFkTCIntfTObjCod_AmbAplic]	--	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
--					 OR 'AEFEA6F0-CC81-41AB-AD12-354A484273DA' = CxI2.[IDFkTCIntfTObjCod_AmbAplic]		--	Ele		contiene los elementos de la pagina
--					 OR '9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B' = CxI2.[IDFkTCIntfTObjCod_AmbAplic]	--	Pro		contiene las propiedades de la pagina, elementos y estilos
--					 OR 'ABEDD291-3991-4A47-8AEB-82580BF6BA8C' = CxI2.[IDFkTCIntfTObjCod_AmbAplic]	--	Css		contiene todos los estilos posibles de la pagina y los elementos
--					 OR 'B890DD58-58BA-4DA3-8A0C-70422298A88D' = CxI2.[IDFkTCIntfTObjCod_AmbAplic]	--	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
	  WHERE OMA.[IDFkCIntfTObjModArb_PadreID] = CASE WHEN @PAR2 IS NULL THEN OMA.[IDFkCIntfTObjModArb_PadreID] ELSE @PAR2 END
			AND OMA.[ID] = CASE WHEN @PAR3 IS NULL THEN OMA.[ID] ELSE @PAR3 END
	ORDER BY OMA.[ItemNivel]
		  ,OMA.[ItemOrd]

END

--
--	DECLARE	@return_value int
--	EXEC	@return_value = [dbo].[CintfPObjModCodArb]
--
--


