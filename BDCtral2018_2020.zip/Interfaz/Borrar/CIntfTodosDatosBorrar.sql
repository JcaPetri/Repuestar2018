
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- Determina la base de datos donde se trabajar�
USE [BDCtral]
GO

DECLARE	@return_value int

-- El M�dulo Interfaz tiene una estructura independiente en el sistema en lo que se refiere aal ObjCod y ObjCodxIdio
-- seg�n el elemento creado, es si corresponde cambiarle el c�digo en el idioma.
-- si se utiliza para el servlet, el c�digo es igual en todos los idiomas.

--######################################################################################################################################################################
-- Info de los Ambitos de Aplicaci�n del M�dulo C Interfaz Usuario
EXEC @return_value = [dbo].[CIntfPAmbAplic] 
		@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
		,@PAR2 = NULL										-- Ambito de Aplicaci�n elegido o por defecto = NULL

--######################################################################################################################################################################
-- Info de las P�ginas Web cargadas en el sistema.
EXEC @return_value = [dbo].[CIntfPCodxIdio]
		@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
		,@PAR2 = '7C2D7297-34DE-4F10-8F70-ACD26E5AFB04'		-- Ambito de Aplicaci�n elegido o por defecto = NULL

--######################################################################################################################################################################
-- Carga los Objetos en las tablas:
--			[CIntfTObjCod], esta la informaci�n de los ID de objetos, su ubicaci�n outtag, intag, no corr y el estado del objeto (hab / deshab)
--			[CIntfTObjCodxIdio], detalle para el idioma elegido de lo que significa cada ID, para todos los elementos que se utilizan en el sevlet, los valores son iguales para todos los idiomas.

-- Hay 10 variables a cambiar, pero las m�s importantes son:
--	@PAR4 = Ambito de aplicaci�n, determina en que tabla se cargar� el objeto creado
		-- Algunos ejemplos:
			--	EBFEF35D-D9F8-4116-953D-0E2ED4341E6E	CIntfObjTipo		tabla con los tipos de objetos de la interfaz de usuario.
			--	C3133A27-4F21-4793-B186-4A640AB2AE52	CIntfObjUbic		determina si el objeto va dentro intag o fuera del tag outtag.
			--	EBFEF35D-D9F8-4116-953D-0E2ED4341E6E	CIntfObjTipo		tabla con los tipos de objetos de la interfaz de usuario.
			--	C3133A27-4F21-4793-B186-4A640AB2AE52	CIntfObjUbic		determina si el objeto va dentro intag o fuera del tag outtag.
			--	ABEDD291-3991-4A47-8AEB-82580BF6BA8C	Css					contiene todos los estilos posibles de la pagina y los elementos.
			--	AEFEA6F0-CC81-41AB-AD12-354A484273DA	Ele					contiene los elementos de la pagina.
			--	9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B	Pro					contiene las propiedades de la pagina, elementos y estilos.
			--	540C0AB8-CFCA-4346-AC40-D159787DAEA2	UsuObj				contiene las descripciones de los usuarios objetos que forman parte de las objetos.
			--	B890DD58-58BA-4DA3-8A0C-70422298A88D	ObjMod				contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
			--	7C2D7297-34DE-4F10-8F70-ACD26E5AFB04	PagWeb				contiene las pagina web de la aplicacion.
			--  60F2A98E-23BC-4BFF-9C13-9FE3D922C4D9	<footer>			pie de p�gina
--	@PAR5 = c�digo, debe ser �nico para el �mbito de aplicaci�n elegido.
--	@PAR6 = descripci�n del c�digo.
--	@PAR7 = c�digo web, es el valor que se utiliza para poner el ID de cada elmento en el html del servlet
--	@PAR8 - determina si el objeto va dentro intag o fuera del tag outtag
	-- Para ver los par�metros ejecutar el siguiente procedimiento
			--	DECLARE	@return_value int
			--	EXEC	@return_value = [dbo].[CDiccPCodxIdio]	@PAR2 = N'C3133A27-4F21-4793-B186-4A640AB2AE52'
				--	A745CCC2-262B-4F2A-B6AB-EAD4BCCA3CFA	intag			valores dentro del tag
				--	00ECF783-C3C7-4178-8E8A-F83AE2EE7872	outtag			valores fuera del tag
				--  DCDF7DF1-14A0-4C31-ACB4-9B0A176406E3	no aplica		no aplica clasificacion

--######################################################################################################################################################################
-- Consulta para determinar la integridad del M�dulo Interfaz
--	CIntfPCodxIdioIntegridad.sql


--######################################################################################################################################################################
-- Consulta para eliminar realmente un c�digo de la base de datos, cuando se ejecuta, elimina todos los codigos de la base de datos
-- tener mucho cuidado ya que puede romper la integridad del sistema.
--	CIntfPEliminaRealmenteUnCodigo.sql

--######################################################################################################################################################################
-- Info de los Objetos y sus propiedades
-- busca en las tablas:
--			[CIntfTObjCod], esta la informaci�n de los ID de objetos, su ubicaci�n outtag, intag, no corr y el estado del objeto (hab / deshab)
--			[CintfTObjCodProp], esta la informaci�n para cada objeto, la propiedad, el valor, tipo de propiedad (oblig o no)
--			[CIntfTObjCodxIdio], detalle para el idioma elegido de lo que significa cada ID, para todos los elementos que se utilizan en el sevlet, los valores son iguales para todos los idiomas.
--	Tips: si no carga dato a la variable @PAR2, trae todos los elementos y sus propiedades.
	DECLARE	@return_value int
	EXEC	@return_value = [dbo].[CIntfPObjConProp]
	@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'					-- Idioma elegido o por defecto = espa�ol
	,@PAR2 = 'CCD03587-4CFE-4088-A699-6F8E8AD31088'					-- [ID] tabla [CIntfTObjMod]-- codigo ID �nico del objeto al que se le asignar�la propiedad.


--######################################################################################################################################################################
--	Modulo Procesos e Interfaz de Usuario
--######################################################################################################################################################################
-- Info de la TGestionEtapaMotivo de inicio de los proceso del sistema.
-- cada proceso solo puede tener una sola EtapaMotivo de Inicio.
-- Para una Empresa determinada, especifica la TGestion Etapa Motivo que inicia el proceso elegido
--DECLARE	@return_value int
EXEC @return_value = [dbo].[CPrGePProcInicio] 
	@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- Empresa

--######################################################################################################################################################################
-- Para una Empresa y un Usuario determinado, especifica la p�gina inicial que deber� abrir.
-- va desde el Usuario, al Grupo de Usuarios, luego va a los Perfiles, 
-- Ya con el perfil busca la p�gina Default que tiene asociada.
--DECLARE	@return_value int
EXEC @return_value = [dbo].[CPrGePUsuAPagInic] 
	@PAR1 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- Empresa		--	BPM	Business Process Managment
	,@PAR2 = 'D3AE6446-4D7B-474B-ACF0-E9A75A233BC6'		-- Usuario		--	An�nimo

---- Trae la p�gina Web asociada a la Empresa y Usuario seleccionado
--DECLARE	@return_value int
--EXEC	@return_value = [dbo].[CIntfPUsu]
--		@PAR1 = N'B1E3B2FA-A308-41BC-BF59-7664A6380CE3'