set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


USE [BDCtral]
GO

-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 17/10/2018
-- Description:	Detalle de la Tabla CintPObjCod y CodxIdio, para el idioma elegido o el por defecto = espa�ol
-- =============================================
ALTER PROCEDURE [dbo].[CIntfPObjYProp]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 NVARCHAR(50) = NULL										-- Ambito de Aplicaci�n elegido o por defecto = NULL
	,@PAR3 NVARCHAR(50) = NULL										-- ID Objeto Codigo
AS
BEGIN

--	DECLARE @PAR1 NVARCHAR(50)		-- Idioma elegido o por defecto = espa�ol
--	DECLARE @PAR2 NVARCHAR(50) 		-- Ambito de Aplicaci�n elegido o por defecto = NULL
--	DECLARE @PAR3 NVARCHAR(50) 		-- ID Objeto Codigo
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR2 = NULL										-- Ambito de Aplicaci�n elegido o por defecto = NULL
--	SET @PAR3 = NULL										-- ID Objeto Codigo

	-- Tabla con la informaci�n de los C�digos por Idiomas
	DECLARE @TmpTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)

	-- Inserta en la tabla temporal la informaci�n de los c�digos seg�n el idioma elegido
	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1
				AND
			  CxI.[IDFkTCodAmbAplic] = CASE WHEN @PAR2 IS NULL THEN CxI.[IDFkTCodAmbAplic] ELSE @PAR2 END

	-- Tabla con la informaci�n de los Objetos C�digos por Idiomas
	DECLARE @TmpIntfTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCIntfTObjCod_CodxIdio] [uniqueidentifier] NOT NULL,
		[CxICodigo] [varchar](55) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[CxIDescripcion] [varchar](255) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[IDFkTCIntfTObjCod_AmbAplic] [uniqueidentifier] NOT NULL,
		[AmbApliCodigo] [varchar](55) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[AmbApliDescripcion] [varchar](255) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[IDFkCDiccTCod_ObjCodxIdioEst] [uniqueidentifier] NULL,
		[CxIEstCodigo] [varchar](55) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[CxIEstDescripcion] [varchar](255) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[IDFkTCDiccTIdio_Idioma] [uniqueidentifier] NOT NULL,
		[CodIdioma] [varchar](55) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](255) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[TCodxIdioFechaModif] [datetime] NULL
	)
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO @TmpIntfTCodxIdi
		SELECT IfCxI.[IDFkTCIntfTObjCod_CodxIdio]
			  ,IfCxI.[Codigo]
			  ,IfCxI.[Descripcion]
			  ,IfCxI.[IDFkTCIntfTObjCod_AmbAplic]
			  ,IfCxI2.[Codigo] AS [AmbApliCodigo]
			  ,IfCxI2.[Descripcion] AS [AmbApliDescripcion]
			  ,IfCxI.[IDFkCDiccTCod_ObjCodxIdioEst]
			  ,CxI.[Codigo] AS [EstCodigo]
			  ,CxI.[Descripcion] AS [EstDescripcion]
			  ,IfCxI.[IDFkTCDiccTIdio_Idioma]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
			  ,IfCxI.[ObjCodxIdioFechaModif]
		  FROM [BDCtral].[dbo].[CIntfTObjCodxIdio] AS IfCxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON IfCxI.[IDFkTCDiccTIdio_Idioma] = Idi.[ID]
							AND
						Idi.[ID] = @PAR1				-- Idioma elegido
				INNER JOIN [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK)
					ON IfCxI.[IDFkCDiccTCod_ObjCodxIdioEst] = CxI.[IDFkTCodigos]
							AND
						CxI.IDFkTIdioma = @PAR1		-- Idioma elegido
				INNER JOIN [BDCtral].[dbo].[CIntfTObjCodxIdio] AS IfCxI2 WITH (NOLOCK) 
					ON IfCxI.[IDFkTCIntfTObjCod_AmbAplic] = IfCxI2.[IDFkTCIntfTObjCod_CodxIdio]
							AND
						IfCxI2.[IDFkTCDiccTIdio_Idioma] = @PAR1		-- Idioma elegido
		WHERE IfCxI.[IDFkTCIntfTObjCod_AmbAplic] = CASE WHEN @PAR2 IS NULL THEN IfCxI.[IDFkTCIntfTObjCod_AmbAplic] ELSE @PAR2 END		-- Ambito de Aplicaci�n

--	SELECT * FROM @TmpTCodxIdi
--	SELECT * FROM @TmpIntfTCodxIdi

		SELECT  ICxI1.[IDFkTCIntfTObjCod_CodxIdio]
--			, OP.[IDFkTCIntfTObjCod_ObjCod]
			, ICxI1.[AmbApliCodigo] AS ObjTipo
			, ICxI1.[CxICodigo] AS ObjCod
			, ICxI1.[CxIDescripcion] AS ObjDesc
			, OP.[ID] AS [IDFkCintfTObjCodProp]
--			, OP.[IDFkTCIntfTObjCod_ObjCodProp]
			, ICxI2.[AmbApliCodigo] AS ObjPropTipo
			, ICxI2.[CxICodigo] AS ObjPropCod
			, ICxI2.[CxIDescripcion] AS ObjPropDesc
			, OP.[ObjCodPropValor] AS ObjPropVal
			, OP.[ObjCodPropOrden] AS ObjPropOrd
			, ICxI3.[Codigo] AS ObjPropUbic
		FROM [BDCtral].[dbo].[CintfTObjCodProp] AS OP WITH (NOLOCK) 
			INNER JOIN @TmpIntfTCodxIdi AS ICxI1
				ON OP.[IDFkTCIntfTObjCod_ObjCod] = ICxI1.[IDFkTCIntfTObjCod_CodxIdio]
			INNER JOIN @TmpIntfTCodxIdi AS ICxI2
				ON OP.[IDFkTCIntfTObjCod_ObjCodProp] = ICxI2.[IDFkTCIntfTObjCod_CodxIdio]
			INNER JOIN [BDCtral].[dbo].[CIntfTObjCod] AS OC WITH (NOLOCK)
				ON OP.[IDFkTCIntfTObjCod_ObjCod] = OC.[ID]
					LEFT OUTER JOIN @TmpTCodxIdi AS ICxI3
						ON OC.[IDFkCDiccTCod_ObjCodUbic] = ICxI3.[IDFkTCodigos]
		WHERE ICxI1.[IDFkTCIntfTObjCod_CodxIdio] = CASE WHEN @PAR3 IS NULL THEN ICxI1.[IDFkTCIntfTObjCod_CodxIdio] ELSE @PAR3 END
		ORDER BY ICxI1.[IDFkTCIntfTObjCod_CodxIdio], OP.[ObjCodPropOrden]

 END
--
--	DECLARE	@return_value int
--	EXEC	@return_value = [dbo].[CIntfPObjYProp]
