-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
/* Muestra para cada objeto sus propiedades */
SELECT Obj01.[ID] AS [Obj_ID]
       ,Obj01.[ObjTipo] AS [Obj_Tipo]
       ,Obj01.[ObjCod] AS [Obj_Cod]
--       ,Obj01.[ObjDesc] AS [Obj_Desc]
	   ,ObjPro01.[ID] AS [PropID]
--	   ,ObjPro01.[IDGIntObj] AS [Obj_ID_TablaProp]
--	   ,ObjPro01.[IDGIntObjProp] AS [Obj_ID_ProCssMetFun]
	   ,Obj02.[ObjTipo] AS [PropTipo]		-- _ProCssMetFun
       ,Obj02.[ObjCod] AS [PropCodObj]		-- _Cod_ProCssMetFun
       ,Obj02.[ObjUbic] AS [Obj_Ubic]
--       ,Obj02.[ObjDesc] AS [Obj_Des_ProCssMetFun]
	   ,ObjPro01.[IntObjValor] AS [ProCssMetFun_Valor]
	   ,ObjPro01.[IntObjOrden] AS [ProCssMetFun_Orden]
	FROM [BDCtral].[dbo].[GIntObj] AS Obj01 WITH(NOLOCK)
		INNER JOIN [BDCtral].[dbo].[GintObjProp] AS ObjPro01 WITH(NOLOCK)		-- Detalla las Propiedades, Estilos, Metodos y Funciones de cada elemento.
			ON Obj01.[ID] = ObjPro01.[IDGIntObj]
		INNER JOIN [BDCtral].[dbo].[GIntObj] AS Obj02 WITH(NOLOCK)				-- Toma el detalle de la Propiedad, Estilo, Metodos y funciones.
			ON ObjPro01.[IDGIntObjProp] = Obj02.[ID]
ORDER BY Obj01.[ObjCod], ObjPro01.[IntObjOrden]	

