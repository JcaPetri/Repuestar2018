-- #########################################################################################################################################################
--  GENERA LOS PROCEDIMIENTOS ALMACENADOS PARA HACER EL ALTA, MODIFICACION, BAJA O RECUPERO DE LAS PROPIEDADES 
--	DE LOS OBJETOS MODELOS tabla [CIntfTObjMod] -- 

-- ################################################################################################################################
-- ################################################################################################################################
-- Trabaja con la tabla CIntfTObjModProp  
-- Para armar el objeto:
--			1.- Insertar la propiedades del objeto
-- Las propiedades disponibles para cada objeto estan en la tabla [CintfTObjCodProp]
-- para un objeto solo puede tener una sola vez la propiedad.
-- ################################################################################################################################

USE [BDCtral]
GO

-- Tabla propiedades [CintfTObjCodProp]

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 05/12/2018
-- Description: Trabaja con la tabla [CIntfTObjCod] y [CintfTObjCodProp]
-- arma la estructura de los objetos (Paginas, Elementos, Propiedades, Estilos, Metodos, Funciones)
-- estas Tablas no tienen los valores del usuario, sino conforman como es el objeto predeterminado.
-- =============================================

ALTER PROCEDURE [dbo].[CintfPObjModPropABM]
	@PAR1 AS VARCHAR(50)	-- Determina acci�na realizar 
	,@PAR2 AS VARCHAR(36)	-- NewId() [ID] Valor Unico de la Tabla CIntfTObjModProp
	,@PAR3 AS VARCHAR(36)	-- [ID] tabla [CIntfTObjMod]  -- codigo ID �nico del objeto al que se le asignar�la propiedad.
	,@PAR4 AS VARCHAR(36)	-- [ID] tabla [CintfTObjCodProp] -- valor ID �nico de la Propiedad
	,@PAR5 AS VARCHAR(250) 	--  Como este valor lo puede colocar el usuario, se carga, si es NULL, se pone el de la tabla
	,@PAR6 AS VARCHAR(36) 	-- [IDFkCDiccTCod_ObjModPropEst] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
AS
BEGIN

	DECLARE	@return_value int
	DECLARE @PARInt1 AS INT						-- [ObjModCodPropOrden] -- orden en que se armara el TAG
	DECLARE @ValVar AS VARCHAR(50)
	SET @ValVar = 'VAL'

	-- Variables para obtener los valores del procedimiento almacenado de CGetErrorInfo
		DECLARE @RTADO_PROCALM AS VARCHAR(250)
		DECLARE @NOMB_PROCALM AS VARCHAR(250)
		DECLARE @FUNC_PROCALM AS VARCHAR(100)
		DECLARE @RTADO AS VARCHAR(250)
		DECLARE @REG_AFEC AS NUMERIC(18, 0)
		DECLARE @ERR_MESSAGE AS VARCHAR(250)
		DECLARE @ERR_NUMBER AS NUMERIC(18, 0)
		DECLARE @ERR_SEVERITY AS NUMERIC(18, 0)
		DECLARE @ERR_STATE AS NUMERIC(18, 0)
		DECLARE @ERR_LINE AS NUMERIC(18, 0)
		
		SET @NOMB_PROCALM = 'CIntfTObjModProp'				-- Nombre del procedimiento almacenado.

--		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--		-- Variables para realizar al ABM, se debe:
--			-- Variables Etapa 1
--			DECLARE @PAR1 AS VARCHAR(50)			-- Determina acci�na realizar 
--				-- valores posibles: ALTA - MODIFICACION - BAJA - RECUPERO
--				-- Como estos valores son para todas las tablas e idiomas unicos siempre van los mismos
--
--			DECLARE @PAR2 AS uniqueidentifier		-- [ID], de la tabla [CIntfTObjModProp], esto se usa para modificar una propiedad
--
--			DECLARE @PAR3 AS VARCHAR(36)			-- [ID] tabla [CIntfTObjMod]-- codigo ID �nico del objeto al que se le asignar�la propiedad.
--				-- Caso Alta: 
--					-- surge de la tabla [CIntfTObjMod], que se muestra en la consulta [CIntfVObjMod]
--						--	SELECT * FROM [BDCtral].[dbo].[CIntfVObjMod]
--
--			DECLARE @PAR4 AS VARCHAR(36)				-- [ID] tabla [CintfTObjCodProp] -- valor ID �nico de la Propiedad
--				-- Caso Alta: 
--					-- Este valor se incorpora manualmente. Seg�n el Objeto es la propiedad que el usuario quiera asignar.
--						--	DECLARE	@return_value int
--						--	EXEC	@return_value = [dbo].[CIntfPObjYProp] @PAR4 = N'a96324e5-b360-4d6d-9486-4dfd63565f70'
--
--			DECLARE @PAR5 AS nvarchar(250)				-- [ObjModCodPropValor] -- valor del Objeto
--				-- Caso Alta: 
--					-- El valor puede o no cambiarlo el usuario
--				-- Caso Modificaci�n: 
--
--			DECLARE @PAR6 AS VARCHAR(36) 				-- [IDFkCDiccTCod_ObjModPropEst] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
--				-- Caso Alta:
--					-- Es un c�digo ID con las distintas opciones, estas pueden ser. Habilitado, Deshabilitado, Eliminado.
--						-- 6B0CD910-C127-4450-9865-15E9F4C287B4	EST	estados			EST	estados
--							-- EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0	DES	deshabilitado	EST	estados
--							-- 3749D6D8-EF8F-4C37-893A-BE7209239810	ELI	eliminado		EST	estados
--							-- C6FE2749-0CB8-49CD-97DF-03C299C0C6CF	HAB	habilitado		EST	estados
--				-- Caso Modificaci�n:
--					-- Se cambia el estado sin realizar verificaciones. en caso de que se recupere el c�digo, se debe verificar que no se infrinjan las reglas primarias.
--		-- Valores de las variables para generar las prueba del funcionamiento de las consultas.
--		--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--			-- SETEO DE LAS VARIABLES PARA EL ALTA DE UN CODIGO Y SUS DESCRIPCIONES
--				SET @PAR1 = 'ALTA'													-- ALTA - MODIFICACION - BAJA - RECUPERO
--				SET @PAR2 = NEWID()													-- [ID] Valor Unico de la Tabla CIntfTObjModProp
--				SET @PAR3 = 'ACEF84DB-B007-4BD2-AFB2-CCF4343B925B'					-- [ID] tabla [CIntfTObjMod]  -- codigo ID �nico del objeto al que se le asignar�la propiedad.
--					-- #################################################################################################################################
--					-- Determina el Objeto Modelo al que se le insertar� la Propiedad
--					-- para ello ejecuta el <<< Procedimiento Almacenado 06 [CintfPObjModBucleID] >>>
--					-- el mismo esta en el archivo ### Sentencia SQL CintfPObjModBucleID.sql ###
--					-- Hace el bucle de la Vista [dbo].[CintfVObjModCodArb], que tiene la info del [CIntfTObjModArb] y el Padre surge de la tabla [CIntfTObjCod] y [CIntfTObjCodxIdio]
--					-- el resultado es la estructura del Objeto Modelo, seg�n HTML
----						DECLARE	@return_value int
----						DECLARE @PARObjMod NVARCHAR(50)		-- Objeto Modelo Padre
----						SET @PARObjMod = '5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D'	--	EncPag001	encabezado de la p�gina
----								--	'6EFA0E33-F537-4861-A35F-10ECB328FB74'	--	PiePag001	pie de la p�gina
----								--	'B890DD58-58BA-4DA3-8A0C-70422298A88D'	--	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
----								--	'57504A29-9F06-41B2-896C-81D5A57E37BF'	--	EstWeb001	Estructura de la p�gina Web hasta el Body
----
----						EXEC	@return_value = [dbo].[CintfPObjModBucleID] 
----									@PAR1 = @PARObjMod		--	Objeto Modelo Padre
----									,@PAR2 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
----									,@PAR3 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'		-- Ambito de Aplicaci�n elegido o por defecto = ObjMod
--					-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--				SET @PAR4 = '68410BFD-E436-4614-91B5-1994BE0742BA'			-- valor ID �nico de la Propiedad que esta asociada al Objeto. 
--					--	No es el ID de la propiedad de la tabla [CIntfTObjCod], sino el ID de la tabla [CintfTObjCodProp], 
--					--	o sea de la propiedad asignada.
--					-- Este valor se incorpora manualmente. Seg�n el Objeto es la propiedad que el usuario quiera asignar.
--							-- Para ver los valores disponibles para el CodObjeto, hay que ejecutar la siguiente consulta
--		--					DECLARE	@return_value int
--		--					EXEC	@return_value = [dbo].[CIntfPObjConPropResu]
--		--							@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--					-- Se toma el valor ID que es el [CintfTObjCodProp]
--
--				-- [ObjModCodPropValor] y [ObjModCodPropOrden]
--				SET @PAR5 = 'wrapper borrar'			--  Como este valor lo puede colocar el usuario, se carga, si es NULL, se pone el de la tabla
--			
--				-- @PAR4 = [ID]				-- Con el ID del Objeto y el ID de la propiedad, busca el ID de la tabla [CintfTObjCodProp], que representa el valor �nico de esa combinaci�n
--
--				SET @PAR6 = 'c6fe2749-0cb8-49cd-97df-03c299c0c6cf'									-- [IDFkCDiccTCod_ObjModPropEst] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado

				SELECT @PAR5 = CASE WHEN @PAR5 IS NULL THEN [ObjCodPropValor] ELSE @PAR5 END		-- [ObjCodPropValor] -- valor del Objeto
					  , @PARInt1 = [ObjCodPropOrden]													-- [ObjCodPropValor] -- orden en que se armara el TAG
				  FROM [BDCtral].[dbo].[CintfVObjCodProp]
				WHERE [ID] = @PAR4

				SET @PARInt1 = CASE WHEN @PARInt1 IS NULL THEN 1 ELSE @PARInt1 END

				SET @ValVar = CASE WHEN @PAR1 IS NULL THEN 'Err' 
									WHEN @PAR2 IS NULL THEN 'Err' 
									WHEN @PAR3 IS NULL THEN 'Err' 
									WHEN @PAR4 IS NULL THEN 'Err' 
									WHEN @PAR5 IS NULL THEN 'Err' 
									WHEN @PARInt1 IS NULL THEN 'Err' 
									WHEN @PAR6 IS NULL THEN 'Err'
									ELSE @ValVar 
								END
-- Resultados
--				SELECT @ValVar
--				SELECT @PAR1 AS 'P01_Accion', @PAR2 AS 'P02_CIntfTObjModProp', @PAR3 AS 'P03_IDObjModProp', @PAR4 AS 'P05_ObjCodProp', @PAR5 AS 'P06_PropVal', @PARInt1 AS 'P07_PropOrd', @PAR6 AS 'P08_PropEst'

		--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		--	-- SETEO DE LAS VARIABLES PARA LA MODIFICACION DE UN CODIGO Y SUS DESCRIPCIONES
		--		SET @PAR1 = 'MODIFICACION'											-- ALTA - MODIFICACION - BAJA - RECUPERO
		--		SET @PAR5 = 'ABE14F0E-8DF7-4492-9DB9-77199807D80A'					-- ID del codigo, debe ser �nico
		--		SET @PARInt1 = 'FB478ECC-85FE-4FC8-B792-CAF8ECB921B1'					-- ID del Idioma	-- Espa�ol		
		--		SET @PAR6 = '528CEED9-D2B3-4CB5-8116-01BDAD455C83'					-- ID del Ambito de Aplicaci�n del C�digo -- Usuarios	

		---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		---- Valores de las variables para agregarle al codigo ID, solo el Codigo por Idioma nuevo. No agrega el cogido porque ya existe para un idioma.
		---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		--	-- SETEO DE LAS VARIABLES PARA EL ALTA DE UN CODIGO Y SUS DESCRIPCIONES
		--		SET @PAR1 = 'ALTA'												-- ALTA - MODIFICACION - BAJA - RECUPERO
		--		SET @PAR5 = '3749D6D8-EF8F-4C37-893A-BE7209239810'					-- ID del codigo, este ya es un codigo generado
		--		SET @PARInt1 = 'b1268278-4eb3-4a93-8f67-0d425b767c65'					-- ID del Idioma
		----				ee954f5d-ca27-48a9-a23b-010788b18631	ITA	italiano
		----				b1268278-4eb3-4a93-8f67-0d425b767c65	ENG	english
		----				a455281d-76f5-4bad-8dbb-201c5928aaf8	FRA	fran�ais
		----				1048c13b-1cc9-4154-8b8b-64ca9ac9fe12	POR	portugu�s
		----				fb478ecc-85fe-4fc8-b792-caf8ecb921b1	ESP	espa�ol
		--		SET @PAR6 = '6B0CD910-C127-4450-9865-15E9F4C287B4'					-- ID del Ambito de Aplicaci�n del C�digo -- Usuarios	

		---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

		-- Pasos antes de hacer ABM de los datos:
			-- Etapa 1: Primero verificar que con el cambio no se infrinja ninguna clave primaria
			-- Etapa 2: 
					-- 1: Si el resultado es que se infrinje, no realizar el cambio e informar al usuario
					-- 2: Si es todo OK, se realiza el cambio. Para hacer esto se hace una transacci�n para asegurar la integridad del cambio.	

			IF @PAR1 = 'ALTA'
			BEGIN
				-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				-- ##############################################################################################################################################
				-- INICIO -- ALTA DE CODIGO Y SUS DESCRIPCIONES
				-- ##############################################################################################################################################
				
				SET @FUNC_PROCALM = 'Alta'		-- Funcion dentro del procedimiento almacenado.

				-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				-- Para agregar un nuevo C�digo, se debe:
					-- Aqu� hay ciertos elementos que en una pagina no se pueden duplicar.
					-- Esta validaci�n hay que hacerla luego.
					-- Los otros campos pueden tener cualquier valor, no se validan.

					-- Aclaraci�n: La combinaci�n m�s ID del Ambito de Aplicaci�n, por lo tanto para un idioma, puede haber dos c�digos iguales, pero cada uno para un ambito de aplicaci�n diferente.

				-- Etapa 1: Verifica Clave Primaria: que el objeto no tenga ya la propiedad, Cada Objeto puede tener una propiedad solo una vez.
					-- Si alguno de los valores son encontrados, la variable @PAR3 se pone a NULL
					SELECT @PAR3 = NULL
					  FROM [BDCtral].[dbo].[CIntfTObjModProp] WITH(NOLOCK)
					WHERE [IDFkCIntfTObjMod_ObjModID] = @PAR3 AND [IDFkCintfTObjCodProp_ObjModProp] = @PAR4
			--			 Clave Primaria: -- [IDFkCIntfTUsuObj_UsuObj], [IDFkCintfTObjCodProp_UsuObjProp].
			--				SELECT @PAR3

				-- Etapa 2: 
						-- 1: Si el C�digo infringe la clave primaria, no hace el cambio e informa al usuario
					IF @PAR3 IS NULL OR @ValVar = 'Err'
						-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
						BEGIN
							-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
							SET @RTADO = 'ERR' 
							SET @REG_AFEC = 0
							SET @ERR_MESSAGE = 'La propiedad para el Objeto ya esta asignada o hubo un error.'
							SET @ERR_NUMBER = 0
							SET @ERR_SEVERITY = 0
							SET @ERR_STATE = 0
							SET @ERR_LINE = 0
						END
					ELSE
						-- 2: Si es todo OK, se realiza el cambio.
						BEGIN TRY
						BEGIN TRANSACTION;
						-- Inserta el codigo en las tablas. 
							
							-- PRIMERO en la tabla [CIntfTUsuObj]		Inserta los objetos de la p�gina
							BEGIN
								INSERT INTO [BDCtral].[dbo].[CIntfTObjModProp]
										   ([ID]
										   ,[IDFkCIntfTObjMod_ObjModID]
										   ,[IDFkCintfTObjCodProp_ObjModProp]
										   ,[ObjModCodPropValor]
										   ,[ObjModCodPropOrden]
										   ,[IDFkCDiccTCod_ObjModPropEst]
										   ,[ObjModPropFechaModif])
								SELECT @PAR2			-- [ID] unico del objeto modelo propiedad
										,@PAR3			-- [ID] tabla [IDFkCIntfTObjMod_ObjModID]			-- codigo ID �nico del objeto al que se le asignar�la propiedad.
										,@PAR4			-- [ID] tabla [IDFkCintfTObjCodProp_ObjModProp]		-- valor ID �nico de la Propiedad
										,@PAR5			-- [ObjModCodPropValor] -- valor del Objeto
										,@PARInt1			-- [ObjModCodPropOrden] -- orden en que se armara el TAG
										,@PAR6			-- [IDFkCDiccTCod_ObjModPropEst] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
										,GETDATE()		-- [ObjModPropFechaModif] -- Fecha de Modificaci�n

							END
							-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
							BEGIN
								-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
								SET @RTADO = 'OK' 
								SET @REG_AFEC = 1
								SET @ERR_MESSAGE = 'Se cargo la informacion solicitada.'
								SET @ERR_NUMBER = 0
								SET @ERR_SEVERITY = 0
								SET @ERR_STATE = 0
								SET @ERR_LINE = 0
							END
						
							-- Si el procedimiento es exitoso, confirma la operaci�n.
							COMMIT TRANSACTION;
						END TRY
						-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
						BEGIN CATCH

							-- Ejecuta el Procedimiento Almacenado para obtener el error.
							EXECUTE [dbo].[CGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT

							-- Como la operaci�n fall�, se deshacen las modificaciones.
							ROLLBACK TRANSACTION;

							-- Por las dudas se elimana el registro con el ID generado.
							DELETE FROM [BDCtral].[dbo].[CIntfTObjModProp] WHERE [ID] = @PAR2

							-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
							SET @RTADO = 'ERR'
							SET @REG_AFEC = 0
						END CATCH;

				-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				-- ##############################################################################################################################################
				-- FINAL -- ALTA DE CODIGO Y SUS DESCRIPCIONES
				-- ##############################################################################################################################################
				-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			END

			--
			--ELSE 
			--IF @PAR1 = 'MODIFICACION'
			--BEGIN
			---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			---- ##############################################################################################################################################
			---- INICIO	-- MODIFICACION DE CODIGO Y SUS DESCRIPCIONES
			---- ##############################################################################################################################################
			--	
			--	SET @FUNC_PROCALM = 'Modificacion'		-- Funcion dentro del procedimiento almacenado.
			--
			--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			--	-- Para modificar un nuevo C�digo, se debe:
			--		-- Clave Primaria: IDC�digo [IDFkTIntCodigos], IDIdiomas [IDFkTIdioma], IDAmbitoAplicaci�n [IDFkTCodAmbAplic], C�digo Unico [Codigo]
			--		-- Los otros campos pueden tener cualquier valor, no se validan.
			--
			--		-- Aclaraci�n: La combinaci�n m�s ID del Ambito de Aplicaci�n, por lo tanto para un idioma, puede haber dos c�digos iguales, pero cada uno para un ambito de aplicaci�n diferente.
			--
			--	-- Etapa 1: Verifica Clave Primaria: que el objeto creado puede tener solamente una propiedad una sola vez
			--		-- Si alguno de los valores son encontrados, la variable @PAR3 se pone a NULL
			----		SELECT @PAR3 = NULL
			----		  FROM [BDCtral].[dbo].[CIntfTUsuObjProp] WITH(NOLOCK)
			----		WHERE [IDFkCIntfTUsuObj_UsuObj] = @PAR3 AND [IDFkCintfTObjCodProp_UsuObjProp] = @PAR4
			------			 Clave Primaria: -- [IDFkCIntfTUsuObj_UsuObj], [IDFkCintfTObjCodProp_UsuObjProp].
			------				SELECT @PAR3
			--
			--
			--	-- Etapa 2: 
			--			-- Si el codigo ya esta utilizado, infrinje la clave primaria, no hace los cambios e informa al usuario.
			--		IF @PAR3 IS NULL
			--			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			--			BEGIN
			--				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
			--				SET @RTADO = 'ERR' 
			--				SET @REG_AFEC = 0
			--				SET @ERR_MESSAGE = 'El Objeto ingresado ya tiene asignado esa propiedad.'
			--				SET @ERR_NUMBER = 0
			--				SET @ERR_SEVERITY = 0
			--				SET @ERR_STATE = 0
			--				SET @ERR_LINE = 0
			--			END
			--		ELSE
			--			-- 2: Si es todo OK, se realiza el cambio.
			--			BEGIN TRY
			--			BEGIN TRANSACTION;
			--				-- Modifica el codigo en la tabla. Le puede cambiar el idioma, ambito de aplicacion, el codigo, su descripcion y el estado.
			----				UPDATE [BDCtral].[dbo].[CintfTObjCodProp]
			----				   SET [IDFkTObjCod] = @PARInt1
			----					  ,[IDFkTCodObjProp] = @PAR6
			----					  ,[UsuObjCodPropValor] = @PAR6
			----					  ,[UsuObjCodPropOrden] = @PAR6
			----					  ,[IDFkCDiccTCod_UsuObjPropEst] = @PAR6
			----					  ,[TObjCodProFechaModif] = GETDATE()
			----				 WHERE [ID] = @PAR5
			--
			--				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			--				BEGIN
			--					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
			--					SET @RTADO = 'OK' 
			--					SET @REG_AFEC = 1
			--					SET @ERR_MESSAGE = 'Se modific� la informacion solicitada.'
			--					SET @ERR_NUMBER = 0
			--					SET @ERR_SEVERITY = 0
			--					SET @ERR_STATE = 0
			--					SET @ERR_LINE = 0
			--				END
			--			
			--				-- Si el procedimiento es exitoso, confirma la operaci�n.
			--				COMMIT TRANSACTION;
			--			END TRY
			--			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
			--			BEGIN CATCH
			--
			--				-- Ejecuta el Procedimiento Almacenado para obtener el error.
			--				EXECUTE [dbo].[CGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT
			--
			--				-- Como la operaci�n fall�, se deshacen las modificaciones.
			--				ROLLBACK TRANSACTION;
			--
			--				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
			--				SET @RTADO = 'ERR'
			--				SET @REG_AFEC = 0
			--			END CATCH;
			--
			---- ##############################################################################################################################################
			---- FINAL	-- MODIFICACION DE CODIGO Y SUS DESCRIPCIONES
			---- ##############################################################################################################################################
			---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			--END
			--
			--ELSE
			--IF @PAR1 = 'BAJA'
			--BEGIN
			---- ##############################################################################################################################################
			---- INICIO	-- BAJA DE CODIGO Y SUS DESCRIPCIONES
			---- ##############################################################################################################################################
			---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			--	SET @FUNC_PROCALM = 'Baja'		-- Funcion dentro del procedimiento almacenado.
			--
			--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			--	-- Para dar de baja un C�digo, se debe:
			--		-- Cambiar solo el estado. No se elimina ya que puede afectar las relaciones asociadas.
			----	-- Etapa 1: verifica que el codigo ya no est� dado de baja.
			----		-- Si alguno de los valores son encontrados, la variable @PAR3 se pone a NULL
			----		SELECT @PAR3 = NULL
			----		  FROM [BDCtral].[dbo].[CIntfTUsuObjProp] WITH(NOLOCK)
			----		WHERE [IDFkCIntfTUsuObj_UsuObj] = @PAR3 AND [IDFkCintfTObjCodProp_UsuObjProp] = @PAR4
			------			 Clave Primaria: -- [IDFkCIntfTUsuObj_UsuObj], [IDFkCintfTObjCodProp_UsuObjProp].
			------				SELECT @PAR3
			--
			--
			--	-- Etapa 2: 
			--			-- 1: Si el codigo ya esta dado de baja, no hace nada, solo le informa al usuario.
			--		IF @PAR3 IS NULL
			--			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			--			BEGIN
			--				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
			--				SET @RTADO = 'ERR' 
			--				SET @REG_AFEC = 0
			--				SET @ERR_MESSAGE = 'El c�digo ingresado ya esta dado de baja.'
			--				SET @ERR_NUMBER = 0
			--				SET @ERR_SEVERITY = 0
			--				SET @ERR_STATE = 0
			--				SET @ERR_LINE = 0
			--			END
			--		ELSE
			--			-- 2: El c�digo esta para darle de baja, procede a hacerlo.
			--			BEGIN TRY
			--			BEGIN TRANSACTION;
			----				-- Elimina el codigo en la tabla. Para ello le agrega la leyenda '-ELI', si supera la cantidad de d�gitos permitidos del campo, le reduce el c�digo original.
			----				-- el c�digo no se elimina, pero al ponerle -ELI, el codigo anterior se puede usar nuevamente
			----				UPDATE [BDCtral].[dbo].[CintfTObjCodProp]
			----				   SET [UsuObjCodPropValor] = CASE WHEN LEN ([UsuObjCodPropValor] + '-ELI') >= 54 THEN (SUBSTRING([UsuObjCodPropValor], 1, 50) + '-ELI') ELSE [UsuObjCodPropValor] + '-ELI' END			-- Le pone la leyenda que el c�digo esta eliminado.
			----						,[IDFkCDiccTCod_UsuObjPropEst] = @PAR6			-- Le pone el estado de eliminado.
			----				WHERE [ID] = @PAR5
			--
			--				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			--				BEGIN
			--					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
			--					SET @RTADO = 'OK' 
			--					SET @REG_AFEC = 1
			--					SET @ERR_MESSAGE = 'Se elimin� el c�digo indicado.'
			--					SET @ERR_NUMBER = 0
			--					SET @ERR_SEVERITY = 0
			--					SET @ERR_STATE = 0
			--					SET @ERR_LINE = 0
			--				END
			--			
			--				-- Si el procedimiento es exitoso, confirma la operaci�n.
			--				COMMIT TRANSACTION;
			--			END TRY
			--			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
			--			BEGIN CATCH
			--				-- Ejecuta el Procedimiento Almacenado para obtener el error.
			--				EXECUTE [dbo].[CGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT
			--
			--				-- Como la operaci�n fall�, se deshacen las modificaciones.
			--				ROLLBACK TRANSACTION;
			--
			--				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
			--				SET @RTADO = 'ERR'
			--				SET @REG_AFEC = 0
			--			END CATCH;
			--
			---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			---- ##############################################################################################################################################
			---- FINAL	-- BAJA DE CODIGO Y SUS DESCRIPCIONES
			---- ##############################################################################################################################################
			---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			--END
			--
			--ELSE
			--IF @PAR1 = 'RECUPERO'
			--BEGIN
			---- ##############################################################################################################################################
			---- INICIO	-- RECUPERO DE CODIGO Y SUS DESCRIPCIONES
			---- ##############################################################################################################################################
			---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			--	SET @FUNC_PROCALM = 'Recupero'		-- Funcion dentro del procedimiento almacenado.
			--
			--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			--	-- Para recuperar un C�digo, se debe:
			--		-- Cambiar solo el estado. Ya que no se elimina, solo se debe verificar que ese c�digo que vuelve a funcionar, 
			--		-- no est� utilizado y por ende infrinja la regla primaria.
			--		-- Clave Primaria: IDC�digo [IDFkTIntCodigos], IDIdiomas [IDFkTIdioma], IDAmbitoAplicaci�n [IDFkTCodAmbAplic], C�digo Unico [Codigo]
			--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			--
			--	-- Etapa 1: verifica que el codigo est� dado de baja, si no es as� le informa al usuario.
			--		-- Si alguno de los valores son encontrados, la variable @PAR3 se pone a NULL
			----		SELECT @PAR3 = NULL
			----		  FROM [BDCtral].[dbo].[CIntfTUsuObjProp] WITH(NOLOCK)
			----		WHERE [IDFkCIntfTUsuObj_UsuObj] = @PAR3 AND [IDFkCintfTObjCodProp_UsuObjProp] = @PAR4
			------			 Clave Primaria: -- [IDFkCIntfTUsuObj_UsuObj], [IDFkCintfTObjCodProp_UsuObjProp].
			----				SELECT @PAR3
			--		-- Etapa 2: 
			--				-- 1: Si el codigo NO esta dado de baja, no hace nada y le informa al usuario.
			--		IF @PAR3 IS NULL
			--			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			--			BEGIN
			--				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
			--				SET @RTADO = 'ERR' 
			--				SET @REG_AFEC = 0
			--				SET @ERR_MESSAGE = 'El c�digo ingresado no est� dado de baja.'
			--				SET @ERR_NUMBER = 0
			--				SET @ERR_SEVERITY = 0
			--				SET @ERR_STATE = 0
			--				SET @ERR_LINE = 0
			--			END
			--		ELSE
			--
			--		-- Etapa 3: Ya sabemos que el c�digo esta dado de baja. Verificamos que no infrinja la clave primaria.
			--				-- Clave Primaria: IDC�digo [IDFkTIntCodigos], IDIdiomas [IDFkTIdioma], IDAmbitoAplicaci�n [IDFkTCodAmbAplic], C�digo Unico [Codigo]
			--		-- Aclaraci�n:
			--				-- Ahora verificamos si el valor que tiene el c�digo, fue utilizado por alg�n c�digo activo.
			--				-- Si el c�digo esta repetido, le agrega la palabra 'REC-' valor ID, y si no tiene espacio, le reduce el c�digo original. De esta manera no se duplica nunca el c�digo.
			--				-- el usuario luego debe modificar el c�digo indicado.
			----		SELECT @PAR6 = NULL
			----		  FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK)
			----		WHERE [IDFkTObjCod] = @PARInt1 AND [IDFkTCodObjProp] = @PAR6		-- Primero verifica que no se infrinja la clave primaria: C�digoID - Idioma - Ambito Aplicacion - C�digo
			----		-- Si el codigo ya esta utilizado agrega el c�digo m�s una leyenda de 4 caracteres y le cambia el estado a habilitado.
			--		--		SELECT @PAR6
			----
			----		-- Etapa 4: Si el codigo ya esta utilizado, Verifica el OK con el c�digo modificado
			----		IF @PAR6 IS NULL
			----			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			----			BEGIN
			----				-- Como el c�digo ya esta utilizado, le pone el ID al C�digo para que no haya forma de duplicidad.
			----				SELECT @PAR6 = SUBSTRING([IDFkTObjCod], 1, 18) + @PAR5
			----					FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK)
			----				WHERE [ID] <> @PAR5
			----				GOTO HaceCambio
			----				-- Ya le realizo a la variable que tiene el c�digo, ahora lo implementa en la transacci�n.
			----			END
			----		ELSE
			--HaceCambio:
			--			BEGIN TRY
			--			BEGIN TRANSACTION;
			--				-- Modifica el codigo en la tabla. Le puede cambiar el idioma, ambito de aplicacion, el codigo, su descripcion y el estado.
			--
			--				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			--				BEGIN
			--					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
			--					SET @RTADO = 'OK' 
			--					SET @REG_AFEC = 1
			--					SET @ERR_MESSAGE = 'Se recuper� el c�digo indicado.'
			--					SET @ERR_NUMBER = 0
			--					SET @ERR_SEVERITY = 0
			--					SET @ERR_STATE = 0
			--					SET @ERR_LINE = 0
			--				END
			--			
			--				-- Si el procedimiento es exitoso, confirma la operaci�n.
			--				COMMIT TRANSACTION;
			--			END TRY
			--			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
			--			BEGIN CATCH
			--
			--				-- Ejecuta el Procedimiento Almacenado para obtener el error.
			--				EXECUTE [dbo].[CGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT
			--
			--				-- Como la operaci�n fall�, se deshacen las modificaciones.
			--				ROLLBACK TRANSACTION;
			--
			--				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
			--				SET @RTADO = 'ERR'
			--				SET @REG_AFEC = 0
			--			END CATCH;
			--
			---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			---- ##############################################################################################################################################
			---- FINAL	-- RECUPERO DE CODIGO Y SUS DESCRIPCIONES
			---- ##############################################################################################################################################
			---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			--END
		END
		--
		---- ##############################################################################################################################################
		---- MUESTRA EL RESULTADO DEL PROCEDIMIENTO ALMACENADO
		---- Envia el resultado: Nombre Proc Alm | Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
		----SET @RTADO_PROCALM = @NOMB_PROCALM + '|' + @FUNC_PROCALM + '|' + @RTADO + '|' + CAST(@REG_AFEC AS VARCHAR(10)) + '|' + @ERR_MESSAGE + '|' + CAST(@ERR_NUMBER AS VARCHAR(10)) + '|' + CAST(@ERR_SEVERITY AS VARCHAR(10)) + '|' + CAST(@ERR_STATE AS VARCHAR(10)) + '|' + CAST(@ERR_LINE AS VARCHAR(10))
		----SELECT @RTADO_PROCALM			-- Muestra el resulado en una unica columna
		--SELECT @NOMB_PROCALM AS ProcAlm_Nomb, @FUNC_PROCALM AS ProcAlm_Funcion, @RTADO AS ProcAlm_Rtado, @REG_AFEC AS ProcAlm_RegAfec, @ERR_MESSAGE AS ProcAlm_Mensaje, @ERR_NUMBER AS ProcAlm_ErrNum, @ERR_SEVERITY AS ProcAlm_ErrSeveridad, @ERR_STATE AS ProcAlm_ErrEstado, @ERR_LINE AS ProcAlm_ErrLinea
		--
		---- DECLARE @return_value int
		-- DECLARE @PARInt01 AS VARCHAR(36)	-- IDFkTIdioma -- codigo del idioma para ese codigo
		-- DECLARE @PARInt02 AS VARCHAR(36)	-- Ambito de Aplicaci�n elegido o por defecto = NULL
		-- DECLARE @PARInt03 AS VARCHAR(36)	-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
		--	SET @PARInt01 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'	-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
		--	SET @PARInt02 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	-- Ambito de Aplicaci�n elegido o por defecto = NULL
		--	SET @PARInt03 = '6EFA0E33-F537-4861-A35F-10ECB328FB74'	-- Padre Inicial de toda la estructura, sale de la vista [CIntfVCodigos]
		----					SELECT [IDgdicTCodigos], [Codigo], [Descripcion]
		----					  FROM [BDCtral].[dbo].[CIntfVCodigos]
		----					WHERE [IDFkTCIntfTObjCod_AmbAplic] = 'b890dd58-58ba-4da3-8a0c-70422298a88d'
		----							AND [IDFkTCDiccTIdio_Idioma] = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'
		--
		--						--	6EFA0E33-F537-4861-A35F-10ECB328FB74	PiePag001	pie de la p�gina
		--						--	5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D	EncPag001	encabezado de la p�gina
		--						--	B890DD58-58BA-4DA3-8A0C-70422298A88D	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
		--						--	57504A29-9F06-41B2-896C-81D5A57E37BF	EstWeb001	Estructura de la p�gina Web hasta el Body
		--	EXEC	@return_value = [dbo].[CintfPObjModBucleIDProp] 
		--			@PAR1 = @PARInt01			-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
		--			, @PAR2 = @PARInt02			-- Ambito de Aplicaci�n elegido o por defecto = NULL
		--			, @PAR3 = @PARInt03			-- Padre ID General
		--
		--
		---- ##############################################################################################################################################^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		---- El GO va al final del procedimiento
		--GO
		---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		---- ##############################################################################################################################################
		--
		------
		------ Elimina Datos de las tablas
		----DECLARE @PAR1 AS VARCHAR(36)
		----SET @PAR1 = '196FA314-E1FE-4AC8-B653-17564CF62A88'		-- ID de la Tabla [CIntfTUsuObj]
		----
		----DELETE FROM [BDCtral].[dbo].[CIntfTUsuObjProp] WHERE [ID] = @PAR1
		--
		----
		------ #################################################################################################################################################3
		------ Revisa resultados
		----	DECLARE	@return_value int
		----	EXEC	@return_value = [dbo].[CIntfPObjModProp]