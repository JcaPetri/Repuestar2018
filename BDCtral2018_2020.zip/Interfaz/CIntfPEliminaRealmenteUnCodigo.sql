-- Define que se trabaja con al Base de Datos
USE [BDCtral]
GO

-- Revisar, se deben eliminar todos los registros que tengan clave primaria asociada a la Tabla CDiccTCodigos

DECLARE @PAR01 AS VARCHAR(36)
SET @PAR01 = 'ef37dd55-a6d1-4d95-887d-828a66d7e316'

---- Tablas Central Interfaz Objetos
--DELETE FROM [BDCtral].[dbo].[CIntfTObjCod]					-- Tabla Objeto C�digos
--	WHERE [ID] = @PAR01
--
--DELETE FROM [BDCtral].[dbo].[CIntfTObjCodxIdio]				-- Tabla Objeto Codigos por Idiomas
--	WHERE [IDFkTCIntfTObjCod_CodxIdio] = @PAR01 OR [IDFkTCIntfTObjCod_AmbAplic] = @PAR01
--
--DELETE FROM [BDCtral].[dbo].[CintfTObjCodProp]				-- Tabla Objetos Codigos Propiedades
--	WHERE [IDFkTCIntfTObjCod_ObjCod] = @PAR01 OR [IDFkTCIntfTObjCod_ObjCodProp] = @PAR01


-- Tablas Central Interfaz Objetos Modelos
DELETE FROM [BDCtral].[dbo].[CIntfTObjMod]				-- Tabla Objetos Modelos
	WHERE [ID] = @PAR01 OR [IDFkCIntfTObjCod_ObjMod] = @PAR01

DELETE FROM [BDCtral].[dbo].[CIntfTObjModArb]				-- Tabla Objetos Modelos Arbol
	WHERE [ID] = @PAR01 OR [IDFkCIntfTObjModArb_PadreID] = @PAR01 OR [IDFkCIntfTObjMod] = @PAR01

DELETE FROM [BDCtral].[dbo].[CIntfTObjModProp]				-- Tabla Objetos Modelos Propiedades
	WHERE [ID] = @PAR01 OR [IDFkCIntfTObjMod_ObjModID] = @PAR01 OR [IDFkCintfTObjCodProp_ObjModProp] = @PAR01
-- Aqu� hay que borrar los vinculos, eje si borramos el ObjCod, hay que borrar sus dependiencias

--
--
---- Tablas Central Interfaz Usuarios
--DELETE FROM [BDCtral].[dbo].[CIntfTUsuObj]				-- Tabla Objetos Usuarios
--	WHERE [ID] = @PAR01 OR [IDFkCIntfTObjCod_UsuObjCod] = @PAR01
--
--DELETE FROM [BDCtral].[dbo].[CIntfTUsuObjArb]				-- Tabla Objetos Usuarios Arbol
--	WHERE [ID] = @PAR01 OR [IDFkCIntfTUsuObjArb_PadreID] = @PAR01 OR [IDFkCIntfTUsuObj] = @PAR01
--
--
--DELETE FROM [BDCtral].[dbo].[CIntfTUsuObjProp]				-- Tabla Objetos Usuarios Propiedades
--	WHERE [ID] = @PAR01 OR [IDFkCIntfTUsuObj_UsuObj] = @PAR01 OR [IDFkCintfTObjCodProp_UsuObjProp] = @PAR01
--
----
------ Tablas Central Interfaz Web
----DELETE FROM [BDCtral].[dbo].[CintfTUsuObjEstWeb]				-- Tabla Objetos Estructura Web
----	WHERE [ArbolID] = @PAR01 OR [IDFkCIntfTUsuObjArb] = @PAR01 OR [IDFkCIntfTObjCod] = @PAR01 OR [IDFkCIntfTUsuObj] = @PAR01
------
----DELETE FROM [BDCtral].[dbo].[CintfTUsuObjEstWebSecc]				-- Tabla Objetos Estructura Web
----	WHERE [ArbolID] = @PAR01 OR [IDFkCIntfTUsuObjArb] = @PAR01 OR [IDFkCIntfTObjCod] = @PAR01 OR [IDFkCIntfTUsuObj] = @PAR01
----
