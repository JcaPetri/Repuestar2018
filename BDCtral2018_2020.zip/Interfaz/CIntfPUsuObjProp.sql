set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 16/10/2018
-- Description: detalle de las Propiedades de los Usuario Objetos.
-- surge de las tablas [CIntfTUsuObjProp], se relaciona con las tablas [CIntfTUsuObj], [CDiccTCodxIdiomas] y [CIntfTObjCodxIdio]
-- Esto nos permite ver que propiedades tiene cada elemento
-- =============================================

ALTER PROCEDURE [dbo].[CIntfPUsuObjProp]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 NVARCHAR(50) = NULL		-- ID de la IDFkCIntfTObjCod_UsuObjCod

AS
BEGIN

	DECLARE	@return_value int

--	DECLARE @PAR1 NVARCHAR(50) 
--	DECLARE @PAR1 NVARCHAR(50) 
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR2 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- ID de la IDFkCIntfTObjCod_UsuObjCod


-- Tabla con la Informaci�n del Diccionario [CDiccTCodxIdiomas]
	DECLARE @TmpTCodxIdi TABLE	-- Codigos x Idiomas -- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTCDiccTIdio_Idioma] [uniqueidentifier] NOT NULL,
		[IDFkTCIntfTObjCod_AmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)

	-- Inserta en la tabla temporal la informaci�n de los c�digos seg�n el idioma elegido
	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1

-- Tabla con la Informaci�n de los Objetos [CIntfTObjCodxIdio]
	DECLARE @TmpTIntObjCodxIdi TABLE	-- Codigos x Idiomas -- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCIntfTObjCod_CodxIdio] [uniqueidentifier] NOT NULL,
		[IDFkTCDiccTIdio_Idioma] [uniqueidentifier] NOT NULL,
		[IDFkTCIntfTObjCod_AmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [nvarchar](55) COLLATE Modern_Spanish_CI_AS,  -- NOT NULL,
		[Descripcion] [nvarchar](255) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodigoWeb] [nvarchar](50) COLLATE Modern_Spanish_CI_AS NULL,
		[IDFkCDiccTCod_ObjCodxIdioEst] [uniqueidentifier] NULL,
		[ObjCodxIdioFechaModif] [datetime] NULL, 
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)

	-- Inserta en la tabla temporal la informaci�n de los c�digos seg�n el idioma elegido
	INSERT INTO @TmpTIntObjCodxIdi
		SELECT [IDFkTCIntfTObjCod_CodxIdio]
			  ,[IDFkTCDiccTIdio_Idioma]
			  ,[IDFkTCIntfTObjCod_AmbAplic]
			  ,[Codigo]
			  ,[Descripcion]
			  ,[CodigoWeb]
			  ,[IDFkCDiccTCod_ObjCodxIdioEst]
			  ,[ObjCodxIdioFechaModif]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CIntfTObjCodxIdio] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTCDiccTIdio_Idioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1

--	SELECT * FROM @TmpTCodxIdi
--	SELECT * FROM @TmpTIntObjCodxIdi

		SELECT -- Informaci�n general de los elementos
					'CIntfTObjMod' AS 'Tabla01'	-- , UO.*, IOCxI.*
					,UO.[IDFkCIntfTObjCod_UsuObjCod]
					,IOCxI.[Codigo] AS [ObjCodUnico]
					,IOCxI.[Descripcion] AS [ObjCodDescFunc]
					-- Informaci�n particular para el objeto de los elementos
					,UO.[ID] AS [IDCIntfTUsuObj]
					,UO.[IntUsuObjCodUnico]
--					,UO.[IntUsuObjCodUsuUnico]
					,UO.[IntUsuObjCodDescFuncion]
					,UO.[IDFkCDiccTCod_UsuObjEst]
					,UO.[UsuObjFechaModif]
					-- Informaci�n generales de las propiedades de los elementos
					,'CintfTObjCodProp' AS 'Tabla02' -- , OCP.*, OCxI.*
					,UOP.[IDFkCintfTObjCodProp_UsuObjProp]
					,OCP.[ObjCodPropValor]
					,OCP.[ObjCodPropOrden]
					,OCP.[ObjCodPropValorWeb]
					-- info del tipo de propiedad
					,OCP.[IDFkTCIntfTObjCod_ObjCodProp]
					,OCxI.[Codigo] AS [PropObjCodUnico]
					,OCxI.[Descripcion] AS [PropObjCodDescFunc]
					-- info del tipo de ubicaci�n de la propiedad en el elemento, si es Intag, OutTag o No Aplica
					,'CIntfTObjCod' AS 'Tabla03'	-- , OC.*, CxI2.*
					,OC.[IDFkCDiccTCod_ObjCodUbic]
					,CxI2.[Codigo] AS [PropObjUbicCodUnico]
					,CxI2.[Descripcion] AS [PropObjUbicCodDescFunc]
					-- Informaci�n particular de las propiedades de los elementos
					,'CIntfTUsuObjProp' AS 'Tabla04'	--, OMP.*
					,UOP.[ID] AS [IDCIntfTObjModProp]
					,UOP.[UsuObjCodPropValor]
					,UOP.[UsuObjCodPropOrden]
		  FROM [BDCtral].[dbo].[CIntfTUsuObj] AS UO WITH(NOLOCK)
				LEFT OUTER JOIN @TmpTIntObjCodxIdi AS IOCxI
					ON UO.[IDFkCIntfTObjCod_UsuObjCod] = IOCxI.[IDFkTCIntfTObjCod_CodxIdio]
							AND
						@PAR1 = IOCxI.[IDFkTCDiccTIdio_Idioma]
				LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTUsuObjProp] AS UOP WITH(NOLOCK)
					ON UO.[ID] = UOP.[IDFkCIntfTUsuObj_UsuObj]
						LEFT OUTER JOIN [BDCtral].[dbo].[CintfTObjCodProp] AS OCP WITH(NOLOCK)
							ON UOP.[IDFkCintfTObjCodProp_UsuObjProp] = OCP.[ID]
								LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTObjCodxIdio] AS OCxI WITH(NOLOCK)
									ON OCP.[IDFkTCIntfTObjCod_ObjCodProp] =  OCxI.[IDFkTCIntfTObjCod_CodxIdio]
											AND
										@PAR1 = OCxI.[IDFkTCDiccTIdio_Idioma]
								LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTObjCod] AS OC WITH(NOLOCK)
									ON OCP.[IDFkTCIntfTObjCod_ObjCodProp] = OC.[ID]
										LEFT OUTER JOIN @TmpTCodxIdi AS CxI2  
											ON OC.[IDFkCDiccTCod_ObjCodUbic] =  CxI2.[IDFkTCodigos]
													AND
												@PAR1 = CxI2.[IDFkTCDiccTIdio_Idioma]
		WHERE UO.[IDFkCIntfTObjCod_UsuObjCod] = CASE WHEN @PAR2 IS NULL THEN UO.[IDFkCIntfTObjCod_UsuObjCod] ELSE @PAR2 END
		ORDER BY UO.[ID], UOP.[UsuObjCodPropOrden]

	-- Borra Tablas Temporales
		IF OBJECT_ID('@TmpTCodxIdi') IS NOT NULL
		BEGIN
		DROP TABLE [BDCtral].[dbo].[@TmpTCodxIdi];
		END

		IF OBJECT_ID('@TmpTIntObjCodxIdi') IS NOT NULL
		BEGIN
		DROP TABLE [BDCtral].[dbo].[@TmpTIntfUsuObj];
		END
END

--
--
--	DECLARE	@return_value int
--	EXEC	@return_value = [dbo].[CIntfPUsuObjProp]
