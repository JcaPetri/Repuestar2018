set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO
SELECT  Cod.ID AS IDgdicTCodigos
		, Cd.IDFkTCDiccTIdio_Idioma
		, Cd.IDFkTCIntfTObjCod_AmbAplic
		, Cd.Codigo
		, Cd.Descripcion
		, Cd.IdiCod
		, Cd.Idioma
		, Cd.IDFkCDiccTCod_ObjCodxIdioEst
		, Cd.ObjCodxIdioFechaModif
FROM dbo.CIntfTObjCod AS Cod WITH (NOLOCK) 
		LEFT OUTER JOIN
			  (SELECT CxI.IDFkTCIntfTObjCod_CodxIdio
					, CxI.IDFkTCDiccTIdio_Idioma
					, CxI.IDFkTCIntfTObjCod_AmbAplic
					, CxI.Codigo
					, CxI.Descripcion
					, Idi.CodIdioma AS IdiCod
					, Idi.DescIdioma AS Idioma
					, CxI.IDFkCDiccTCod_ObjCodxIdioEst
					, CxI.ObjCodxIdioFechaModif
				FROM dbo.CIntfTObjCodxIdio AS CxI WITH (NOLOCK) 
					INNER JOIN dbo.CDiccTIdioma AS Idi WITH (NOLOCK) 
						ON CxI.IDFkTCDiccTIdio_Idioma = Idi.ID
				) AS Cd 
					ON Cod.ID = Cd.IDFkTCIntfTObjCod_CodxIdio
