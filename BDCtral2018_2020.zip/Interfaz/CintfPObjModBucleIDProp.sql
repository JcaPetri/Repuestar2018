set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO

-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 25/10/2018
-- Description: Muestra el Objeto Modelo y sus propiedades.
-- surge de la uni�n: del procedimiento almacenado [CintfPObjModBucleID] donde esta la informaci�n de la estructura arbol del elemento y
--					del procedimiento almacena [CIntfPObjModProp] donde esta la informaci�n de las propiedades de cada elemento.
-- =============================================

ALTER PROCEDURE [dbo].[CintfPObjModBucleIDProp]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 NVARCHAR(50)	= 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	-- Ambito de Aplicaci�n elegido o por defecto = NULL
	,@PAR3 NVARCHAR(50)			-- ID del Padre que a trabajar, este es el ID de la p�gina a agregar

AS
BEGIN
	DECLARE	@return_value int
--	-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--	-- <<< Consulta 01 >>>
--	-- Detalle los Objetos Modelos disponibles, para el modulo Central Interfaz Objetos
--	-- surge de la combinaci�n de las tablas [CIntfTObjCod] y [CIntfTObjCodxIdio]
--	--	DECLARE	@return_value int
--		DECLARE @PAR1 NVARCHAR(50) 		-- Idioma elegido o por defecto = espa�ol
--		DECLARE @PAR2 NVARCHAR(50)		-- Ambito de Aplicaci�n elegido o por defecto = NULL
--		SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'	-- Idioma elegido o por defecto = espa�ol
--		SET @PAR2 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	-- Ambito de Aplicaci�n Objetos Modelos

--	--	EXEC @return_value = [dbo].[CIntfPCodxIdio]	@PAR1 = @PAR1, 	@PAR2 = @PAR2
--
		-- Aqu� se elige el Padre que se va a mostrar, toda la estructura

	-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	-- <<< Consulta 02 >>>
	-- Detalle la Estructura de los Objetos Modelos disponibles, para el modulo Central Interfaz Objetos
	-- No muestra el ID Padre, ya que como este no tiene propiedades [CIntfTObjModProp], Este ID Padre esta en la tabla [CIntfTObjCod] y [CIntfTObjCodxIdio]
	--	DECLARE	@return_value int
		DECLARE @TempObjModBucleID TABLE
			(
				[EstOrd] [bigint] NULL,
				[ArbolID] [uniqueidentifier] NULL,
				[ArbolDesc] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
				[ArbPadreID] [uniqueidentifier] NULL,
				[IDFkCIntfTObjModArb] [uniqueidentifier] NOT NULL,
				[ArbolNivel] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
				[IDFkCIntfTObjCod] [uniqueidentifier] NULL,
				[IntfTObjCod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
				[IDFkCIntfTObjMod] [uniqueidentifier] NULL,
				[ObjModCodUnico] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
				[ObjModCodDescFuncion] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
				[ArbItemNivel] [smallint] NULL,
				[ArbItemOrd] [smallint] NULL,
				[IDTagOpen] [varchar](36) COLLATE Modern_Spanish_CI_AS NOT NULL,
				[TagOpen] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
				[IDTagClose] [varchar](36) COLLATE Modern_Spanish_CI_AS NOT NULL,
				[TagClose] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL
			)

--		DECLARE @PAR3 AS VARCHAR(36)
--		SET @PAR3 = '57504A29-9F06-41B2-896C-81D5A57E37BF'			-- ID del Padre que a trabajar, este es el ID de la p�gina a agregar

		INSERT INTO @TempObjModBucleID EXEC @return_value = [dbo].[CintfPObjModBucleID] @PAR1 = @PAR3, @PAR2 = @PAR1, @PAR3 = @PAR2 
--		SELECT * FROM @TempObjModBucleID

			-- Valores surgen de la Consulta 01
			--	5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D	EncPag001	encabezado de la p�gina
			--	57504A29-9F06-41B2-896C-81D5A57E37BF	EstWeb001	Estructura de la p�gina Web hasta el Body
			--	B890DD58-58BA-4DA3-8A0C-70422298A88D	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
			--	6EFA0E33-F537-4861-A35F-10ECB328FB74	PiePag001	pie de la p�gina
					
				---- Detalle de la Estructura de una P�gina, para el modulo Central Interfaz Objetos
				---- aqu� est�n los elementos solamente en el nivel y orden que deben aparecer, no estan sus propiedades.
				----	DECLARE @PAR1 AS VARCHAR(36)							-- ID del Padre que a trabajar
				----	SET @PAR3 = '57504A29-9F06-41B2-896C-81D5A57E37BF'		-- Pagina es el ID de la tabla [CIntfTUsuObjArb]  ID del Padre que a trabajar, este es el ID de la p�gina a agregar
				----					'6EFA0E33-F537-4861-A35F-10ECB328FB74'
				----					'57504A29-9F06-41B2-896C-81D5A57E37BF'
				--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'			-- Idioma elegido o por defecto = espa�ol
				--	SET @PAR2 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'		-- Ambito de Aplicaci�n elegido o por defecto = ObjMod
				--
				--	EXEC @return_value = [dbo].[CintfPObjModBucleID] @PAR1 = @PAR3, @PAR2 = @PAR1, @PAR3 = @PAR2

	---- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	---- <<< Consulta 03 >>
	---- <<< IMPORTANTE >>> Para ejecutar esta consulta, utiliza el Procedimiento Almacenado [CIntfPObjModProp]
	---- Detalle las Propiedades del Objetos Modelos disponibles, para el modulo Central Interfaz Objetos
	---- aqu� esta como se forma cada uno de los elementos y las propiedades que tienen
	----	DECLARE	@return_value int
		DECLARE @TempObjModProp TABLE
			(	-- Informaci�n general de los elementos
				[Tabla01] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
				[IDFkCIntfTObjCod_ObjMod] [uniqueidentifier] NULL,
				[ObjCodUnico] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
				[ObjCodDescFunc] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
				-- Informaci�n particular para el objeto de los elementos
				[IDCIntfTObjMod] [uniqueidentifier] NULL,
				[ObjModCodUnico] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
				[ObjModCodDescFuncion] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
				[IDFkCDiccTCod_ObjModEst] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
				[ObjModFechaModif] [datetime] NULL,
				-- Informaci�n generales de las propiedades de los elementos
				[Tabla02] [varchar](50) COLLATE Modern_Spanish_CI_AS,
				[IDFkCintfTObjCodProp_ObjModProp] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
				[ObjCodPropValor] [varchar](50) COLLATE Modern_Spanish_CI_AS,
				[ObjCodPropOrden] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
				[ObjCodPropValorWeb] [varchar](50) COLLATE Modern_Spanish_CI_AS,
				-- info del tipo de propiedad
				[IDFkTCIntfTObjCod_ObjCodProp] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
				[PropObjCodUnico] [varchar](50) COLLATE Modern_Spanish_CI_AS,
				[PropObjCodDescFunc] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
				-- info del tipo de ubicaci�n de la propiedad en el elemento, si es Intag, OutTag o No Aplica
				[Tabla03] [varchar](50) COLLATE Modern_Spanish_CI_AS,
				[IDFkCDiccTCod_ObjCodUbic] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
				[PropObjUbicCodUnico] [varchar](50) COLLATE Modern_Spanish_CI_AS,
				[PropObjUbicCodDescFunc] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
				-- Informaci�n particular de las propiedades de los elementos
				[Tabla04] [varchar](50) COLLATE Modern_Spanish_CI_AS,
				[IDFkCintfTObjProp] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
				[ObjModCodPropValor] [nvarchar](255) COLLATE Modern_Spanish_CI_AS NULL,
				[ObjModCodPropOrden] [int] NULL
			)

	--	DECLARE @PAR1 NVARCHAR(50)		-- Idioma elegido o por defecto = espa�ol
		SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--		EXEC @return_value = [dbo].[CIntfPObjModProp] @PAR1 = @PAR1
		INSERT INTO @TempObjModProp EXEC @return_value = [dbo].[CIntfPObjModProp] @PAR1 = @PAR1
--		SELECT * FROM @TempObjModProp

	-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	-- <<< Consulta 04 >>>
	-- Detalle los Objetos Modelos, sus Elementos y sus Propiedades, para el modulo Central Interfaz Objetos
	-- si el elemento no tiene propiedades, deja NULL, y es como si no estuviera para cuando se hace el Objeto Web
	SELECT 'ObjModBucleID' AS 'Table01'
			,OM.[EstOrd]
			,OM.[ArbolDesc]
			,OM.[ArbolNivel]
			,OM.[IDFkCIntfTObjCod]
			,OM.[IntfTObjCod]
			,OMP.[IDCIntfTObjMod]
			,OM.[ObjModCodUnico]
	--	    ,OM.[ObjModCodDescFuncion]
			,OM.[ArbItemNivel]
			,OM.[ArbItemOrd]
	--	    ,OM.[TagOpen]
	--	    ,OM.[TagClose]
--			,OM.*
			,'ObjModProp' AS 'Table02'
			,OMP.[IDFkCintfTObjCodProp_ObjModProp]
			,OMP.[PropObjCodUnico]
			,OMP.[ObjModCodPropValor]
			,OMP.[ObjModCodPropOrden]
			,OMP.[ObjCodPropValor]
			,OMP.[PropObjCodDescFunc]
			,OMP.[PropObjUbicCodUnico]
			,OMP.[IDFkCDiccTCod_ObjModEst]
	--		,OMP.
	--		,OMP.*
	FROM @TempObjModBucleID OM
		LEFT OUTER JOIN @TempObjModProp OMP
			ON OM.[IDFkCIntfTObjMod] = OMP.[IDCIntfTObjMod]
	ORDER BY OM.[EstOrd], OMP.[ObjModCodPropOrden]

	-- Borra Tablas Temporales
		IF OBJECT_ID('@TempObjModBucleID') IS NOT NULL
		BEGIN
		DROP TABLE [BDCtral].[dbo].[@TempObjModBucleID];
		END

		IF OBJECT_ID('@TempObjModProp') IS NOT NULL
		BEGIN
		DROP TABLE [BDCtral].[dbo].[@TempObjModProp];
		END

END


--
--	DECLARE	@return_value int
--	EXEC	@return_value = [dbo].[CintfPObjModBucleIDProp] 
--			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--			, @PAR2 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	-- Ambito de Aplicaci�n elegido o por defecto = NULL
--			, @PAR3 = '57504A29-9F06-41B2-896C-81D5A57E37BF'	-- Padre ID
--
--				----					'6EFA0E33-F537-4861-A35F-10ECB328FB74'
--				----					'57504A29-9F06-41B2-896C-81D5A57E37BF'