USE [BDCtral]
GO
	DECLARE	@return_value int

-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<< Consulta 01 >>>
-- Detalle los Objetos Modelos disponibles, para el modulo Central Interfaz Objetos
-- surge de la combinaci�n de las tablas [CIntfTObjCod] y [CIntfTObjCodxIdio]
--	DECLARE	@return_value int
	DECLARE @PARIdioma NVARCHAR(50) 		-- Idioma elegido o por defecto = espa�ol
	DECLARE @PARAmbAplic NVARCHAR(50)		-- Ambito de Aplicaci�n elegido o por defecto = NULL
	SET @PARIdioma = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'	-- Idioma elegido o por defecto = espa�ol
	SET @PARAmbAplic = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	-- Ambito de Aplicaci�n Objetos Modelos

--	EXEC @return_value = [dbo].[CIntfPCodxIdio]	@PAR1 = @PARIdioma, 	@PAR2 = @PARAmbAplic

	-- Aqu� se elige el Padre que se va a mostrar, toda la estructura

-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<< Consulta 02 >>>
-- Detalle la Estructura de los Objetos Modelos disponibles, para el modulo Central Interfaz Objetos
-- No muestra el ID Padre, ya que como este no tiene propiedades [CIntfTObjModProp], Este ID Padre esta en la tabla [CIntfTObjCod] y [CIntfTObjCodxIdio]
--	DECLARE	@return_value int
	DECLARE @TempObjModBucleID TABLE
		(
			[EstOrd] [bigint] NULL,
			[ArbolID] [uniqueidentifier] NULL,
			[ArbolDesc] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[IDFkCIntfTObjModArb] [uniqueidentifier] NOT NULL,
			[ArbolNivel] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[IDFkCIntfTObjCod] [uniqueidentifier] NULL,
			[IntfTObjCod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[IDFkCIntfTObjMod] [uniqueidentifier] NULL,
			[ObjModCodUnico] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[ObjModCodDescFuncion] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
			[ArbItemNivel] [smallint] NULL,
			[ArbItemOrd] [smallint] NULL,
			[IDTagOpen] [varchar](36) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[TagOpen] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[IDTagClose] [varchar](36) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[TagClose] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL
		)

	DECLARE @PARPadreID AS VARCHAR(36)
	SET @PARPadreID = '57504A29-9F06-41B2-896C-81D5A57E37BF'			-- ID del Padre que a trabajar, este es el ID de la p�gina a agregar

	INSERT INTO @TempObjModBucleID EXEC @return_value = [dbo].[CintfPObjModBucleID] @PAR1 = @PARPadreID, @PAR2 = @PARIdioma, @PAR3 = @PARAmbAplic 
--	SELECT * FROM @TempObjModBucleID

		-- Valores surgen de la Consulta 01
		--	5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D	EncPag001	encabezado de la p�gina
		--	57504A29-9F06-41B2-896C-81D5A57E37BF	EstWeb001	Estructura de la p�gina Web hasta el Body
		--	B890DD58-58BA-4DA3-8A0C-70422298A88D	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
		--	6EFA0E33-F537-4861-A35F-10ECB328FB74	PiePag001	pie de la p�gina
				
			-- <<< IMPORTANTE >>> Para ejecutar esta consulta, utiliza el Procedimiento Almacenado [CIntfPObjModProp]
			---- Detalle de la Estructura de una P�gina, para el modulo Central Interfaz Objetos
			---- aqu� est�n los elementos solamente en el nivel y orden que deben aparecer, no estan sus propiedades.
			----	DECLARE @PAR1 AS VARCHAR(36)							-- ID del Padre que a trabajar
			----	SET @PARPadreID = '57504A29-9F06-41B2-896C-81D5A57E37BF'		-- Pagina es el ID de la tabla [CIntfTUsuObjArb]  ID del Padre que a trabajar, este es el ID de la p�gina a agregar
			----					'6EFA0E33-F537-4861-A35F-10ECB328FB74'
			----					'57504A29-9F06-41B2-896C-81D5A57E37BF'
			--	SET @PARIdioma = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'			-- Idioma elegido o por defecto = espa�ol
			--	SET @PARAmbAplic = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'		-- Ambito de Aplicaci�n elegido o por defecto = ObjMod
			--
			--	EXEC @return_value = [dbo].[CintfPObjModBucleID] @PAR1 = @PARPadreID, @PAR2 = @PARIdioma, @PAR3 = @PARAmbAplic

---- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
---- <<< Consulta 03 >>>
---- Detalle las Propiedades del Objetos Modelos disponibles, para el modulo Central Interfaz Objetos
---- aqu� esta como se forma cada uno de los Objetos, que caracter�sticas tienen
----	DECLARE	@return_value int
	DECLARE @TempObjModProp TABLE
		(
			[IDFkCIntfTObjMod] [uniqueidentifier] NULL,
			[IDFkCIntfTObjCod_CodxIdio] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
			[IntfTObjCod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[ObjModCodUnico] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[ObjModCodDescFuncion] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
			[IDFkCintfTObjProp] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
			[ObjModCodPropValor] [nvarchar](255) COLLATE Modern_Spanish_CI_AS NULL,
			[ObjModCodPropOrden] [int] NULL,
			[IDFkCintfTObjCod_ObjCodProp] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
			[ObjCodPropCodigo] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[ObjCodPropDesc] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
			[IDFkCDiccTCod_ObjCodUbic] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
			[ObjCodPropUbicCod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[ObjCodPropUbicDesc] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
			[IDFkCDiccTCod_ObjModPropEst] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL,
			[IntUsuObjPropEst] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[IntUsuObjPropEstDesc] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
			[ObjModPropFechaModif] [datetime] NULL
		)

--	DECLARE @PARIdioma NVARCHAR(50)		-- Idioma elegido o por defecto = espa�ol
	SET @PARIdioma = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	INSERT INTO @TempObjModProp EXEC @return_value = [dbo].[CIntfPObjModProp] @PAR1 = @PARIdioma

--	SELECT * FROM @TempObjModProp

-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<< Consulta 04 >>>
-- Detalle los Objetos Modelos, sus Elementos y sus Propiedades, para el modulo Central Interfaz Objetos
-- si el elemento no tiene propiedades, deja NULL, y es como si no estuviera para cuando se hace el Objeto Web
SELECT 'ObjModBucleID'
	    ,OM.[EstOrd]
	    ,OM.[ArbolDesc]
	    ,OM.[ArbolNivel]
	    ,OM.[IntfTObjCod]
	    ,OM.[ObjModCodUnico]
--	    ,OM.[ObjModCodDescFuncion]
	    ,OM.[ArbItemNivel]
	    ,OM.[ArbItemOrd]
--	    ,OM.[TagOpen]
--	    ,OM.[TagClose]
--		,OM.*
		,'ObjModProp'
		,OMP.[ObjModCodPropValor]
		,OMP.[ObjModCodPropOrden]
		,OMP.[ObjCodPropCodigo]
		,OMP.[ObjCodPropDesc]
		,OMP.[ObjCodPropUbicCod]
		,OMP.[IntUsuObjPropEst]
--		,OMP.
--		,OMP.*
FROM @TempObjModBucleID OM
	LEFT OUTER JOIN @TempObjModProp OMP
		ON OM.[IDFkCIntfTObjMod] = OMP.[IDFkCIntfTObjMod]
ORDER BY OM.[EstOrd], OMP.[ObjModCodPropOrden]


---- <<<<<<< Importante >>>>>>>>>>>
---- Hay que ver que ciertos objetos deber�an, tener valores por defecto y cuando se carga el Objeto esta propiedades se asignan con valores est�ndares
---- <<<<<<< Importante >>>>>>>>>>>
--
