set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO
-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 22/07/2017
-- Description:	Detalle de los c�digos ID, para el idioma elegido o el por defecto = espa�ol
-- =============================================
ALTER PROCEDURE [dbo].[CIntfPAmbAplic]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 NVARCHAR(50) = NULL										-- Ambito de Aplicaci�n elegido o por defecto = NULL
AS
BEGIN

--	DECLARE @PAR1 NVARCHAR(50) 
--	DECLARE @PAR2 NVARCHAR(50) 
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR2 = NULL										-- Ambito de Aplicaci�n elegido o por defecto = NULL


	DECLARE @TmpTCodxIdi TABLE	-- Codigos x Idiomas -- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)

	-- Inserta en la tabla temporal la informaci�n de los c�digos seg�n el idioma elegido
	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1
				AND
			  CxI.[IDFkTCodAmbAplic] = CASE WHEN @PAR2 IS NULL THEN CxI.[IDFkTCodAmbAplic] ELSE @PAR2 END

--  SELECT * FROM @TmpTCodxIdi

	SELECT CxI.[IDFkTCIntfTObjCod_CodxIdio]
	--      ,CxI.[IDFkTCIntfTObjCod_AmbAplic]
			,CxI.[Codigo]
			,CxI.[Descripcion]
--			,CxI.[IDFkTCDiccTIdio_Idioma]
			,Cd01.[Codigo]
			,Cd01.[Descripcion]
--			,CxI.[IDFkCDiccTCod_ObjCodxIdioEst]
			,Cd02.[Codigo]
			,Cd02.[Descripcion]
			,CxI.[ObjCodxIdioFechaModif]
	  FROM [BDCtral].[dbo].[CIntfTObjCodxIdio] AS CxI WITH (NOLOCK)
			INNER JOIN @TmpTCodxIdi AS Cd01			-- Detalle del Idioma
				ON CxI.[IDFkTCDiccTIdio_Idioma] = Cd01.[IDFkTCodigos]
			INNER JOIN @TmpTCodxIdi AS Cd02			-- Detalle del Estado
				ON CxI.[IDFkCDiccTCod_ObjCodxIdioEst] = Cd02.[IDFkTCodigos]
	WHERE CxI.[IDFkTCIntfTObjCod_CodxIdio] = CxI.[IDFkTCIntfTObjCod_AmbAplic]
	ORDER BY CxI.[Codigo]

END



--	DECLARE	@return_value int
--	EXEC	@return_value = [dbo].[CIntfPAmbAplic]
--






