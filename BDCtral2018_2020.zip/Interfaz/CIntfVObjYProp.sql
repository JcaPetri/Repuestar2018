set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO
			DECLARE	@return_value int
			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'AEFEA6F0-CC81-41AB-AD12-354A484273DA'		-- Ambito Aplicaci�n Elemento
--			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'ABEDD291-3991-4A47-8AEB-82580BF6BA8C'		-- Ambito Aplicaci�n Estilos
			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B'		-- Ambito Aplicaci�n Propiedad
