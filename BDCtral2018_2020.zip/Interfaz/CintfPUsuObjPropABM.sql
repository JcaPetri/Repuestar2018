-- #########################################################################################################################################################
--  GENERA LOS PROCEDIMIENTOS ALMACENADOS PARA HACER EL ALTA, MODIFICACION, BAJA O RECUPERO DE LAS PROPIEDADES DE LOS OBJETOS MODELOS tabla [CIntfTObjMod] -- 

-- ################################################################################################################################
-- ################################################################################################################################
-- Trabaja con la tabla CIntfTObjModProp  
-- Para armar el objeto:
--			1.- Insertar la propiedades del objeto
-- Las propiedades disponibles para cada objeto estan en la tabla [CintfTObjCodProp]
-- para un objeto solo puede tener una sola vez la propiedad.
-- ################################################################################################################################

USE [BDCtral]
GO

-- Tabla propiedades [CintfTObjCodProp]

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO

DECLARE	@return_value int

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Variables para realizar al ABM, se debe:
	-- Variables Etapa 1
	DECLARE @PAR1 AS VARCHAR(50)	-- Determina acci�na realizar 
		-- valores posibles: ALTA - MODIFICACION - BAJA - RECUPERO
		-- Como estos valores son para todas las tablas e idiomas unicos siempre van los mismos

	DECLARE @PAR2 AS uniqueidentifier		-- [ID], de la tabla [CIntfTUsuObjProp], esto se usa para modificar una propiedad

	DECLARE @PAR3 AS VARCHAR(36)	-- [ID] tabla [CIntfTUsuObj]-- codigo ID �nico del objeto al que se le asignar�la propiedad.
		-- Caso Alta: 
			-- surge de la tabla [CIntfTUsuObj], que se muestra en la consulta [CIntfVUsuObj]
				--	SELECT * FROM [BDCtral].[dbo].[CIntfVUsuObj]

	DECLARE @PAR4 AS VARCHAR(36)	-- [ID] tabla [IDFkTIntCodObj] -- 
		-- Caso Alta: 
			-- surge de la tabla [CIntfTObjCod], es el ID del elemento cargado en el Objeto Modelo

	DECLARE @PAR5 AS VARCHAR(36)	-- [ID] tabla [CintfTObjCodProp] -- valor ID �nico de la Propiedad
		-- Caso Alta: 
			-- Este valor se incorpora manualmente. Seg�n el Objeto es la propiedad que el usuario quiera asignar.
				--	DECLARE	@return_value int
				--	EXEC	@return_value = [dbo].[CIntfPObjYProp] @PAR5 = N'a96324e5-b360-4d6d-9486-4dfd63565f70'

	DECLARE @PAR6 AS nvarchar(250)		-- [UsuObjCodPropValor] -- valor del Objeto
		-- Caso Alta: 
			-- El valor puede o no cambiarlo el usuario
		-- Caso Modificaci�n: 

	DECLARE @PAR7 AS INT			-- [UsuObjCodPropOrden] -- orden en que se armara el TAG
		-- Caso Alta: 
			-- Este valor no se puede cambiar

	DECLARE @PAR8 AS VARCHAR(36) 			-- [IDFkCDiccTCod_UsuObjPropEst] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
		-- Caso Alta:
			-- Es un c�digo ID con las distintas opciones, estas pueden ser. Habilitado, Deshabilitado, Eliminado.
				-- 6B0CD910-C127-4450-9865-15E9F4C287B4	EST	estados			EST	estados
					-- EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0	DES	deshabilitado	EST	estados
					-- 3749D6D8-EF8F-4C37-893A-BE7209239810	ELI	eliminado		EST	estados
					-- C6FE2749-0CB8-49CD-97DF-03C299C0C6CF	HAB	habilitado		EST	estados
		-- Caso Modificaci�n:
			-- Se cambia el estado sin realizar verificaciones. en caso de que se recupere el c�digo, se debe verificar que no se infrinjan las reglas primarias.

	DECLARE @ValVar AS VARCHAR(50)
	SET @ValVar = 'VAL'

	-- Variables para obtener los valores del procedimiento almacenado de CGetErrorInfo
		DECLARE @RTADO_PROCALM AS VARCHAR(250)
		DECLARE @NOMB_PROCALM AS VARCHAR(250)
		DECLARE @FUNC_PROCALM AS VARCHAR(100)
		DECLARE @RTADO AS VARCHAR(250)
		DECLARE @REG_AFEC AS NUMERIC(18, 0)
		DECLARE @ERR_MESSAGE AS VARCHAR(250)
		DECLARE @ERR_NUMBER AS NUMERIC(18, 0)
		DECLARE @ERR_SEVERITY AS NUMERIC(18, 0)
		DECLARE @ERR_STATE AS NUMERIC(18, 0)
		DECLARE @ERR_LINE AS NUMERIC(18, 0)
		
		SET @NOMB_PROCALM = 'CintfPUsuObjPropABM'				-- Nombre del procedimiento almacenado.

-- Valores de las variables para generar las prueba del funcionamiento de las consultas.
--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- SETEO DE LAS VARIABLES PARA EL ALTA DE UN CODIGO Y SUS DESCRIPCIONES
		SET @PAR1 = 'ALTA'													-- ALTA - MODIFICACION - BAJA - RECUPERO
		SET @PAR2 = NEWID()													-- [ID] Valor Unico de la Tabla CIntfTUsuObjProp
		SET @PAR3 = '3992A919-2E7E-4539-9F68-94E38BFC20F6'					-- [ID] tabla [CIntfTUsuObj]-- codigo ID �nico del objeto al que se le asignar�la propiedad.
		SET @PAR4 = '75A8EA76-C0A0-4DA1-A07F-1E1FF1514043'					-- [ID] tabla [IDFkTIntCodObj] -- conjuntamente con el @PAR5, se utiliza para sacar los valores y orden de la tabla [CintfVObjCodProp]

			-- Caso Alta: 
				-- surge de la tabla [CIntfTUsuObj], que se muestra en la consulta [CIntfVUsuObj]
--						SELECT [ID]
--							  ,[IDFkCIntfTObjCod_UsuObjCod]
--							  ,[IntObjCodigo]
--							  ,[IntUsuObjCodUnico]
--							  ,[IntUsuObjCodDescFuncion]
--							--      ,[IntUsuObjCodUsuUnico]						--      ,[IDFkCDiccTCod_UsuObjEst]						--      ,[UsuObjFechaModif]						--      ,[IDFkCIntfTObjCod_UsuObjCod]						--      ,[IntObjDescripcion]
--						  FROM [BDCtral].[dbo].[CIntfVUsuObj]
						--	@PAR3 = [ID]							@PAR4 = [IDFkTIntCodObj]				[IntUsuCodUnico]	[IntUsuDescFuncion]
						--	El Objeto Page no tiene propiedades, es para que sea el Padre de Todo
						--	35E47F59-6B64-4D37-9B1F-28FF086FD33E	F9DA8C8E-925D-4C2A-BF1C-EA363BEB3D41	doctype1121	
						--	10C79DD0-3CD4-4F98-B7C9-E731D3054CEF	75A8EA76-C0A0-4DA1-A07F-1E1FF1514043	<meta>	meta3144	especifica description
						--	3992A919-2E7E-4539-9F68-94E38BFC20F6	75A8EA76-C0A0-4DA1-A07F-1E1FF1514043	<meta>	meta3145	especifica viewport		tipo de documento
-- Inicio Borrar
--		DECLARE @CodObj AS VARCHAR(36)		-- [IDFkTIntCodObj] -- codigo ID del ObjetoID que tiene la propiedad.
--			-- Surge de la consulta a la [CIntfVUsuObj], donde el [ID] = @PAR3
--		SELECT @CodObj = [IDFkCIntfTObjCod_UsuObjCod] FROM [BDCtral].[dbo].[CIntfVUsuObj] WHERE [ID] = @PAR3
--		SELECT @CodObj
-- Fin Borrar
--		DECLARE	@return_value int
		EXEC @return_value = [dbo].[CIntfPObjConProp] @PAR2 = @PAR4
		-- Se toma el valor ID, de la propiedad elegida, para poner en la variable @PAR5

		-- D46E782C-80AC-4162-BDAB-94766A18FE78, NO VA, LO QUE VA ES EL id
		SET @PAR5 = 'D46E782C-80AC-4162-BDAB-94766A18FE78'			-- [ID] tabla [CintfTObjCodProp] -- valor ID �nico de la Propiedad
			-- Este valor se incorpora manualmente. Seg�n el Objeto es la propiedad que el usuario quiera asignar.
					-- Para ver los valores disponibles para el UsuCodObjeto, hay que ejecutar la siguiente consulta ANTERIOR (1)

		-- [UsuObjCodPropValor] y [UsuObjCodPropOrden]
		SET @PAR6 = '<meta>'			--  Como este valor lo puede colocar el usuario, se carga, si es NULL, se pone el de la tabla

		SELECT @PAR6 = CASE WHEN @PAR6 IS NULL THEN [ObjCodPropValor] ELSE @PAR6 END				-- [UsuObjCodPropValor] -- valor del Objeto
			  ,@PAR7 = [ObjCodPropOrden]				-- [UsuObjCodPropOrden] -- orden en que se armara el TAG
		  FROM [BDCtral].[dbo].[CintfVObjCodProp]
		WHERE [ID] = @PAR5

		SET @PAR8 = 'c6fe2749-0cb8-49cd-97df-03c299c0c6cf'					-- [IDFkCDiccTCod_UsuObjPropEst] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado

--		SELECT @PAR1 AS 'P01_Accion', @PAR2 AS 'P02_CIntfTUsuObjProp', @PAR3 AS 'P03_IDCIntfTUsuObj', @PAR4 AS 'P04_IDFkTIntCodObj', @PAR5 AS 'P05_CintfTObjCodProp', @PAR6 AS 'P06_PropVal', @PAR7 AS 'P07_PropOrd', @PAR8 AS 'P08_PropEst'

		SET @ValVar = CASE WHEN @PAR1 IS NULL THEN 'Err' 
							WHEN @PAR2 IS NULL THEN 'Err' 
							WHEN @PAR3 IS NULL THEN 'Err' 
							WHEN @PAR4 IS NULL THEN 'Err'
							WHEN @PAR5 IS NULL THEN 'Err' 
							WHEN @PAR6 IS NULL THEN 'Err' 
							WHEN @PAR7 IS NULL THEN 'Err' 
							WHEN @PAR8 IS NULL THEN 'Err'
							ELSE @ValVar 
						END
--		SELECT @ValVar

--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	-- SETEO DE LAS VARIABLES PARA LA MODIFICACION DE UN CODIGO Y SUS DESCRIPCIONES
--		SET @PAR1 = 'MODIFICACION'											-- ALTA - MODIFICACION - BAJA - RECUPERO
--		SET @PAR6 = 'ABE14F0E-8DF7-4492-9DB9-77199807D80A'					-- ID del codigo, debe ser �nico
--		SET @PAR7 = 'FB478ECC-85FE-4FC8-B792-CAF8ECB921B1'					-- ID del Idioma	-- Espa�ol		
--		SET @PAR8 = '528CEED9-D2B3-4CB5-8116-01BDAD455C83'					-- ID del Ambito de Aplicaci�n del C�digo -- Usuarios	
--		SET @PAR8 = 'PPVTGTIA'													-- C�digo, debe ser �nico
--		SET @PAR8 = 'personal postventa garantia'												-- Descripcion del codigo
--		SET @PAR8 = 'c6fe2749-0cb8-49cd-97df-03c299c0c6cf'					-- Habilitado
--		SET @PAR8 = 'AltaCompleto'

---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- Valores de las variables para agregarle al codigo ID, solo el Codigo por Idioma nuevo. No agrega el cogido porque ya existe para un idioma.
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	-- SETEO DE LAS VARIABLES PARA EL ALTA DE UN CODIGO Y SUS DESCRIPCIONES
--		SET @PAR1 = 'ALTA'												-- ALTA - MODIFICACION - BAJA - RECUPERO
--		SET @PAR6 = '3749D6D8-EF8F-4C37-893A-BE7209239810'					-- ID del codigo, este ya es un codigo generado
--		SET @PAR7 = 'b1268278-4eb3-4a93-8f67-0d425b767c65'					-- ID del Idioma
----				ee954f5d-ca27-48a9-a23b-010788b18631	ITA	italiano
----				b1268278-4eb3-4a93-8f67-0d425b767c65	ENG	english
----				a455281d-76f5-4bad-8dbb-201c5928aaf8	FRA	fran�ais
----				1048c13b-1cc9-4154-8b8b-64ca9ac9fe12	POR	portugu�s
----				fb478ecc-85fe-4fc8-b792-caf8ecb921b1	ESP	espa�ol
--		SET @PAR8 = '6B0CD910-C127-4450-9865-15E9F4C287B4'					-- ID del Ambito de Aplicaci�n del C�digo -- Usuarios	
--		SET @PAR8 = 'REM'													-- C�digo, debe ser �nico
--		SET @PAR8 = 'removed'													-- Descripcion del codigo
--		SET @PAR8 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'					-- Habilitado
--		SET @PAR8 = 'SoloCodxIdio'
--
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- Pasos antes de hacer ABM de los datos:
	-- Etapa 1: Primero verificar que con el cambio no se infrinja ninguna clave primaria
	-- Etapa 2: 
			-- 1: Si el resultado es que se infrinje, no realizar el cambio e informar al usuario
			-- 2: Si es todo OK, se realiza el cambio. Para hacer esto se hace una transacci�n para asegurar la integridad del cambio.	

IF @PAR1 = 'ALTA'
BEGIN
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- ##############################################################################################################################################
	-- INICIO -- ALTA DE CODIGO Y SUS DESCRIPCIONES
	-- ##############################################################################################################################################
	
	SET @FUNC_PROCALM = 'Alta'		-- Funcion dentro del procedimiento almacenado.

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Para agregar un nuevo C�digo, se debe:
		-- Aqu� hay ciertos elementos que en una pagina no se pueden duplicar.
		-- Esta validaci�n hay que hacerla luego.
		-- Los otros campos pueden tener cualquier valor, no se validan.

		-- Aclaraci�n: La combinaci�n m�s ID del Ambito de Aplicaci�n, por lo tanto para un idioma, puede haber dos c�digos iguales, pero cada uno para un ambito de aplicaci�n diferente.

	-- Etapa 1: Verifica Clave Primaria: que el objeto no tenga ya la propiedad, Cada Objeto puede tener una propiedad solo una vez.
		-- Si alguno de los valores son encontrados, la variable @PAR3 se pone a NULL
		SELECT @PAR3 = NULL
		  FROM [BDCtral].[dbo].[CIntfTUsuObjProp] WITH(NOLOCK)
		WHERE [IDFkCintfTObjCodProp_UsuObjProp] = @PAR3 AND [IDFkCintfTObjCodProp_UsuObjProp] = @PAR5
--			 Clave Primaria: -- [IDFkCIntfTUsuObj_UsuObj], [IDFkCintfTObjCodProp_UsuObjProp].
--				SELECT @PAR3

	-- Etapa 2: 
			-- 1: Si el C�digo infringe la clave primaria, no hace el cambio e informa al usuario
		IF @PAR3 IS NULL
			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			BEGIN
				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
				SET @RTADO = 'ERR' 
				SET @REG_AFEC = 0
				SET @ERR_MESSAGE = 'La propiedad para el Objeto ya esta asignada.'
				SET @ERR_NUMBER = 0
				SET @ERR_SEVERITY = 0
				SET @ERR_STATE = 0
				SET @ERR_LINE = 0
			END
		ELSE
			-- 2: Si es todo OK, se realiza el cambio.
			BEGIN TRY
			BEGIN TRANSACTION;
			-- Inserta el codigo en las tablas. 
				
				-- PRIMERO en la tabla [CIntfTUsuObj]		Inserta los objetos de la p�gina
				BEGIN
				 INSERT INTO [BDCtral].[dbo].[CIntfTUsuObjProp]
						   ([ID]
						   ,[IDFkCIntfTUsuObj_UsuObj]
						   ,[IDFkCintfTObjCodProp_UsuObjProp]
						   ,[UsuObjCodPropValor]
						   ,[UsuObjCodPropOrden]
						   ,[IDFkCDiccTCod_UsuObjPropEst]
						   ,[UsuObjPropFechaModif])
					SELECT @PAR2			-- [ID] unico del objeto usuario propiedad
							,@PAR3			-- [ID] tabla [CIntfTUsuObj]-- codigo ID �nico del objeto al que se le asignar�la propiedad.
							,@PAR5			-- [ID] tabla [CintfTObjCodProp] -- valor ID �nico de la Propiedad
							,@PAR6			-- [UsuObjCodPropValor] -- valor del Objeto
							,@PAR7			-- [UsuObjCodPropOrden] -- orden en que se armara el TAG
							,@PAR8			-- [IDFkCDiccTCod_UsuObjPropEst] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
							,GETDATE()

				END
				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
				BEGIN
					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
					SET @RTADO = 'OK' 
					SET @REG_AFEC = 1
					SET @ERR_MESSAGE = 'Se cargo la informacion solicitada.'
					SET @ERR_NUMBER = 0
					SET @ERR_SEVERITY = 0
					SET @ERR_STATE = 0
					SET @ERR_LINE = 0
				END
			
				-- Si el procedimiento es exitoso, confirma la operaci�n.
				COMMIT TRANSACTION;
			END TRY
			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
			BEGIN CATCH

				-- Ejecuta el Procedimiento Almacenado para obtener el error.
				EXECUTE [dbo].[CGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT

				-- Como la operaci�n fall�, se deshacen las modificaciones.
				ROLLBACK TRANSACTION;

				-- Por las dudas se elimana el registro con el ID generado.
				DELETE FROM [BDCtral].[dbo].[CIntfTUsuObjProp] WHERE [ID] = @PAR2

				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				SET @RTADO = 'ERR'
				SET @REG_AFEC = 0
			END CATCH;

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- ##############################################################################################################################################
	-- FINAL -- ALTA DE CODIGO Y SUS DESCRIPCIONES
	-- ##############################################################################################################################################
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
END


ELSE 
IF @PAR1 = 'MODIFICACION'
BEGIN
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- INICIO	-- MODIFICACION DE CODIGO Y SUS DESCRIPCIONES
-- ##############################################################################################################################################
	
	SET @FUNC_PROCALM = 'Modificacion'		-- Funcion dentro del procedimiento almacenado.

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Para modificar un nuevo C�digo, se debe:
		-- Clave Primaria: IDC�digo [IDFkTIntCodigos], IDIdiomas [IDFkTIdioma], IDAmbitoAplicaci�n [IDFkTCodAmbAplic], C�digo Unico [Codigo]
		-- Los otros campos pueden tener cualquier valor, no se validan.

		-- Aclaraci�n: La combinaci�n m�s ID del Ambito de Aplicaci�n, por lo tanto para un idioma, puede haber dos c�digos iguales, pero cada uno para un ambito de aplicaci�n diferente.

	-- Etapa 1: Verifica Clave Primaria: que el objeto creado puede tener solamente una propiedad una sola vez
		-- Si alguno de los valores son encontrados, la variable @PAR3 se pone a NULL
		SELECT @PAR3 = NULL
		  FROM [BDCtral].[dbo].[CIntfTUsuObjProp] WITH(NOLOCK)
		WHERE [IDFkCIntfTUsuObj_UsuObj] = @PAR3 AND [IDFkCintfTObjCodProp_UsuObjProp] = @PAR5
--			 Clave Primaria: -- [IDFkCIntfTUsuObj_UsuObj], [IDFkCintfTObjCodProp_UsuObjProp].
--				SELECT @PAR3


	-- Etapa 2: 
			-- Si el codigo ya esta utilizado, infrinje la clave primaria, no hace los cambios e informa al usuario.
		IF @PAR3 IS NULL
			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			BEGIN
				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
				SET @RTADO = 'ERR' 
				SET @REG_AFEC = 0
				SET @ERR_MESSAGE = 'El Objeto ingresado ya tiene asignado esa propiedad.'
				SET @ERR_NUMBER = 0
				SET @ERR_SEVERITY = 0
				SET @ERR_STATE = 0
				SET @ERR_LINE = 0
			END
		ELSE
			-- 2: Si es todo OK, se realiza el cambio.
			BEGIN TRY
			BEGIN TRANSACTION;
				-- Modifica el codigo en la tabla. Le puede cambiar el idioma, ambito de aplicacion, el codigo, su descripcion y el estado.
--				UPDATE [BDCtral].[dbo].[CintfTObjCodProp]
--				   SET [IDFkTObjCod] = @PAR7
--					  ,[IDFkTCodObjProp] = @PAR8
--					  ,[UsuObjCodPropValor] = @PAR8
--					  ,[UsuObjCodPropOrden] = @PAR8
--					  ,[IDFkCDiccTCod_UsuObjPropEst] = @PAR8
--					  ,[TObjCodProFechaModif] = GETDATE()
--				 WHERE [ID] = @PAR6

				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
				BEGIN
					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
					SET @RTADO = 'OK' 
					SET @REG_AFEC = 1
					SET @ERR_MESSAGE = 'Se modific� la informacion solicitada.'
					SET @ERR_NUMBER = 0
					SET @ERR_SEVERITY = 0
					SET @ERR_STATE = 0
					SET @ERR_LINE = 0
				END
			
				-- Si el procedimiento es exitoso, confirma la operaci�n.
				COMMIT TRANSACTION;
			END TRY
			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
			BEGIN CATCH

				-- Ejecuta el Procedimiento Almacenado para obtener el error.
				EXECUTE [dbo].[CGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT

				-- Como la operaci�n fall�, se deshacen las modificaciones.
				ROLLBACK TRANSACTION;

				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				SET @RTADO = 'ERR'
				SET @REG_AFEC = 0
			END CATCH;

-- ##############################################################################################################################################
-- FINAL	-- MODIFICACION DE CODIGO Y SUS DESCRIPCIONES
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
END

ELSE
IF @PAR1 = 'BAJA'
BEGIN
-- ##############################################################################################################################################
-- INICIO	-- BAJA DE CODIGO Y SUS DESCRIPCIONES
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	SET @FUNC_PROCALM = 'Baja'		-- Funcion dentro del procedimiento almacenado.

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Para dar de baja un C�digo, se debe:
		-- Cambiar solo el estado. No se elimina ya que puede afectar las relaciones asociadas.
	-- Etapa 1: verifica que el codigo ya no est� dado de baja.
		-- Si alguno de los valores son encontrados, la variable @PAR3 se pone a NULL
		SELECT @PAR3 = NULL
		  FROM [BDCtral].[dbo].[CIntfTUsuObjProp] WITH(NOLOCK)
		WHERE [IDFkCIntfTUsuObj_UsuObj] = @PAR3 AND [IDFkCintfTObjCodProp_UsuObjProp] = @PAR5
--			 Clave Primaria: -- [IDFkCIntfTUsuObj_UsuObj], [IDFkCintfTObjCodProp_UsuObjProp].
--				SELECT @PAR3


	-- Etapa 2: 
			-- 1: Si el codigo ya esta dado de baja, no hace nada, solo le informa al usuario.
		IF @PAR3 IS NULL
			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			BEGIN
				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
				SET @RTADO = 'ERR' 
				SET @REG_AFEC = 0
				SET @ERR_MESSAGE = 'El c�digo ingresado ya esta dado de baja.'
				SET @ERR_NUMBER = 0
				SET @ERR_SEVERITY = 0
				SET @ERR_STATE = 0
				SET @ERR_LINE = 0
			END
		ELSE
			-- 2: El c�digo esta para darle de baja, procede a hacerlo.
			BEGIN TRY
			BEGIN TRANSACTION;
--				-- Elimina el codigo en la tabla. Para ello le agrega la leyenda '-ELI', si supera la cantidad de d�gitos permitidos del campo, le reduce el c�digo original.
--				-- el c�digo no se elimina, pero al ponerle -ELI, el codigo anterior se puede usar nuevamente
--				UPDATE [BDCtral].[dbo].[CintfTObjCodProp]
--				   SET [UsuObjCodPropValor] = CASE WHEN LEN ([UsuObjCodPropValor] + '-ELI') >= 54 THEN (SUBSTRING([UsuObjCodPropValor], 1, 50) + '-ELI') ELSE [UsuObjCodPropValor] + '-ELI' END			-- Le pone la leyenda que el c�digo esta eliminado.
--						,[IDFkCDiccTCod_UsuObjPropEst] = @PAR8			-- Le pone el estado de eliminado.
--				WHERE [ID] = @PAR6

				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
				BEGIN
					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
					SET @RTADO = 'OK' 
					SET @REG_AFEC = 1
					SET @ERR_MESSAGE = 'Se elimin� el c�digo indicado.'
					SET @ERR_NUMBER = 0
					SET @ERR_SEVERITY = 0
					SET @ERR_STATE = 0
					SET @ERR_LINE = 0
				END
			
				-- Si el procedimiento es exitoso, confirma la operaci�n.
				COMMIT TRANSACTION;
			END TRY
			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
			BEGIN CATCH
				-- Ejecuta el Procedimiento Almacenado para obtener el error.
				EXECUTE [dbo].[CGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT

				-- Como la operaci�n fall�, se deshacen las modificaciones.
				ROLLBACK TRANSACTION;

				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				SET @RTADO = 'ERR'
				SET @REG_AFEC = 0
			END CATCH;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- FINAL	-- BAJA DE CODIGO Y SUS DESCRIPCIONES
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
END

ELSE
IF @PAR1 = 'RECUPERO'
BEGIN
-- ##############################################################################################################################################
-- INICIO	-- RECUPERO DE CODIGO Y SUS DESCRIPCIONES
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	SET @FUNC_PROCALM = 'Recupero'		-- Funcion dentro del procedimiento almacenado.

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Para recuperar un C�digo, se debe:
		-- Cambiar solo el estado. Ya que no se elimina, solo se debe verificar que ese c�digo que vuelve a funcionar, 
		-- no est� utilizado y por ende infrinja la regla primaria.
		-- Clave Primaria: IDC�digo [IDFkTIntCodigos], IDIdiomas [IDFkTIdioma], IDAmbitoAplicaci�n [IDFkTCodAmbAplic], C�digo Unico [Codigo]
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	-- Etapa 1: verifica que el codigo est� dado de baja, si no es as� le informa al usuario.
		-- Si alguno de los valores son encontrados, la variable @PAR3 se pone a NULL
		SELECT @PAR3 = NULL
		  FROM [BDCtral].[dbo].[CIntfTUsuObjProp] WITH(NOLOCK)
		WHERE [IDFkCIntfTUsuObj_UsuObj] = @PAR3 AND [IDFkCintfTObjCodProp_UsuObjProp] = @PAR5
--			 Clave Primaria: -- [IDFkCIntfTUsuObj_UsuObj], [IDFkCintfTObjCodProp_UsuObjProp].
--				SELECT @PAR3
		-- Etapa 2: 
				-- 1: Si el codigo NO esta dado de baja, no hace nada y le informa al usuario.
		IF @PAR3 IS NULL
			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			BEGIN
				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
				SET @RTADO = 'ERR' 
				SET @REG_AFEC = 0
				SET @ERR_MESSAGE = 'El c�digo ingresado no est� dado de baja.'
				SET @ERR_NUMBER = 0
				SET @ERR_SEVERITY = 0
				SET @ERR_STATE = 0
				SET @ERR_LINE = 0
			END
		ELSE

		-- Etapa 3: Ya sabemos que el c�digo esta dado de baja. Verificamos que no infrinja la clave primaria.
				-- Clave Primaria: IDC�digo [IDFkTIntCodigos], IDIdiomas [IDFkTIdioma], IDAmbitoAplicaci�n [IDFkTCodAmbAplic], C�digo Unico [Codigo]
		-- Aclaraci�n:
				-- Ahora verificamos si el valor que tiene el c�digo, fue utilizado por alg�n c�digo activo.
				-- Si el c�digo esta repetido, le agrega la palabra 'REC-' valor ID, y si no tiene espacio, le reduce el c�digo original. De esta manera no se duplica nunca el c�digo.
				-- el usuario luego debe modificar el c�digo indicado.
--		SELECT @PAR8 = NULL
--		  FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK)
--		WHERE [IDFkTObjCod] = @PAR7 AND [IDFkTCodObjProp] = @PAR8		-- Primero verifica que no se infrinja la clave primaria: C�digoID - Idioma - Ambito Aplicacion - C�digo
--		-- Si el codigo ya esta utilizado agrega el c�digo m�s una leyenda de 4 caracteres y le cambia el estado a habilitado.
		--		SELECT @PAR8
--
--		-- Etapa 4: Si el codigo ya esta utilizado, Verifica el OK con el c�digo modificado
--		IF @PAR8 IS NULL
--			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
--			BEGIN
--				-- Como el c�digo ya esta utilizado, le pone el ID al C�digo para que no haya forma de duplicidad.
--				SELECT @PAR8 = SUBSTRING([IDFkTObjCod], 1, 18) + @PAR6
--					FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK)
--				WHERE [ID] <> @PAR6
--				GOTO HaceCambio
--				-- Ya le realizo a la variable que tiene el c�digo, ahora lo implementa en la transacci�n.
--			END
--		ELSE
HaceCambio:
			BEGIN TRY
			BEGIN TRANSACTION;
				-- Modifica el codigo en la tabla. Le puede cambiar el idioma, ambito de aplicacion, el codigo, su descripcion y el estado.

				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
				BEGIN
					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
					SET @RTADO = 'OK' 
					SET @REG_AFEC = 1
					SET @ERR_MESSAGE = 'Se recuper� el c�digo indicado.'
					SET @ERR_NUMBER = 0
					SET @ERR_SEVERITY = 0
					SET @ERR_STATE = 0
					SET @ERR_LINE = 0
				END
			
				-- Si el procedimiento es exitoso, confirma la operaci�n.
				COMMIT TRANSACTION;
			END TRY
			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
			BEGIN CATCH

				-- Ejecuta el Procedimiento Almacenado para obtener el error.
				EXECUTE [dbo].[CGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT

				-- Como la operaci�n fall�, se deshacen las modificaciones.
				ROLLBACK TRANSACTION;

				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				SET @RTADO = 'ERR'
				SET @REG_AFEC = 0
			END CATCH;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- FINAL	-- RECUPERO DE CODIGO Y SUS DESCRIPCIONES
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
END


-- ##############################################################################################################################################
-- MUESTRA EL RESULTADO DEL PROCEDIMIENTO ALMACENADO
-- Envia el resultado: Nombre Proc Alm | Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
--SET @RTADO_PROCALM = @NOMB_PROCALM + '|' + @FUNC_PROCALM + '|' + @RTADO + '|' + CAST(@REG_AFEC AS VARCHAR(10)) + '|' + @ERR_MESSAGE + '|' + CAST(@ERR_NUMBER AS VARCHAR(10)) + '|' + CAST(@ERR_SEVERITY AS VARCHAR(10)) + '|' + CAST(@ERR_STATE AS VARCHAR(10)) + '|' + CAST(@ERR_LINE AS VARCHAR(10))
--SELECT @RTADO_PROCALM			-- Muestra el resulado en una unica columna
SELECT @NOMB_PROCALM AS ProcAlm_Nomb, @FUNC_PROCALM AS ProcAlm_Funcion, @RTADO AS ProcAlm_Rtado, @REG_AFEC AS ProcAlm_RegAfec, @ERR_MESSAGE AS ProcAlm_Mensaje, @ERR_NUMBER AS ProcAlm_ErrNum, @ERR_SEVERITY AS ProcAlm_ErrSeveridad, @ERR_STATE AS ProcAlm_ErrEstado, @ERR_LINE AS ProcAlm_ErrLinea

SELECT [ID]
      ,[IDFkCIntfTUsuObj_UsuObj]
      ,[IDFkCintfTObjCodProp_UsuObjProp]
      ,[UsuObjCodPropValor]
      ,[UsuObjCodPropOrden]
      ,[IDFkCDiccTCod_UsuObjPropEst]
      ,[UsuObjPropFechaModif]
  FROM [BDCtral].[dbo].[CIntfTUsuObjProp] WITH(NOLOCK)
	WHERE [ID] =  @PAR2

-- ##############################################################################################################################################^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- El GO va al final del procedimiento
GO
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################

----
---- Elimina Datos de las tablas
--DECLARE @PAR1 AS VARCHAR(36)
--SET @PAR1 = '196FA314-E1FE-4AC8-B653-17564CF62A88'		-- ID de la Tabla [CIntfTUsuObj]
--
--DELETE FROM [BDCtral].[dbo].[CIntfTUsuObjProp] WHERE [ID] = @PAR1


