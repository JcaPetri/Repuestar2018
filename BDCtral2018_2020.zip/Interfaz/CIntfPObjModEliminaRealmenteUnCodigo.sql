-- Define que se trabaja con al Base de Datos
USE [BDCtral]
GO

-- Revisar, se deben eliminar todos los registros que tengan clave primaria asociada a la Tabla CDiccTCodigos
-- Aqui se deben hacer los ajustes en todas las estructuras para que no se rompa el sistema.

DECLARE @PAR01 AS VARCHAR(36)
SET @PAR01 = '3e6ae0ab-d971-411d-a561-decee85a691e'

-- Tablas Central Interfaz Objetos Modelos
DELETE FROM [BDCtral].[dbo].[CIntfTObjMod]				-- Tabla Objetos Modelos
	WHERE [ID] = @PAR01 OR [IDFkCIntfTObjCod_ObjMod] = @PAR01

DELETE FROM [BDCtral].[dbo].[CIntfTObjModArb]				-- Tabla Objetos Modelos Arbol
	WHERE [ID] = @PAR01 OR [IDFkCIntfTObjModArb_PadreID] = @PAR01 OR [IDFkCIntfTObjMod] = @PAR01

DELETE FROM [BDCtral].[dbo].[CIntfTObjModArbEst]
      WHERE [IDFkCIntfTObjMod] = @PAR01

DELETE FROM [BDCtral].[dbo].[CIntfTObjModArbWeb]
      WHERE [IDFkCIntfTObjMod] = @PAR01

DELETE FROM [BDCtral].[dbo].[CIntfTObjModProp]				-- Tabla Objetos Modelos Propiedades
	WHERE [ID] = @PAR01 OR [IDFkCIntfTObjMod_ObjModID] = @PAR01 OR [IDFkCintfTObjCodProp_ObjModProp] = @PAR01
