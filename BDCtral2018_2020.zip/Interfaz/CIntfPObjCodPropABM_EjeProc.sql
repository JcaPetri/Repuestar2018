-- #########################################################################################################################################################
--  GENERA LOS PROCEDIMIENTOS ALMACENADOS PARA HACER EL ALTA, MODIFICACION, BAJA O RECUPERO DE LOS CODIGOS Y SUS DESCRIPCIONES DE LA INTERFAZ DE USUARIOS -- 
-- #########################################################################################################################################################

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- Determina la base de datos donde se trabajar�
USE [BDCtral]
GO

-- ===================================================
-- Author: Juan Petri
-- Create date: 26/11/2018
-- Description:	inserta nuevas propiedades a los Elementos HTML
-- ===================================================

	-- #################################################################################################################################
	-- Para una p�gina Web - Crea los elementos que se utilizar�n
	-- para ello ejecuta el procedimiento almacenado [CintfPObjCodPropABM]
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

		DECLARE	@return_value int
		DECLARE @PARint1 AS uniqueidentifier
		DECLARE @PARint2 AS uniqueidentifier

		SET @PARint1 = NEWID()
		SET @PARint2 = 'B99E0185-49D6-4D9E-89AE-DAA8C754D9A3'			-- ID c�digo del Elemento / Objeto al que se aplicar� la propiedad [IDFkTCIntfTObjCod_ObjCod]		
					-- Lista los elementos que contiene cada uno de los Ambitos de Aplicaci�n para el Idioma definido.
--					DECLARE	@return_value int
--					EXEC	@return_value = [dbo].[CIntfPCodxIdio]
--								@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--								-- Ambito de Aplicaci�n elegido o por defecto = NULL
--								,@PAR2 = 'AEFEA6F0-CC81-41AB-AD12-354A484273DA'		--	Ele	contiene los elementos de la pagina

							--	B99E0185-49D6-4D9E-89AE-DAA8C754D9A3	<a>	etiqueta que define un hiperv�nculo, que se utiliza para enlazar de una p�gina a otra. El atributo m�s importante del elemento <a> es el atributo href, que indica el destino del enlace
							--	62F38F66-AF19-4F62-98D2-5CCCCBB63125	<article>	etiqueta especifica contenido independiente, Un art�culo deber�a tener sentido por s� mismo y deber�a ser posible distribuirlo independientemente del resto del sitio
							--	DEC3F05F-E7C3-476F-BEAA-F2FE3A79BC99	<aside>	etiqueta define alg�n contenido aparte del contenido en el que se encuentra, pero este debe estar relacionado con el contenido que lo rodea
							--	EE8E9BBA-E7FD-40AA-A97F-9A085126B841	<body>	cuerpo de la pagina
							--	8BA11A28-67B7-4A15-B2E2-E5A30FCCB8FE	<br>	salto de pagina
							--	CBC7CCD2-6825-4288-A1EE-07C83D57FE97	<div>	seccion de pagina
							--	F9DA8C8E-925D-4C2A-BF1C-EA363BEB3D41	<doctype>	tipo de documento
							--	60F2A98E-23BC-4BFF-9C13-9FE3D922C4D9	<footer>	pie de p�gina
							--	4E3F5983-416B-47C5-918E-C7B4910C017F	<form>	formulario
							--	6A20FFB1-EF83-46AC-9DDA-9C37096B489D	<h1>	titulo h1
							--	66C2E055-CB9B-41FC-AD33-E5DF741CE7A8	<h2>	titulo h2
							--	116D43EC-D0FF-4915-B878-099A2ABE4EC6	<h3>	titulo h3
							--	DCF47D44-133A-4865-ADC0-57869979F845	<h4>	titulo h4
							--	C8BC46DE-7EA5-40F7-849C-8E381698CB93	<h5>	titulo h5
							--	FF6D64CD-B3CC-48D4-9409-634C25D9CA96	<h6>	titulo h6
							--	BEF7DACA-65E9-4662-89C8-35BC84274009	<head>	encabezado a nivel pagina
							--	79362741-DB66-4010-B494-9697786D8AA6	<header>	representa un contenedor para contenido introductorio o un conjunto de enlaces de navegaci�n
							--	E31EC871-F1C8-48F5-9C34-77326C46BB4D	<html>	hepertext markup languages
							--	EF69A94B-5C69-430C-A066-B6336A153A05	<inputcheck>	opcion de chequeo
							--	13C46A05-262C-48C4-BD29-7A5D0BB91D22	<inputpass>	ingreso de password
							--	CC3414AF-7742-4AFD-8EDA-E8D00130A553	<inputsubmit>	boton de env�o
							--	5432E780-F1C7-4D2E-B4C6-53DD7A9D729D	<inputtext>	campo de ingreso
							--	4BFD72B4-D915-413D-A9AF-3B93D448E543	<label>	texto
							--	CB6255ED-613B-4636-A971-2A2466CBC16E	<li>	etiqueta que define un elemento de la lista, se usa en listas ordenadas (<ol>), listas desordenadas (<ul>) y en listas de men� (<menu>)
							--	CCD03587-4CFE-4088-A699-6F8E8AD31088	<link>	permite vincular un archivo externo o documento
							--	75A8EA76-C0A0-4DA1-A07F-1E1FF1514043	<meta>	especificaciones de la p�gina
							--	9C4DD333-995B-4856-AB05-CBCEA7CBED31	<nav>	etiqueta que define un conjunto de enlaces de navegaci�n
							--	D16482D8-9D50-4A2B-BD3F-654CF56864AA	<ol>	etiqueta que define una lista ordenada. Una lista ordenada puede ser num�rica o alfab�tica. Use la etiqueta <li> para definir los elementos de la lista
							--	CB0D1A8F-E833-41E1-9272-173A230C9D78	<p>	parrafo
							--	A96324E5-B360-4D6D-9486-4DFD63565F70	<page>	pagina web
							--	5CE0D99D-230B-4C90-A5FF-C3FD6D37F095	<script>	script relacionados a la p�gina
							--	46BC5283-24AA-4B11-88F8-30D29AB09297	<section>	define las secciones de un documento, como cap�tulos, encabezados, pies de p�gina o cualquier otra secci�n del documento
							--	7E7703AF-582E-45E5-BB60-3D5735E37379	<title>	es el t�tulo de la lengueta de la p�gina
							--	EEA070F1-6BB2-41CB-BB3D-AD49549EB186	<ul>	etiqueta que define una lista desordenada (con vi�etas), Use la etiqueta <ul> junto con la etiqueta <li> para crear listas

		EXEC @return_value = [dbo].[CintfPObjCodPropABM]
			-- ALTA - MODIFICACION - BAJA - RECUPERO
				@PAR1 = 'ALTA'					
			-- ID del codigo, debe ser �nico
				,@PAR2 = @PARint1				
			-- ID c�digo del Elemento / Objeto al que se aplicar� la propiedad [IDFkTCIntfTObjCod_ObjCod]		
				,@PAR3 = @PARint2				
			--	ID de la propiedad a asignar [IDFkTCIntfTObjCod_ObjCodProp]
				,@PAR4 = '88A072A1-FFDE-4812-AA64-D33950CB5655'	--	href	ubicacion archivo
					-- ID de la propiedad a asignar [IDFkTCIntfTObjCod_ObjCodProp]
					-- Lista las propiedades disponibles para asignar a los elemento
--					DECLARE	@return_value int
--					EXEC	@return_value = [dbo].[CIntfPCodxIdio]
--								@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--								-- Ambito de Aplicaci�n elegido o por defecto = NULL
--								,@PAR2 = '9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B'	--	Pro	contiene las propiedades de la pagina, elementos y estilos

							-- Propiedades obligatorias
							--	D46E782C-80AC-4162-BDAB-94766A18FE78	tagopen		abre el tag
							--	B328283E-EF57-427F-A936-B0935AE5F679	tagclose	cierra el tag

							-- Todas las propiedades
							--	'6B3E68A8-56FE-4390-8FF6-A2ADB3B35BD2'	--	action	accion que sucede cuando se pasa el form
							--	'F56A99BF-4A55-41F7-81C7-D769DE20110D'	--	autofocus	objeto toma el foco
							--	'512CAFFA-599E-4630-A91C-C47D1EBE0A68'	--	charset	tipo de caracteres
							--	'178DCF27-5836-4A35-A21F-BA1D7FFB8BC8'	--	checked	opcion de chequeo
							--	'3719CE4C-9A6C-44D0-AD96-78EB101688DB'	--	class	especifica la clase de estilo del elemento
							--	'BF29781F-80DE-4E0C-9D62-32E2BE3C9349'	--	content	contexto
							--	'212B3630-B42C-46C7-9713-8459989A1391'	--	for	especifica al label a que al elemento esta asociado
							--	'902B236E-E46A-4EE5-91D5-ADF18894F735'	--	form	especifica al label a que formulario esta asociado
							--	'88A072A1-FFDE-4812-AA64-D33950CB5655'	--	href	ubicacion archivo
							--	'35B5EF8F-0417-4C24-92A5-CEF5EA69E22C'	--	http-equiv	Define especificaciones generales de la pagina, tipo caracteres, estilo por default, refresh interval.
							--	'BD4EA9B8-95FF-4287-B992-0A9DC71402AA'	--	id	c�digo unico del objeto
							--	'E10042E7-ED1C-41D9-9213-FB8E645B0A53'	--	method	metodo del form get / post
							--	'AF43D49B-0D5B-4E4E-8973-B3246AC8164B'	--	name	nombre del objeto
							--	'6AD03A4B-3596-4940-B876-645BBC38B7FB'	--	onclick	cuando usuario hace click con el mouse
							--	'1EFCFF28-5BD6-423A-A283-7FEF8CBDB0D6'	--	placeholder	valor sugerido al usuario
							--	'9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B'	--	Pro	contiene las propiedades de la pagina, elementos y estilos
							--	'5F20D71A-BB8D-48A4-94E6-87ADACACF83A'	--	rel	tipo archivo relacionado
							--	'09D4EF3E-07AE-4973-ACCB-EB2C43D52401'	--	size	largo del objeto
							--	'E518F810-1670-4361-87CB-E121419E7DC4'	--	src	ubicacion archivo
							--	'B328283E-EF57-427F-A936-B0935AE5F679'	--	tagclose	cierra el tag
							--	'D46E782C-80AC-4162-BDAB-94766A18FE78'	--	tagopen	abre el tag
							--	'622279E9-F399-4785-BF59-9AEB09E421BF'	--	texttag	texto que va entre los tags
							--	'1864CD78-30F1-4E42-A7AF-47F37F698D6C'	--	type	tipo de objeto
							--	'89076C64-8A5F-4A58-A0D1-9F016C5BC87D'	--	value	valor del objeto

				,@PAR5 = 'especifica la URL de la p�gina a la que va el enlace' 	--	Valor que tiene la propiedad [CodObjPropValor].

				,@PAR6 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'		--	HAB		habilitado 	-- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
				--		-- Caso Alta:
				--			-- Es un c�digo ID con las distintas opciones, estas pueden ser. Habilitado, Deshabilitado, Eliminado.
							-- Ejecute esta consulta y estar�n los estados disponibles. Los mismos son para todo el sistema por eso es multiempresa
--							DECLARE	@return_value int
--							EXEC	@return_value = [dbo].[CDiccPCodxIdio] 
--									@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--									,@PAR2 = '6B0CD910-C127-4450-9865-15E9F4C287B4'		-- AmbitoApicaci�n EST	estados
--									,@PAR3 = 'A5E49ED6-EFDD-4C43-955F-7F3616E39F99'		-- multiempresa	se aplica para los c�digos generales del sistema
										-- 'EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0'	--		DES		deshabilitado
										-- '3749D6D8-EF8F-4C37-893A-BE7209239810'	--		ELI		eliminado
										-- 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'	--		HAB		habilitado

				,@PAR7 = 'E2501954-E494-40E8-BC6F-EC5ABD9945C8'		--	opcional		propiedad opcional
					-- [IDFkCDiccTCod_PropTipo]	-- Define si la propiedad es o no Obligatoria 
					-- Valores Disponibles
						--	F88BE042-527E-4FC1-A2EC-88572D3BA5C3		CIntfPropTipo	tabla con los tipos de propiedades, si la misma es obligatoria y opcional.
						--	'CC9699C0-B646-427E-B545-7AAFB23D5B95'		--	obligatoria		propiedad obligatoria
							-- Usualmente se utiliza para los TagOpen, TagClose
						--	'E2501954-E494-40E8-BC6F-EC5ABD9945C8'		--	opcional		propiedad opcional

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- #################################################################################################################################

		-- Info de los Elementos HTML que forman parte de las paginas web
		-- aqu� esta el detalle de los elementos ingresados
--			DECLARE	@return_value int
			EXEC	@return_value = [dbo].[CIntfPObjConProp]
						@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
						,@PAR2 = @PARint2				-- ID c�digo del Elemento / Objeto al que se aplicar� la propiedad [IDFkTCIntfTObjCod_ObjCod]		

--
--
---- Todos los Elementos y sus propiedades
--	DECLARE	@return_value int
--	EXEC	@return_value = [dbo].[CIntfPObjConProp]
--				@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--
--	DECLARE	@return_value int
--	EXEC	@return_value = [dbo].[CIntfPObjConPropResu]
--			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
