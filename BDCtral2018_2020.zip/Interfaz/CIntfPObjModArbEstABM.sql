-- #########################################################################################################################################################
--  GENERA EL PROCEDIMIENTO ALMACENADO PARA CARGAR LA TABLA [CIntfTObjModArbEst]
--	en esta Tabla esta el resultado final de la estructura Web sin las propiedades
-- #########################################################################################################################################################

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- Determina la base de datos donde se trabajar�
USE [BDCtral]
GO

		--	SELECT * FROM [BDCtral].[dbo].[CIntfTObjModArbEst]
-- ===============================================================================================================
-- Author:		Juan Carlos Petri
-- Create date: 12/12/2018
-- Description: Ejecjta el procedimiento almacenado EXEC @return_value = [dbo].[CintfPObjModBucleID] 
-- hay que definir dos variables: Idioma y Padre ID
-- ===============================================================================================================

ALTER PROCEDURE [dbo].[CIntfTObjModArbEstABM]
	@PAR1 AS VARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 AS VARCHAR(36) = NULL										-- ID del Padre
AS
BEGIN

	DECLARE	@return_value int
	DECLARE @PARAmbAplic NVARCHAR(50)		-- Ambito de Aplicaci�n elegido o por defecto = NULL
	SET @PARAmbAplic = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	-- Ambito de Aplicaci�n Objetos Modelos

-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
--	DECLARE @PAR1 NVARCHAR(50) 				-- Idioma elegido o por defecto = espa�ol
--	DECLARE @PAR2 NVARCHAR(50) 				-- ID del Padre
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR2 = ''		-- ID del Padre
--		-- Para ver los ID del Padre, ejecutar la siguiente consulta
----		EXEC @return_value = [dbo].[CIntfPCodxIdio]	@PAR1 = @PAR1, @PAR2 = @PARAmbAplic
--		-- Aqu� se elige el Padre que se va a mostrar, toda la estructura
--			--	5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D	EncPag001	encabezado de la p�gina
--			--	57504A29-9F06-41B2-896C-81D5A57E37BF	EstWeb001	Estructura de la p�gina Web hasta el Body
--			--	B890DD58-58BA-4DA3-8A0C-70422298A88D	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
--			--	6EFA0E33-F537-4861-A35F-10ECB328FB74	PiePag001	pie de la p�gina

-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-- Detalle la Estructura de los Objetos Modelos disponibles, para el modulo Central Interfaz Objetos
-- No muestra el ID Padre, ya que como este no tiene propiedades [CIntfTObjModProp], Este ID Padre esta en la tabla [CIntfTObjCod] y [CIntfTObjCodxIdio]
	DECLARE @TempObjModBucleID TABLE
		(
			[EstOrd] [bigint] NULL,
			[ArbolID] [uniqueidentifier] NULL,
			[ArbolDesc] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[ArbPadreID] [uniqueidentifier] NULL,
			[IDFkCIntfTObjModArb] [uniqueidentifier] NOT NULL,
			[ArbolNivel] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[IDFkCIntfTObjCod] [uniqueidentifier] NULL,
			[IntfTObjCod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[IDFkCIntfTObjMod] [uniqueidentifier] NULL,
			[ObjModCodUnico] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[ObjModCodDescFuncion] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
			[ArbItemNivel] [smallint] NULL,
			[ArbItemOrd] [smallint] NULL,
			[IDTagOpen] [varchar](36) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[TagOpen] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[IDTagClose] [varchar](36) COLLATE Modern_Spanish_CI_AS NOT NULL,
			[TagClose] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL
		)

	DECLARE @PARPadreID AS VARCHAR(36)
	SET @PARPadreID = '5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D'			-- ID del Padre que a trabajar, este es el ID de la p�gina a agregar
	-- Valores surgen de la Consulta 01

	INSERT INTO @TempObjModBucleID EXEC @return_value = [dbo].[CintfPObjModBucleID] 
			@PAR1 = @PAR2		-- @PARPadreID					-- ID de la Tabla [CIntfTObjCod], la descripci�n est� en la tabla [CIntfTObjCodxIdio].
			, @PAR2 = @PAR1						-- Idioma elegido o por defecto = espa�ol
			, @PAR3 = @PARAmbAplic				-- Ambito de Aplicaci�n Objetos Modelos
--		SELECT * FROM @TempObjModBucleID
		-- NO estan sus propiedades.

-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-- Ahora inserta en la Tabla [CIntfTObjModArbWeb], la estructura Web. Solo los ID, no inserta la descripci�n y/o contenido
	-- Elimina la estructura que se va a insertar luego
	DELETE FROM [BDCtral].[dbo].[CIntfTObjModArbEst]
		  WHERE [ArbolID] = @PARPadreID
	
	-- Inserta la estructura completa del Padre - No tiene las propiedades
	INSERT INTO [BDCtral].[dbo].[CIntfTObjModArbEst]
			   ([EstOrd]
			   ,[ArbolID]
			   ,[ArbolDesc]
			   ,[ArbPadreID]
			   ,[IDFkCIntfTObjModArb]
			   ,[ArbolNivel]
			   ,[IDFkCIntfTObjCod]
			   ,[IntfTObjCod]
			   ,[IDFkCIntfTObjMod]
			   ,[ObjModCodUnico]
			   ,[ObjModCodDescFuncion]
			   ,[ArbItemNivel]
			   ,[ArbItemOrd]
			   ,[IDFkCIntfTObjCod_TagOpen]
			   ,[TagOpenCod]
			   ,[IDFkCIntfTObjCod_TagClose]
			   ,[TagCloseCod])
			SELECT [EstOrd]
					,[ArbolID]
					,[ArbolDesc]
					,[ArbPadreID]
					,[IDFkCIntfTObjModArb]
					,[ArbolNivel]
					,[IDFkCIntfTObjCod]
					,[IntfTObjCod]
					,[IDFkCIntfTObjMod]
					,[ObjModCodUnico]
					,[ObjModCodDescFuncion]
					,[ArbItemNivel]
					,[ArbItemOrd]
					,[IDTagOpen]
					,[TagOpen]
					,[IDTagClose]
					,[TagClose]
			FROM @TempObjModBucleID
END


-- #########################################################################################################################################################
--  GENERA EL PROCEDIMIENTO ALMACENADO PARA CARGAR LA TABLA [CIntfTObjModArbEst]
--	en esta Tabla esta el resultado final de la estructura Web sin las propiedades
-- DECLARE	@return_value int
-- EXEC @return_value = [dbo].[CIntfTObjModArbEstABM] 
--		@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--		,@PAR2 = '5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D'	--	EncPag001	encabezado de la p�gina
-- Ejemplos Padres ID
--		-- Para ver los ID del Padre, ejecutar la siguiente consulta
----		EXEC @return_value = [dbo].[CIntfPCodxIdio]	@PAR1 = @PAR1, @PAR2 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	-- Ambito de Aplicaci�n Objetos Modelos
--		-- Aqu� se elige el Padre que se va a mostrar, toda la estructura
--			--	'5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D'	--	EncPag001	encabezado de la p�gina
--			--	'57504A29-9F06-41B2-896C-81D5A57E37BF'	--	EstWeb001	Estructura de la p�gina Web hasta el Body
--			--	'B890DD58-58BA-4DA3-8A0C-70422298A88D'	--	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
--			--	'6EFA0E33-F537-4861-A35F-10ECB328FB74'	--	PiePag001	pie de la p�gina
