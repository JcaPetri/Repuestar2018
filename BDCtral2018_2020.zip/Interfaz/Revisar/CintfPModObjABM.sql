-- #########################################################################################################################################################
--  GENERA LOS PROCEDIMIENTOS ALMACENADOS PARA HACER EL ALTA, MODIFICACION, BAJA O RECUPERO DE LOS OBJETOS CODIGOS PROPIEDADES DE LA INTERFAZ DE USUARIOS -- 

---- ################################################################################################################################
---- Trabaja con la tabla [CIntfTObjCod] y [CintfTObjCodProp]
---- arma la estructura de los objetos (Paginas, Elementos, Propiedades, Estilos, Metodos, Funciones)
---- estas Tablas no tienen los valores del usuario, sino conforman como es el objeto predeterminado.
---- ################################################################################################################################

USE [BDCtral]
GO

-- Ambitos de aplicaci�n donde est�n cargados los Elemento, Estilos y Propiedades.
--DECLARE	@return_value int
--EXEC	@return_value = [dbo].[CIntfPAmbAplic]

--	ABEDD291-3991-4A47-8AEB-82580BF6BA8C	Css		contiene todos los estilos posibles de la pagina y los elementos
--	AEFEA6F0-CC81-41AB-AD12-354A484273DA	Ele		contiene los elementos de la pagina
--	9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B	Pro		contiene las propiedades de la pagina, elementos y estilos

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO

DECLARE	@return_value int

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Variables para realizar al ABM, se debe:
	-- Variables Etapa 1
	DECLARE @PAR1 AS VARCHAR(50)	-- Determina acci�na realizar 
		-- valores posibles: ALTA - MODIFICACION - BAJA - RECUPERO
		-- Como estos valores son para todas las tablas e idiomas unicos siempre van los mismos
	DECLARE @PAR2 AS VARCHAR(36)	-- ID -- valor ID, debe ser �nico.
		-- Caso Alta: valor nuevo se genera con el NewID()
			-- este valor es el ID unico de la combinaci�n del Objeto = [IDFkTObjCod] y la Propiedad =[IDFkTCodObjProp].
		-- Caso Modificaci�n: 

	DECLARE @PAR3 AS VARCHAR(50)		-- IDFkTObjCod -- codigo ID del Objeto (Elemento o Estilo) al que se le asignara la propiedad.
		-- Caso Alta: 
--			DECLARE	@return_value int
--			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'AEFEA6F0-CC81-41AB-AD12-354A484273DA'		-- Ambito Aplicaci�n Elemento
--			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'ABEDD291-3991-4A47-8AEB-82580BF6BA8C'		-- Ambito Aplicaci�n Estilos
		-- Caso Modificaci�n:

	DECLARE @PAR4 AS VARCHAR(250)		-- IDFkTCodObjProp -- codigo ID de la propiedad que se le asigna al Objeto (Elemento o Estilo).
		-- Caso Alta: 
--			DECLARE	@return_value int
--			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B'		-- Ambito Aplicaci�n Propiedad

		-- Caso Modificaci�n: 

	DECLARE @PAR5 AS VARCHAR(250) 		-- CodObjPropValor -- Valor que tiene la Propiedad para ese Objeto
		-- Caso Alta:
			-- Este valor es �nico para el independiente del Idioma, ya que es lo que se lee en los script del servlet de java.
		-- Caso Modificaci�n:

	DECLARE @PAR6 AS INT 				-- CodObjPropOrden -- Es el orden en que se leen las propiedades del objeto. Esto sirve para armar en el Servlet el Tag.
		-- Caso Alta:
			-- Por defecto se hace un orden ascendente para cada objeto. Escepto el �ltimo elemento que cierra el Tag, que tiene valor de 999.
		-- Caso Modificaci�n:
			-- Se modifica el orden, el resto de los elementos se organizan nuevamente para mantener un correcto orden cronologico.

	DECLARE @PAR7 AS VARCHAR(36) 			-- IDFkObjCodEstados -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
		-- Caso Alta:
			-- Es un c�digo ID con las distintas opciones, estas pueden ser. Habilitado, Deshabilitado, Eliminado.
				-- 6B0CD910-C127-4450-9865-15E9F4C287B4	EST	estados			EST	estados
					-- EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0	DES	deshabilitado	EST	estados
					-- 3749D6D8-EF8F-4C37-893A-BE7209239810	ELI	eliminado		EST	estados
					-- C6FE2749-0CB8-49CD-97DF-03C299C0C6CF	HAB	habilitado		EST	estados
		-- Caso Modificaci�n:
			-- Se cambia el estado sin realizar verificaciones. en caso de que se recupere el c�digo, se debe verificar que no se infrinjan las reglas primarias.


	-- Variables para obtener los valores del procedimiento almacenado de CGetErrorInfo
		DECLARE @RTADO_PROCALM AS VARCHAR(250)
		DECLARE @NOMB_PROCALM AS VARCHAR(250)
		DECLARE @FUNC_PROCALM AS VARCHAR(100)
		DECLARE @RTADO AS VARCHAR(250)
		DECLARE @REG_AFEC AS NUMERIC(18, 0)
		DECLARE @ERR_MESSAGE AS VARCHAR(250)
		DECLARE @ERR_NUMBER AS NUMERIC(18, 0)
		DECLARE @ERR_SEVERITY AS NUMERIC(18, 0)
		DECLARE @ERR_STATE AS NUMERIC(18, 0)
		DECLARE @ERR_LINE AS NUMERIC(18, 0)
		
		SET @NOMB_PROCALM = 'CintfPObjCodPropABM'				-- Nombre del procedimiento almacenado.

-- Valores de las variables para generar las prueba del funcionamiento de las consultas.
--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- SETEO DE LAS VARIABLES PARA EL ALTA DE UN CODIGO Y SUS DESCRIPCIONES
		SET @PAR1 = 'ALTA'													-- ALTA - MODIFICACION - BAJA - RECUPERO
		SET @PAR2 = NEWID()													-- ID -- valor ID, debe ser �nico.
		SET @PAR3 = '5CE0D99D-230B-4C90-A5FF-C3FD6D37F095'					-- IDFkTObjCod -- codigo ID del Objeto (Elemento o Estilo) al que se le asignara la propiedad.
--			DECLARE	@return_value int
--			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'AEFEA6F0-CC81-41AB-AD12-354A484273DA'		-- Ambito Aplicaci�n Elemento
--			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'ABEDD291-3991-4A47-8AEB-82580BF6BA8C'		-- Ambito Aplicaci�n Estilos

		SET @PAR4 = 'E518F810-1670-4361-87CB-E121419E7DC4'					-- IDFkTCodObjProp -- codigo ID de la propiedad que se le asigna al Objeto (Elemento o Estilo).
--			DECLARE	@return_value int
--			EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B'		-- Ambito Aplicaci�n Propiedad

			--	D46E782C-80AC-4162-BDAB-94766A18FE78	tagopen	abre el tag
			--	622279E9-F399-4785-BF59-9AEB09E421BF	texttag	texto que va entre los tags

		SET @PAR5 = 'url archivo'										-- CodObjPropValor -- Valor que tiene la Propiedad para ese Objeto
		
		-- CodObjPropOrden -- Es el orden en que se leen las propiedades del objeto. Esto sirve para armar en el Servlet el Tag.
		SELECT @PAR6 = CASE WHEN [CodObjPropOrden] IS NULL THEN 0 ELSE [CodObjPropOrden] END + 1 			-- Orden en que se ejecutan las acciones
		  FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK) 
		WHERE [IDFkTObjCod] = @PAR3 AND [CodObjPropOrden] < 999

		SET @PAR6 = CASE WHEN @PAR6 IS NULL THEN 1 ELSE @PAR6 END
		
		SET @PAR6 = CASE WHEN LEFT(@PAR5,2) = '</' THEN 999 ELSE @PAR6 END

		SET @PAR7 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'		-- IDFkObjCodEstados -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado

--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	-- SETEO DE LAS VARIABLES PARA LA MODIFICACION DE UN CODIGO Y SUS DESCRIPCIONES
--		SET @PAR1 = 'MODIFICACION'											-- ALTA - MODIFICACION - BAJA - RECUPERO
--		SET @PAR2 = 'ABE14F0E-8DF7-4492-9DB9-77199807D80A'					-- ID del codigo, debe ser �nico
--		SET @PAR3 = 'FB478ECC-85FE-4FC8-B792-CAF8ECB921B1'					-- ID del Idioma	-- Espa�ol		
--		SET @PAR4 = '528CEED9-D2B3-4CB5-8116-01BDAD455C83'					-- ID del Ambito de Aplicaci�n del C�digo -- Usuarios	
--		SET @PAR5 = 'PPVTGTIA'													-- C�digo, debe ser �nico
--		SET @PAR6 = 'personal postventa garantia'												-- Descripcion del codigo
--		SET @PAR7 = 'c6fe2749-0cb8-49cd-97df-03c299c0c6cf'					-- Habilitado
--		SET @PAR9 = 'AltaCompleto'

---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- Valores de las variables para agregarle al codigo ID, solo el Codigo por Idioma nuevo. No agrega el cogido porque ya existe para un idioma.
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	-- SETEO DE LAS VARIABLES PARA EL ALTA DE UN CODIGO Y SUS DESCRIPCIONES
--		SET @PAR1 = 'ALTA'												-- ALTA - MODIFICACION - BAJA - RECUPERO
--		SET @PAR2 = '3749D6D8-EF8F-4C37-893A-BE7209239810'					-- ID del codigo, este ya es un codigo generado
--		SET @PAR3 = 'b1268278-4eb3-4a93-8f67-0d425b767c65'					-- ID del Idioma
----				ee954f5d-ca27-48a9-a23b-010788b18631	ITA	italiano
----				b1268278-4eb3-4a93-8f67-0d425b767c65	ENG	english
----				a455281d-76f5-4bad-8dbb-201c5928aaf8	FRA	fran�ais
----				1048c13b-1cc9-4154-8b8b-64ca9ac9fe12	POR	portugu�s
----				fb478ecc-85fe-4fc8-b792-caf8ecb921b1	ESP	espa�ol
--		SET @PAR4 = '6B0CD910-C127-4450-9865-15E9F4C287B4'					-- ID del Ambito de Aplicaci�n del C�digo -- Usuarios	
--		SET @PAR5 = 'REM'													-- C�digo, debe ser �nico
--		SET @PAR6 = 'removed'													-- Descripcion del codigo
--		SET @PAR7 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'					-- Habilitado
--		SET @PAR9 = 'SoloCodxIdio'
--
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- Pasos antes de hacer ABM de los datos:
	-- Etapa 1: Primero verificar que con el cambio no se infrinja ninguna clave primaria
	-- Etapa 2: 
			-- 1: Si el resultado es que se infrinje, no realizar el cambio e informar al usuario
			-- 2: Si es todo OK, se realiza el cambio. Para hacer esto se hace una transacci�n para asegurar la integridad del cambio.	

IF @PAR1 = 'ALTA'
BEGIN
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- ##############################################################################################################################################
	-- INICIO -- ALTA DE CODIGO Y SUS DESCRIPCIONES
	-- ##############################################################################################################################################
	
	SET @FUNC_PROCALM = 'Alta'		-- Funcion dentro del procedimiento almacenado.

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Para agregar un nuevo C�digo, se debe:
		-- Clave Primaria: IDC�digo [IDFkTIntCodigos], IDIdiomas [IDFkTIdioma], IDAmbitoAplicaci�n [IDFkTCodAmbAplic], C�digo Unico [Codigo]
		-- Los otros campos pueden tener cualquier valor, no se validan.

		-- Aclaraci�n: La combinaci�n m�s ID del Ambito de Aplicaci�n, por lo tanto para un idioma, puede haber dos c�digos iguales, pero cada uno para un ambito de aplicaci�n diferente.

	-- Etapa 1: Verifica Clave Primaria: que el objeto creado puede tener solamente una propiedad una sola vez
		-- Si alguno de los valores son encontrados, la variable @PAR2 se pone a NULL
		SELECT @PAR2 = NULL
		  FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK)
		WHERE [IDFkTObjCod] = @PAR3 AND [IDFkTCodObjProp] = @PAR4
			-- Clave Primaria: -- IDFkTObjCod, IDFkTCodObjProp.
		--		SELECT @PAR2

	-- Etapa 2: 
			-- 1: Si el C�digo infringe la clave primaria, no hace el cambio e informa al usuario
		IF @PAR2 IS NULL
			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			BEGIN
				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
				SET @RTADO = 'ERR' 
				SET @REG_AFEC = 0
				SET @ERR_MESSAGE = 'El Objeto ingresado ya tiene asignado esa propiedad.'
				SET @ERR_NUMBER = 0
				SET @ERR_SEVERITY = 0
				SET @ERR_STATE = 0
				SET @ERR_LINE = 0
			END
		ELSE
			-- 2: Si es todo OK, se realiza el cambio.
			BEGIN TRY
			BEGIN TRANSACTION;
			-- Inserta el codigo en las tablas. 
				
				-- PRIMERO en la tabla [CintfTObjCodProp]
				BEGIN
					INSERT INTO [BDCtral].[dbo].[CintfTObjCodProp]
							   ([ID]
							   ,[IDFkTObjCod]
							   ,[IDFkTCodObjProp]
							   ,[CodObjPropValor]
							   ,[CodObjPropOrden]
							   ,[IDFkCxIEstados]
							   ,[TObjCodProFechaModif])
						 SELECT @PAR2		-- [BDCtral]				-- valor ID, debe ser �nico.
								,@PAR3		-- [IDFkTObjCod]			-- codigo ID del Objeto (Elemento o Estilo) al que se le asignara la propiedad.
								,@PAR4		-- [IDFkTCodObjProp]		-- codigo ID de la propiedad que se le asigna al Objeto (Elemento o Estilo).
								,@PAR5		-- [CodObjPropValor]		-- Valor que tiene la Propiedad para ese Objeto
								,@PAR6		-- [CodObjPropOrden]		-- Es el orden en que se leen las propiedades del objeto. Esto sirve para armar en el Servlet el Tag.
								,@PAR7		-- [IDFkCxIEstados]			-- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
								,GETDATE()	-- [TObjCodProFechaModif]
				END
				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
				BEGIN
					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
					SET @RTADO = 'OK' 
					SET @REG_AFEC = 1
					SET @ERR_MESSAGE = 'Se cargo la informacion solicitada.'
					SET @ERR_NUMBER = 0
					SET @ERR_SEVERITY = 0
					SET @ERR_STATE = 0
					SET @ERR_LINE = 0
				END
			
				-- Si el procedimiento es exitoso, confirma la operaci�n.
				COMMIT TRANSACTION;
			END TRY
			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
			BEGIN CATCH

				-- Ejecuta el Procedimiento Almacenado para obtener el error.
				EXECUTE [dbo].[CGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT

				-- Como la operaci�n fall�, se deshacen las modificaciones.
				ROLLBACK TRANSACTION;

				-- Por las dudas se elimana el registro con el ID generado.
				DELETE FROM [BDCtral].[dbo].[CintfTObjCodProp] WHERE [ID] = @PAR2

				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				SET @RTADO = 'ERR'
				SET @REG_AFEC = 0
			END CATCH;

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- ##############################################################################################################################################
	-- FINAL -- ALTA DE CODIGO Y SUS DESCRIPCIONES
	-- ##############################################################################################################################################
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
END


ELSE 
IF @PAR1 = 'MODIFICACION'
BEGIN
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- INICIO	-- MODIFICACION DE CODIGO Y SUS DESCRIPCIONES
-- ##############################################################################################################################################
	
	SET @FUNC_PROCALM = 'Modificacion'		-- Funcion dentro del procedimiento almacenado.

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Para modificar un nuevo C�digo, se debe:
		-- Clave Primaria: IDC�digo [IDFkTIntCodigos], IDIdiomas [IDFkTIdioma], IDAmbitoAplicaci�n [IDFkTCodAmbAplic], C�digo Unico [Codigo]
		-- Los otros campos pueden tener cualquier valor, no se validan.

		-- Aclaraci�n: La combinaci�n m�s ID del Ambito de Aplicaci�n, por lo tanto para un idioma, puede haber dos c�digos iguales, pero cada uno para un ambito de aplicaci�n diferente.

	-- Etapa 1: Verifica Clave Primaria: que el objeto creado puede tener solamente una propiedad una sola vez
		-- Si alguno de los valores son encontrados, la variable @PAR2 se pone a NULL
		SELECT @PAR2 = NULL
		  FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK)
		WHERE [IDFkTObjCod] = @PAR3 AND [IDFkTCodObjProp] = @PAR4
			-- Clave Primaria: -- IDFkTObjCod, IDFkTCodObjProp.
		--		SELECT @PAR2

	-- Etapa 2: 
			-- Si el codigo ya esta utilizado, infrinje la clave primaria, no hace los cambios e informa al usuario.
		IF @PAR2 IS NULL
			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			BEGIN
				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
				SET @RTADO = 'ERR' 
				SET @REG_AFEC = 0
				SET @ERR_MESSAGE = 'El Objeto ingresado ya tiene asignado esa propiedad.'
				SET @ERR_NUMBER = 0
				SET @ERR_SEVERITY = 0
				SET @ERR_STATE = 0
				SET @ERR_LINE = 0
			END
		ELSE
			-- 2: Si es todo OK, se realiza el cambio.
			BEGIN TRY
			BEGIN TRANSACTION;
				-- Modifica el codigo en la tabla. Le puede cambiar el idioma, ambito de aplicacion, el codigo, su descripcion y el estado.
				UPDATE [BDCtral].[dbo].[CintfTObjCodProp]
				   SET [IDFkTObjCod] = @PAR3
					  ,[IDFkTCodObjProp] = @PAR4
					  ,[CodObjPropValor] = @PAR5
					  ,[CodObjPropOrden] = @PAR6
					  ,[IDFkCxIEstados] = @PAR7
					  ,[TObjCodProFechaModif] = GETDATE()
				 WHERE [ID] = @PAR2

				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
				BEGIN
					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
					SET @RTADO = 'OK' 
					SET @REG_AFEC = 1
					SET @ERR_MESSAGE = 'Se modific� la informacion solicitada.'
					SET @ERR_NUMBER = 0
					SET @ERR_SEVERITY = 0
					SET @ERR_STATE = 0
					SET @ERR_LINE = 0
				END
			
				-- Si el procedimiento es exitoso, confirma la operaci�n.
				COMMIT TRANSACTION;
			END TRY
			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
			BEGIN CATCH

				-- Ejecuta el Procedimiento Almacenado para obtener el error.
				EXECUTE [dbo].[CGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT

				-- Como la operaci�n fall�, se deshacen las modificaciones.
				ROLLBACK TRANSACTION;

				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				SET @RTADO = 'ERR'
				SET @REG_AFEC = 0
			END CATCH;

-- ##############################################################################################################################################
-- FINAL	-- MODIFICACION DE CODIGO Y SUS DESCRIPCIONES
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
END

ELSE
IF @PAR1 = 'BAJA'
BEGIN
-- ##############################################################################################################################################
-- INICIO	-- BAJA DE CODIGO Y SUS DESCRIPCIONES
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	SET @FUNC_PROCALM = 'Baja'		-- Funcion dentro del procedimiento almacenado.

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Para dar de baja un C�digo, se debe:
		-- Cambiar solo el estado. No se elimina ya que puede afectar las relaciones asociadas.
	-- Etapa 1: verifica que el codigo ya no est� dado de baja.
		SELECT @PAR2 = NULL		-- Si alguno de los valores son encontrados, la variable @PAR2 se pone a NULL
		  FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK)
		WHERE [IDFkCxIEstados] = '3749D6D8-EF8F-4C37-893A-BE7209239810'		-- ELI	eliminado		EST	estados
		-- Si encuentra el registro quiere decir que el c�digo ya esta dado de baja.
		--		SELECT @PAR2

	-- Etapa 2: 
			-- 1: Si el codigo ya esta dado de baja, no hace nada, solo le informa al usuario.
		IF @PAR2 IS NULL
			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			BEGIN
				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
				SET @RTADO = 'ERR' 
				SET @REG_AFEC = 0
				SET @ERR_MESSAGE = 'El c�digo ingresado ya esta dado de baja.'
				SET @ERR_NUMBER = 0
				SET @ERR_SEVERITY = 0
				SET @ERR_STATE = 0
				SET @ERR_LINE = 0
			END
		ELSE
			-- 2: El c�digo esta para darle de baja, procede a hacerlo.
			BEGIN TRY
			BEGIN TRANSACTION;
				-- Elimina el codigo en la tabla. Para ello le agrega la leyenda '-ELI', si supera la cantidad de d�gitos permitidos del campo, le reduce el c�digo original.
				-- el c�digo no se elimina, pero al ponerle -ELI, el codigo anterior se puede usar nuevamente
				UPDATE [BDCtral].[dbo].[CintfTObjCodProp]
				   SET [CodObjPropValor] = CASE WHEN LEN ([CodObjPropValor] + '-ELI') >= 54 THEN (SUBSTRING([CodObjPropValor], 1, 50) + '-ELI') ELSE [CodObjPropValor] + '-ELI' END			-- Le pone la leyenda que el c�digo esta eliminado.
						,[IDFkCxIEstados] = @PAR7			-- Le pone el estado de eliminado.
				WHERE [ID] = @PAR2

				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
				BEGIN
					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
					SET @RTADO = 'OK' 
					SET @REG_AFEC = 1
					SET @ERR_MESSAGE = 'Se elimin� el c�digo indicado.'
					SET @ERR_NUMBER = 0
					SET @ERR_SEVERITY = 0
					SET @ERR_STATE = 0
					SET @ERR_LINE = 0
				END
			
				-- Si el procedimiento es exitoso, confirma la operaci�n.
				COMMIT TRANSACTION;
			END TRY
			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
			BEGIN CATCH
				-- Ejecuta el Procedimiento Almacenado para obtener el error.
				EXECUTE [dbo].[CGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT

				-- Como la operaci�n fall�, se deshacen las modificaciones.
				ROLLBACK TRANSACTION;

				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				SET @RTADO = 'ERR'
				SET @REG_AFEC = 0
			END CATCH;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- FINAL	-- BAJA DE CODIGO Y SUS DESCRIPCIONES
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
END

ELSE
IF @PAR1 = 'RECUPERO'
BEGIN
-- ##############################################################################################################################################
-- INICIO	-- RECUPERO DE CODIGO Y SUS DESCRIPCIONES
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	SET @FUNC_PROCALM = 'Recupero'		-- Funcion dentro del procedimiento almacenado.

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Para recuperar un C�digo, se debe:
		-- Cambiar solo el estado. Ya que no se elimina, solo se debe verificar que ese c�digo que vuelve a funcionar, 
		-- no est� utilizado y por ende infrinja la regla primaria.
		-- Clave Primaria: IDC�digo [IDFkTIntCodigos], IDIdiomas [IDFkTIdioma], IDAmbitoAplicaci�n [IDFkTCodAmbAplic], C�digo Unico [Codigo]
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	-- Etapa 1: verifica que el codigo est� dado de baja, si no es as� le informa al usuario.
		SELECT @PAR2 = NULL		-- Si alguno de los valores son encontrados, la variable @PAR2 se pone a NULL
		  FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK)
		WHERE [ID] = @PAR2													-- ID del c�digo.
				AND [IDFkCxIEstados] <> '3749D6D8-EF8F-4C37-893A-BE7209239810'			-- Estado Eliminado
		--		SELECT @PAR2

		-- Etapa 2: 
				-- 1: Si el codigo NO esta dado de baja, no hace nada y le informa al usuario.
		IF @PAR2 IS NULL
			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			BEGIN
				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
				SET @RTADO = 'ERR' 
				SET @REG_AFEC = 0
				SET @ERR_MESSAGE = 'El c�digo ingresado no est� dado de baja.'
				SET @ERR_NUMBER = 0
				SET @ERR_SEVERITY = 0
				SET @ERR_STATE = 0
				SET @ERR_LINE = 0
			END
		ELSE

		-- Etapa 3: Ya sabemos que el c�digo esta dado de baja. Verificamos que no infrinja la clave primaria.
				-- Clave Primaria: IDC�digo [IDFkTIntCodigos], IDIdiomas [IDFkTIdioma], IDAmbitoAplicaci�n [IDFkTCodAmbAplic], C�digo Unico [Codigo]
		-- Aclaraci�n:
				-- Ahora verificamos si el valor que tiene el c�digo, fue utilizado por alg�n c�digo activo.
				-- Si el c�digo esta repetido, le agrega la palabra 'REC-' valor ID, y si no tiene espacio, le reduce el c�digo original. De esta manera no se duplica nunca el c�digo.
				-- el usuario luego debe modificar el c�digo indicado.
		SELECT @PAR5 = NULL
		  FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK)
		WHERE [IDFkTObjCod] = @PAR3 AND [IDFkTCodObjProp] = @PAR4		-- Primero verifica que no se infrinja la clave primaria: C�digoID - Idioma - Ambito Aplicacion - C�digo
		-- Si el codigo ya esta utilizado agrega el c�digo m�s una leyenda de 4 caracteres y le cambia el estado a habilitado.
		--		SELECT @PAR5

		-- Etapa 4: Si el codigo ya esta utilizado, Verifica el OK con el c�digo modificado
		IF @PAR5 IS NULL
			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			BEGIN
				-- Como el c�digo ya esta utilizado, le pone el ID al C�digo para que no haya forma de duplicidad.
				SELECT @PAR5 = SUBSTRING([IDFkTObjCod], 1, 18) + @PAR2
					FROM [BDCtral].[dbo].[CintfTObjCodProp] WITH(NOLOCK)
				WHERE [ID] <> @PAR2
				GOTO HaceCambio
				-- Ya le realizo a la variable que tiene el c�digo, ahora lo implementa en la transacci�n.
			END
		ELSE
HaceCambio:
			BEGIN TRY
			BEGIN TRANSACTION;
				-- Modifica el codigo en la tabla. Le puede cambiar el idioma, ambito de aplicacion, el codigo, su descripcion y el estado.

				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
				BEGIN
					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
					SET @RTADO = 'OK' 
					SET @REG_AFEC = 1
					SET @ERR_MESSAGE = 'Se recuper� el c�digo indicado.'
					SET @ERR_NUMBER = 0
					SET @ERR_SEVERITY = 0
					SET @ERR_STATE = 0
					SET @ERR_LINE = 0
				END
			
				-- Si el procedimiento es exitoso, confirma la operaci�n.
				COMMIT TRANSACTION;
			END TRY
			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
			BEGIN CATCH

				-- Ejecuta el Procedimiento Almacenado para obtener el error.
				EXECUTE [dbo].[CGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT

				-- Como la operaci�n fall�, se deshacen las modificaciones.
				ROLLBACK TRANSACTION;

				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				SET @RTADO = 'ERR'
				SET @REG_AFEC = 0
			END CATCH;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- FINAL	-- RECUPERO DE CODIGO Y SUS DESCRIPCIONES
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
END


-- ##############################################################################################################################################
-- MUESTRA EL RESULTADO DEL PROCEDIMIENTO ALMACENADO
-- Envia el resultado: Nombre Proc Alm | Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
--SET @RTADO_PROCALM = @NOMB_PROCALM + '|' + @FUNC_PROCALM + '|' + @RTADO + '|' + CAST(@REG_AFEC AS VARCHAR(10)) + '|' + @ERR_MESSAGE + '|' + CAST(@ERR_NUMBER AS VARCHAR(10)) + '|' + CAST(@ERR_SEVERITY AS VARCHAR(10)) + '|' + CAST(@ERR_STATE AS VARCHAR(10)) + '|' + CAST(@ERR_LINE AS VARCHAR(10))
--SELECT @RTADO_PROCALM			-- Muestra el resulado en una unica columna
SELECT @NOMB_PROCALM AS ProcAlm_Nomb, @FUNC_PROCALM AS ProcAlm_Funcion, @RTADO AS ProcAlm_Rtado, @REG_AFEC AS ProcAlm_RegAfec, @ERR_MESSAGE AS ProcAlm_Mensaje, @ERR_NUMBER AS ProcAlm_ErrNum, @ERR_SEVERITY AS ProcAlm_ErrSeveridad, @ERR_STATE AS ProcAlm_ErrEstado, @ERR_LINE AS ProcAlm_ErrLinea

-- DECLARE	@return_value int
EXEC	@return_value = [dbo].[CIntfPObjYProp] @PAR3 = @PAR3

-- ##############################################################################################################################################^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- El GO va al final del procedimiento
GO
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################

