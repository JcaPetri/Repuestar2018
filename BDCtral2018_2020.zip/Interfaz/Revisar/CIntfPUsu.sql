--set ANSI_NULLS ON
--set QUOTED_IDENTIFIER ON
--go
--
--
---- =============================================
---- Author:		Juan Carlos Petri
---- Create date: 04/10/2017
---- Description:	Detalle de la Tabla CintPObjCod y CodxIdio, para el idioma elegido o el por defecto = espa�ol
---- =============================================
--ALTER PROCEDURE [dbo].[CIntfPUsu]
--	-- Add the parameters for the stored procedure here
--	@PAR1 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	,@PAR2 NVARCHAR(50) = NULL										-- Ambito de Aplicaci�n elegido o por defecto = NULL
--	,@PAR3 NVARCHAR(50) = NULL										-- P�gina Elegida
--AS
--BEGIN

	DECLARE @PAR1 NVARCHAR(50)		-- Idioma elegido o por defecto = espa�ol
	DECLARE @PAR2 NVARCHAR(50) 		-- Ambito de Aplicaci�n elegido o por defecto = NULL
	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	SET @PAR2 = NULL										-- Ambito de Aplicaci�n elegido o por defecto = NULL

	DECLARE @PAR3 AS NVARCHAR(50)
	SET @PAR3 = 'pag001'

	DECLARE @PAR4 AS UNIQUEIDENTIFIER

	-- Determina el ID de la p�gina seleccionada
	SELECT @PAR4 = GIU1.[ID]
	  FROM [BDCtral].[dbo].[CIntfTUsuObj] AS GIU1 WITH(NOLOCK)
	WHERE GIU1.[IntUsuCodUnico] = @PAR3

--	SELECT @PAR4
	DECLARE @TmpIntfTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](55) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Descripcion] [varchar](255) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[AmbApliCodigo] [varchar](55) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[AmbApliDescripcion] [varchar](255) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[IDFkCxIEstados] [uniqueidentifier] NULL,
		[EstCodigo] [varchar](55) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[EstDescripcion] [varchar](255) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[CodIdioma] [varchar](55) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](255) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[TCodxIdioFechaModif] [datetime] NULL
	)
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO @TmpIntfTCodxIdi
		SELECT IfCxI.[IDFkTIntCodigos]
			  ,IfCxI.[Codigo]
			  ,IfCxI.[Descripcion]
			  ,IfCxI.[IDFkTCodAmbAplic]
			  ,IfCxI2.[Codigo] AS [AmbApliCodigo]
			  ,IfCxI2.[Descripcion] AS [AmbApliDescripcion]
			  ,IfCxI.[IDFkCxIEstados]
			  ,CxI.[Codigo] AS [EstCodigo]
			  ,CxI.[Descripcion] AS [EstDescripcion]
			  ,IfCxI.[IDFkTIdioma]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
			  ,IfCxI.[TCodxIdioFechaModif]
		  FROM [BDCtral].[dbo].[CIntfTObjCodxIdio] AS IfCxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON IfCxI.[IDFkTIdioma] = Idi.[ID]
							AND
						Idi.[ID] = @PAR1				-- Idioma elegido
				INNER JOIN [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK)
					ON IfCxI.[IDFkCxIEstados] = CxI.[IDFkTCodigos]
							AND
						CxI.IDFkTIdioma = @PAR1		-- Idioma elegido
				INNER JOIN [BDCtral].[dbo].[CIntfTObjCodxIdio] AS IfCxI2 WITH (NOLOCK) 
					ON IfCxI.[IDFkTCodAmbAplic] = IfCxI2.[IDFkTIntCodigos]
							AND
						IfCxI2.[IDFkTIdioma] = @PAR1		-- Idioma elegido
		WHERE IfCxI.[IDFkTCodAmbAplic] = CASE WHEN @PAR2 IS NULL THEN IfCxI.[IDFkTCodAmbAplic] ELSE @PAR2 END		-- Ambito de Aplicaci�n

		SELECT 
--			, UOP.[IDFkTIntfUsuObj] AS IDObj
			 ICxI1.[AmbApliCodigo] AS ObjTipo
			, ICxI1.[Codigo] AS ObjCod
			, ICxI1.[Descripcion] AS ObjDesc
--			, UOP.[IDFkTIntCodObjProp] AS IDProp
			, ICxI2.[AmbApliCodigo] AS PropTipo
			, ICxI2.[Codigo] AS PropCod
			, ICxI2.[Descripcion] AS PropDesc
			, UOP.[IntObjValor] AS PropVal
			, UOP.[IntObjOrden] AS PropOrd
			, ICxI3.[Codigo] AS PropUbic
--			, UO.[IntUsuCodUnico]
--		    , UO.[IntUsuDescFuncion]
--		    , UO.[IntUsuOrd]
		FROM [BDCtral].[dbo].[CIntfTUsuObjProp] AS UOP WITH (NOLOCK) 
			INNER JOIN @TmpIntfTCodxIdi AS ICxI1
				ON UOP.[IDFkTIntfUsuObj] = ICxI1.[IDFkTCodigos]
			INNER JOIN @TmpIntfTCodxIdi AS ICxI2
				ON UOP.[IDFkTIntCodObjProp] = ICxI2.[IDFkTCodigos]
			INNER JOIN [BDCtral].[dbo].[CIntfTObjCod] AS OC WITH (NOLOCK)
				ON UOP.[IDFkTIntfUsuObj] = OC.[ID]
					INNER JOIN @TmpIntfTCodxIdi AS ICxI3
						ON OC.[IDFkTCodObjUbic] = ICxI3.[IDFkTCodigos]
			INNER JOIN [BDCtral].[dbo].[CIntfTUsuObj] AS UO WITH (NOLOCK)
				ON UOP.[IDFkTIntfUsuObj] = UO.[ID]
--		WHERE UO.[IDFkTIntfObjPadre] = @PAR4
		ORDER BY ICxI1.[Codigo], UOP.[IntObjOrden]


--
--SELECT [ID]
--      ,[IDFkTIntfUsuObj]
--      ,[IDFkTIntCodObjProp]
--      ,[IntObjValor]
--      ,[IntObjOrden]
--  FROM [BDCtral].[dbo].[CIntfTUsuObjProp]
--WHERE [IDFkTIntfUsuObj] = 'B82F54D5-5831-4DD7-B4C6-BEC74DCAE180'
--
--SELECT [ID]
--      ,[IDFkTIntfObjPadre]
--      ,[IDFkTIntCodObj]
--      ,[IntUsuCodUnico]
--      ,[IntUsuDescFuncion]
--      ,[IntUsuOrd]
--  FROM [BDCtral].[dbo].[CIntfTUsuObj]

--END

