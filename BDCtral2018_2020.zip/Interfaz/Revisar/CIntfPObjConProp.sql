set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO
-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 03/10/2018
-- Description:	Detalle de los c�digos ID, para el idioma elegido o el por defecto = espa�ol
-- =============================================
ALTER PROCEDURE [dbo].[CIntfPObjConProp]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 NVARCHAR(50) = NULL										-- Ambito de Aplicaci�n elegido o por defecto = NULL
AS
BEGIN

--	DECLARE @PAR1 NVARCHAR(50) 
--	DECLARE @PAR2 NVARCHAR(50) 
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR2 = NULL										-- Ambito de Aplicaci�n elegido o por defecto = NULL


	DECLARE @TmpTIntfCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO @TmpTIntfCodxIdi
		SELECT CxI.[IDFkTIntCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CIntfTObjCodxIdio] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1				-- Idioma elegido
				AND
			  CxI.[IDFkTCodAmbAplic] = CASE WHEN @PAR2 IS NULL THEN CxI.[IDFkTCodAmbAplic] ELSE @PAR2 END		-- Ambito de Aplicaci�n





	-- Muestra los c�digos con su descripci�n por cada idioma
	SELECT Cod.[ID] AS [IDFkTIntCodigos]
			, Cd01.[Codigo]
			, Cd01.[Descripcion]
			, Cd01.[IDFkTCodAmbAplic]
			, Cd02.[Codigo] AS [CodigoAmbitoAplic]
			, Cd02.[Descripcion] AS [CodDescAmbitoAplic]
			, Cd01.[IDFkTIdioma]
			, Cd01.CodIdioma AS [IdiomaCod]
			, Cd01.DescIdioma AS [IdiomaDesc]
		  ,COP.[IDFkTCodObj]
			, Cd03.[Codigo]
			, Cd03.[Descripcion]
		  ,COP.[IDFkTCodObjProp]
			, Cd04.[Codigo]
			, Cd04.[Descripcion]
		  ,COP.[IntObjOrden]
		  ,COP.[IntObjValor]
	FROM [BDCtral].[dbo].[CIntfTObjCod] AS Cod WITH (NOLOCK)
		INNER JOIN @TmpTIntfCodxIdi AS Cd01			-- Detalle del C�digo
			ON Cod.[ID] = Cd01.[IDFkTCodigos]
		INNER JOIN @TmpTIntfCodxIdi AS Cd02			-- Detalle del Ambito de Aplicaci�n
			ON Cd01.[IDFkTCodAmbAplic] = Cd02.[IDFkTCodigos]
		LEFT OUTER JOIN [BDCtral].[dbo].[CintfTObjProp] AS COP WITH(NOLOCK)
				ON Cod.[ID] = COP.[IDFkTCodObj]
			LEFT OUTER JOIN @TmpTIntfCodxIdi AS Cd03			-- Detalle del C�digo
				ON COP.[IDFkTCodObj] = Cd03.[IDFkTCodigos]
			LEFT OUTER JOIN @TmpTIntfCodxIdi AS Cd04			-- Detalle del Ambito de Aplicaci�n
				ON COP.[IDFkTCodObjProp] = Cd04.[IDFkTCodigos]
	WHERE (Cd01.[IDFkTCodAmbAplic] = 'ABEDD291-3991-4A47-8AEB-82580BF6BA8C' OR Cd01.[IDFkTCodAmbAplic] = 'AEFEA6F0-CC81-41AB-AD12-354A484273DA')
			AND Cod.[ID] <> Cd01.[IDFkTCodAmbAplic]
			AND Cd01.[IDFkTCodAmbAplic] = CASE WHEN @PAR2 IS NULL THEN Cd01.[IDFkTCodAmbAplic] ELSE @PAR2 END
	ORDER BY Cd02.[Codigo], Cd01.[Codigo], COP.[IntObjOrden]
END
