set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO

-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 16/10/2018
-- Description:	Detalle de los c�digos [CIntfTUsuObj], para el idioma elegido o el por defecto = espa�ol
--				aqui se muestra la info de los elementos que forman parte de la estructuras arbol.
-- =============================================

CREATE PROCEDURE [dbo].[CIntfPObjMod]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol

AS
BEGIN

--	DECLARE @PAR1 NVARCHAR(50) 
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol

-- Tabla con la Informaci�n del Diccionario [CDiccTCodxIdiomas]
	DECLARE @TmpTCodxIdi TABLE	-- Codigos x Idiomas -- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)

--	 Inserta en la tabla temporal la informaci�n de los c�digos seg�n el idioma elegido
	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1

-- Tabla con la Informaci�n de los Objetos [CIntfTObjCodxIdio]
	DECLARE @TmpTIntObjCodxIdi TABLE	-- Codigos x Idiomas -- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTIntCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [nvarchar](55) COLLATE Modern_Spanish_CI_AS,  -- NOT NULL,
		[Descripcion] [nvarchar](255) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodigoWeb] [nvarchar](50) COLLATE Modern_Spanish_CI_AS NULL,
		[IDFkCxIUsuObjEstado] [uniqueidentifier] NULL,
		[TCodxIdioFechaModif] [datetime] NULL, 
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)

--	 Inserta en la tabla temporal la informaci�n de los c�digos seg�n el idioma elegido
	INSERT INTO @TmpTIntObjCodxIdi
		SELECT IDFkTCIntfTObjCod_CodxIdio
			  ,IDFkTCDiccTIdio_Idioma
			  ,IDFkTCIntfTObjCod_AmbAplic
			  ,[Codigo]
			  ,[Descripcion]
			  ,[CodigoWeb]
			  ,IDFkCDiccTCod_ObjCodxIdioEst
			  ,[ObjCodxIdioFechaModif]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CIntfTObjCodxIdio] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTCDiccTIdio_Idioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1

--	SELECT * FROM @TmpTCodxIdi
--	SELECT * FROM @TmpTIntObjCodxIdi

		SELECT IOM.[ID] AS [IDFkCIntfTObjMod]
			  ,IOM.[ObjModCodUnico]
			  ,IOM.[ObjModCodDescFuncion]
			  ,IOM.[IDFkCDiccTCod_ObjModEst]
			  ,CxI.[Codigo] AS [ObjModEst]
			  ,CxI.[Descripcion] AS [ObjModEstDesc]
			  ,IOM.[ObjModFechaModif]
			  ,IOM.[IDFkCIntfTObjCod_ObjMod]
			  ,OCxI01.[Codigo] AS [ObjCodMod]
			  ,OCxI01.[Descripcion] AS [ObjCodModDesc]
		  FROM [BDCtral].[dbo].[CIntfTObjMod] AS IOM WITH(NOLOCK)
			INNER JOIN @TmpTCodxIdi AS CxI
				ON IOM.[IDFkCDiccTCod_ObjModEst] = CxI.[IDFkTCodigos]
						AND 
					@PAR1 = CxI.[IDFkTIdioma]
			INNER JOIN @TmpTIntObjCodxIdi AS OCxI01
				ON IOM.[IDFkCIntfTObjCod_ObjMod] = OCxI01.[IDFkTIntCodigos]
						AND 
					@PAR1 = OCxI01.[IDFkTIdioma]

--	 Borra Tablas Temporales
		IF OBJECT_ID('@TmpTCodxIdi') IS NOT NULL
		BEGIN
		DROP TABLE [BDCtral].[dbo].[@TmpTCodxIdi];
		END

		IF OBJECT_ID('@TmpTIntObjCodxIdi') IS NOT NULL
		BEGIN
		DROP TABLE [BDCtral].[dbo].[@TmpTIntObjCodxIdi];
		END

END

--
--	DECLARE	@return_value int
--	EXEC	@return_value = [dbo].[CIntfPObjMod] @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'
