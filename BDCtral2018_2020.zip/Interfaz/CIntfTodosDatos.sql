USE [BDCtral]
GO
	DECLARE	@return_value int
-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-- Aqu� se explica como funciona todo el M�dulo Interfaz de Usuario
-- para ello se van a ir explicando las funciones de cada una de las tablas, vistas y procedimientos almacenados
-- en el excel en la hoja Modulo Interfaz esta el esquema gr�fico de la relaci�n entre tabla y procedimientos almacenados
-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

-- Resumen del funcionamiento
--	Primero: se deben generar los elementos (html, css, etc) y sus propiedades (que lo definen)
--			por lo tanto, primero generamos los elementos, luego relacionamos las propiedades a cada elemento.
--			se utilizan 3 tablas: [T01: CIntfTObjCod], [T02: CIntfTObjCodxIdio] y [T03: CintfTObjCodProp]
--			ya creado los elementos, se pueden utilizar para crear los Objetos Modelos y de Usuarios.


--	Segundo: se deben crear los Objetos Modelos, que estos se van a utilizar para se usados varias veces en distintas p�ginas webs
--			Objeto Modelo Padre: para ello debemos crear el Objeto Modelo Padre CintfPObjModABM_Padre.sql,
--			Objeto Modelo Hijo: luego agregarle los Objetos Modelo Hijos Ejecuta CintfPObjModABM_Hijos.sql, se incorpora automaticamente las propiedades obligatorias de los elementos insertados.
--				Cuando se carga un elemento hijo se ejecuta los procedimientos almacenados:
--						[PA12: CIntfTObjModArbEstABM]	se hace manual, ya que debe colocar el Padre Inicial, no los intermedios
--						[PA13: CintfPObjModArbWebABM]	se hace manual
--						[PA14: CintfUsuObjModABM]
--			Propiedades Optativas: ya creado el Objeto Modelo, sus Elemntos y propiedades obligatorias, se deben agregar las propiedades optativas.
--				al cargar las propiedades se ejecuta los procedimientos almacenados:
--						[PA12: CIntfTObjModArbEstABM]	se hace manual
--						[PA13: CintfPObjModArbWebABM]	se hace manual
--						[PA14: CintfUsuObjModABM]
--		Esto asegura que todas las tablas tengan integridad.


-- Tercero:	se deben crear los Objetos de Usuario, estos son las p�ginas webs reales del sistema.




-- ###################################################################################################################################################################
-- ~~~~~~~~~~~~~~~~~~~
-- INTERFAZ DE OBJETOS
-- ~~~~~~~~~~~~~~~~~~~
-- ###################################################################################################################################################################
-- Explicaci�n de todo lo relacionado con el submodulo Interfaz Objetos
-- ###################################################################################################################################################################
-- ###################################################################################################################################################################
-- ===================================================================================================================================================================
-- <<< Tabla 01 [CIntfTObjCod] >>>
-- Todos los Objetos, Elementos, Propiedades, Estilos, Paginas, etc que forman parte del modulo
-- aqu� se destaca la ubicaci�n cuando se arma el tag: puede ser Intag, Outag, No Aplica. 
	-- InTag, se abre el tag y se inserta la propiedad eje: <label css="negrita">
	-- OutTag, se escribe entre los tag. Eje: <label>Hola Mundo</label>
	-- No Aplica, es idem OutTag a los fines del Servlet, pero se utiliza para cuando no se utiliza esta propiedad.
	SELECT [ID]								-- ID unico del objeto
		  ,[IDFkCDiccTCod_ObjCodUbic]		-- C�digo de la ubicaci�n para armar el Tag en el Sevlet. Valor en la tabla [CDiccTCodxIdiomas]
		  ,[IDFkCDiccTCod_ObjCodEst]		-- C�digo del estado del objeto. Valor en la tabla [CDiccTCodxIdiomas]
		  ,[ObjCodFechaModif]				-- Fecha de carga y/o modificaci�n del objeto.
	  FROM [BDCtral].[dbo].[CIntfTObjCod]
	-- Los valores del [IDFkCDiccTCod_ObjCodUbic] y [IDFkCDiccTCod_ObjCodEst], est�n en la tabla [CDiccTCodigos] y [CDiccTCodxIdiomas]
	-- esto es para que no haya dos conceptos con distinto c�digo en el sistema.

-- ===================================================================================================================================================================
-- <<< Tabla 02 [CIntfTObjCodxIdio] >>>
-- Aqu� se escribe el C�digo y su Descripci�n para todos los valores de la <<< Tabla 01 [CIntfTObjCod] >>>
-- Ya que todos los Objetos, Elementos, Propiedades, Estilos, Paginas, etc., tienen un c�digo y descripi�n seg�n el idioma, es aqu� donde se carga.
-- Los cogidos que se utilizan en la programaci�n del Servlet, no cambian. Esto es para los Elementos, Propiedades, Estilos. 
-- Siempre tienen el mismo c�digo independiente del idioma.
-- Cuando se ingresa un Ambito de Aplicaci�n, se debe poner el ID = Ambito de Aplicaci�n. Esto significa que es un Ambito nuevo.
-- los Ambitos de Aplicaci�n, funcionan como si fueran Tablas del Sistema.
	SELECT [IDFkTCIntfTObjCod_CodxIdio]		-- ID unico del objeto, viene de la tabla << Tabla 01 >> [CIntfTObjCod]
		  ,[IDFkTCDiccTIdio_Idioma]			-- ID del idioma, viene de la tabla [CDiccTIdioma]. Son los idiomas disponibles del sistema.
		  ,[IDFkTCIntfTObjCod_AmbAplic]		-- ID del Ambito de Aplicaci�n, este esta contenido en las tablas [CIntfTObjCod] y [CIntfTObjCodxIdio], el ID = Ambito de Aplicaci�n.
		  ,[Codigo]							-- C�digo unico para el Idioma y Ambito de Aplicaci�n. Este c�digo si es utilizado en el Servlet, no cambia.
		  ,[Descripcion]					-- Descripci�n del c�digo.
		  ,[CodigoWeb]						-- C�digo Web ingresado por el usuario.
		  ,[IDFkCDiccTCod_ObjCodxIdioEst]	-- C�digo del estado del objeto. Valor en la tabla [CDiccTCodxIdiomas]
		  ,[ObjCodxIdioFechaModif]			-- Fecha de carga y/o modificaci�n del objeto.
	  FROM [BDCtral].[dbo].[CIntfTObjCodxIdio]
		ORDER BY [IDFkTCIntfTObjCod_AmbAplic], [Codigo]
	-- Los valores del [IDFkCDiccTCod_ObjCodxIdioEst], est�n en la tabla [CDiccTCodigos] y [CDiccTCodxIdiomas]
	-- esto es para que no haya dos conceptos con distinto c�digo en el sistema.

-- ===================================================================================================================================================================
-- <<< Tabla 03 [CintfTObjCodProp] >>>
-- Aqu� se incorporan las propiedades que tienen los Objetos, Eleentos, Estilos.
-- Un Objeto, solo puede tener una sola vez una propiedad.
-- Por lo tanto, a un Elemento, se le puede insertar una propiedad, y esta tiene que tener: Valor, Orden, ValorWeb, Estado y FechaModif
SELECT [ID]										-- Valor ID �nico que agrupa la �nica combinaci�n entre el Objeto y la Propiedad
      ,[IDFkTCIntfTObjCod_ObjCod]				-- ID del Elemento al que se insertar� la propiedad. Surge de <<< Tabla 01 [CIntfTObjCod] >>> y su descripci�n para el idioma est� en <<< Tabla 02 [CIntfTObjCodxIdio] >>>
      ,[IDFkTCIntfTObjCod_ObjCodProp]			-- ID de la propiedad que se le asignar� al Elemento. Surge de <<< Tabla 01 [CIntfTObjCod] >>> y su descripci�n para el idioma est� en <<< Tabla 02 [CIntfTObjCodxIdio] >>>
      ,[ObjCodPropValor]						-- Valor �nico de la propiedad para ese elemento. En el caso de que sea un elemento que se utiliza por el Servlet, este se pone autom�tico y surge de la tabla  <<< Tabla 02 [CIntfTObjCodxIdio] >>>
      ,[ObjCodPropOrden]						-- Orden en que se deber� escribir la propiedad en el elemento del Tag. Eje: primero se escribe el tag <label> y luego las propiedades que van dentro del mismo, como ID, name, form, etc.
      ,[ObjCodPropValorWeb]						-- Valor del elemento ingresado por el usuario.
      ,[IDFkCDiccTCod_ObjCodPropEstado]			-- C�digo del estado del objeto. Valor en la tabla [CDiccTCodxIdiomas] 
      ,[ObjCodPropFechaModif]					-- Fecha de carga y/o modificaci�n del objeto.
  FROM [BDCtral].[dbo].[CintfTObjCodProp]


-- ===================================================================================================================================================================
-- <<< Procedimiento Almacenado 01 [CIntfPAmbAplic] >>>
-- el mismo esta en el archivo ### Sentencia SQL CIntfPAmbAplic.sql ###
-- Lista los Ambitos de Aplicaci�n para un idioma definido. 
-- estos �mbitos de aplicaci�n funcionan como Tablas dentro del sistema
DECLARE	@return_value int
EXEC	@return_value = [dbo].[CIntfPAmbAplic]
			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--			,@PAR2 = NULL										-- Ambito de Aplicaci�n elegido o por defecto = NULL
-- Ejemplos:
				--	ABEDD291-3991-4A47-8AEB-82580BF6BA8C	Css	contiene todos los estilos posibles de la pagina y los elementos
				--	AEFEA6F0-CC81-41AB-AD12-354A484273DA	Ele	contiene los elementos de la pagina
				--	B890DD58-58BA-4DA3-8A0C-70422298A88D	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
				--	7C2D7297-34DE-4F10-8F70-ACD26E5AFB04	PagWeb	contiene las pagina web de la aplicacion.
				--	9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B	Pro	contiene las propiedades de la pagina, elementos y estilos
				--	540C0AB8-CFCA-4346-AC40-D159787DAEA2	UsuObj	contiene las descripciones de los usuarios objetos que forman parte de las objetos.

-- ===================================================================================================================================================================
-- <<< Procedimiento Almacenado 02 [CIntfPCodxIdio] >>>
-- el mismo esta en el archivo ### Sentencia SQL CIntfPCodxIdio.sql ###
-- Lista los elementos que contiene cada uno de los Ambitos de Aplicaci�n para el Idioma definido.
DECLARE	@return_value int
EXEC	@return_value = [dbo].[CIntfPCodxIdio]
			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
			-- Ambito de Aplicaci�n elegido o por defecto = NULL
			,@PAR2 = 'AEFEA6F0-CC81-41AB-AD12-354A484273DA'		--	Ele	contiene los elementos de la pagina
--			,@PAR2 = 'ABEDD291-3991-4A47-8AEB-82580BF6BA8C'		--	Css	contiene todos los estilos posibles de la pagina y los elementos
--			,@PAR2 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'		--	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
--			,@PAR2 = '7C2D7297-34DE-4F10-8F70-ACD26E5AFB04'		--	PagWeb	contiene las pagina web de la aplicacion.
--			,@PAR2 = '9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B'		--	Pro	contiene las propiedades de la pagina, elementos y estilos


-- ===================================================================================================================================================================
-- <<< Procedimiento Almacenado 03 [CIntfPCodxIdioABM] >>>
-- el mismo esta en el archivo ### Sentencia SQL CIntfPCodxIdioABM.sql ###
-- Esta sentencia se utiliza para dar de alta/Baja/Modif los elementos en las tablas <<< Tabla 01 [CIntfTObjCod] >>> y <<< Tabla 02 [CIntfTObjCodxIdio] >>>
-- Se 10 variables pero las claves son:
--					@PAR1 = ALTA - MODIFICACION - BAJA - RECUPERO
--					@PAR2 = NEWID()
--					@PAR3 = Idioma Elegido
--					@PAR4 = Ambito de Aplicaci�n donde se insertar� el Elemento
--					@PAR5 = C�digo del elemento. Para un �mbito de aplicaci�n este c�digo no se puede repetir.
--					@PAR6 = Descripci�n del elemento.
--					@PAR7 = C�digo Web, que es el nombre del elemento que le da el usuario.
--					@PAR8 = Ubicaci�n del Elemento, Intag, OutTag, No Aplica.
--					@PAR9 = Estado del elemento, Habilitado, Deshabilitado, Baja
--					@PAR10 = AltaCompleto (se genera el Alta en las dos Tablas <<< Tabla 01 [CIntfTObjCod] >>> y su descripci�n para el idioma est� en <<< Tabla 02 [CIntfTObjCodxIdio] >>>
--							o SoloCodxIdio. Para cuando el Objeto ya esta creado, solo se carga la descripci�n del nuevo idioma en <<< Tabla 02 [CIntfTObjCodxIdio] >>>
-- Cuando se crea un Ambito de Aplicaci�n el valor de @PAR4 = @PAR2

	-- ===================================================================================================================================================================
	-- <<< Sentencia SQL 01 CIntfPCodxIdioABM_EjeProc.sql >>>
	-- Ejecuta Procedimiento Almacenado [CIntfPCodxIdioABM], para agregar un codigo en el M�dulo de Acceso
		EXEC @return_value = [dbo].[CIntfPCodxIdioABM]
	-- las principales variables que se ajustan son:
	--		,@PAR3 = ''			-- Ambito de Aplicaci�n "Tabla" donde va el c�digo
				-- algunos ejemplos
						--	'EBFEF35D-D9F8-4116-953D-0E2ED4341E6E'	--	CIntfObjTipo		tabla con los tipos de objetos de la interfaz de usuario.
						--	'C3133A27-4F21-4793-B186-4A640AB2AE52'	--	CIntfObjUbic		determina si el objeto va dentro intag o fuera del tag outtag.
						--	'EBFEF35D-D9F8-4116-953D-0E2ED4341E6E'	--	CIntfObjTipo		tabla con los tipos de objetos de la interfaz de usuario.
						--	'C3133A27-4F21-4793-B186-4A640AB2AE52'	--	CIntfObjUbic		determina si el objeto va dentro intag o fuera del tag outtag.
						--	'ABEDD291-3991-4A47-8AEB-82580BF6BA8C'	--	Css					contiene todos los estilos posibles de la pagina y los elementos.
						--	'AEFEA6F0-CC81-41AB-AD12-354A484273DA'	--	Ele					contiene los elementos de la pagina.
						--	'9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B'	--	Pro					contiene las propiedades de la pagina, elementos y estilos.
						--	'540C0AB8-CFCA-4346-AC40-D159787DAEA2'	--	UsuObj				contiene las descripciones de los usuarios objetos que forman parte de las objetos.
						--	'B890DD58-58BA-4DA3-8A0C-70422298A88D'	--	ObjMod				contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
						--	'7C2D7297-34DE-4F10-8F70-ACD26E5AFB04'	--	PagWeb				contiene las pagina web de la aplicacion.
	--		,@PAR5 = 'PAG-VIS' 									-- Codigo			 -- C�digo en letras del ID debe ser �nico para el �mbito de aplicaci�n
	--		,@PAR6 = 'visualiza la p�gina' 						-- Descripci�n		 -- Es la descripci�n del c�digo en letras.
	--		,@PAR7 = 'PAG-VIS' 									-- CodigoWeb		 -- C�digo en letras que se utiliza para armar la p�gina web.
	--		,@PAR8 = '00ECF783-C3C7-4178-8E8A-F83AE2EE7872'		--	[IDFkCDiccTCod_ObjCodUbic]	determina si el objeto va dentro intag o fuera del tag outtag


	-- ===================================================================================================================================================================
	-- <<< Sentencia SQL 02 CIntfPObjElementosABM.sql >>>
	-- utiliza el procedimiento almacenado [CIntfPCodxIdioABM] para dar de alta a los Elementos 
	-- para ello el Ambito de Aplicaci�n es siempre	'AEFEA6F0-CC81-41AB-AD12-354A484273DA'	--	Ele	contiene los elementos de la pagina
	-- las principales variables que se ajustan son:
	--		,@PAR5 = 'PAG-VIS' 									-- Codigo			 -- C�digo en letras del ID debe ser �nico para el �mbito de aplicaci�n
	--		,@PAR6 = 'visualiza la p�gina' 						-- Descripci�n		 -- Es la descripci�n del c�digo en letras.
	--		,@PAR7 = 'PAG-VIS' 									-- CodigoWeb		 -- C�digo en letras que se utiliza para armar la p�gina web.
	--		,@PAR8 = '00ECF783-C3C7-4178-8E8A-F83AE2EE7872'		--	[IDFkCDiccTCod_ObjCodUbic]	determina si el objeto va dentro intag o fuera del tag outtag


	-- ===================================================================================================================================================================
	-- <<< Sentencia SQL 03 CIntfPObjPropiedadesABM.sql >>>
	-- utiliza el procedimiento almacenado [CIntfPCodxIdioABM] para dar de alta a las propiedades
	-- para ello el Ambito de Aplicaci�n es siempre	'9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B'	--	Pro	contiene las propiedades de la pagina, elementos y estilos
	-- las principales variables que se ajustan son:
	--		,@PAR5 = 'PAG-VIS' 				-- Codigo -- C�digo en letras del ID debe ser �nico para el �mbito de aplicaci�n
	--		,@PAR6 = 'visualiza la p�gina' 	-- Descripci�n -- Es la descripci�n del c�digo en letras.
	--		,@PAR7 = 'PAG-VIS' 	-- CodigoWeb -- C�digo en letras que se utiliza para armar la p�gina web.
	--		,@PAR8 = 'A745CCC2-262B-4F2A-B6AB-EAD4BCCA3CFA'	--	[IDFkCDiccTCod_ObjCodUbic]	determina si el objeto va dentro intag o fuera del tag outtag
				-- para las propiedades usualmente se utiliza intag
								--	A745CCC2-262B-4F2A-B6AB-EAD4BCCA3CFA	intag			valores dentro del tag
								--	00ECF783-C3C7-4178-8E8A-F83AE2EE7872	outtag			valores fuera del tag
								--  DCDF7DF1-14A0-4C31-ACB4-9B0A176406E3	no aplica		no aplica clasificacion

			--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			-- Lista las propiedades para ello utiliza el PA02 [CIntfPCodxIdio] 
			-- especifica el Ambito de Aplicaci�n de Propiedades para generar el informe
			--	DECLARE	@return_value int
				EXEC	@return_value = [dbo].[CIntfPCodxIdio]
							@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
							-- Ambito de Aplicaci�n elegido o por defecto = NULL
							,@PAR2 = '9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B'		--	Pro	contiene las propiedades de la pagina, elementos y estilos


-- ===================================================================================================================================================================
-- <<< Procedimiento Almacenado 04 [CintfPObjCodPropABM] >>>
-- incorpora una nueva propiedad para un Elemento
-- la base de este procedimiento es el <<< Sentencia SQL 03 CintfPObjCodPropABM.sql >>>
		-- <<< Sentencia SQL 04 CIntfPObjCodPropABM_EjeProc.sql >>>
		-- Esta sentencia se utiliza para dar de alta/Baja/Modif las propiedades a los elementos en las tablas <<< Tabla 03 [CintfTObjCodProp] >>>
		-- Se 7 variables pero las claves son:
		--			@PAR1 = ALTA - MODIFICACION - BAJA - RECUPERO
		--			@PAR2 = NEWID()
		--			@PAR3 = ID c�digo del Elemento / Objeto al que se aplicar� la propiedad [IDFkTCIntfTObjCod_ObjCod]
		--			@PAR4 = ID de la propiedad a asignar [IDFkTCIntfTObjCod_ObjCodProp]
		--			@PAR5 = Valor que tiene la propiedad [CodObjPropValor].
		--			@PAR6 = valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
		--			@PAR7 = -- [IDFkCDiccTCod_PropTipo]	-- Define si la propiedad es o no Obligatoria 
					-- Valores Disponibles
						--	F88BE042-527E-4FC1-A2EC-88572D3BA5C3		CIntfPropTipo	tabla con los tipos de propiedades, si la misma es obligatoria y opcional.
						--	'CC9699C0-B646-427E-B545-7AAFB23D5B95'		obligatoria		propiedad obligatoria
						--	'E2501954-E494-40E8-BC6F-EC5ABD9945C8'		opcional		propiedad opcional
		--	^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		-- Importante: si hay que crear un nuevo elemento, se debe ejecutar la consulta -- <<< Sentencia SQL CIntfPObjElementosABM.sql >>>
		--			   si hay que crear una nueva propiedad, se debe ejecutar la consulta -- <<< Sentencia SQL CIntfPObjPropiedadesABM.sql >>>
		--	^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


		--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		-- <<< Procedimiento Almacenado 05 [CIntfPObjConProp] >>>
		-- el mismo esta en el archivo ### Sentencia SQL CIntfPObjConProp.sql ###
		-- Lista las propiedades de los elementos Ele y las Hojas de Estilo Css
		-- Si hay un elemento que no tiene asignada la propiedad el valor C�digo es NULL.
		-- en el caso de que no tenga asignada ninguna propiedad, para el sistema es como si no existiera, ya que las propiedades lo definen.
		DECLARE	@return_value int
		EXEC	@return_value = [dbo].[CIntfPObjConProp]
					@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
					,@PAR2 = 'CBC7CCD2-6825-4288-A1EE-07C83D57FE97'		-- IDFkCIntfTObjCod, es el elemento que tiene las propiedades, surge de la consutla [CintfPObjModBucleIDProp]
		-- Procedimiento Almacenado a Borrar, ya que se duplica con este es [CIntfPObjYProp_Borrar]
		-- y esta en el archivo CIntfPObjYProp.sql

		-- <<< Procedimiento Almacenado 06 [CIntfPObjConPropResu] >>>
		-- Es lo mismo pero muestra algunos campos
		-- el mismo esta en el archivo ### Sentencia SQL CIntfPObjConPropResu.sql ###
			DECLARE	@return_value int
			EXEC	@return_value = [dbo].[CIntfPObjConPropResu]
					@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
					,@PAR2 = '6A20FFB1-EF83-46AC-9DDA-9C37096B489D'		-- IDFkCIntfTObjCod, es el elemento que tiene las propiedades, surge de la consutla [CintfPObjModBucleIDProp]


-- ===================================================================================================================================================================-- <<< Procedimiento SQL 02 CIntfPCodxIdioIntegridad.sql >>>
-- <<< Sentencia SQL 05 CIntfPCodxIdioIntegridad.sql >>>
-- Determina la integridad de las tablas <<< Tabla 01 [CIntfTObjCod] >>> y su descripci�n para el idioma est� en <<< Tabla 02 [CIntfTObjCodxIdio] >>>

-- ===================================================================================================================================================================-- <<< Procedimiento SQL 02 CIntfPCodxIdioIntegridad.sql >>>
-- <<< Sentencia SQL 06 CIntfPEliminaRealmenteUnCodigo.sql >>>
-- Elimina un cogido de todas las tablas del M�dulo Interfaz de Usuario 


-- ###################################################################################################################################################################
-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- INTERFAZ DE OBJETOS MODELOS
-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- ###################################################################################################################################################################
-- ###################################################################################################################################################################
-- Explicaci�n de todo lo relacionado con el submodulo Objetos Modelos
-- ###################################################################################################################################################################
-- ###################################################################################################################################################################
-- ===================================================================================================================================================================
-- <<< Tabla 04 [CIntfTObjMod] >>>
-- Todos los Elementos que forman parte de la Estructura Objeto Modelo.
-- estos objetos modelos, permiten que se creen modulos y que puedan ser utilizados en distintas p�ginas web.
-- de esta manera, modificando un objeto modelo, se cambian todas las p�ginas web que lo utilizan.
-- ejemplos de usos de estos objetos modelos, son:
	-- Estructura general de la p�gina, desde el <doctype> hasta el <body>
	-- Encabezado y Pie de p�gina.
	-- Men�es
	SELECT [ID]								-- ID unico del objeto, se utiliza para relacionarlo con las otras tablas [CIntfTObjModProp] y [CIntfTObjModArb]
		  ,[IDFkCIntfTObjCod_ObjMod]		-- ID del elemento que se le asignar� al Objeto Modelo.
		  ,[ObjModCodUnico]					-- C�digo unico para el elemento dentro del Objeto Modelo. Este c�digo se carga autom�ticamente para que no se repita dentro de la estructura.
		  ,[ObjModCodDescFuncion]			-- Descripci�n la funci�n del Elemento en la estructura modelo.
		  ,[IDFkCDiccTCod_ObjModEst]		-- C�digo del estado del objeto. Valor en la tabla [CDiccTCodxIdiomas]
		  ,[ObjModFechaModif]				-- Fecha de carga y/o modificaci�n del objeto.
	  FROM [BDCtral].[dbo].[CIntfTObjMod]
-- Los Objeto Modelo Padre NO esta en esta tabla, sino en las tablas <<< Tabla 01 [CIntfTObjCod] >>> y <<< Tabla 02 [CIntfTObjCodxIdio] >>>
-- Estos elementos sin la asociaci�n a su estructura [CIntfTObjModArb] no tienen mucho significado.

		--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		-- <<< Procedimiento Almacenado 07 [CIntfPObjMod] >>>
		-- el mismo esta en el archivo ### Sentencia SQL CIntfPObjMod.sql ###
		-- detalle de los elementos que forman los objetos modelos. Estos elementos sin la asociaci�n a su estructura no tienen mucho significado.
		-- Los Objeto Modelo Padre NO esta en esta tabla, sino en las tablas <<< Tabla 01 [CIntfTObjCod] >>> y <<< Tabla 02 [CIntfTObjCodxIdio] >>>
			DECLARE	@return_value int
			DECLARE @PAR1 NVARCHAR(50) 
			SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
			EXEC @return_value = [dbo].[CIntfPObjMod] @PAR1 = @PAR1

-- ===================================================================================================================================================================
-- <<< Tabla 05 [CIntfTObjModArb] >>>
-- Aqu� se arma la estructura Padre Hijo del Objeto Modelo.
-- Esta estructura es la que permite hacer la estructura del Objeto que luego se insertara en la p�gina
SELECT [ID]									-- Valor ID �nico que sirve de Padre e Hijo
      ,[IDFkCIntfTObjModArb_PadreID]		-- Valor ID del Padre, este es uno de los valores del [ID] de la fila anterior
      ,[ItemNivel]							-- Nivel dentro de la estructura Padre Hijo, va de 1 a infinito
      ,[ItemOrd]							-- Orden dentro del mismo nivel.
      ,[IDFkCIntfTObjMod]					-- ID del Objeto Modelo surge de la tabla -- <<< Tabla 04 [CIntfTObjMod] >>>
  FROM [BDCtral].[dbo].[CIntfTObjModArb]


-- ===================================================================================================================================================================
-- <<< Tabla 06 [CIntfTObjModProp] >>>
-- Aqu� se incorporan las propiedades que tienen los Elementos, Estilos.
-- Un elemento para un Modelo espec�fico tiene una serie de propiedades que lo identifican y lo hacen �nico.
-- Luego este elemento se puede utilizar infinitas veces dentro de las p�ginas o se puede utilizar como tapiz para crear otras p�ginas.
SELECT [ID]										-- Valor ID �nico que agrupa la �nica combinaci�n entre el Elemnto del Objeto Modulo y la Propiedad
      ,[IDFkCIntfTObjMod_ObjModID]				-- ID del Elemento al que se insertar� la propiedad. Surge de <<< Tabla 04 [CIntfTObjMod] >>>
      ,[IDFkCintfTObjCodProp_ObjModProp]		-- ID de la propiedad que se le asignar� al Elemento. Surge de<<< Tabla 03 [CintfTObjCodProp] >>>
      ,[ObjModCodPropValor]						-- Valor �nico de la propiedad para ese elemento. Hay propiedades que tiene un valor fijo ya que se utilizan en el Servlet, eje: <html>, pero hay otras que las carga el usuario para el Objeto Modulo en particular. Eje: contenido dentro del estilo, dentro de los labels 
      ,[ObjModCodPropOrden]						-- Orden en que se deber� escribir la propiedad en el elemento del Tag. Eje: primero se escribe el tag <label> y luego las propiedades que van dentro del mismo, como ID, name, form, etc.
      ,[IDFkCDiccTCod_ObjModPropEst]			-- C�digo del estado del objeto. Valor en la tabla [CDiccTCodxIdiomas] 
      ,[ObjModPropFechaModif]					-- Fecha de carga y/o modificaci�n del objeto.
  FROM [BDCtral].[dbo].[CIntfTObjModProp]


-- ===================================================================================================================================================================
-- <<< Tabla 07 [CIntfTObjModArbEst] >>>
-- Estructura del Arbol del Objeto Modelo, surge de ejecutar la consulta CIntfPObjModArbEstABM.sql, 
-- que ejecuta el procedimiento almacenado [dbo].[CintfPObjModBucleID]
-- la misma muestra la estructura generada para el elemento SIN sus propiedades, solo los elementos que la forman
SELECT [EstOrd]							-- Orden dentro de la estructura
      ,[ArbolID]						-- ID del arbol, surge de la tabla <<< Tabla 01 [CIntfTObjCod] >>>
      ,[ArbolDesc]						-- Nombre / Descripci�n del arbol, surge de la tabla <<< Tabla 02 [CIntfTObjCodxIdio] >>>
      ,[ArbPadreID]						-- ID del Padre, surge de la tabla <<< Tabla 01 [CIntfTObjCod] >>>
      ,[IDFkCIntfTObjModArb]			-- ID del ObjModArb
      ,[ArbolNivel]						-- Nivel dentro del Arbol
      ,[IDFkCIntfTObjCod]				-- ID del elemento <<< Tabla 01 [CIntfTObjCod] >>>. A traves
      ,[IntfTObjCod]					-- C�digo del elemento <<< Tabla 01 [CIntfTObjCod] >>>. A traves
      ,[IDFkCIntfTObjMod]				-- ID del elemento que forma el Objeto Modelo, surge de la tabla <<< Tabla 04 [CIntfTObjMod] >>>
      ,[ObjModCodUnico]					-- C�digo unico para el elemento dentro del Objeto Modelo. Este c�digo se carga autom�ticamente para que no se repita dentro de la estructura, surge de la tabla <<< Tabla 04 [CIntfTObjMod] >>>
      ,[ObjModCodDescFuncion]			-- Descripci�n la funci�n del Elemento en la estructura modelo, surge de la tabla <<< Tabla 04 [CIntfTObjMod] >>>
      ,[ArbItemNivel]					-- Nivel dentro de la estructura arbol, surge de la tabla <<< Tabla 06 [CIntfTObjModArb] >>>
      ,[ArbItemOrd]						-- Orden dentro del nivel, surge de la tabla <<< Tabla 06 [CIntfTObjModArb] >>>
      ,[IDFkTCDiccTIdio_Idioma]			-- ID del Idioma
      ,[IDFkCIntfTObjCod_AmbAplic]		-- ID del Ambito de Aplicaci�n
      ,[IDFkCIntfTObjCod_TagOpen]		-- ID TagOpen
      ,[TagOpenCod]						-- TagOpen Descripci�n
      ,[IDFkCIntfTObjCod_TagClose]		-- ID TagClose
      ,[TagCloseCod]					-- TagClose Descripci�n
  FROM [BDCtral].[dbo].[CIntfTObjModArbEst]
		WHERE [ArbolID] = '5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D'	--	EncPag001	encabezado de la p�gina
--		WHERE [ArbolID] = '57504A29-9F06-41B2-896C-81D5A57E37BF'	--	EstWeb001	Estructura de la p�gina Web hasta el Body
--		WHERE [ArbolID] = '6EFA0E33-F537-4861-A35F-10ECB328FB74'	--	PiePag001	pie de la p�gina


-- ===================================================================================================================================================================
-- <<< Tabla 08 [CIntfTObjModArbWeb] >>>
-- Estructura del Objeto Modelo lista para insertar en la P�gina Web, surge de la combinaci�n de las tablas <<< Tabla 04 [CIntfTObjMod] >>> y <<< Tabla 06 [CIntfTObjModArb] >>>
-- esta tabla surge de una consulta CintfPObjModEstWeb_ABM.sql, y arma para cada Objeto Modelo, la estructura Web 
--SELECT [EstOrd]							-- Orden dentro de la estructura
--      ,[ArbolID]							-- ID del arbol, surge de la tabla <<< Tabla 01 [CIntfTObjCod] >>>
--      ,[ArbolDesc]						-- Nombre / Descripci�n del arbol, surge de la tabla <<< Tabla 02 [CIntfTObjCodxIdio] >>>
--      ,[IDFkCIntfTObjModArb]				-- ID dentro de la estructura Padre/Hijo, surge de la tabla <<< Tabla 06 [CIntfTObjModArb] >>>
--      ,[ArbolNivel]						-- Nivel dentro del Arbol
--      ,[IDFkCIntfTObjCod]					-- ID del elemento <<< Tabla 01 [CIntfTObjCod] >>>. A traves
--      ,[IntfTObjCod]						-- C�digo del elemento <<< Tabla 01 [CIntfTObjCod] >>>. A traves
--      ,[IDFkCIntfTObjMod]					-- ID del elemento que forma el Objeto Modelo, surge de la tabla <<< Tabla 04 [CIntfTObjMod] >>>
--      ,[ObjModCodUnico]					-- C�digo unico para el elemento dentro del Objeto Modelo. Este c�digo se carga autom�ticamente para que no se repita dentro de la estructura, surge de la tabla <<< Tabla 04 [CIntfTObjMod] >>>
--      ,[ObjModCodDescFuncion]				-- Descripci�n la funci�n del Elemento en la estructura modelo, surge de la tabla <<< Tabla 04 [CIntfTObjMod] >>>
--      ,[ArbItemNivel]						-- Nivel dentro de la estructura arbol, surge de la tabla <<< Tabla 06 [CIntfTObjModArb] >>>
--      ,[ArbItemOrd]						-- Orden dentro del nivel, surge de la tabla <<< Tabla 06 [CIntfTObjModArb] >>>
--  FROM [BDCtral].[dbo].[CIntfTObjModArbWeb]



-- ************************
-- OBJETOS MODELOS - PADRE
-- ************************
-- ===================================================================================================================================================================
-- Muestra los Objetos Modelo Padre, esto surgen de ejecutar el <<< Procedimiento Almacenado 02 [CIntfPCodxIdio] >>>
-- el mismo esta en el archivo ### Sentencia SQL CIntfPCodxIdio.sql ###
-- En Ambitos de Aplicaci�n es 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	-- ObjMod contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
-- el idioma es el definido por el usuario.
DECLARE	@return_value int
EXEC	@return_value = [dbo].[CIntfPCodxIdio]
			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
			,@PAR2 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'		-- Ambito de Aplicaci�n elegido o por defecto = NULL

			--	B890DD58-58BA-4DA3-8A0C-70422298A88D	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
			--	5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D	EncPag001	encabezado de la p�gina
			--	57504A29-9F06-41B2-896C-81D5A57E37BF	EstWeb001	Estructura de la p�gina Web hasta el Body
			--	6EFA0E33-F537-4861-A35F-10ECB328FB74	PiePag001	pie de la p�gina

-- ===================================================================================================================================================================
-- <<< Sentencia SQL 07 CintfPObjModABM_Padre.sql >>>
-- Esta sentencia se utiliza para dar de alta/Baja/Modif los elementos en las tablas <<< Tabla 01 [CIntfTObjCod] >>> y <<< Tabla 02 [CIntfTObjCodxIdio] >>>
-- El Padre se da de alta en la tabla [CIntfTObjCod] y [CIntfTObjCodxIdio], luego se incorpora en la tabla [CIntfTObjModArb].
-- Esto se incorpora en el ambito de aplicaci�n: B890DD58-58BA-4DA3-8A0C-70422298A88D ObjMod contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
-- Este procedimiento afecta las tablas [CIntfTObjCod], [CIntfTObjCodxIdio], [CIntfTObjModArb]

-- Se 10 variables pero las claves son:
--					@PAR1 = ALTA - MODIFICACION - BAJA - RECUPERO
--					@PAR2 = NEWID()
--					@PAR3 = Idioma Elegido
--					@PAR4 = Ambito de Aplicaci�n, siempre se utiliza 'B890DD58-58BA-4DA3-8A0C-70422298A88D'		--	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
--					@PAR5 = C�digo del elemento. Para un �mbito de aplicaci�n este c�digo no se puede repetir.
--					@PAR6 = Descripci�n del elemento.
--					@PAR7 = C�digo Web, que es el nombre del elemento que le da el usuario.
--					@PAR8 = Ubicaci�n del Elemento, siempre se utiliza 'B890DD58-58BA-4DA3-8A0C-70422298A88D'		--	ObjMod				contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
--					@PAR9 = Estado del elemento, Habilitado, Deshabilitado, Baja
--					@PAR10 = AltaCompleto (se genera el Alta en las dos Tablas <<< Tabla 01 [CIntfTObjCod] >>> y su descripci�n para el idioma est� en <<< Tabla 02 [CIntfTObjCodxIdio] >>>
--							o SoloCodxIdio. Para cuando el Objeto ya esta creado, solo se carga la descripci�n del nuevo idioma en <<< Tabla 02 [CIntfTObjCodxIdio] >>>


-- ************************
-- OBJETOS MODELOS - HIJOS
-- ************************
-- ===================================================================================================================================================================
-- <<< Sentencia SQL 08 CintfPObjModABM_Hijos.sql >>>
-- Trabaja con la tabla [CIntfObjMod], [CIntfObjModArb], [CIntfTObjModProp]
-- Para armar el objeto:
--			1.- Insertar el elemento en la tabla [CIntfObjMod]
--			2.- Insertar en la tabla [CIntfObjModArb], la ubicaci�n del elemento en la estructura Padre / Hijo
--			3.- Insertar en la tabla [CIntfTObjModProp], las propiedades obligatorias del elemento
-- Se 14 variables pero las claves son:
--					@PAR1 = ALTA - MODIFICACION - BAJA - RECUPERO
--					@PAR2 = Idioma Elegido
-- Crea los elementos asignados al objeto -- Tabla [CIntfTObjMod]
--					@PAR3 = ambito de aplicaci�n, siempre se utiliza 'AEFEA6F0-CC81-41AB-AD12-354A484273DA'	-- Ele	contiene los elementos de la pagina
--					@PAR4 = NEWID()	-- valor ID, debe ser �nico para el elemento asignado a la estructura modelo.
--					@PAR5 = codigo ID del Objeto (Elemento o Estilo) al que se insertar� en la p�gina, sale de la tabla [IDFkTIntCodObj]
--					@PAR6 = C�digo del elemento. Este se genera autom�ticamente con el nombre codigo unico web (tabla [CIntfTObjCodxIdio]) y el nivel donde esta el elemento.
--					@PAR7 = NO se utiliza.
--					@PAR8 = Descripci�n de la funci�n espec�fica del elemento dentro del Objeto Modelo.
-- Crea la Estructura Arbol -- Tabla [CIntfTObjModArb]
--					@PAR9 = C�digo ID unico del Objeto dentro de la estructura arbol
--					@PAR10 = ID del Padre, este valor es manual:
							-- 1.- En el caso que es el Padre Inicial, el ID viene de la tabla [CIntfTObjCod] y [CIntfTObjCodxIdio]
							-- 2.- En el caso de que otro elemento sea el padre, hay que buscar el ID, para incorporarlo como padre,
--					@PAR11 = [ItemNivel] es el nivel del arbol que tiene el objeto. En el caso inicial = 1
--					@PAR12 = [ItemOrd] es el orden dentro del Item Nivel.
--					@PAR13 = es el ID del objeto que se inserto en la Tabla TUsuObj. Este no es el ID del Objeto de la tabla TObjCod.
--					@PAR14 = 'c6fe2749-0cb8-49cd-97df-03c299c0c6cf'					-- [IDFkCxIEstados] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado

-- Se insertan las propiedades obligatorias de los elemntos. 
-- Esto permite reducir significativamente el trabajo de agregar elementos y 
-- solo se utiliza <<< Sentencia SQL 06 CintfPObjModPropABM.sql >>> para agregar las propiedades espec�ficas.

-- Con estas dos sentencias SQL, damos de alta a una estructura, sus elementos y las propiedades obligatorias, como son TagOpen, TagClose y alguna propiedad espec�fica del mismo.

-- ===================================================================================================================================================================
-- Procedimiento almacenado 08 [CintfPObjModPropABM]
-- sirve para insertar las propiedades opcionales a los Objetos Modelos
-- Para ejecutar este procedimiento almacenado hay que ejecutar la <<< Sentencia SQL 09 CintfPObjModPropABM_Ejec.sql >>>
-- Ahora hay que dar de alta las propiedades espec�ficas de los elementos. 
-- Trabaja con la tabla [CIntfObjMod], [CIntfObjModArb]
-- Se 7 variables pero las claves son:
--					@PAR1 = ALTA - MODIFICACION - BAJA - RECUPERO
--					@PAR2 = NEWID()		-- [ID] Valor Unico de la Tabla CIntfTObjModProp
--					@PAR3 = [ID] tabla [CIntfTObjMod]-- codigo ID �nico del objeto al que se le asignar�la propiedad.
--					@PAR4 = [ID] tabla [CintfTObjCodProp] -- valor ID �nico de la Propiedad
--					@PAR5 = [ObjModCodPropValor] Como este valor lo puede colocar el usuario, se carga, si es NULL, se pone el de la tabla
--					@PAR6 = [ObjModCodPropOrden] orden en que se armara el TAG, surge de una consulta de la tabla [CintfVObjCodProp]
--					@PAR7 = Estado del elemento, Habilitado, Deshabilitado, Baja

-- la Sentencia SQL CintfPObjModPropABM_Obligatoria.sql, es solo informativa ya que esta contenida dentro -- <<< Sentencia SQL 05 CintfPObjModABM_Hijos.sql >>>

		--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`
		-- <<< Procedimiento Almacenado 09 [CIntfPObjModProp] >>>
		-- el mismo esta en el archivo ### Sentencia SQL CIntfPObjModProp.sql ###
		-- Detalle las Propiedades de los Objetos Modelos disponibles, para el modulo Central Interfaz Objetos
		-- aqu� esta como se forma cada uno de los Objetos, que caracter�sticas tienen
		-- si el objeto no tiene propiedad, las mismas aparecen como null
			DECLARE	@return_value int
			DECLARE @PARIdioma NVARCHAR(50)		-- Idioma elegido o por defecto = espa�ol
			SET @PARIdioma = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
			EXEC	@return_value = [dbo].[CIntfPObjModProp] @PAR1 = @PARIdioma
		-- Esta consulta sirve para poder armar la sentencia CIntfPObjModCodArbProp.sql, donde estan las propiedades de la estructura Objeto Modelo.


-- ###########################################
-- OBJETOS MODELOS - MUESTRA LAS ESTRUCTURAS
-- ###########################################
-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<< Procedimiento Almacenado 10 [CintfPObjModBucleID] >>>
-- el mismo esta en el archivo ### Sentencia SQL CintfPObjModBucleID.sql ###
-- Hace el bucle de la Vista [dbo].[CintfVObjModCodArb], que tiene la info del [CIntfTObjModArb] y el Padre surge de la tabla [CIntfTObjCod] y [CIntfTObjCodxIdio]
-- el resultado es la estructura del Objeto Modelo, seg�n HTML
	DECLARE	@return_value int
	DECLARE @PARIdioma NVARCHAR(50)		-- Idioma elegido o por defecto = espa�ol
	SET @PARIdioma = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	EXEC	@return_value = [dbo].[CintfPObjModBucleID] 
				--	@PAR1 = '6EFA0E33-F537-4861-A35F-10ECB328FB74'	-- PiePag001	pie de la p�gina
				@PAR1 = '5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D'		--	EncPag001	encabezado de la p�gina
						--	'6EFA0E33-F537-4861-A35F-10ECB328FB74'	--	PiePag001	pie de la p�gina
						--	'5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D'	--	EncPag001	encabezado de la p�gina
						--	'B890DD58-58BA-4DA3-8A0C-70422298A88D'	--	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
						--	'57504A29-9F06-41B2-896C-81D5A57E37BF'	--	EstWeb001	Estructura de la p�gina Web hasta el Body
				,@PAR2 = @PARIdioma		-- Idioma elegido o por defecto = espa�ol
				,@PAR3 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'		-- Ambito de Aplicaci�n elegido o por defecto = ObjMod


-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<< Procedimiento Almacenado 11 [CintfPObj ModBucleIDProp] >>>
-- el mismo esta en el archivo ### Sentencia SQL CintfPObjModBucleIDProp.sql ###
-- Muestra el Objeto Modelo y sus propiedades.
-- surge de la uni�n: del procedimiento almacenado 10 [CintfPObjModBucleID] donde esta la informaci�n de la estructura arbol del elemento y
--					del procedimiento almacena 09 [CIntfPObjModProp] donde esta la informaci�n de las propiedades de cada elemento.
	DECLARE	@return_value int
	DECLARE @PARIdioma NVARCHAR(50)		-- Idioma elegido o por defecto = espa�ol
	SET @PARIdioma = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	EXEC	@return_value = [dbo].[CintfPObjModBucleIDProp] 
			@PAR1 = @PARIdioma									-- Idioma elegido o por defecto = espa�ol
			, @PAR2 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	-- Ambito de Aplicaci�n elegido o por defecto = NULL

			-- Detalle los Objetos Modelos disponibles, para el modulo Central Interfaz Objetos
			, @PAR3 = '5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D'	--	EncPag001	encabezado de la p�gina
--			, @PAR3 = '57504A29-9F06-41B2-896C-81D5A57E37BF'	--	EstWeb001	Estructura de la p�gina Web hasta el Body
--			, @PAR3 = '6EFA0E33-F537-4861-A35F-10ECB328FB74'	--	PiePag001	pie de la p�gina

			-- surge de la combinaci�n de las tablas [CIntfTObjCod] y [CIntfTObjCodxIdio]
				DECLARE	@return_value int
				DECLARE @PAR1 NVARCHAR(50) 		-- Idioma elegido o por defecto = espa�ol
				DECLARE @PAR2 NVARCHAR(50)		-- Ambito de Aplicaci�n elegido o por defecto = NULL
				SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'	-- Idioma elegido o por defecto = espa�ol
				SET @PAR2 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	-- Ambito de Aplicaci�n Objetos Modelos
				EXEC @return_value = [dbo].[CIntfPCodxIdio]	@PAR1 = @PAR1, 	@PAR2 = @PAR2



-- ***************************************************************************************************************************************************************8
-- Para finalizar debe insertar el Objeto Modelo en la tabla [CIntfTObjModArbWeb], para que tenga efecto en el sistema
-- ###########################################
-- OBJETOS MODELOS - ARMADO DE LAS ESTRUCTURAS
-- ###########################################
-- <<< Procedimiento Almacenado 12 [CIntfTObjModArbEst] >>>
--	carga la tabla [CIntfTObjModArbEst] en esta Tabla esta el resultado final de la estructura Web sin las propiedades
DECLARE	@return_value int
EXEC @return_value = [dbo].[CIntfTObjModArbEstABM] 
	@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 = '5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D'		--	EncPag001	encabezado de la p�gina

-- Ejemplos Padres ID
		-- Para ver los ID del Padre, ejecutar la siguiente consulta
--		EXEC @return_value = [dbo].[CIntfPCodxIdio]	@PAR1 = @PAR1, @PAR2 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	-- Ambito de Aplicaci�n Objetos Modelos
		-- Aqu� se elige el Padre que se va a mostrar, toda la estructura
			--	'5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D'	--	EncPag001	encabezado de la p�gina
			--	'57504A29-9F06-41B2-896C-81D5A57E37BF'	--	EstWeb001	Estructura de la p�gina Web hasta el Body
			--	'B890DD58-58BA-4DA3-8A0C-70422298A88D'	--	ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
			--	'6EFA0E33-F537-4861-A35F-10ECB328FB74'	--	PiePag001	pie de la p�gina

-- <<< Procedimiento Almacenado 13 [CintfPObjModArbWebABM] >>>
--	Carga la tabla [CIntfTObjModArbWeb] en esta Tabla esta el resultado final de la estructura Web lista para cargar en la p�gina
DECLARE	@return_value int
DECLARE @ObjMod AS NVARCHAR(36)
SET @ObjMod = '5C5AF46F-B84E-44F7-80C1-68D7B3DFD86D'	--	EncPag001	encabezado de la p�gina
--SET @ObjMod = '57504A29-9F06-41B2-896C-81D5A57E37BF'	--	EstWeb001	Estructura de la p�gina Web hasta el Body
--SET @ObjMod = '6EFA0E33-F537-4861-A35F-10ECB328FB74'	--	PiePag001	pie de la p�gina

EXEC	@return_value = [dbo].[CintfPObjModArbWebABM]
		@PAR1 = @ObjMod
		,@PAR2 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol

		-- Muestra los Resultados
		SELECT * FROM  [BDCtral].[dbo].[CIntfTObjModArbWeb]
		WHERE [ArbolID] = @ObjMod
		ORDER BY [ArbolID], [EstOrden], [ObjCodPropOrden]



-- ###################################################################################################################################################################
-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- INTERFAZ DE USUARIOS OBJETOS
-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- ###################################################################################################################################################################
-- ###################################################################################################################################################################
-- ###################################################################################################################################################################
-- Explicaci�n de todo lo relacionado con los Usuarios Objetos
-- ###################################################################################################################################################################
-- ===================================================================================================================================================================
-- <<< Tabla 09 [CIntfTUsuObj] >>>
-- Contiene todos los Elementos que forman parte de la Estructura de la P�gina.
-- aqu� se puede insertar un elemento y/o un ObjetoModelo. En este �ltimo caso, cuando se hace la estructura de la p�gina web,
-- se busca en la tabla [CIntfTObjModEstWeb] y se inserta los elementos que contienen a estos objeto modelo.
-- Estos elementos sin la asociaci�n a su estructura no tienen mucho significado.
SELECT [ID]								-- ID unico del objeto, se utiliza para relacionarlo con las otras tablas [CIntfTUsuObjProp] y [CIntfTUsuObjArb]
      ,[IDFkCIntfTObjCod_UsuObjCod]		-- ID de la tabla IDFkCIntfTObjCod, es el elemento que se insertar� en la p�gina
      ,[IntUsuObjCodUnico]				-- C�digo unico para el elemento dentro del Objeto Modelo. Este c�digo se carga autom�ticamente para que no se repita dentro de la estructura.
      ,[IntUsuObjCodUsuUnico]			-- Nombre del objeto para el usuario.
      ,[IntUsuObjCodDescFuncion]		-- Descripci�n la funci�n del Elemento en la estructura de la p�gina.
      ,[IDFkCDiccTCod_UsuObjEst]		-- C�digo del estado del objeto. Valor en la tabla [CDiccTCodxIdiomas]
      ,[UsuObjFechaModif]				-- Fecha de carga y/o modificaci�n del objeto.
  FROM [BDCtral].[dbo].[CIntfTUsuObj]


		-- <<< Procedimiento Almacenado 14 [CIntfPUsuObj] >>>
		-- Muestra los Usuarios Objetos creados. Aqu� pueden insertarse Elementos y Objetos Modelos.
		-- en el caso de que se inserten elementos, sus propiedades est�n en la tabla CIntfTUsuObjProp
		-- en el caso de que se inserten Objetos Modelos, sus propiedades est�n dentro de las tablas de las estructura ObjMod.
		-- Informaci�n surge de la tabla [CIntfTObjCodxIdio], [CDiccTCodxIdiomas] y [CIntfTObjCodxIdio]
			DECLARE	@return_value int
			DECLARE @PAR1 NVARCHAR(50) 
			SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
			EXEC	@return_value = [dbo].[CIntfPUsuObj] @PAR1 = @PAR1


-- ===================================================================================================================================================================
-- <<< Tabla 10 [CIntfTUsuObjArb] >>>
-- Aqu� se arma la estructura Padre Hijo de la p�gina web.
-- Esta estructura es la que permite hacer la p�gina seg�n los estandares html5
-- Cuando la estructura tiene un Objeto Modelo, para hacer la estructura se busca en esta tablas sus definiciones
SELECT [ID]									-- Valor ID �nico que sirve de Padre e Hijo
      ,[IDFkCIntfTUsuObjArb_PadreID]		-- Valor ID del Padre, este es uno de los valores del [ID] de la fila anterior
      ,[ItemNivel]							-- Nivel dentro de la estructura Padre Hijo, va de 1 a infinito
      ,[ItemOrd]							-- Orden dentro del mismo nivel.
      ,[IDFkCIntfTUsuObj]					-- ID del Usuario Objeto surge de la tabla <<< Tabla 08 [CIntfTUsuObj] >>>
  FROM [BDCtral].[dbo].[CIntfTUsuObjArb]


-- ===================================================================================================================================================================
-- <<< Tabla 11 [CIntfTUsuObjProp] >>>
-- Aqu� se incorporan las propiedades que tienen los Elementos, Estilos.
-- Un elemento tiene una serie de propiedades que lo identifican y lo hacen �nico.
-- Cuando se inserta un elemento en la tabla <<< Tabla 08 [CIntfTUsuObj] >>>, las propiedades obligatorias se cargan autom�ticamente, eje: TagOpen, TagClose.
-- Luego las propiedades opcionales se cargan con el sentencia CintfPUsuObjPropABM.sql.
SELECT [ID]										-- Valor ID �nico que agrupa la �nica combinaci�n entre el Elemnto del Objeto Modulo y la Propiedad
      ,[IDFkCIntfTUsuObj_UsuObj]				-- ID del Elemento al que se insertar� la propiedad. Surge de <<< Tabla 04 [CIntfTObjMod] >>>
      ,[IDFkCintfTObjCodProp_UsuObjProp]		-- ID de la propiedad que se le asignar� al Elemento. Surge de<<< Tabla 03 [CintfTObjCodProp] >>>
      ,[UsuObjCodPropValor]						-- Valor �nico de la propiedad para ese elemento. Hay propiedades que tiene un valor fijo ya que se utilizan en el Servlet, eje: <html>, pero hay otras que las carga el usuario para el Objeto Modulo en particular. Eje: contenido dentro del estilo, dentro de los labels 
      ,[UsuObjCodPropOrden]						-- Orden en que se deber� escribir la propiedad en el elemento del Tag. Eje: primero se escribe el tag <label> y luego las propiedades que van dentro del mismo, como ID, name, form, etc.
      ,[IDFkCDiccTCod_UsuObjPropEst]			-- C�digo del estado del objeto. Valor en la tabla [CDiccTCodxIdiomas]
      ,[UsuObjPropFechaModif]					-- Fecha de carga y/o modificaci�n del objeto.
  FROM [BDCtral].[dbo].[CIntfTUsuObjProp]


-- ===================================================================================================================================================================
-- <<< Tabla 12 [CIntfTUsuObjArbWeb] >>>
-- Contiene las p�ginas web del sistema
-- esta tabla se inserta con la sentencia SQL CIntfPUsuObjArbWebABM.sql.
-- Aqu� se arma la estructura Padre Hijo de la p�gina web.
-- Esta estructura es la que permite hacer la estructura de la p�gina
-- Cuando la estructura tiene un Objeto Modelo, para hacer la estructura se busca en esta tablas sus definiciones
SELECT [EstOrden]
      ,[ArbolID]
      ,[ArbolDesc]
      ,[IDFkCIntfTUsuModObjArb]
      ,[ArbolNivel]
      ,[IDFkCIntfTObjCod]
      ,[IntfTObjCod]
      ,[IDFkCIntfTObjUsuMod]
      ,[ObjUsuModCodUnico]
      ,[ObjUsuModCodDescFuncion]
      ,[ArbItemNivel]
      ,[ArbItemOrd]
      ,[ObjCodPropOrden]
      ,[IDFkCIntfTObjCodProp]
      ,[IDFkCIntfTUsuObjModProp]
      ,[Codigo]
      ,[IDFkObjCodPropUbic]
      ,[ObjCodPropUbicCod]
  FROM [BDCtral].[dbo].[CIntfTUsuObjArbWeb]



-- *************************
-- OBJETOS USUARIOS - PADRE
-- *************************
-- ===================================================================================================================================================================
-- Muestra los Objetos Usuario Padre, esto surgen de ejecutar el <<< Procedimiento Almacenado 02 [CIntfPCodxIdio] >>>
-- el mismo esta en el archivo ### Sentencia SQL CIntfPCodxIdio.sql ###
-- En Ambitos de Aplicaci�n es '7C2D7297-34DE-4F10-8F70-ACD26E5AFB04'	PagWeb	contiene las pagina web de la aplicacion.
-- el idioma es el definido por el usuario.
DECLARE	@return_value int
EXEC	@return_value = [dbo].[CIntfPCodxIdio]
			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
			-- Ambito de Aplicaci�n elegido o por defecto = NULL
			,@PAR2 = '7C2D7297-34DE-4F10-8F70-ACD26E5AFB04'		--	PagWeb	contiene las pagina web de la aplicacion.

				--	B1E3B2FA-A308-41BC-BF59-7664A6380CE3	PagInic001	p�gina inicial
				--	9A01BFBA-6DFE-4BFA-AFD3-6A8F4044B97B	PagInic002	pagina segunda
				--	7C2D7297-34DE-4F10-8F70-ACD26E5AFB04	PagWeb	contiene las pagina web de la aplicacion.

-- ================================================================================================================================================================
-- <<< Sentencia SQL 10 CintfPUsuObjABM_Padre_Ejec.sql >>>
-- esta sentencia ejecuta el procedimiento almacenado CintfPUsuObjABM_Padre, para crea las nuevas P�ginas
-- Esta sentencia se utiliza para dar de alta/Baja/Modif los elementos en las tablas <<< Tabla 01 [CIntfTObjCod] >>> y <<< Tabla 02 [CIntfTObjCodxIdio] >>>
-- El Padre se da de alta en la tabla [CIntfTObjCod] y [CIntfTObjCodxIdio], luego se incorpora en la tabla [CIntfTUsuObjArb].
-- Esto se incorpora en el ambito de aplicaci�n:
					-- 7C2D7297-34DE-4F10-8F70-ACD26E5AFB04		PagWeb		contiene las pagina web de la aplicacion.
-- Este procedimiento afecta las tablas [CIntfTObjCod], [CIntfTObjCodxIdio], [CIntfTUsuObjArb]

-- Se 10 variables pero las claves son:
--					@PAR1 = ALTA - MODIFICACION - BAJA - RECUPERO
--					@PAR2 = NEWID()
--					@PAR3 = Idioma Elegido
--					@PAR4 = Ambito de Aplicaci�n, siempre se utiliza '7C2D7297-34DE-4F10-8F70-ACD26E5AFB04'		PagWeb		contiene las pagina web de la aplicacion.
--					@PAR5 = C�digo de la p�gina. Para un �mbito de aplicaci�n este c�digo no se puede repetir.
--					@PAR6 = Descripci�n de la p�gina.
--					@PAR7 = C�digo Web, que es el nombre de la pagina abreviada.-- [CodigoWeb] C�digo que sale como ID para armar la p�gina web.
--					@PAR8 = 'DCDF7DF1-14A0-4C31-ACB4-9B0A176406E3'					--	[IDFkCDiccTCod_ObjCodUbic]	determina si el objeto va dentro intag o fuera del tag outtag
							--	Para PagWeb -- No Aplica --  DCDF7DF1-14A0-4C31-ACB4-9B0A176406E3	no aplica		no aplica clasificacion
--					@PAR9 = Estado del elemento, Habilitado, Deshabilitado, Baja
--					@PAR10 = AltaCompleto (se genera el Alta en las dos Tablas <<< Tabla 01 [CIntfTObjCod] >>> y su descripci�n para el idioma est� en <<< Tabla 02 [CIntfTObjCodxIdio] >>>
--							o SoloCodxIdio. Para cuando el Objeto ya esta creado, solo se carga la descripci�n del nuevo idioma en <<< Tabla 02 [CIntfTObjCodxIdio] >>>

	-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	-- <<< Procedimiento Almacenado 15 [CintfPUsuObjArbBucleIDEstInic] >>>
	-- Muestra la estructura de una p�gina sin la incorporaci�n de los Objetos Modelos si los tuviera
	-- as� se puede definir el objeto Padre si se guiere insertar un Elemento y ObjModelo
		DECLARE	@return_value int
		DECLARE @Pag AS NVARCHAR(36)
	--	SET @Pag = '9A01BFBA-6DFE-4BFA-AFD3-6A8F4044B97B'	-- 	PagInic002	pagina segunda
		SET @Pag = 'B1E3B2FA-A308-41BC-BF59-7664A6380CE3'	--	PagInic001	p�gina inicial
		EXEC	@return_value = [dbo].[CintfPUsuObjArbBucleIDEstInic]  @PAR1 = @Pag
		
				
-- *************************
-- OBJETOS USUARIOS - HIJOS
-- *************************
-- ===================================================================================================================================================================
-- <<< Sentencia SQL 11 CintfPUsuObjABM_Hijos_Ejec.sql >>>
-- esta sentencia ejecuta el procedimiento almacenado CintfPUsuObjABM_Hijos, para cargar los elementos u Objetos Modelos a las p�ginas
-- Trabaja con la tabla [CIntfTUsuObj], [CIntfTUsuObjArb] y [CIntfTUsuObjProp]
-- Para armar el objeto:
--			1.- Insertar el elemento en la tabla [CIntfTUsuObj]
--			2.- Insertar en la tabla [CIntfTUsuObjArb], la ubicaci�n del elemento en la estructura Padre / Hijo
--			3.- Insertar en la tabla [CIntfTUsuObjProp], las propiedades obligatorias del elemento
-- Dependiendo el tipo de Objeto si es o no contenedor de otros objetos, es el nivel que le da a los elemento.
-- El objeto Page, es el primer elemento, todos los otros estan dentro de la pagina.

-- Se 11 variables pero las claves son:
--					@PAR1 = ALTA - MODIFICACION - BAJA - RECUPERO
--					@PAR2 = Idioma Elegido
-- Crea los elementos asignados al objeto -- Tabla [CIntfTObjMod]
--					@PAR3 = ambito de aplicaci�n, 
--													se utiliza 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	--	ObjMod		contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
--													se utiliza 'AEFEA6F0-CC81-41AB-AD12-354A484273DA'	--	Ele			contiene los elementos de la pagina
--					@PAR4 = NEWID()	-- [ID] -- valor ID del nuevo Objeto [CIntfTUsuObj], debe ser �nico.
--					@PAR5 = codigo ID del Objeto -- [IDFkTIntCodObj] codigo ID del Objeto (Elemento u Objeto Modelo) que se insertar� en la p�gina.
							-- Elementos
--							DECLARE	@return_value int
--							EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D' -- N'AEFEA6F0-CC81-41AB-AD12-354A484273DA'		-- Ambito Aplicaci�n Elemento
--										-- Objetos Modelos 
--							DECLARE	@return_value int
--							EXEC	@return_value = [dbo].[CIntfPCodxIdio] @PAR2 = N'B890DD58-58BA-4DA3-8A0C-70422298A88D'		-- Ambito Aplicaci�n ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.

--					@PAR6 = C�digo del elemento. Este se genera autom�ticamente con el nombre codigo unico web (tabla [CIntfTObjCodxIdio]) y el nivel donde esta el elemento.
--					@PAR7 = NO se utiliza.-- [IntUsuObjCodUsuUnico] -- codigo unico del Objeto ingresado por el usuario.
--					@PAR8 = Descripci�n de la funci�n espec�fica del elemento dentro de la estructura Usuario Objeto.
-- Crea la Estructura Arbol -- Tabla [CIntfTUsuObjArb]
--					@PAR9 = C�digo ID unico del Objeto dentro de la estructura arbol
--					@PAR10 = ID del Padre, este valor es manual:
							-- 1.- En el caso que es el Padre Inicial, el ID viene de la tabla [CIntfTObjCod] y [CIntfTObjCodxIdio]
							-- 2.- En el caso de que otro elemento sea el padre, hay que buscar el ID, para incorporarlo como padre,
--					@PAR11 = 'c6fe2749-0cb8-49cd-97df-03c299c0c6cf'					-- [IDFkCxIEstados] -- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado

-- En esta sentencia se ejecuta el procedimiento almacenado [CintfPUsuObjArbWebABM] que arma la estructura Web de Usuario


-- Se insertan las propiedades obligatorias de los elemntos. 
-- Esto permite reducir significativamente el trabajo de agregar elementos y 
-- solo se utiliza <<< Sentencia SQL 06 CintfPUsuObjPropABM_Obligatoria.sql >>> para agregar las propiedades espec�ficas.
-- Con estas dos sentencias SQL, damos de alta a una estructura, sus elementos y las propiedades obligatorias, como son TagOpen, TagClose y alguna propiedad espec�fica del mismo.

-- la Sentencia SQL CintfPUsuObjPropABM_Obligatoria.sql, es solo informativa ya que esta contenida dentro -- <<< Sentencia SQL 16 CintfPUsuObjABM_Hijos.sql >>>


-- ===================================================================================================================================================================
-- <<< Sentencia SQL 12 CintfPUsuObjPropABM.sql >>>
-- Ahora hay que dar de alta las propiedades espec�ficas de los elementos. 
-- Trabaja con la tabla [CIntfUsuObj], [CIntfUsuObjArb]
-- Se 7 variables pero las claves son:
--					@PAR1 = ALTA - MODIFICACION - BAJA - RECUPERO
--					@PAR2 = NEWID()		[ID] tabla [CIntfTUsuObj]-- codigo ID �nico del objeto al que se le asignar�la propiedad.
--					@PAR3 = [IDFkTIntCodObj] -- codigo ID del ObjetoID que tiene la propiedad.
--					@PAR4 = [ID] tabla [CintfTObjCodProp] -- valor ID �nico de la Propiedad
--					@PAR5 = [ObjModCodPropValor] Como este valor lo puede colocar el usuario, se carga, si es NULL, se pone el de la tabla
--					@PAR6 = [ObjModCodPropOrden] orden en que se armara el TAG, surge de una consulta de la tabla [CintfVObjCodProp]
--					@PAR7 = Estado del elemento, Habilitado, Deshabilitado, Baja

		-- ===================================================================================================================================================================
		-- <<< Procedimiento Almacenado 16 [CIntfPUsuObjProp] >>>
		-- detalle de las Propiedades de los Usuario Objetos.
		-- surge de las tablas [CIntfTUsuObjProp], se relaciona con las tablas [CIntfTUsuObj], [CDiccTCodxIdiomas] y [CIntfTObjCodxIdio]
		-- Esto nos permite ver que propiedades tiene cada elemento, ya que las mismas no estan asociadas a las paginas, no tiene mucho significados.
			DECLARE	@return_value int
			DECLARE @PAR1 NVARCHAR(50) 
			SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
			EXEC @return_value = [dbo].[CIntfPUsuObjProp] @PAR1 = @PAR1


		-- borrar inicio
		---- ===================================================================================================================================================================
		---- <<< Procedimiento Almacenado [CintfPUsuObjBucleIDProp] >>>
		---- Muestra la estructura de una p�gina completa, con sus propiedades
		---- si la misma tiene ObjModelos, los reemplaza e incorpora las propiedades que tenga
		---- No esta finalizada
		--	DECLARE	@return_value int
		--	EXEC	@return_value = [dbo].[CintfPUsuObjBucleIDProp] 
		--			@PAR1 = '40924f56-d311-4690-a911-512a67c0f312' 
		--					-- 'b1e3b2fa-a308-41bc-bf59-7664a6380ce3'
		--					-- '40924f56-d311-4690-a911-512a67c0f312'
		---- IMPORTANTE: NO ESTA FINALIZADA
		-- borrar fin


-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<< Procedimiento Almacenado 17 [CintfPUsuObjBucleID] >>>
-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- IMPORTANTE: NO TIENE LOS OBJETOS MODELOS, SOLO LOS ELEMENTOS DIRECTOS
-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- el mismo esta en el archivo ### Sentencia SQL CintfPUsuObjBucleID.sql ###
-- Hace el bucle de la Vista [dbo].[CintfVUsuObjCodArb], que tiene la info del [CIntfTUsuObjArb] y el Padre surge de la tabla [CIntfTObjCod] y [CIntfTObjCodxIdio]
-- Solo se muestran los Elementos Direc
	DECLARE	@return_value int
	EXEC	@return_value = [dbo].[CintfPUsuObjArbBucleID]
		--	ID del Padre "Paginas" que a trabajar
--			 @PAR1 = 'B1E3B2FA-A308-41BC-BF59-7664A6380CE3'	--	PagInic001	p�gina inicial
			 @PAR1 = '9A01BFBA-6DFE-4BFA-AFD3-6A8F4044B97B'	--	PagInic002	pagina segunda
		--	Idioma elegido o por defecto = espa�ol
			,@PAR2 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'
 
				-- Los valores de las p�ginas disponibles surgen de la siguiente consulta
--					DECLARE	@return_value int
--					EXEC	@return_value = [dbo].[CIntfPCodxIdio]
--							-- Idioma elegido o por defecto = espa�ol
--								@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		
--							-- Ambito de Aplicaci�n
--								,@PAR2 = '7C2D7297-34DE-4F10-8F70-ACD26E5AFB04'		-- PagWeb	contiene las pagina web de la aplicacion.


-- ####################################################################################################################################################################
--	Resultado Final
-- ####################################################################################################################################################################
-- <<< Procedimiento Almacenado 18 [CintfPUsuObjArbWebABM] >>>
-- Ya finalizada la estructura de la p�gina, ejecuta el procedimiento almacenado [CintfPUsuObjArbWebABM]
-- Esto inserta en la tabla [CIntfTUsuObjArbWeb] la pagina web finalizada
	DECLARE	@return_value int
	DECLARE @Pag AS NVARCHAR(36)
	SET @Pag = 'B1E3B2FA-A308-41BC-BF59-7664A6380CE3'	--	PagInic001	p�gina inicial
--	SET @Pag = '9A01BFBA-6DFE-4BFA-AFD3-6A8F4044B97B'	--	PagInic002	pagina segunda
	EXEC	@return_value = [dbo].[CintfPUsuObjArbWebABM] @PAR1 = @Pag

-- ####################################################################################################################################################################
-- <<< Procedimiento Almacenado 19 [CIntfPUsu] >>>
-- Consulta con la informaci�n relevante para ejecutar la p�gina web
-- surge de la consulta [CIntfTUsuObjArbWeb] vinculada con las Propiedades de los elementos que surgen de la vista [CIntfVObjUsuModProp]
--DECLARE	@return_value int
EXEC	@return_value = [dbo].[CIntfPUsu] @PAR1 = @Pag




