-- #########################################################################################################################################################
--  GENERA LOS PROCEDIMIENTOS ALMACENADOS PARA HACER EL ALTA, MODIFICACION, BAJA O RECUPERO DEL OBJETO MODELO -- 
-- #########################################################################################################################################################
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- Determina la base de datos donde se trabajar�
USE [BDCtral]
GO

-- ===================================================
-- Author: Juan Petri
-- Create date: 18/12/2018
-- Description:	Crea Nuevos Elementos HTML
-- ===================================================

	DECLARE	@return_value int
	DECLARE @PARint1 AS uniqueidentifier		-- ID Nuevo
	DECLARE @PARint5 AS NVARCHAR(50)			-- [Codigo], debe ser �nico
	DECLARE @PARint6 AS NVARCHAR(250)			-- Descripcion del codigo
	DECLARE @PARint7 AS NVARCHAR(50)		-- [CodigoWeb] para PagWeb -- siempre debe ser incorporado, la abreviatura sin numeros

	SET @PARint1 = NEWID()
	DECLARE @PARIdio AS NVARCHAR(36)			-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito

	-- Define las variables que se cambian
		-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
		SET @PARIdio = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		

		-- [Codigo], debe ser �nico
		SET @PARint5 = 'PrLgIU05'	
		-- Descripcion del codigo
		SET @PARint6 = 'Proceso Login Interfaz Usuario Usu-Blo'	
		-- [CodigoWeb] para PagWeb -- siempre debe ser incorporado, la abreviatura sin numeros
		SET @PARint7 = 'PrLgIU05'


	-- Ejecuta el Procedimiento Almacenado
	EXEC @return_value = [dbo].[CintfPUsuObjABM_Padre]
			-- ALTA - MODIFICACION - BAJA - RECUPERO
				@PAR1 = 'ALTA'					

			-- [ID] Valor Unico de la Tabla [CIntfTObjCod]
				,@PAR2 = @PARint1				

			-- [IDFkTCDiccTIdio_Idioma], codigo ID �nico del objeto al que se le asignar�la propiedad.
				,@PAR3 = @PARIdio		-- Idioma espa�ol por defecto

			-- [IDFkTCIntfTObjCod_AmbAplic], Ambito de Aplicaci�n: PagWeb, contiene las pagina web de la aplicacion.
				,@PAR4 = '7C2D7297-34DE-4F10-8F70-ACD26E5AFB04'		
	
			-- [Codigo], debe ser �nico
				,@PAR5 = @PARint5	

			-- Descripcion del codigo
				,@PAR6 = @PARint6	

			-- [CodigoWeb] para PagWeb -- siempre debe ser incorporado, la abreviatura sin numeros					
				,@PAR7 = @PARint7

			-- [IDFkCDiccTCod_ObjCodUbic], No aplica para PagWeb, determina si el objeto va dentro intag o fuera del tag outtag
				,@PAR8 = 'DCDF7DF1-14A0-4C31-ACB4-9B0A176406E3'		

			-- ID del estado del c�digo.
				,@PAR9 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'		-- Habilitado		

			-- Tipo de alta
				,@PAR10 = 'AltaCompleto'

--	Muestra los resultados
--DECLARE	@return_value int
EXEC	@return_value = [dbo].[CIntfPCodxIdio]
			@PAR1 = @PARIdio	-- Idioma elegido o por defecto = espa�ol
			-- Ambito de Aplicaci�n elegido o por defecto = NULL
			,@PAR2 = '7C2D7297-34DE-4F10-8F70-ACD26E5AFB04'		--	PagWeb	contiene las pagina web de la aplicacion.

