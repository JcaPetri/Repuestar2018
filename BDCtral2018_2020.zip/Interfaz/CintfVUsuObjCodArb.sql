set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO

	SELECT UOA.[ID] 
		  ,UOA.[IDFkCIntfTUsuObjArb_PadreID]
		  ,UOA.[ItemNivel]
		  ,UOA.[ItemOrd]
		  ,CASE WHEN UO.[IDFkCIntfTObjCod_UsuObjCod] IS NULL THEN CxI2.[IDFkTCIntfTObjCod_CodxIdio] ELSE UO.[IDFkCIntfTObjCod_UsuObjCod] END AS 'IDFkCIntfTObjCod_UsuObjCod'
		  ,CASE WHEN UO.[IDFkCIntfTObjCod_UsuObjCod] IS NULL THEN CxI2.[Codigo] ELSE CxI1.[Codigo] END AS 'IDFkCIntfTObjCod_UsuObjCodDesc'
		  ,UOA.[IDFkCIntfTUsuObj]
		  ,CASE WHEN UO.[IntUsuObjCodUnico] IS NULL THEN CxI2.[Codigo] ELSE UO.[IntUsuObjCodUnico] END AS 'IntUsuObjCodUnico'
		  ,CASE WHEN UO.[IntUsuObjCodDescFuncion] IS NULL THEN CxI2.[Descripcion] ELSE UO.[IntUsuObjCodDescFuncion] END AS 'IntUsuObjCodDescFuncion'
		  ,CASE WHEN UO.[IDFkCDiccTCod_UsuObjEst] IS NULL THEN CxI2.[IDFkCDiccTCod_ObjCodxIdioEst] ELSE UO.[IDFkCDiccTCod_UsuObjEst] END AS 'IDFkCDiccTCod_UsuObjEst'
		  ,CASE WHEN CxI1.[IDFkTCDiccTIdio_Idioma] IS NULL THEN CxI2.[IDFkTCDiccTIdio_Idioma] ELSE CxI1.[IDFkTCDiccTIdio_Idioma] END AS 'IDFkTCDiccTIdio_Idioma'
		  ,CASE WHEN CxI1.[IDFkTCIntfTObjCod_AmbAplic] IS NULL THEN CxI2.[IDFkTCIntfTObjCod_AmbAplic] ELSE CxI1.[IDFkTCIntfTObjCod_AmbAplic] END AS 'IDFkTCIntfTObjCod_AmbAplic'
--		  ,'|' AS '|', CxI1.*
	  FROM [BDCtral].[dbo].[CIntfTUsuObjArb] AS UOA WITH (NOLOCK) 
		-- Informaci�n de los Elementos que estan en la tabla UsuObj, como es un elemento, primero debi ir a la tabla [CIntfTUsuObj] y se ah� buscar la descripci�n
		LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTUsuObj] AS UO WITH (NOLOCK) 
			ON UOA.[IDFkCIntfTUsuObj] = UO.[ID]
				-- Descripci�n del elemento IDFkCIntfTObjCod
				LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTObjCodxIdio] AS CxI1 WITH (NOLOCK) 
					ON UO.[IDFkCIntfTObjCod_UsuObjCod] = CxI1.[IDFkTCIntfTObjCod_CodxIdio]
						AND ('ABEDD291-3991-4A47-8AEB-82580BF6BA8C' = CxI1.[IDFkTCIntfTObjCod_AmbAplic]		-- Css		contiene todos los estilos posibles de la pagina y los elementos
									OR
								'AEFEA6F0-CC81-41AB-AD12-354A484273DA' = CxI1.[IDFkTCIntfTObjCod_AmbAplic]	-- Ele		contiene los elementos de la pagina
									OR
								'B890DD58-58BA-4DA3-8A0C-70422298A88D' = CxI1.[IDFkTCIntfTObjCod_AmbAplic]	-- ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
									OR 
								'7C2D7297-34DE-4F10-8F70-ACD26E5AFB04' = CxI1.[IDFkTCIntfTObjCod_AmbAplic])	-- PagWeb	contiene las pagina web de la aplicacion.
		-- Descripci�n del elemento, Ya que el Mismo es un Objeto Modelo, directamente se vincula con la tabla [CIntfTObjCodxIdio]
		LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTObjCodxIdio] AS CxI2 WITH (NOLOCK) 
			ON UOA.[IDFkCIntfTUsuObj]  = CxI2.[IDFkTCIntfTObjCod_CodxIdio]
				AND ('ABEDD291-3991-4A47-8AEB-82580BF6BA8C' = CxI2.[IDFkTCIntfTObjCod_AmbAplic]		-- Css		contiene todos los estilos posibles de la pagina y los elementos
							OR
						'AEFEA6F0-CC81-41AB-AD12-354A484273DA' = CxI2.[IDFkTCIntfTObjCod_AmbAplic]	-- Ele		contiene los elementos de la pagina
							OR
						'B890DD58-58BA-4DA3-8A0C-70422298A88D' = CxI2.[IDFkTCIntfTObjCod_AmbAplic]	-- ObjMod	contiene las objetos Modelos que forman parte de las paginas web de la aplicacion.
							OR 
						'7C2D7297-34DE-4F10-8F70-ACD26E5AFB04' = CxI2.[IDFkTCIntfTObjCod_AmbAplic])	-- PagWeb	contiene las pagina web de la aplicacion.
