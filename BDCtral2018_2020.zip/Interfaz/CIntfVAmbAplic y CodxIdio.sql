USE [BDCtral]
GO

DECLARE	@return_value int

 EXEC	@return_value = [dbo].[CIntfPAmbAplic]
EXEC	@return_value = [dbo].[CIntfPCodxIdio]

GO
