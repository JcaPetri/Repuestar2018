set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO
SELECT UO.[ID] AS [IDUsuObj]
      ,UO.[IDFkTIntCodObj]
      ,UO.[IntUsuCodUnico]
      ,UO.[IntUsuCodUsuUnico]
      ,UO.[IntUsuDescFuncion]
      ,UO.[IDFkCxIEstados] AS [UObjEstado]
      ,UO.[TItemFechaModif] AS [UObjFechaModif]
	  ,UOP.[ID] AS [IDUsuObjProp]
--      ,UOP.[IDFkTIntfUsuObj]
      ,UOP.[IDFkTIntCodObjProp]
	  ,OCP.[IDFkTCodObjProp]
	  ,OCxI.[Codigo]
	  ,OCxI.[IDFkTCodAmbAplic]
      ,UOP.[IntObjValor]
      ,UOP.[IntObjOrden]
      ,UOP.[IDFkCxIEstados] AS [UOPropEstado]
      ,UOP.[TUsuObjCodProFechaModif] AS [UOPropFechaModif]
  FROM [BDCtral].[dbo].[CIntfTUsuObj] AS UO WITH(NOLOCK)
	LEFT OUTER JOIN [BDCtral].[dbo].[CIntfTUsuObjProp] AS UOP WITH(NOLOCK)
		ON UO.[ID] = UOP.[IDFkTIntfUsuObj]
			INNER JOIN [BDCtral].[dbo].[CintfTObjCodProp] AS OCP WITH(NOLOCK)
				ON UOP.[IDFkTIntCodObjProp] = OCP.[ID]
					INNER JOIN [BDCtral].[dbo].[CIntfTObjCodxIdio] AS OCxI WITH(NOLOCK)
						ON OCP.[IDFkTCodObjProp] = OCxI.[IDFkTIntCodigos]
WHERE OCP.[IDFkTCodObjProp] = 'D46E782C-80AC-4162-BDAB-94766A18FE78'		-- TagOpen
	OR OCP.[IDFkTCodObjProp] = 'B328283E-EF57-427F-A936-B0935AE5F679'		-- TagClose
ORDER BY UO.[ID]
