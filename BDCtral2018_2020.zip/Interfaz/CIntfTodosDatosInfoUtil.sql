USE [BDCtral]
GO
	DECLARE	@return_value int
-- ####################################################################################################################################################################
-- ####################################################################################################################################################################
-- CONSULTAS CON INFORMACI�N �TIL PARA EL MODULO
-- ####################################################################################################################################################################
-- ####################################################################################################################################################################
-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-- Detalle las p�ginas disponibles, para el modulo Central Interfaz Objetos
-- surge de la combinaci�n de las tablas [CIntfTObjCod] y [CIntfTObjCodxIdio]
	DECLARE	@return_value int
	DECLARE @PARint01 NVARCHAR(50) 		-- Idioma elegido o por defecto = espa�ol
	DECLARE @PARint02 NVARCHAR(50)		-- Ambito de Aplicaci�n elegido o por defecto = NULL
	SET @PARint01 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'	-- Idioma elegido o por defecto = espa�ol
	SET @PARint02 = '7C2D7297-34DE-4F10-8F70-ACD26E5AFB04'	-- Ambito de Aplicaci�n P�ginas Webs

	EXEC @return_value = [dbo].[CIntfPCodxIdio]	@PAR1 = @PARint01, 	@PAR2 = @PARint02


-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-- Detalle los Objetos Modelos disponibles, para el modulo Central Interfaz Objetos
-- surge de la combinaci�n de las tablas [CIntfTObjCod] y [CIntfTObjCodxIdio]
	DECLARE	@return_value int
	DECLARE @PARint01 NVARCHAR(50) 		-- Idioma elegido o por defecto = espa�ol
	DECLARE @PARint02 NVARCHAR(50)		-- Ambito de Aplicaci�n elegido o por defecto = NULL
	SET @PARint01 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'	-- Idioma elegido o por defecto = espa�ol
	SET @PARint02 = 'B890DD58-58BA-4DA3-8A0C-70422298A88D'	-- Ambito de Aplicaci�n Objetos Modelos

	EXEC @return_value = [dbo].[CIntfPCodxIdio]	@PAR1 = @PARint01, 	@PAR2 = @PARint02


-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-- Detalle los Usuarios Objetos disponibles, para el modulo Central Interfaz Objetos
-- surge de la combinaci�n de las tablas [CIntfTObjCod] y [CIntfTObjCodxIdio]
	DECLARE	@return_value int
	DECLARE @PARint01 NVARCHAR(50) 		-- Idioma elegido o por defecto = espa�ol
	DECLARE @PARint02 NVARCHAR(50)		-- Ambito de Aplicaci�n elegido o por defecto = NULL
	SET @PARint01 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'	-- Idioma elegido o por defecto = espa�ol
	SET @PARint02 = '540C0AB8-CFCA-4346-AC40-D159787DAEA2'	-- Ambito de Aplicaci�n Usuarios Objetos

	EXEC @return_value = [dbo].[CIntfPCodxIdio]	@PAR1 = @PARint01, 	@PAR2 = @PARint02


-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-- Detalle los elementos disponibles, para el modulo Central Interfaz Objetos
-- surge de la combinaci�n de las tablas [CIntfTObjCod] y [CIntfTObjCodxIdio]
	DECLARE	@return_value int
	DECLARE @PARint01 NVARCHAR(50) 		-- Idioma elegido o por defecto = espa�ol
	DECLARE @PARint02 NVARCHAR(50)		-- Ambito de Aplicaci�n elegido o por defecto = NULL
	SET @PARint01 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'	-- Idioma elegido o por defecto = espa�ol
	SET @PARint02 = 'AEFEA6F0-CC81-41AB-AD12-354A484273DA'	-- Ambito de Aplicaci�n elementos

	EXEC @return_value = [dbo].[CIntfPCodxIdio]	@PAR1 = @PARint01, 	@PAR2 = @PARint02


-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-- Detalle las propiedades disponibles, para el modulo Central Interfaz Objetos
-- surge de la combinaci�n de las tablas [CIntfTObjCod] y [CIntfTObjCodxIdio]
	DECLARE	@return_value int
	DECLARE @PARint01 NVARCHAR(50) 		-- Idioma elegido o por defecto = espa�ol
	DECLARE @PARint02 NVARCHAR(50)		-- Ambito de Aplicaci�n elegido o por defecto = NULL
	SET @PARint01 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'	-- Idioma elegido o por defecto = espa�ol
	SET @PARint02 = '9B491CCE-47A1-4F7A-AEAC-FD30F5E2999B'	-- Ambito de Aplicaci�n las propiedades

	EXEC @return_value = [dbo].[CIntfPCodxIdio]	@PAR1 = @PARint01, 	@PAR2 = @PARint02



-- <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-- Detalle los estilos disponibles, para el modulo Central Interfaz Objetos
-- surge de la combinaci�n de las tablas [CIntfTObjCod] y [CIntfTObjCodxIdio]
	DECLARE	@return_value int
	DECLARE @PARint01 NVARCHAR(50) 		-- Idioma elegido o por defecto = espa�ol
	DECLARE @PARint02 NVARCHAR(50)		-- Ambito de Aplicaci�n elegido o por defecto = NULL
	SET @PARint01 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'	-- Idioma elegido o por defecto = espa�ol
	SET @PARint02 = 'ABEDD291-3991-4A47-8AEB-82580BF6BA8C'	-- Ambito de Aplicaci�n los estilos

	EXEC @return_value = [dbo].[CIntfPCodxIdio]	@PAR1 = @PARint01, 	@PAR2 = @PARint02
