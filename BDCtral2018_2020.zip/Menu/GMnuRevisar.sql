set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

USE [BDGral]
GO

SELECT MP.[ID]
      ,MP.[IDFkTMnuItems]
      ,MP.[IDFkTPerfil]
	  ,MI.[MnuItems]
      ,MI.[ItemNivel]
      ,MI.[IDFkCodMenu]
      ,MI.[ItemCod]
      ,MI.[ItemVinculo]
  FROM [BDGral].[dbo].[GMnuPerfil] AS MP WITH(NOLOCK)
	INNER JOIN [BDGral].[dbo].[GMnuItems] AS MI WITH(NOLOCK)
		ON MP.[IDFkTMnuItems] = MI.[ID]
ORDER BY MP.[IDFkTPerfil]



SELECT *  FROM [BDGral].[dbo].[GMnuPerfil] AS MP WITH(NOLOCK)


SELECT [ID]
      ,[MnuItems]
      ,[ItemNivel]
      ,[IDFkCodMenu]
      ,[ItemCod]
      ,[ItemVinculo]
      ,[GRLM010_ITMVINIZ]
      ,[GRLM010_ITMVINDE]
      ,[GRLM010_ITMMSGM]
      ,[GRLM010_ITMTARG]
      ,[ItemEstado]
      ,[GRLM010_ITMSTYL]
      ,[GRLM010_SUBMNSTY]
      ,[SubItems]
  FROM [BDGral].[dbo].[GMnuItems]