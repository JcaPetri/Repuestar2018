set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

USE [BDGral]
GO


	DECLARE @PAR1 NVARCHAR(50) 
	DECLARE @PAR2 NVARCHAR(50) 
	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	SET @PAR2 = NULL										-- Ambito de Aplicaci�n elegido o por defecto = NULL

	DECLARE @TmpTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)


	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDGral].[dbo].[GDicTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDGral].[dbo].[GDicTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1
				AND
			  CxI.[IDFkTCodAmbAplic] = CASE WHEN @PAR2 IS NULL THEN CxI.[IDFkTCodAmbAplic] ELSE @PAR2 END

	-- Muestra los perfiles de usuario
	SELECT UP.[ID]
		  ,UP.[IDFkPerfilTipo]
		  ,Cd01.[Codigo] AS [IdiomaCod]
		  ,Cd01.[Descripcion] AS [IdiomaDesc]
		  ,UP.[IDFkPerfil]
		  ,Cd02.[Codigo] AS [CodigoAmbitoAplic]
		  ,Cd02.[Descripcion] AS [CodDescAmbitoAplic]
		  ,Cd01.CodIdioma AS [IdiomaCod]
		  ,Cd01.DescIdioma AS [IdiomaDesc]
	  FROM [BDGral].[dbo].[GUsuTPerfil] AS UP WITH (NOLOCK)
			INNER JOIN @TmpTCodxIdi AS Cd01			-- Detalle del C�digo
				ON UP.[IDFkPerfilTipo] = Cd01.[IDFkTCodigos]
			INNER JOIN @TmpTCodxIdi AS Cd02			-- Detalle del Ambito de Aplicaci�n
				ON UP.[IDFkPerfil] = Cd02.[IDFkTCodigos]