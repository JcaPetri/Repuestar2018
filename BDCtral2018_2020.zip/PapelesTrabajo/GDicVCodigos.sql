-- Muestra los c�digos con su descripci�n por cada idioma
SELECT [ID] AS [IDgdicTCodigos]
		, Cd.[IDgdicTIdioma]
		, Cd.[Codigo]
		, Cd.[Descripcion]
		, Cd.IdiCod
		, Cd.Idioma
FROM [BDGral].[dbo].[GDicTCodigos] AS Cod WITH (NOLOCK)
	LEFT OUTER JOIN (
					SELECT CxI.[IDgdicTCodigos]
						  ,CxI.[IDgdicTIdioma]
						  ,CxI.[Codigo]
						  ,CxI.[Descripcion]
						  ,Idi.[CodIdioma] AS IdiCod
						  ,Idi.[DescIdioma] AS Idioma
					  FROM [BDGral].[dbo].[GDicTCodIdiomas] AS CxI WITH (NOLOCK) 
							INNER JOIN [BDGral].[dbo].[GDicTIdioma] AS Idi WITH (NOLOCK) 
								ON CxI.[IDgdicTIdioma] = Idi.[ID]
					) AS Cd
		ON Cod.[ID] = Cd.[IDgdicTCodigos]
--WHERE Idi.[CodIdioma] = 'ITA'

-- Info Taabla Codigos
SELECT * FROM [BDGral].[dbo].[GDicTCodigos] AS Cod  WITH (NOLOCK)
-- Info Tabla CodIdiomas
SELECT * FROM [BDGral].[dbo].[GDicTCodIdiomas] AS CxI WITH (NOLOCK)
-- Info Tabla 
SELECT * FROM [BDGral].[dbo].[GDicTIdioma] AS Idi WITH (NOLOCK)
