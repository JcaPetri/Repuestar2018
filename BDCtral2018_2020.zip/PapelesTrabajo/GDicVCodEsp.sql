-- Muestra los c�digos con su descripci�n para el Idioma Espa�ol
SELECT CxI.[IDgdicTCodigos]
      ,CxI.[IDgdicTIdioma]
      ,CxI.[Codigo]
      ,CxI.[Descripcion]
	  ,Idi.[CodIdioma] AS IdiCod
      ,Idi.[DescIdioma] AS Idioma
  FROM [BDGral].[dbo].[GDicTCodIdiomas] AS CxI WITH (NOLOCK) 
		INNER JOIN [BDGral].[dbo].[GDicTIdioma] AS Idi WITH (NOLOCK) 
			ON CxI.[IDgdicTIdioma] = Idi.[ID]
WHERE Idi.CodIdioma = 'ESP'
