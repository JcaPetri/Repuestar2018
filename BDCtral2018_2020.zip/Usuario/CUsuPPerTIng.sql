set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

USE [BDCtral]
GO

-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 03/10/2018
-- Description:	Para una emprsa muestra la relacion entre:
--										  los usuarios y sus Perfiles
--										  los usuarios y sus Acceso Procesos.
-- =============================================
ALTER PROCEDURE [dbo].[CUsuPPerTIng]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(36) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 NVARCHAR(36) = NULL										-- Empresa seleccionada
	,@PAR3 NVARCHAR(36) = NULL										-- Usuario seleccionado
	,@PAR4 NVARCHAR(36) = NULL										-- TipoTabla, especifica si busca los Perfiles o el Acceso a los Procesos
AS
BEGIN

--	DECLARE @PAR1 NVARCHAR(36)								-- Idioma elegido o por defecto = espa�ol
--	DECLARE @PAR2 NVARCHAR(36)								-- Empresa seleccionada
--	DECLARE @PAR3 NVARCHAR(36)								-- Usuario seleccionado
--	DECLARE @PAR4 NVARCHAR(36)								-- Usuario seleccionado
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR2 = NULL										-- BPM	Business Process Managment
--	SET @PAR3 = NULL										-- Usuario seleccionado
--	SET @PAR4 = NULL										-- TipoTabla, especifica si busca los Perfiles o el Acceso a los Procesos

	DECLARE	@return_value int

	DECLARE @TmpTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[cDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1

--		SELECT * FROM @TmpTCodxIdi WHERE [IDFkTCodigos] = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'

	--	 Los Usuarios y sus perfiles
	SELECT PTI.[IDFkTUsuarios]
		  ,TU.[UsuCod]
		  ,TU.[UsuAbr]
		  ,TU.[UsuApellido]
		  ,TU.[UsuNombre]
		  ,TU.[UsuClave]
		  ,TU.[UsuEmail]
		  ,PTI.[IDFkTEmpresa]
		  ,CxI1.[Codigo] AS [EmpCod]
		  ,CxI1.[Descripcion] AS [EmpDesc]
		  ,PTI.[IDFkTTipoTabla]
		  ,CxI2.[Codigo] AS [TablaCod]
		  ,CxI2.[Descripcion] AS [TablaDesc]
		  ,PTI.[IDFkTPerfilAccProc]
		  ,CxI3.[Codigo] AS [PerfCod]
		  ,CxI3.[Descripcion] AS [PerfDesc]
	  FROM [BDCtral].[dbo].[CUsuTPerfTIng] AS PTI WITH(NOLOCK)
		LEFT OUTER JOIN [BDCtral].[dbo].[CUsuTUsuarios] AS TU WITH(NOLOCK)
			ON PTI.[IDFkTUsuarios] = TU.[ID]
		LEFT OUTER JOIN @TmpTCodxIdi AS CxI1
			ON PTI.[IDFkTEmpresa] = CxI1.[IDFkTCodigos]
		LEFT OUTER JOIN @TmpTCodxIdi AS CxI2
			ON PTI.[IDFkTTipoTabla] = CxI2.[IDFkTCodigos]
		LEFT OUTER JOIN @TmpTCodxIdi AS CxI3
			ON PTI.[IDFkTPerfilAccProc] = CxI3.[IDFkTCodigos]
	  WHERE PTI.[IDFkTEmpresa] = CASE WHEN @PAR2 IS NULL THEN PTI.[IDFkTEmpresa] ELSE @PAR2 END
				AND	PTI.[IDFkTUsuarios] = CASE WHEN @PAR3 IS NULL THEN PTI.[IDFkTUsuarios] ELSE @PAR3 END
				AND	PTI.[IDFkTTipoTabla] = CASE WHEN @PAR4 IS NULL THEN PTI.[IDFkTTipoTabla] ELSE @PAR4 END
END

---- Info de la tabla [CUsuPPerTIng], donde esta el resumen de todo el resultado del Modulo Acceso
--	DECLARE	@return_value int
--	EXEC @return_value = [dbo].[CUsuPPerTIng]				-- Tabla 07 -- Relacion entre los Usuarios Agrupados y los Perfiles Agrupados
--			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--			,@PAR2 = NULL		-- '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- Emrpesa	BPM	Business Process Managment
--			,@PAR3 = NULL		-- 'D3AE6446-4D7B-474B-ACF0-E9A75A233BC6'		-- Usuario	ANONIMO
--			,@PAR4 = NULL		-- TipoTabla, especifica si busca los Perfiles o el Acceso a los Procesos
						--	'69752B6B-9B31-402B-83DC-4E945DF7879C'	--	CPerfTPerfil
						--	'50E6A111-D9BE-4CF7-9115-69A1294EACAB'	--	CPerfTAccesoProcesos




