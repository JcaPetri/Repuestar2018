set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

USE [BDCtral]
GO


-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 30/09/2018
-- Description:	Detalle de los perfiles del sistema
-- =============================================
ALTER PROCEDURE [dbo].[CPerfPPerfAccProc]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 NVARCHAR(50) = NULL										-- Empresa
AS
BEGIN

--	DECLARE @PAR1 NVARCHAR(50)								-- Idioma elegido o por defecto = espa�ol
--	DECLARE @PAR2 NVARCHAR(50)								-- Empresa Seleccionada
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment


	-- Add the parameters for the stored procedure here
--	DECLARE @PAR1 NVARCHAR(50) 
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	DECLARE @PARInt1 NVARCHAR(50)		-- Ambito de Aplicacion elegido GPerTPerfiles  = Tabla con los perfiles
	DECLARE @PARInt2 NVARCHAR(50)		-- Ambito de Aplicaci�n elegido GPerfTAgrup = Tabla perfiles agrupados
	SET @PARInt1 = '50E6A111-D9BE-4CF7-9115-69A1294EACAB'		-- CPerfTAccesoProcesos	tabla acceso a los procesos del sistema
	SET @PARInt2 = '69752B6B-9B31-402B-83DC-4E945DF7879C'		-- CPerfTPerfil	tabla perfiles de usuarios agrupados

	DECLARE @TmpTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1

--		SELECT * FROM @TmpTCodxIdi

	-- Muestra los grupos de perfiles, esto surge de la relaci�n entre las tablas Virtuales:
	-- GPerTPerfiles y GPerfTAgrup.
	-- (Surgen de las tablas TCodigo y TCodxIdioma, ya que tiene la misma estructura).
	-- En el �mbito de aplicaci�n se pone el c�digo de GPerTPerfiles o GPerfTAgrup como si fuera el nombre de la tabla.

	-- Un perfil puede pertenecer a varios grupos y Un grupo puede tener varios perfiles

	-- Aqui esta la relacion desde el Perfil hasta el PerfilAgrupado. 
	-- Este ultimo es el que se vincula con los objetos del sistema.

	SELECT TC1.[IDFkCodEmpresas]
			,CxI1.[Codigo] AS [EmpCodigo]
			,CxI1.[Descripcion] AS [EmpDesc]
			,PA.[IDFkTCDiccTCod_Perfil]
			,PAgr.[Codigo] AS [PerfilCod]
			,PAgr.[Descripcion] AS [PerfilDesc]
			,PA.[IDFkTCDiccTCod_AccProc]
			,Perf.[Codigo] AS [AccProcCod]
			,Perf.[Descripcion] AS [AccProcDesc]
--			,Perf.[CodIdioma]
--			,Perf.[Descidioma]
	FROM [BDCtral].[dbo].[CPerfTAccProcPerfil] AS PA WITH(NOLOCK)		-- Tabla con la relacion entre los Perfiles Agrupados y los Usuarios Agrupados
		LEFT OUTER JOIN  @TmpTCodxIdi AS Perf 
			ON Perf.[IDFkTCodigos] = PA.[IDFkTCDiccTCod_AccProc]
					AND
			   Perf.[IDFkTCodAmbAplic] = @PARInt1		-- GPerTPerfiles
		LEFT OUTER JOIN [BDCtral].[dbo].[CDiccTCodigos] AS TC1 WITH(NOLOCK)
			ON PA.[IDFkTCDiccTCod_Perfil] = TC1.[ID]
				LEFT OUTER JOIN @TmpTCodxIdi AS CxI1
					ON TC1.[IDFkCodEmpresas] = CxI1.[IDFkTCodigos]
						-- Trae el c�digo de la empresa seleccionada y el multiidioma
						AND (TC1.[IDFkCodEmpresas] = CASE WHEN @PAR2 IS NULL THEN TC1.[IDFkCodEmpresas] ELSE @PAR2 END 
								OR TC1.[IDFkCodEmpresas] = 'A5E49ED6-EFDD-4C43-955F-7F3616E39F99')
		LEFT OUTER JOIN  @TmpTCodxIdi AS PAgr 
			ON PAgr.[IDFkTCodigos] = PA.[IDFkTCDiccTCod_Perfil]
					AND
			   PAgr.[IDFkTCodAmbAplic] = @PARInt2		-- GPerfTAgrup
		LEFT OUTER JOIN [BDCtral].[dbo].[CDiccTCodigos] AS TC2 WITH(NOLOCK)
			ON PA.[IDFkTCDiccTCod_AccProc] = TC2.[ID]
				LEFT OUTER JOIN @TmpTCodxIdi AS CxI2
					ON TC2.[IDFkCodEmpresas] = CxI2.[IDFkTCodigos]
						-- Trae el c�digo de la empresa seleccionada y el multiidioma
						AND (TC2.[IDFkCodEmpresas] = CASE WHEN @PAR2 IS NULL THEN TC2.[IDFkCodEmpresas] ELSE @PAR2 END 
								OR TC2.[IDFkCodEmpresas] = 'A5E49ED6-EFDD-4C43-955F-7F3616E39F99')

END
--
--EXEC	@return_value = [dbo].[CPerfPPerfAccProc]				-- Tabla 06 -- Perfiles asociados a las agrupaciones de perfiles. Esto quiere decir que una Agrupaci�n puede tener varios perfiles.
--			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--			,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
--	


