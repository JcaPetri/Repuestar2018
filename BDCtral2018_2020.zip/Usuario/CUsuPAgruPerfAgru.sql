set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO
-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 30/09/2018
-- Description:	Muestra la relacion entre los usuarios y sus agrupaciones.
-- Un usuario puede tener muchas agrupaciones (equipos), y una agrupacion (equipo) puede tener muchos usuarios
-- =============================================
ALTER PROCEDURE [dbo].[CUsuPPerfUsuAgru]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 NVARCHAR(50) = NULL										-- Empresa
AS
BEGIN

--	DECLARE @PAR1 NVARCHAR(50)								-- Idioma elegido o por defecto = espa�ol
--	DECLARE @PAR2 NVARCHAR(50)								-- Empresa Seleccionada
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment


	DECLARE @PARInt1 NVARCHAR(50)		-- Ambito de Aplicaci�n elegido GUsuTAgrup = Tabla usuarios agrupaciones
	DECLARE @PARInt2 NVARCHAR(50)		-- Ambito de Aplicaci�n elegido GPerfTAgrup = Tabla perfiles agrupados
	SET @PARInt1 = '528CEED9-D2B3-4CB5-8116-01BDAD455C83'		-- GUsuTAgrup = Tabla usuarios agrupaciones
	SET @PARInt2 = '69752b6b-9b31-402b-83dc-4e945df7879c'		-- GPerfTAgrup Tabla con los perfiles agrupados

	DECLARE @TmpTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1

	--	SELECT * FROM @TmpTCodxIdi

	-- Muestra los grupos de Usuarios y Perfiles, esto surge de la relaci�n entre las tablas Virtuales:
	-- GPerTPerfiles y GPerfTAgrup.
	-- Las tablas virtuales surgen de las tablas TCodigo y TCodxIdioma, ya que tiene la misma estructura.
	-- En el �mbito de aplicaci�n se pone el c�digo de GPerTPerfiles o GPerfTAgrup como si fuera el nombre de la tabla.

	--	Tabla donde estan la relacion entre GrupoUsuarios y GrupoPerfiles
	SELECT TC1.[IDFkCodEmpresas]
			,CxI1.[Codigo]
			,CxI1.[Descripcion]
			,UPA.[IDFkTCDiccTCod_Perfil]
			,PAgr.[Codigo] AS [PerAgruCod]
			,PAgr.[Descripcion] AS [PerAgruDesc]
			,UPA.[IDFkTCDiccTCod_UsuAgrup]
			,Perf.[Codigo] AS [PerfilCod]
			,Perf.[Descripcion] AS [PerfilDesc]
			,Perf.[CodIdioma]
			,Perf.[Descidioma]
	FROM [BDCtral].[dbo].[CUsuTPerfUsuAgru] AS UPA WITH(NOLOCK)		-- Tabla con la relacion entre los Perfiles y los Usuarios Agrupados
		INNER JOIN @TmpTCodxIdi AS Perf 
			ON Perf.[IDFkTCodigos] = UPA.[IDFkTCDiccTCod_Perfil]
					AND
			   Perf.[IDFkTCodAmbAplic] = @PARInt2		-- GPerfTAgrup
		LEFT OUTER JOIN [BDCtral].[dbo].[CDiccTCodigos] AS TC1 WITH(NOLOCK)
			ON UPA.[IDFkTCDiccTCod_Perfil] = TC1.[ID]
				LEFT OUTER JOIN @TmpTCodxIdi AS CxI1
					ON TC1.[IDFkCodEmpresas] = CxI1.[IDFkTCodigos]
						-- Trae el c�digo de la empresa seleccionada y el multiidioma
						AND (TC1.[IDFkCodEmpresas] = CASE WHEN @PAR2 IS NULL THEN TC1.[IDFkCodEmpresas] ELSE @PAR2 END 
								OR TC1.[IDFkCodEmpresas] = 'A5E49ED6-EFDD-4C43-955F-7F3616E39F99')
		INNER JOIN  @TmpTCodxIdi AS PAgr 
			ON PAgr.[IDFkTCodigos] = UPA.[IDFkTCDiccTCod_UsuAgrup]
					AND
			   PAgr.[IDFkTCodAmbAplic] = @PARInt1		-- GPerTPerfiles
		LEFT OUTER JOIN [BDCtral].[dbo].[CDiccTCodigos] AS TC2 WITH(NOLOCK)
			ON UPA.[IDFkTCDiccTCod_UsuAgrup] = TC2.[ID]
				LEFT OUTER JOIN @TmpTCodxIdi AS CxI2
					ON TC2.[IDFkCodEmpresas] = CxI2.[IDFkTCodigos]
						-- Trae el c�digo de la empresa seleccionada y el multiidioma
						AND (TC2.[IDFkCodEmpresas] = CASE WHEN @PAR2 IS NULL THEN TC2.[IDFkCodEmpresas] ELSE @PAR2 END 
								OR TC2.[IDFkCodEmpresas] = 'A5E49ED6-EFDD-4C43-955F-7F3616E39F99')

END

--EXEC	@return_value = [dbo].[CUsuPPerfUsuAgru]				-- Tabla 07 -- Relacion entre los Usuarios Agrupados y los Perfiles
--			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--			,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
--	
