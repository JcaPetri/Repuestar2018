set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO

DECLARE	@return_value int
DECLARE @Idio AS NVARCHAR(36)
DECLARE @Emp AS NVARCHAR(36)

--######################################################################################################################################################################
--	USUARIOS
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Info de los Usuarios
--	DECLARE	@return_value int
EXEC @return_value = [dbo].[CUsuPUsuarios]		-- Tabla 01 - [CUsuTUsuarios], datos de los usuarios. Los Usuarios pueden acceder a todas las empresas del sistema.

-- Info de las Empresas, y que Organigrama y Agrupaciones tiene.  Claver para relacionar los submodulos perfiles y usuario
--	DECLARE	@return_value int
EXEC	@return_value = [dbo].[CUsuPAgruTabla]		-- Tabla 02 - [CDiccTCodigos] y [CDiccTCodxIdiomas], datos de las Empresas y sus agrupaciones
			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
			,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment		

-- Info de la relaci�n entre los Usuarios y las Empresas y sus sectores a los que pertenencen
--	DECLARE	@return_value int
EXEC	@return_value = [dbo].[CUsuPUsuAgru]		-- Tabla 03 - [CUsuTUsuAgru], relaci�n entre los Usuarios T01 y Empresas T02 y sus Agrupaciones
			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
			,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment		

--######################################################################################################################################################################
--	PERFILES
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Info del Acceso a los Procesos del Sistema
--	DECLARE	@return_value int
EXEC	@return_value = [dbo].[CPerfPAccesoProcesos]			-- Tabla 04 - [CDiccTCodigos] y [CDiccTCodxIdiomas], datos de los Perfiles que tienen las Empresas
			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
			,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment

-- Info de los Perfiles, para relacionar los submodulos Acceso a los Procesos y Usuario Agrupados
--	DECLARE	@return_value int
EXEC	@return_value = [dbo].[CPerfPPerfil]				-- Tabla 05 - [CDiccTCodigos] y [CDiccTCodxIdiomas], datos de las Agrupaciones de  Perfiles que tienen las Empresas. Se utiliza para vincular las agrupaciones de Usuarios.
			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
			,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
	
-- Info de los Perfiles asociados a Acceso a los Procesos. Esto quiere decir que una Perfil puede tener varios accesos a proceso y un acceso a proceso puede tener varios perfiles.
--	DECLARE	@return_value int
EXEC	@return_value = [dbo].[CPerfPPerfAccProc]				-- Tabla 06 -- Perfiles asociados a las agrupaciones de perfiles. Esto quiere decir que una Agrupaci�n puede tener varios perfiles. Varios perfiles pueden estar asociados a varias agrupaciones
			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
			,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment


--######################################################################################################################################################################
--	USUARIOS AGRUPADOS y PERFILES
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Info de las Agrupaciones de Usuario y Perfiles de Usuarios
--	DECLARE	@return_value int
EXEC	@return_value = [dbo].[CUsuPPerfUsuAgru]				-- Tabla 07 -- Relacion entre los Usuarios Agrupados y los Perfiles Agrupados
			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
			,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
	

--######################################################################################################################################################################
--	TABLA CON LOS RESULTADOS DE LAS RELACIONES DE TODO EL M�DULO DE ACCESO
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Actualiza la tabla de [CUsuTPerfTIng], con la informacion de los perfiles y los acceso a los procesos para una empresa
--		Primero: va desde la tabla [CUsuTUsuarios] hasta la tabla [CPerfTPerfil], que esta en [CDiccTCodigos] y [CDiccTCodxIdiomas] 
--		Segundo: va desde la tabla [CUsuTUsuarios] hasta la tabla [CPerfTAccesoProcesos], que esta en [CDiccTCodigos] y [CDiccTCodxIdiomas] 
-- de esta forma se tiene para un usuario, los perfiles asociados y los acceso a los procesos habilitados
--	DECLARE	@return_value int
SET @Idio = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
SET @Emp = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
	EXEC @return_value = [dbo].[CUsuPPerTIng_ABM]				-- Tabla 07 -- Relacion entre los Usuarios Agrupados y los Perfiles Agrupados
			@PAR1 = @Idio		-- Idioma elegido o por defecto = espa�ol
			,@PAR2 = @Emp		-- BPM	Business Process Managment
--			,@PAR3 = ''		-- Usuario

-- Info de la tabla [CUsuPPerTIng], donde esta el resumen de todo el resultado del Modulo Acceso
--	DECLARE	@return_value int
	EXEC @return_value = [dbo].[CUsuPPerTIng]				-- Tabla 07 -- Relacion entre los Usuarios Agrupados y los Perfiles Agrupados
			@PAR1 = @Idio		-- Idioma elegido o por defecto = espa�ol
			,@PAR2 = @Emp		-- BPM	Business Process Managment
			,@PAR3 = NULL		-- 'D3AE6446-4D7B-474B-ACF0-E9A75A233BC6'		-- Usuario	ANONIMO
		-- TipoTabla, especifica si busca los Perfiles o el Acceso a los Procesos
			,@PAR4 = '69752B6B-9B31-402B-83DC-4E945DF7879C'	--	CPerfTPerfil
--			,@PAR4 = '50E6A111-D9BE-4CF7-9115-69A1294EACAB'	--	CPerfTAccesoProcesos



----######################################################################################################################################################################
----	Lista los tipos de relaci�n entre el M�dulo de Acceso y el M�dulo de Procesos.
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--DECLARE	@return_value int
EXEC @return_value = [dbo].[CPrGeTipoRelacion] 
		@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'			-- Idioma elegido o por defecto = espa�ol
