set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

USE [BDGral]
GO


	DECLARE @PAR1 NVARCHAR(50) 
	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RC int				-- Determina si la consulta tiene valores

	-- Procedimiento Almacenado, donde esta la informaci�n de los datos de acceso del usuario y a que agrupaci�n pertenece.
	-- Surge de la relaci�n entre las tablas GUsuTDatAcceso y UsuAgrup
	-- el ambito de aplicaci�n es TUsuAgrup que significa Tabla Usuarios Agrupados, esta info se guarda en las tablas TCodigos y TCodxIdio
	DECLARE @TmpPUsuAgru TABLE			-- Tabla temporal para obtener la informaci�n Usuarios y sus Agrupaciones
	(
		[IDFkTUsuDatAcc] [uniqueidentifier] NOT NULL,
		[UsuCod] [int] NOT NULL,
		[UsuAbr] [varchar](15) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[UsuApellido] [varchar](50) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[UsuNombre] [varchar](50) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[UsuEmail] [varchar](50) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[IDFkTCodUsuAgrup] [uniqueidentifier] NOT NULL,
		[UsuGrupoCod] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[UsuGrupoDesc] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[IDIdioma] [uniqueidentifier] NOT NULL,
		[IdiomaCod] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[IdiomaDesc] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[AmbAplicCod] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[AmbAplicDesc] [varchar](250) COLLATE Modern_Spanish_CI_AS -- NOT NULL,
	)

	-- Ejecuta el procedimiento almacenado con valores dependiendo de si tiene o no definido el idioma
	IF @PAR1 IS NULL 
		INSERT INTO @TmpPUsuAgru EXECUTE @RC = [dbo].[GUsuPUsuAgru]
	ELSE
		INSERT INTO @TmpPUsuAgru EXECUTE @RC = [dbo].[GUsuPUsuAgru] @PAR1
		-- El ambito de aplicaci�n no se pone ya que es siempre el mismo
		-- , @PAR2 = N'528CEED9-D2B3-4CB5-8116-01BDAD455C83'		-- Ambito de aplicaci�n tabla usuarios agrupaciones

	-- SELECT * FROM @TmpPUsuAgru WHERE [UsuGrupoCod] = 'MENGRAL01' ORDER BY UsuAbr		-- WHERE [UsuAbr] = 'JPETRI' 

	-- Procedimiento Almacenado, donde esta la informaci�n de los tipos de perfiles y el perfil disponible.
	-- Surge de la relaci�n entre las tablas GUsuTPerfil y TCodigo y TCodxIdioma
	-- el ambito de aplicaci�n es usuarios
	DECLARE @TmpPPerfil TABLE			-- Tabla temporal para obtener la informaci�n Usuarios y sus Agrupaciones
	(
		[ID] [uniqueidentifier] NOT NULL,
		[IDFkPerfilTipo] [uniqueidentifier] NOT NULL,
		[TipoPerfilCod] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[TipoPerfilDesc] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[IDFkPerfil] [uniqueidentifier] NOT NULL,
		[PerfilCod] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[PerfilDesc] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[IDTIdioma] [uniqueidentifier] NOT NULL,
		[IdiomaCod] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[IdiomaDesc] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[AmbAplicCod] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[AmbAplicDesc] [varchar](250) COLLATE Modern_Spanish_CI_AS -- NOT NULL,
	)

	-- Ejecuta el procedimiento almacenado con valores dependiendo de si tiene o no definido el idioma
	IF @PAR1 IS NULL 
		INSERT INTO @TmpPPerfil EXECUTE @RC = [dbo].[GUsuPPerfil]
	ELSE
		INSERT INTO @TmpPPerfil EXECUTE @RC = [dbo].[GUsuPPerfil] @PAR1
		-- El ambito de aplicaci�n no se pone ya que es siempre el mismo
		--, @PAR2 = N'528CEED9-D2B3-4CB5-8116-01BDAD455C83'		-- Ambito de aplicaci�n tabla usuarios agrupaciones

    -- SELECT * FROM @TmpPPerfil ORDER BY TipoPerfilCod, PerfilCod

	-- Muestra la informaci�n del Usuario y su Perfil
	SELECT PAU.[IDFkTPerfil]			-- Este es el perfil ID
		  ,TP.[IDFkPerfilTipo]			-- Este es el perfil tipo, vinculo con tabla TCodigo y TCodxIdi
		  ,TP.[TipoPerfilCod]
		  ,TP.[TipoPerfilDesc]
		  ,TP.[IDFkPerfil]				-- Este es el perfil codigo, vinculo con tabla TCodigo y TCodxIdi
		  ,TP.[PerfilCod]
		  ,TP.[PerfilDesc]
		  ,PAU.[IDFkTUsuAgrup]			-- Este es el c�digo agrupado, vinculo con la tabla TCodigo y TCodxIdi
		  ,UA.[UsuGrupoCod]
		  ,UA.[UsuGrupoDesc]
		  ,UA.[UsuCod]
		  ,UA.[UsuAbr]
		  ,UA.[UsuApellido]
		  ,UA.[UsuNombre]
		  ,UA.[UsuEmail]
		  ,UA.[IDIdioma]
		  ,UA.[IdiomaCod]
		  ,UA.[IdiomaDesc]
	  FROM [BDGral].[dbo].[GUsuTPerfAgrup] AS PAU WITH(NOLOCK)
		INNER JOIN @TmpPPerfil AS TP
			ON PAU.[IDFkTPerfil] = TP.[ID]
		INNER JOIN @TmpPUsuAgru AS UA
			ON PAU.[IDFkTUsuAgrup] = UA.[IDFkTCodUsuAgrup]	-- UA.[IDFkTUsuDatAcc]
--	WHERE UA.[UsuAbr] = 'JPETRI'
	ORDER BY TP.[TipoPerfilCod]
			,TP.[PerfilCod]
			,UA.[UsuAbr]
--	ORDER BY UA.[UsuAbr]
--			,TP.[TipoPerfilCod]
--			,TP.[PerfilCod]
GO

