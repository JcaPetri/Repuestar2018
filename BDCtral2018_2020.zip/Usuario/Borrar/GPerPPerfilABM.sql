-- ###############################################################################################################################3
--  GENERA LOS PROCEDIMIENTOS ALMACENADOS PARA HACER EL ALTA, MODIFICACION, BAJA O RECUPERO DE LOS PERFILES AGRUPADOS -- 
-- ###############################################################################################################################3

-- Define que se trabaja con al Base de Datos
USE [BDGral]
GO
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- Muestra la informacion de la tabla idioma
--DECLARE	@return_value int
--EXEC	@return_value = [dbo].[GDicPIdioma]
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--
--SELECT [IDFkTCodigos]
--      ,[IDFkTIdioma]
--      ,[IDFkTCodAmbAplic]
--      ,[Codigo]
--      ,[Descripcion]
--      ,[IDFkCxIEstados]
--  FROM [BDGral].[dbo].[GDicTCodxIdiomas]


SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Variables para realizar al ABM, se debe:
	-- Variables Etapa 1
	DECLARE @PAR1 AS VARCHAR(50)	-- Determina acci�na realizar 
		-- valores posibles: ALTA - MODIFICACION - BAJA - RECUPERO
		-- Como estos valores son para todas las tablas e idiomas unicos siempre van los mismos
	DECLARE @PAR2 AS VARCHAR(36)	-- IDFkTCodigos -- valor ID, debe ser �nico.
		-- Caso Alta: valor nuevo se genera con el NewID()
			-- primero se carga en la tabla GDicTCodigos y 
			-- luego en la tabla GDicTCodIdiomas.
		-- Caso Modificaci�n: 
			-- con este valor ID se buscan los datos, luego si hay diferencias se modifica el valor
			-- Si la diferencia es en el estado es simple, solo se cambia, IDFkCxIEstados.
			-- Aclaraciones:
				-- Las claves ID son la combinacion del IDFkTCodigos, el IDFkTIdioma, el IDFkTCodAmbAplic, y el Codigo, 
				-- por lo tanto antes de modificar el dato debemos verificar que no se violen alguna de esta claves primarias
				-- La Descripcion pueden estar repetidas para el mismo ambito
	DECLARE @PAR3 AS VARCHAR(50)	-- IDFkTIdioma -- codigo del idioma para ese codigo y ambito
		-- Caso Alta: 
			-- codigo del idioma a donde se asignara el codigo.
				--						ee954f5d-ca27-48a9-a23b-010788b18631	ITA
				--						b1268278-4eb3-4a93-8f67-0d425b767c65	ENG
				--						a455281d-76f5-4bad-8dbb-201c5928aaf8	FRA
				--						1048c13b-1cc9-4154-8b8b-64ca9ac9fe12	POR
				--						fb478ecc-85fe-4fc8-b792-caf8ecb921b1	ESP
		-- Caso Modificaci�n:
			-- Codigo del idioma, a que idioma se asigna ese codigo. 
			-- Primero se debe verificar que para ese idioma no este utilizado el codigo, no se debe haber utilizado, si es as� no se genera la modificaci�n
	DECLARE @PAR4 AS VARCHAR(250)	-- IDFkTCodAmbAplic -- codigo del modulo o ambito de aplicacion del codigo.
		-- Caso Alta: 
			-- codigo del modulo o ambito de aplicacion a donde se asignara el codigo.
				-- Algunos ambitos de aplicaci�n			
					-- 6B0CD910-C127-4450-9865-15E9F4C287B4		EST	estados	4
					-- A4E85E68-267B-49E4-A81A-69979E68FE2B		IDI	idiomas	6
					-- 50E6A111-D9BE-4CF7-9115-69A1294EACAB		USU	usuarios	7
					-- AC4A9B82-99C5-48ED-A002-C700C32A4B54		VEH	v�h�culos	26			
		-- Caso Modificaci�n: 
			-- codigo del nuevo modulo o ambito de aplicacion a donde se asignara el codigo. 
			-- Si para ese ambito ya existe el c�digo, no se realizan los cambios.
	DECLARE @PAR5 AS VARCHAR(36) 	-- Codigo -- C�digo en letras del ID
		-- Caso Alta:
			-- Es un c�digo real que se visualiza, este c�digo debe ser �nico, para el ID, Idioma y Ambito de aplicaci�n.
		-- Caso Modificaci�n:
			-- Es un c�digo nuevo, ya que este c�digo debe ser �nico, se debe verificar que no haya duplicidad para el ID, Idioma y Ambito de aplicaci�n.
	DECLARE @PAR6 AS VARCHAR(36) 	-- Descripci�n -- Es la descripci�n del c�digo en letras.
		-- Caso Alta:
			-- Es la descripci�n del c�digo real que se visualiza. Este valor debe ser menor de 250 caracteres.
		-- Caso Modificaci�n:
			-- Se modifica la descripci�n y no se debe hacer ninguna verificaci�n.
	DECLARE @PAR7 AS VARCHAR(36) 	-- valor ID del estado del c�digo (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
		-- Caso Alta:
			-- Es un c�digo ID con las distintas opciones, estas pueden ser. Habilitado, Deshabilitado, Eliminado.
				-- 6B0CD910-C127-4450-9865-15E9F4C287B4	EST	estados			EST	estados
					-- EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0	DES	deshabilitado	EST	estados
					-- 3749D6D8-EF8F-4C37-893A-BE7209239810	ELI	eliminado		EST	estados
					-- C6FE2749-0CB8-49CD-97DF-03C299C0C6CF	HAB	habilitado		EST	estados
		-- Caso Modificaci�n:
			-- Se cambia el estado sin realizar verificaciones. en caso de que se recupere el c�digo, se debe verificar que no se infrinjan las reglas primarias.
	DECLARE @PAR9 AS VARCHAR(50)

	-- Variables para obtener los valores del procedimiento almacenado de GetErrorInfo
		DECLARE @RTADO_PROCALM AS VARCHAR(250)
		DECLARE @NOMB_PROCALM AS VARCHAR(250)
		DECLARE @FUNC_PROCALM AS VARCHAR(100)
		DECLARE @RTADO AS VARCHAR(250)
		DECLARE @REG_AFEC AS NUMERIC(18, 0)
		DECLARE @ERR_MESSAGE AS VARCHAR(250)
		DECLARE @ERR_NUMBER AS NUMERIC(18, 0)
		DECLARE @ERR_SEVERITY AS NUMERIC(18, 0)
		DECLARE @ERR_STATE AS NUMERIC(18, 0)
		DECLARE @ERR_LINE AS NUMERIC(18, 0)
		
		SET @NOMB_PROCALM = 'GDicPCodxIdioABM'				-- Nombre del procedimiento almacenado.

-- Valores de las variables para generar las prueba del funcionamiento de las consultas.
--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	-- SETEO DE LAS VARIABLES PARA EL ALTA DE UN CODIGO Y SUS DESCRIPCIONES
		SET @PAR1 = 'ALTA'													-- ALTA - MODIFICACION - BAJA - RECUPERO
		SET @PAR2 = NEWID()													-- ID del codigo, debe ser �nico
		SET @PAR3 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'					-- ID del Idioma	-- Espa�ol		
--				ee954f5d-ca27-48a9-a23b-010788b18631	ITA	italiano
--				b1268278-4eb3-4a93-8f67-0d425b767c65	ENG	english
--				a455281d-76f5-4bad-8dbb-201c5928aaf8	FRA	fran�ais
--				1048c13b-1cc9-4154-8b8b-64ca9ac9fe12	POR	portugu�s
--				fb478ecc-85fe-4fc8-b792-caf8ecb921b1	ESP	espa�ol
		SET @PAR4 = '50E6A111-D9BE-4CF7-9115-69A1294EACAB'					-- ID del Ambito de Aplicaci�n del C�digo -- Usuarios	
				-- 50e6a111-d9be-4cf7-9115-69a1294eacab			Ambito Usuarios
				-- 50E6A111-D9BE-4CF7-9115-69A1294EACAB			Ambito Perfiles
				-- 528CEED9-D2B3-4CB5-8116-01BDAD455C83			Usuarios Agrupaciones
				-- 69752B6B-9B31-402B-83DC-4E945DF7879C			Perfiles Agrupaciones
				-- 92e0ac56-18ac-4fe2-b679-c59cba5ddc0d			Tabla Gesti�n de Procesos
				-- ADA29ADB-4B38-4610-B1FE-29AFE5B57317			Tabla Etapas
				-- CF0EF997-B52A-42A2-BD70-E12EFB00A724			Tabla Motivos
		SET @PAR5 = 'AteCliSalon'											-- C�digo, debe ser �nico
		SET @PAR6 = 'Atiende Cliente en el salon'							-- Descripcion del codigo
		SET @PAR7 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'					-- Habilitado
		SET @PAR9 = 'AltaCompleto'

--	-- SETEO DE LAS VARIABLES PARA EL ALTA DE UN C�DIGO Y SUS DESCRIPCIONES -- NUEVO AMBITO DE APLICACI�N
--	-- El nuevo �mbito de aplicaci�n el c�digo ID y el ID del ambito de aplicaci�n es el mismo
--	-- @PAR2 = @PAR4
--		SET @PAR1 = 'ALTA'													-- ALTA - MODIFICACION - BAJA - RECUPERO
--		SET @PAR2 = NEWID()													-- ID del codigo, debe ser �nico
--		SET @PAR3 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'					-- ID del Idioma	-- Espa�ol		
----				ee954f5d-ca27-48a9-a23b-010788b18631	ITA	italiano
----				b1268278-4eb3-4a93-8f67-0d425b767c65	ENG	english
----				a455281d-76f5-4bad-8dbb-201c5928aaf8	FRA	fran�ais
----				1048c13b-1cc9-4154-8b8b-64ca9ac9fe12	POR	portugu�s
----				fb478ecc-85fe-4fc8-b792-caf8ecb921b1	ESP	espa�ol
--		SET @PAR4 = @PAR2								-- ID del Ambito de Aplicaci�n del C�digo -- el ID y el Ambito Aplicaci�n son Iguales	
--		SET @PAR5 = 'GPerfTAgrup'															-- C�digo, debe ser �nico
--		SET @PAR6 = 'tabla con los c�digos de los perfiles agrupados'								-- Descripcion del codigo
--		SET @PAR7 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'					-- Habilitado
--		SET @PAR9 = 'AltaCompleto'

--	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	-- SETEO DE LAS VARIABLES PARA LA MODIFICACION DE UN CODIGO Y SUS DESCRIPCIONES
--		SET @PAR1 = 'MODIFICACION'											-- ALTA - MODIFICACION - BAJA - RECUPERO
--		SET @PAR2 = 'ABE14F0E-8DF7-4492-9DB9-77199807D80A'					-- ID del codigo, debe ser �nico
--		SET @PAR3 = 'FB478ECC-85FE-4FC8-B792-CAF8ECB921B1'					-- ID del Idioma	-- Espa�ol		
--		SET @PAR4 = '528CEED9-D2B3-4CB5-8116-01BDAD455C83'					-- ID del Ambito de Aplicaci�n del C�digo -- Usuarios	
--		SET @PAR5 = 'PPVTGTIA'													-- C�digo, debe ser �nico
--		SET @PAR6 = 'personal postventa garantia'												-- Descripcion del codigo
--		SET @PAR7 = 'c6fe2749-0cb8-49cd-97df-03c299c0c6cf'					-- Habilitado
--		SET @PAR9 = 'AltaCompleto'

---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- Valores de las variables para agregarle al codigo ID, solo el Codigo por Idioma nuevo. No agrega el cogido
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--	-- SETEO DE LAS VARIABLES PARA EL ALTA DE UN CODIGO Y SUS DESCRIPCIONES
--		SET @PAR1 = 'ALTA'												-- ALTA - MODIFICACION - BAJA - RECUPERO
--		SET @PAR2 = '3749D6D8-EF8F-4C37-893A-BE7209239810'					-- ID del codigo, este ya es un codigo generado
--		SET @PAR3 = 'b1268278-4eb3-4a93-8f67-0d425b767c65'					-- ID del Idioma
----				ee954f5d-ca27-48a9-a23b-010788b18631	ITA	italiano
----				b1268278-4eb3-4a93-8f67-0d425b767c65	ENG	english
----				a455281d-76f5-4bad-8dbb-201c5928aaf8	FRA	fran�ais
----				1048c13b-1cc9-4154-8b8b-64ca9ac9fe12	POR	portugu�s
----				fb478ecc-85fe-4fc8-b792-caf8ecb921b1	ESP	espa�ol
--		SET @PAR4 = '6B0CD910-C127-4450-9865-15E9F4C287B4'					-- ID del Ambito de Aplicaci�n del C�digo -- Usuarios	
--		SET @PAR5 = 'REM'													-- C�digo, debe ser �nico
--		SET @PAR6 = 'removed'													-- Descripcion del codigo
--		SET @PAR7 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'					-- Habilitado
--		SET @PAR9 = 'SoloCodxIdio'
--
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- Pasos antes de hacer ABM de los datos:
	-- Etapa 1: Primero verificar que con el cambio no se infrinja ninguna clave primaria
	-- Etapa 2: 
			-- 1: Si el resultado es que se infrinje, no realizar el cambio e informar al usuario
			-- 2: Si es todo OK, se realiza el cambio. Para hacer esto se hace una transacci�n para asegurar la integridad del cambio.	

IF @PAR1 = 'ALTA'
BEGIN
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- ##############################################################################################################################################
	-- INICIO -- ALTA DE CODIGO Y SUS DESCRIPCIONES
	-- ##############################################################################################################################################
	
	SET @FUNC_PROCALM = 'Alta'		-- Funcion dentro del procedimiento almacenado.

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Para agregar un nuevo C�digo, se debe:
		-- Clave Primaria: IDC�digo [IDFkTCodigos], IDIdiomas [IDFkTIdioma], IDAmbitoAplicaci�n [IDFkTCodAmbAplic], C�digo Unico [Codigo]
		-- Los otros campos pueden tener cualquier valor, no se validan.

		-- Aclaraci�n: La combinaci�n m�s ID de entorno, por lo tanto para un idioma, puede haber dos c�digos iguales, pero cada uno para un entorno o m�dulo diferente.

	-- Etapa 1: Verifica Clave Primaria: que el codigo que se quiere agregar ya no este creado, para ese idioma y �mbito de aplicaci�n.
		-- Si alguno de los valores son encontrados, la variable @PAR2 se pone a NULL
		SELECT @PAR2 = NULL
		  FROM [BDGral].[dbo].[GDicTCodxIdiomas] AS CxI WITH(NOLOCK)
		WHERE [IDFkTIdioma] = @PAR3 AND [IDFkTCodAmbAplic] = @PAR4 AND [Codigo] = @PAR5
			-- Clave Primaria: Idioma, AmbitoAplicaci�n, C�digo.
		--		SELECT @PAR2

	-- Etapa 2: 
			-- 1: Si el C�digo infringe la clave primaria, no hace el cambio e informa al usuario
		IF @PAR2 IS NULL
			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			BEGIN
				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
				SET @RTADO = 'ERR' 
				SET @REG_AFEC = 0
				SET @ERR_MESSAGE = 'El c�digo ingresado ya esta utilizado para ese idioma y �mbito de aplicaci�n.'
				SET @ERR_NUMBER = 0
				SET @ERR_SEVERITY = 0
				SET @ERR_STATE = 0
				SET @ERR_LINE = 0
			END
		ELSE
			-- 2: Si es todo OK, se realiza el cambio.
			BEGIN TRY
			BEGIN TRANSACTION;
			-- Inserta el codigo en las tablas. 
				
				IF @PAR9 = 'AltaCompleto' 
					-- PRIMERO en la tabla [GDicTCodigos]
					BEGIN
						INSERT INTO [BDGral].[dbo].[GDicTCodigos]
								   ([ID]
								   ,[IDFkCodEstados])
							 SELECT @PAR2		-- ID del codigo, debe ser �nico
									,@PAR7		-- ID del estado del c�digo.
						GOTO ContinuaAlta
					END
				ELSE				
ContinuaAlta:
					-- SEGUNDO en la tabla [GDicTCodxIdiomas]
					BEGIN
						INSERT INTO [BDGral].[dbo].[GDicTCodxIdiomas]
								   ([IDFkTCodigos]
								   ,[IDFkTIdioma]
								   ,[IDFkTCodAmbAplic]
								   ,[Codigo]
								   ,[Descripcion]
								   ,[IDFkCxIEstados])
							 SELECT @PAR2		-- ID del codigo, debe ser �nico
									,@PAR3		-- ID del Idioma
									,@PAR4		-- ID del Ambito de Aplicaci�n del C�digo
									,@PAR5		-- C�digo, debe ser �nico
									,@PAR6		-- Descripcion del codigo
									,@PAR7		-- ID del estado del c�digo.
					END
				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
				BEGIN
					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
					SET @RTADO = 'OK' 
					SET @REG_AFEC = 1
					SET @ERR_MESSAGE = 'Se cargo la informacion solicitada.'
					SET @ERR_NUMBER = 0
					SET @ERR_SEVERITY = 0
					SET @ERR_STATE = 0
					SET @ERR_LINE = 0
				END
			
				-- Si el procedimiento es exitoso, confirma la operaci�n.
				COMMIT TRANSACTION;
			END TRY
			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
			BEGIN CATCH

				-- Ejecuta el Procedimiento Almacenado para obtener el error.
				EXECUTE [dbo].[GGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT

				-- Como la operaci�n fall�, se deshacen las modificaciones.
				ROLLBACK TRANSACTION;

				-- Por las dudas se elimana el registro con el ID generado.
				DELETE FROM [BDGral].[dbo].[GDicTCodigos] WHERE [ID] = @PAR2
				DELETE FROM [BDGral].[dbo].[GDicTCodxIdiomas] WHERE [IDFkTCodigos] = @PAR2;

				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				SET @RTADO = 'ERR'
				SET @REG_AFEC = 0
			END CATCH;

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- ##############################################################################################################################################
	-- FINAL -- ALTA DE CODIGO Y SUS DESCRIPCIONES
	-- ##############################################################################################################################################
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
END


ELSE 
IF @PAR1 = 'MODIFICACION'
BEGIN
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- INICIO	-- MODIFICACION DE CODIGO Y SUS DESCRIPCIONES
-- ##############################################################################################################################################
	
	SET @FUNC_PROCALM = 'Modificacion'		-- Funcion dentro del procedimiento almacenado.

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Para modificar un nuevo C�digo, se debe:
		-- Clave Primaria: IDC�digo [IDFkTCodigos], IDIdiomas [IDFkTIdioma], IDAmbitoAplicaci�n [IDFkTCodAmbAplic], C�digo Unico [Codigo]
		-- Los otros campos pueden tener cualquier valor, no se validan.

		-- Aclaraci�n: La combinaci�n m�s ID de entorno, por lo tanto para un idioma, puede haber dos c�digos iguales, pero cada uno para un entorno o m�dulo diferente.

	-- Etapa 1: Verifica Clave Primaria: hay que verificar que el cambio no afecte la clave primaria.
									-- que el codigo que se quiere modificar ya no este creado, para ese idioma y �mbito de aplicaci�n definido.
		-- Si alguno de los valores son encontrados, la variable @PAR2 se pone a NULL
		SELECT @PAR2 = NULL
		  FROM [BDGral].[dbo].[GDicTCodxIdiomas] AS CxI WITH(NOLOCK)
		WHERE [IDFkTCodigos] <> @PAR2 AND [IDFkTIdioma] = @PAR3 AND [IDFkTCodAmbAplic] = @PAR4 AND [Codigo] = @PAR5
		-- Aclaraciones:
				-- Primero verifica que no se genere duplicidad, para eso hace que todos los otros codigos cargados que no sea el que va a cambiar
				-- para el idioma que se va a poner, el ambito de aplicacion y para ese codigo no sea el mismo.
				-- Si el codigo ya esta creado no modifica ningun otro campo, por eso se cambia la variable a @PAR2 = NULL
		--		SELECT @PAR2

	-- Etapa 2: 
			-- Si el codigo ya esta utilizado, infrinje la clave primaria, no hace los cambios e informa al usuario.
		IF @PAR2 IS NULL
			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			BEGIN
				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
				SET @RTADO = 'ERR' 
				SET @REG_AFEC = 0
				SET @ERR_MESSAGE = 'El c�digo ingresado ya esta utilizado por otro ID, para el idioma y �mbito de aplicaci�n seleccionado.'
				SET @ERR_NUMBER = 0
				SET @ERR_SEVERITY = 0
				SET @ERR_STATE = 0
				SET @ERR_LINE = 0
			END
		ELSE
			-- 2: Si es todo OK, se realiza el cambio.
			BEGIN TRY
			BEGIN TRANSACTION;
				-- Modifica el codigo en la tabla. Le puede cambiar el idioma, ambito de aplicacion, el codigo, su descripcion y el estado.
				UPDATE [BDGral].[dbo].[GDicTCodxIdiomas]
				   SET [IDFkTIdioma] = @PAR3
					  ,[IDFkTCodAmbAplic] = @PAR4
					  ,[Codigo] = @PAR5
					  ,[Descripcion] = @PAR6
					  ,[IDFkCxIEstados] = @PAR7
				 WHERE [IDFkTCodigos] = @PAR2

				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
				BEGIN
					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
					SET @RTADO = 'OK' 
					SET @REG_AFEC = 1
					SET @ERR_MESSAGE = 'Se modific� la informacion solicitada.'
					SET @ERR_NUMBER = 0
					SET @ERR_SEVERITY = 0
					SET @ERR_STATE = 0
					SET @ERR_LINE = 0
				END
			
				-- Si el procedimiento es exitoso, confirma la operaci�n.
				COMMIT TRANSACTION;
			END TRY
			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
			BEGIN CATCH

				-- Ejecuta el Procedimiento Almacenado para obtener el error.
				EXECUTE [dbo].[GGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT

				-- Como la operaci�n fall�, se deshacen las modificaciones.
				ROLLBACK TRANSACTION;

				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				SET @RTADO = 'ERR'
				SET @REG_AFEC = 0
			END CATCH;

-- ##############################################################################################################################################
-- FINAL	-- MODIFICACION DE CODIGO Y SUS DESCRIPCIONES
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
END

ELSE
IF @PAR1 = 'BAJA'
BEGIN
-- ##############################################################################################################################################
-- INICIO	-- BAJA DE CODIGO Y SUS DESCRIPCIONES
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	SET @FUNC_PROCALM = 'Baja'		-- Funcion dentro del procedimiento almacenado.

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Para dar de baja un C�digo, se debe:
		-- Cambiar solo el estado. No se elimina ya que puede afectar las relaciones asociadas.
	-- Etapa 1: verifica que el codigo ya no est� dado de baja.
		SELECT @PAR2 = NULL		-- Si alguno de los valores son encontrados, la variable @PAR2 se pone a NULL
		  FROM [BDGral].[dbo].[GDicTCodxIdiomas] AS CxI WITH(NOLOCK)
		WHERE [IDFkCxIEstados] = '3749D6D8-EF8F-4C37-893A-BE7209239810'		-- ELI	eliminado		EST	estados
		-- Si encuentra el registro quiere decir que el c�digo ya esta dado de baja.
		--		SELECT @PAR2

	-- Etapa 2: 
			-- 1: Si el codigo ya esta dado de baja, no hace nada, solo le informa al usuario.
		IF @PAR2 IS NULL
			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			BEGIN
				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
				SET @RTADO = 'ERR' 
				SET @REG_AFEC = 0
				SET @ERR_MESSAGE = 'El c�digo ingresado ya esta dado de baja.'
				SET @ERR_NUMBER = 0
				SET @ERR_SEVERITY = 0
				SET @ERR_STATE = 0
				SET @ERR_LINE = 0
			END
		ELSE
			-- 2: El c�digo esta para darle de baja, procede a hacerlo.
			BEGIN TRY
			BEGIN TRANSACTION;
				-- Elimina el codigo en la tabla. Para ello le agrega la leyenda '-ELI', si supera la cantidad de d�gitos permitidos del campo, le reduce el c�digo original.
				UPDATE [BDGral].[dbo].[GDicTCodxIdiomas]
				   SET [Codigo] = CASE WHEN LEN ([Codigo] + '-ELI') >= 54 THEN (SUBSTRING([Codigo], 1, 50) + '-ELI') ELSE [Codigo] + '-ELI' END			-- Le pone la leyenda que el c�digo esta eliminado.
						,[IDFkCxIEstados] = @PAR7			-- Le pone el estado de eliminado.
				WHERE [IDFkTCodigos] = @PAR2

				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
				BEGIN
					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
					SET @RTADO = 'OK' 
					SET @REG_AFEC = 1
					SET @ERR_MESSAGE = 'Se elimin� el c�digo indicado.'
					SET @ERR_NUMBER = 0
					SET @ERR_SEVERITY = 0
					SET @ERR_STATE = 0
					SET @ERR_LINE = 0
				END
			
				-- Si el procedimiento es exitoso, confirma la operaci�n.
				COMMIT TRANSACTION;
			END TRY
			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
			BEGIN CATCH
				-- Ejecuta el Procedimiento Almacenado para obtener el error.
				EXECUTE [dbo].[GGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT

				-- Como la operaci�n fall�, se deshacen las modificaciones.
				ROLLBACK TRANSACTION;

				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				SET @RTADO = 'ERR'
				SET @REG_AFEC = 0
			END CATCH;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- FINAL	-- BAJA DE CODIGO Y SUS DESCRIPCIONES
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
END

ELSE
IF @PAR1 = 'RECUPERO'
BEGIN
-- ##############################################################################################################################################
-- INICIO	-- RECUPERO DE CODIGO Y SUS DESCRIPCIONES
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	SET @FUNC_PROCALM = 'Recupero'		-- Funcion dentro del procedimiento almacenado.

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Para recuperar un C�digo, se debe:
		-- Cambiar solo el estado. Ya que no se elimina, solo se debe verificar que ese c�digo que vuelve a funcionar, 
		-- no est� utilizado y por ende infrinja la regla primaria.
		-- Clave Primaria: IDC�digo [IDFkTCodigos], IDIdiomas [IDFkTIdioma], IDAmbitoAplicaci�n [IDFkTCodAmbAplic], C�digo Unico [Codigo]
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	-- Etapa 1: verifica que el codigo est� dado de baja, si no es as� le informa al usuario.
		SELECT @PAR2 = NULL		-- Si alguno de los valores son encontrados, la variable @PAR2 se pone a NULL
		  FROM [BDGral].[dbo].[GDicTCodxIdiomas] AS CxI WITH(NOLOCK)
		WHERE [IDFkTCodigos] = @PAR2													-- ID del c�digo.
				AND [IDFkCxIEstados] <> '3749D6D8-EF8F-4C37-893A-BE7209239810'			-- Estado Eliminado
		--		SELECT @PAR2

		-- Etapa 2: 
				-- 1: Si el codigo NO esta dado de baja, no hace nada y le informa al usuario.
		IF @PAR2 IS NULL
			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			BEGIN
				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
				SET @RTADO = 'ERR' 
				SET @REG_AFEC = 0
				SET @ERR_MESSAGE = 'El c�digo ingresado no est� dado de baja.'
				SET @ERR_NUMBER = 0
				SET @ERR_SEVERITY = 0
				SET @ERR_STATE = 0
				SET @ERR_LINE = 0
			END
		ELSE

		-- Etapa 3: Ya sabemos que el c�digo esta dado de baja. Verificamos que no infrinja la clave primaria.
				-- Clave Primaria: IDC�digo [IDFkTCodigos], IDIdiomas [IDFkTIdioma], IDAmbitoAplicaci�n [IDFkTCodAmbAplic], C�digo Unico [Codigo]
		-- Aclaraci�n:
				-- Ahora verificamos si el valor que tiene el c�digo, fue utilizado por alg�n c�digo activo.
				-- Si el c�digo esta repetido, le agrega la palabra 'REC-' valor ID, y si no tiene espacio, le reduce el c�digo original. De esta manera no se duplica nunca el c�digo.
				-- el usuario luego debe modificar el c�digo indicado.
		SELECT @PAR5 = NULL			-- Pone el c�digo a Null, ya que el c�digo a recuperar ya esta utilizado.
		  FROM [BDGral].[dbo].[GDicTCodxIdiomas] AS CxI WITH(NOLOCK)
		WHERE [IDFkTCodigos] <> @PAR2 AND [IDFkTIdioma] = @PAR3 AND [IDFkTCodAmbAplic] = @PAR4 AND [Codigo] = SUBSTRING([Codigo], 1, LEN([Codigo])-4)		-- �l c�digo le elimina la palabra '-ELI'
		-- Primero verifica que no se infrinja la clave primaria: C�digoID - Idioma - Ambito Aplicacion - C�digo
		-- Si el codigo ya esta utilizado agrega el c�digo m�s una leyenda de 4 caracteres y le cambia el estado a habilitado.
		--		SELECT @PAR2

		-- Etapa 4: Si el codigo ya esta utilizado, Verifica el OK con el c�digo modificado
		IF @PAR5 IS NULL
			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			BEGIN
				-- Como el c�digo ya esta utilizado, le pone el ID al C�digo para que no haya forma de duplicidad.
				SELECT @PAR5 = SUBSTRING([Codigo], 1, 18) + @PAR2
					FROM [BDGral].[dbo].[GDicTCodxIdiomas] AS CxI WITH(NOLOCK)
				WHERE [IDFkTCodigos] <> @PAR2
				GOTO HaceCambio
				-- Ya le realizo a la variable que tiene el c�digo, ahora lo implementa en la transacci�n.
			END
		ELSE
HaceCambio:
			BEGIN TRY
			BEGIN TRANSACTION;
				-- Modifica el codigo en la tabla. Le puede cambiar el idioma, ambito de aplicacion, el codigo, su descripcion y el estado.
				UPDATE [BDGral].[dbo].[GDicTCodxIdiomas]
				   SET [Codigo] = @PAR5					-- C�digo Recuperado
						,[IDFkCxIEstados] = @PAR7		-- Estado Habilitado
				 WHERE [IDFkTCodigos] = @PAR2
						AND [IDFkCxIEstados] = '3749D6D8-EF8F-4C37-893A-BE7209239810'		-- Estado dado de Baja, Solo se puede recuperar un idioma dado de baja.

				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
				BEGIN
					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
					SET @RTADO = 'OK' 
					SET @REG_AFEC = 1
					SET @ERR_MESSAGE = 'Se recuper� el c�digo indicado.'
					SET @ERR_NUMBER = 0
					SET @ERR_SEVERITY = 0
					SET @ERR_STATE = 0
					SET @ERR_LINE = 0
				END
			
				-- Si el procedimiento es exitoso, confirma la operaci�n.
				COMMIT TRANSACTION;
			END TRY
			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
			BEGIN CATCH

				-- Ejecuta el Procedimiento Almacenado para obtener el error.
				EXECUTE [dbo].[GGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT

				-- Como la operaci�n fall�, se deshacen las modificaciones.
				ROLLBACK TRANSACTION;

				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				SET @RTADO = 'ERR'
				SET @REG_AFEC = 0
			END CATCH;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- FINAL	-- RECUPERO DE CODIGO Y SUS DESCRIPCIONES
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
END

IF @PAR1 = 'ALTASOLOCODIGOXIDIOMA'
BEGIN
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- ##############################################################################################################################################
	-- INICIO -- ALTA DE CODIGO Y SUS DESCRIPCIONES SOLO PARA UN NUEVO IDIOMA -- NO GENERA CODIGO NUEVO
	-- ##############################################################################################################################################
	
	SET @FUNC_PROCALM = 'Alta'		-- Funcion dentro del procedimiento almacenado.

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Para agregar un nuevo C�digo, se debe:
		-- Clave Primaria: IDC�digo [IDFkTCodigos], IDIdiomas [IDFkTIdioma], IDAmbitoAplicaci�n [IDFkTCodAmbAplic], C�digo Unico [Codigo]
		-- Los otros campos pueden tener cualquier valor, no se validan.

		-- Aclaraci�n: La combinaci�n m�s ID de entorno, por lo tanto para un idioma, puede haber dos c�digos iguales, pero cada uno para un entorno o m�dulo diferente.

	-- Etapa 1: Verifica Clave Primaria: que el codigo que se quiere agregar ya no este creado, para ese idioma y �mbito de aplicaci�n.
		-- Si alguno de los valores son encontrados, la variable @PAR2 se pone a NULL
		SELECT @PAR2 = NULL
		  FROM [BDGral].[dbo].[GDicTCodxIdiomas] AS CxI WITH(NOLOCK)
		WHERE [IDFkTIdioma] = @PAR3 AND [IDFkTCodAmbAplic] = @PAR4 AND [Codigo] = @PAR5
			-- Clave Primaria: Idioma, AmbitoAplicaci�n, C�digo.
		--		SELECT @PAR2

	-- Etapa 2: 
			-- 1: Si el C�digo infringe la clave primaria, no hace el cambio e informa al usuario
		IF @PAR2 IS NULL
			-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
			BEGIN
				-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
				SET @RTADO = 'ERR' 
				SET @REG_AFEC = 0
				SET @ERR_MESSAGE = 'El c�digo ingresado ya esta utilizado para ese idioma y �mbito de aplicaci�n.'
				SET @ERR_NUMBER = 0
				SET @ERR_SEVERITY = 0
				SET @ERR_STATE = 0
				SET @ERR_LINE = 0
			END
		ELSE
			-- 2: Si es todo OK, se realiza el cambio.
			BEGIN TRY
			BEGIN TRANSACTION;
			-- Inserta el codigo en las tablas. 

				-- PRIMERO en la tabla [GDicTCodigos]
				INSERT INTO [BDGral].[dbo].[GDicTCodigos]
						   ([ID]
						   ,[IDFkCodEstados])
					 SELECT @PAR2		-- ID del codigo, debe ser �nico
							,@PAR7		-- ID del estado del c�digo.
				
				-- SEGUNDO en la tabla [GDicTCodxIdiomas]
				INSERT INTO [BDGral].[dbo].[GDicTCodxIdiomas]
						   ([IDFkTCodigos]
						   ,[IDFkTIdioma]
						   ,[IDFkTCodAmbAplic]
						   ,[Codigo]
						   ,[Descripcion]
						   ,[IDFkCxIEstados])
					 SELECT @PAR2		-- ID del codigo, debe ser �nico
							,@PAR3		-- ID del Idioma
							,@PAR4		-- ID del Ambito de Aplicaci�n del C�digo
							,@PAR5		-- C�digo, debe ser �nico
							,@PAR6		-- Descripcion del codigo
							,@PAR7		-- ID del estado del c�digo.

				-- Carga las variables para mostrar el resultado de procecidmiento almcacenado.
				BEGIN
					-- Estas son las variables que faltan: Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
					SET @RTADO = 'OK' 
					SET @REG_AFEC = 1
					SET @ERR_MESSAGE = 'Se cargo la informacion solicitada.'
					SET @ERR_NUMBER = 0
					SET @ERR_SEVERITY = 0
					SET @ERR_STATE = 0
					SET @ERR_LINE = 0
				END
			
				-- Si el procedimiento es exitoso, confirma la operaci�n.
				COMMIT TRANSACTION;
			END TRY
			-- 2: Si es todo OK, se realiza el cambio y el mismo tiene un error en su implementaci�n, lo atrapa el manejador de errores, deshace los cambios e informa al usuario.
			BEGIN CATCH

				-- Ejecuta el Procedimiento Almacenado para obtener el error.
				EXECUTE [dbo].[GGetErrorInfo] @ERROR_NUMBER = @ERR_NUMBER OUTPUT, @ERROR_SEVERITY = @ERR_SEVERITY OUTPUT, @ERROR_STATE = @ERR_STATE OUTPUT, @ERROR_LINE = @ERR_LINE OUTPUT, @ERROR_MESSAGE = @ERR_MESSAGE OUTPUT

				-- Como la operaci�n fall�, se deshacen las modificaciones.
				ROLLBACK TRANSACTION;

				-- Por las dudas se elimana el registro con el ID generado.
				DELETE FROM [BDGral].[dbo].[GDicTCodigos] WHERE [ID] = @PAR2
				DELETE FROM [BDGral].[dbo].[GDicTCodxIdiomas] WHERE [IDFkTCodigos] = @PAR2;

				-- Resultado Err�neo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				SET @RTADO = 'ERR'
				SET @REG_AFEC = 0
			END CATCH;

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- ##############################################################################################################################################
	-- FINAL -- ALTA DE CODIGO Y SUS DESCRIPCIONES SOLO PARA UN NUEVO IDIOMA -- NO GENERA CODIGO NUEVO
	-- ##############################################################################################################################################
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
END


-- ##############################################################################################################################################
-- MUESTRA EL RESULTADO DEL PROCEDIMIENTO ALMACENADO
-- Envia el resultado: Nombre Proc Alm | Resultado | Cantidad Reg Afectados | Mensaje | Error Numero | Error Severidad | Error Estado | Error Linea
SET @RTADO_PROCALM = @NOMB_PROCALM + '|' + @FUNC_PROCALM + '|' + @RTADO + '|' + CAST(@REG_AFEC AS VARCHAR(10)) + '|' + @ERR_MESSAGE + '|' + CAST(@ERR_NUMBER AS VARCHAR(10)) + '|' + CAST(@ERR_SEVERITY AS VARCHAR(10)) + '|' + CAST(@ERR_STATE AS VARCHAR(10)) + '|' + CAST(@ERR_LINE AS VARCHAR(10))
SELECT @NOMB_PROCALM AS ProcAlm_Nomb, @FUNC_PROCALM AS ProcAlm_Funcion, @RTADO AS ProcAlm_Rtado, @REG_AFEC AS ProcAlm_RegAfec, @ERR_MESSAGE AS ProcAlm_Mensaje, @ERR_NUMBER AS ProcAlm_ErrNum, @ERR_SEVERITY AS ProcAlm_ErrSeveridad, @ERR_STATE AS ProcAlm_ErrEstado, @ERR_LINE AS ProcAlm_ErrLinea
SELECT @RTADO_PROCALM

SELECT [IDgdicTCodigos]
      ,[IDFkTIdioma]
	  ,[IDFkTCodAmbAplic]
      ,[Codigo]
      ,[Descripcion]
      ,[IdiCod]
      ,[Idioma]
	  ,[IDFkCxIEstados]
  FROM [BDGral].[dbo].[GDicVCodigos]
WHERE [IDgdicTCodigos] = @PAR2
--WHERE [Codigo] LIKE 'GCIA%'
--WHERE [IDgdicTCodigos] = 'f66c13cd-aee5-435a-8906-0d5618dabd05'

---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- Muestra la informacion de la tabla idioma
--SET @PAR2 = @PAR4
----DECLARE	@return_value int
--EXEC	@return_value = [dbo].[GDicPCodxIdio] @PAR2
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- ##############################################################################################################################################^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- El GO va al final del procedimiento
GO
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################

