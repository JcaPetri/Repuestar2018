set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

USE [BDGral]
GO


	DECLARE @PAR1 NVARCHAR(50) 
	DECLARE @PAR2 NVARCHAR(50) 
	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	SET @PAR2 = '528CEED9-D2B3-4CB5-8116-01BDAD455C83'		-- Ambito de Aplicaci�n elegido o por defecto = NULL

	DECLARE @TmpTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)

	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDGral].[dbo].[GDicTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDGral].[dbo].[GDicTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1
				AND
			  CxI.[IDFkTCodAmbAplic] = CASE WHEN @PAR2 IS NULL THEN CxI.[IDFkTCodAmbAplic] ELSE @PAR2 END

	-- Muestra las Agrupaciones que Pueden tener los Usuarios, esto surge de la relaci�n entre la tabla:
	-- TUsuAgru (esta �ltima se cargan los datos en las tablas TCodigo y TCodxIdioma, ya que tiene la misma estructura).
	-- En el �mbito de aplicaci�n se pone el c�digo de TUsuAgru como si fuera el nombre de la tabla.
	SELECT IDFkTCodigos
			  ,IDFkTIdioma
			  ,IDFkTCodAmbAplic
			  ,Codigo
			  ,Descripcion
			  ,CodIdioma
			  ,DescIdioma
	 FROM @TmpTCodxIdi
	ORDER BY Codigo
