set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

USE [BDCtral]
GO

-- Tabla [CUsuTUsuarios]
SELECT [ID]
      ,[UsuCod]
      ,[UsuAbr]
      ,[UsuApellido]
      ,[UsuNombre]
      ,[UsuClave]
      ,[UsuEmail]
  FROM [BDCtral].[dbo].[CUsuTUsuarios]

-- Tabla [CUsuTUsuAgru]
SELECT [IDFkTUsuarios]
      ,[IDFkTGUsuTAgrup]
  FROM [BDCtral].[dbo].[CUsuTUsuAgru]



DELETE FROM [BDCtral].[dbo].[CUsuTUsuAgru]
      WHERE [IDFkTUsuarios] IN (
	SELECT TUA.[IDFkTUsuarios]
		FROM [BDCtral].[dbo].[CUsuTUsuAgru] AS TUA WITH(NOLOCK)
			LEFT OUTER JOIN [BDCtral].[dbo].[CUsuTUsuarios] AS TU WITH(NOLOCK)
				ON TUA.[IDFkTUsuarios] = TU.[ID]
		WHERE TU.[ID] IS NULL
	)

