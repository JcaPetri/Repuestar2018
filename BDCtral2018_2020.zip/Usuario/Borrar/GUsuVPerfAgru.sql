set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

USE [BDGral]
GO


	DECLARE @RC int				-- Determina si la consulta tiene valores

	DECLARE @PAR1 NVARCHAR(50) 
	DECLARE @PAR2 NVARCHAR(50) 
	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	SET @PAR2 = '528CEED9-D2B3-4CB5-8116-01BDAD455C83'		-- Ambito de Aplicaci�n elegido o por defecto = NULL

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	-- Procedimiento Almacenado, donde esta la informaci�n de los tipos de perfiles y el perfil disponible.
	-- Surge de la relaci�n entre las tablas GUsuTPerfil y TCodigo y TCodxIdioma
	-- el ambito de aplicaci�n es usuarios
	DECLARE @TmpPPerfilAgrup TABLE			-- Tabla temporal para obtener la informaci�n Usuarios y sus Agrupaciones
	(
		[IDFkPerfil] [uniqueidentifier] NOT NULL,
		[PerfilCod] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[PerfilDesc] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[IDFkTUsuAgrup] [uniqueidentifier] NOT NULL,
		[AgrupUsuCod] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[AgrupUsuDesc] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[IdiomaCod] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[AmbAplicCod] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[AmbAplicDesc] [varchar](250) COLLATE Modern_Spanish_CI_AS -- NOT NULL,
	)

	-- Ejecuta el procedimiento almacenado con valores dependiendo de si tiene o no definido el idioma
	IF @PAR1 IS NULL 
		INSERT INTO @TmpPPerfilAgrup EXECUTE @RC = [dbo].[GUsuPPerfAgrup]
	ELSE
		INSERT INTO @TmpPPerfilAgrup EXECUTE @RC = [dbo].[GUsuPPerfAgrup] @PAR1
		-- El ambito de aplicaci�n no se pone ya que es siempre el mismo
		-- , @PAR2 = N'528CEED9-D2B3-4CB5-8116-01BDAD455C83'		-- Ambito de aplicaci�n tabla usuarios agrupaciones

	-- SELECT * FROM @TmpPPerfil ORDER BY TipoPerfilCod, PerfilCod

	SELECT [IDFkPerfil]
		, [PerfilCod]
		, [PerfilDesc]
		, [IDFkTUsuAgrup]
		, [AgrupUsuCod]
		, [AgrupUsuDesc]
		, [IdiomaCod]
		, [AmbAplicCod]
		, [AmbAplicDesc]
	FROM @TmpPPerfilAgrup
	ORDER BY [PerfilCod]

