set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

USE [BDCtral]
GO

-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 03/10/2018
-- Description:	Muestra la relacion entre los usuarios y sus agrupaciones.
-- Un usuario puede tener muchas agrupaciones (equipos), y una agrupacion (equipo) puede tener muchos usuarios
-- =============================================
ALTER PROCEDURE [dbo].[CUsuPPerTIng_ABM]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 NVARCHAR(50) = NULL										-- Empresa seleccionada
	,@PAR3 NVARCHAR(50) = NULL										-- Usuario seleccionado
AS
BEGIN

--	DECLARE @PAR1 NVARCHAR(50)								-- Idioma elegido o por defecto = espa�ol
--	DECLARE @PAR2 NVARCHAR(50)								-- Empresa seleccionada
--	DECLARE @PAR3 NVARCHAR(50)								-- Usuario seleccionado
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
--	SET @PAR3 = NULL										-- Usuario seleccionado

	DECLARE	@return_value int

-- ###########################################################################################################################
-- Informacion Perfiles de Usuario, surge del Usuario hasta la estructura Empresa (Usuarios Agrupados)
	DECLARE @TmpTCUsuPUsuAgru TABLE				-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkCodEmpresas] [uniqueidentifier] NULL,
		[EmpCod] [nvarchar](50) COLLATE Modern_Spanish_CI_AS NULL,
		[EmpDesc] [nvarchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[IDFkTUsuarios] [uniqueidentifier] NOT NULL,
		[UsuCod] INT,
		[UsuAbr] [nvarchar](50) COLLATE Modern_Spanish_CI_AS NULL,
		[UsuApellido] [nvarchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[UsuNombre] [nvarchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[UsuEmail] [nvarchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[UsuClave] [nvarchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[IDFkTGUsuTAgrup] [uniqueidentifier] NOT NULL,
		[UsuGrupoCod] [nvarchar](50) COLLATE Modern_Spanish_CI_AS NULL,
		[UsuGrupoDesc] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL
	)

	-- Info de los Perfiles asociados a las agrupaciones de perfiles. 
	--	Esto quiere decir que una Agrupaci�n puede tener varios perfiles.
	INSERT INTO @TmpTCUsuPUsuAgru	EXEC @return_value = [dbo].[CUsuPUsuAgru]		-- Tabla 03 - [CUsuTUsuAgru], relaci�n entre los Usuarios T01 y Empresas T02 y sus Agrupaciones
							@PAR1 = @PAR1		-- Idioma elegido o por defecto = espa�ol
							,@PAR2 = @PAR2		-- Empresa Seleccionada
	 --	SELECT * FROM @TmpTCUsuPUsuAgru AS PUA		-- Tabla con la info de los Perfiles Agrupados

--			SELECT PUA.[IDFkCodEmpresas]
--				  ,PUA.[EmpCod]
--				  ,PUA.[EmpDesc]
--				  ,PUA.[IDFkTUsuarios]
--				  ,PUA.[UsuCod]  
--				  ,PUA.[UsuAbr]
--				  ,PUA.[UsuEmail]
--				  ,UP.[IDFkTCDiccTCod_UsuAgrup]
--				  ,PUA.[UsuGrupoCod]
--				  ,PUA.[UsuGrupoDesc]
--				  ,UP.[IDFkTCDiccTCod_Perfil]
--			FROM [BDCtral].[dbo].[CUsuTPerfUsuAgru] AS UP WITH(NOLOCK)
--				LEFT OUTER JOIN @TmpTCUsuPUsuAgru AS PUA
--					ON UP.[IDFkTCDiccTCod_UsuAgrup] = PUA.[IDFkTGUsuTAgrup]

	-- Borra los datos ingresados
	DELETE FROM [BDCtral].[dbo].[CUsuTPerfTIng]
		  WHERE [IDFkTEmpresa] = @PAR2				-- Empresa Seleccionada
				AND [IDFkTTipoTabla] = '69752B6B-9B31-402B-83DC-4E945DF7879C'		-- CPerfTPerfil	tabla perfiles de usuarios agrupados

	-- Inserta los datos en la tabla PerfIngreso 
	INSERT INTO [BDCtral].[dbo].[CUsuTPerfTIng]
			   ([IDFkTUsuarios]
			    ,[IDFkTEmpresa]
			    ,[IDFkTTipoTabla]
			    ,[IDFkTPerfilAccProc]
				)
			SELECT PUA.[IDFkTUsuarios]
				  ,PUA.[IDFkCodEmpresas]
				  ,'69752B6B-9B31-402B-83DC-4E945DF7879C'		-- CPerfTPerfil	tabla perfiles de usuarios agrupados
				  ,UP.[IDFkTCDiccTCod_Perfil]
			FROM [BDCtral].[dbo].[CUsuTPerfUsuAgru] AS UP WITH(NOLOCK)
				LEFT OUTER JOIN @TmpTCUsuPUsuAgru AS PUA
					ON UP.[IDFkTCDiccTCod_UsuAgrup] = PUA.[IDFkTGUsuTAgrup]


-- ###########################################################################################################################
-- Informacion del Acceso a Procesos, surge ir desde el Usuario, hasta el Acceso de los Procesos
	DECLARE @TmpTPerfAccProc TABLE				-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkCodEmpresas] [uniqueidentifier] NULL,
		[EmpCod] [nvarchar](50) COLLATE Modern_Spanish_CI_AS NULL,
		[EmpDesc] [nvarchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[IDFkTPerfil] [uniqueidentifier] NOT NULL,
		[PerfilCod] [nvarchar](50) COLLATE Modern_Spanish_CI_AS NULL,
		[PerfilDesc] [nvarchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[IDFkTAccProc] [uniqueidentifier] NOT NULL,
		[AccProcCod] [nvarchar](50) COLLATE Modern_Spanish_CI_AS NULL,
		[AccProcDesc] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL
	)

	-- Info de los Perfiles asociados a las agrupaciones de perfiles. 
	--	Esto quiere decir que una Agrupaci�n puede tener varios perfiles.
	INSERT INTO @TmpTPerfAccProc	EXEC @return_value = [dbo].[CPerfPPerfAccProc]				-- Tabla 06 -- Perfiles asociados a las agrupaciones de perfiles. Esto quiere decir que una Agrupaci�n puede tener varios perfiles. Varios perfiles pueden estar asociados a varias agrupaciones
						@PAR1 = @PAR1		-- Idioma elegido o por defecto = espa�ol
						,@PAR2 = @PAR2		-- Empresa Seleccionada

--	 	SELECT * FROM @TmpTPerfAccProc AS PAP		-- Tabla con la info de los Perfiles Acceso a los Procesos

		-- Consulta que relaciona el Usuario hasta el Acceso a Proceso
--			SELECT PUA.[IDFkCodEmpresas]
--				  ,PUA.[EmpCod]
--				  ,PUA.[EmpDesc]
--				  ,PUA.[IDFkTUsuarios]
--				  ,PUA.[UsuCod]  
--				  ,PUA.[UsuAbr]
--				  ,PUA.[UsuEmail]
--				  ,UP.[IDFkTCDiccTCod_UsuAgrup]
--				  ,PUA.[UsuGrupoCod]
--				  ,PUA.[UsuGrupoDesc]
--				  ,UP.[IDFkTCDiccTCod_Perfil]
--				  ,PAP.[PerfilCod]
--				  ,PAP.[PerfilDesc]
--				  ,PAP.[IDFkTAccProc]
--				  ,PAP.[AccProcCod]
--				  ,PAP.[AccProcDesc]
--			FROM [BDCtral].[dbo].[CUsuTPerfUsuAgru] AS UP WITH(NOLOCK)
--				LEFT OUTER JOIN @TmpTCUsuPUsuAgru AS PUA
--					ON UP.[IDFkTCDiccTCod_UsuAgrup] = PUA.[IDFkTGUsuTAgrup]
--				LEFT OUTER JOIN @TmpTPerfAccProc AS PAP
--					ON UP.[IDFkTCDiccTCod_Perfil] = PAP.[IDFkTPerfil]

	-- Borra los datos ingresados
	DELETE FROM [BDCtral].[dbo].[CUsuTPerfTIng]
		  WHERE [IDFkTEmpresa] = @PAR2				-- Empresa Seleccionada
				AND [IDFkTTipoTabla] = '50E6A111-D9BE-4CF7-9115-69A1294EACAB'		-- CPerfTAccesoProcesos	tabla acceso a los procesos del sistema

	-- Inserta los datos en la tabla PerfIngreso 
	INSERT INTO [BDCtral].[dbo].[CUsuTPerfTIng]
			   ([IDFkTUsuarios]
			    ,[IDFkTEmpresa]
			    ,[IDFkTTipoTabla]
			    ,[IDFkTPerfilAccProc]
				)
			SELECT PUA.[IDFkTUsuarios]
				  ,PUA.[IDFkCodEmpresas]
				  ,'50E6A111-D9BE-4CF7-9115-69A1294EACAB'		-- CPerfTAccesoProcesos	tabla acceso a los procesos del sistema
				  ,PAP.[IDFkTAccProc]
			FROM [BDCtral].[dbo].[CUsuTPerfUsuAgru] AS UP WITH(NOLOCK)
				LEFT OUTER JOIN @TmpTCUsuPUsuAgru AS PUA
					ON UP.[IDFkTCDiccTCod_UsuAgrup] = PUA.[IDFkTGUsuTAgrup]
				LEFT OUTER JOIN @TmpTPerfAccProc AS PAP
					ON UP.[IDFkTCDiccTCod_Perfil] = PAP.[IDFkTPerfil]
			GROUP BY  PUA.[IDFkTUsuarios]
				  ,PUA.[IDFkCodEmpresas]
				  ,PAP.[IDFkTAccProc]
END

-- Actualiza la tabla de [CUsuTPerfTIng], con la informacion de los perfiles y los acceso a los procesos para una empresa
--		Primero: va desde la tabla [CUsuTUsuarios] hasta la tabla [CPerfTPerfil], que esta en [CDiccTCodigos] y [CDiccTCodxIdiomas] 
--		Segundo: va desde la tabla [CUsuTUsuarios] hasta la tabla [CPerfTAccesoProcesos], que esta en [CDiccTCodigos] y [CDiccTCodxIdiomas] 
-- de esta forma se tiene para un usuario, los perfiles asociados y los acceso a los procesos habilitados
--	DECLARE	@return_value int
--	EXEC @return_value = [dbo].[CUsuPPerTIng_ABM]				-- Tabla 07 -- Relacion entre los Usuarios Agrupados y los Perfiles Agrupados
--			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--			,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment
----			,@PAR3 = ''		-- Usuario
--	





