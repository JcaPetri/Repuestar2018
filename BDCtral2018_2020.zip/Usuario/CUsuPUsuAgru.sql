set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

USE [BDCtral]
GO

-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 22/07/2017
-- Description:	Muestra la relacion entre los usuarios y sus agrupaciones.
-- Un usuario puede tener muchas agrupaciones (equipos), y una agrupacion (equipo) puede tener muchos usuarios
-- =============================================
ALTER PROCEDURE [dbo].[CUsuPUsuAgru]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 NVARCHAR(50) = NULL		-- Empresa
AS
BEGIN


--	DECLARE @PAR1 NVARCHAR(50)			-- Idioma elegido o por defecto = espa�ol
--	DECLARE @PAR2 NVARCHAR(50)		-- Empresa Seleccionada
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment

	DECLARE @PARInt1 NVARCHAR(50)		-- Ambito de Aplicaci�n elegido TUSUAGRUP = Tabla usuarios agrupaciones
	SET @PARInt1 = '528CEED9-D2B3-4CB5-8116-01BDAD455C83'		-- TUSUAGRUP = Tabla usuarios agrupaciones

	DECLARE @TmpTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1
	--	SELECT * FROM @TmpTCodxIdi WHERE [IDFkTCodigos] = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'


	-- Muestra los grupos de usuarios, esto surge de la relaci�n entre las tablas:
	-- [GUsuTUsuarios] y [GUsuTUsuAgru].
	-- (esta �ltima se cargan los datos en las tablas TCodigo y TCodxIdioma, ya que tiene la misma estructura).
	-- En el �mbito de aplicaci�n se pone el c�digo de GUsuTAgrup como si fuera el nombre de la tabla.
	SELECT TC.[IDFkCodEmpresas]
		  ,CxI2.[Codigo] AS [EmpCod]
		  ,CxI2.[Descripcion] AS [EmpDesc]
		  ,UA.[IDFkTUsuarios]			-- Es igual al ID Usuario. Si hay algun usuario que no esta en esta tabla de TUsuAgru y no en la Tabla TUsuario, no saldr� el detalle del usuario. Esto es para control.
		  ,TU.[UsuCod]
		  ,TU.[UsuAbr]
		  ,TU.[UsuApellido]
		  ,TU.[UsuNombre]
		  ,TU.[UsuEmail]
		  ,TU.[UsuClave]
		  ,UA.[IDFkTGUsuTAgrup]			-- Es igual al ID [CDiccTCodxIdiomas]. Si hay alguna Empresa/Sector que no tenga el detalle, es que se borr� de esta tabla.
		  ,CxI1.[Codigo] AS [UsuGrupoCod]
		  ,CxI1.[Descripcion] AS [UsuGrupoDesc]
--		  ,CxI1.[IDFkTIdioma] AS [IDIdioma]
--		  ,CxI1.CodIdioma AS [IdiomaCod]
--		  ,CxI1.DescIdioma AS [IdiomaDesc]
--		  ,CxI1.[IDFkTCodAmbAplic]
--		  ,CxI3.[Codigo] AS [AmbAplicCod]
--		  ,CxI3.[Descripcion] AS [AmbAplicDesc]
	  FROM [BDCtral].[dbo].[CUsuTUsuAgru] AS UA WITH(NOLOCK)
		LEFT OUTER JOIN [BDCtral].[dbo].[CUsuTUsuarios] AS TU WITH(NOLOCK)
			ON UA.[IDFkTUsuarios] = TU.[ID]
		LEFT OUTER JOIN @TmpTCodxIdi AS CxI1			-- Detalle del C�digo
			ON UA.[IDFkTGUsuTAgrup] = CxI1.[IDFkTCodigos]
				LEFT OUTER JOIN [BDCtral].[dbo].[CDiccTCodigos] AS TC WITH(NOLOCK)
					ON CxI1.[IDFkTCodigos] = TC.[ID]
						LEFT OUTER JOIN @TmpTCodxIdi AS CxI2
							ON TC.[IDFkCodEmpresas] = CxI2.[IDFkTCodigos]
								-- Trae el c�digo de la empresa seleccionada y el multiidioma
								AND (TC.[IDFkCodEmpresas] = CASE WHEN @PAR2 IS NULL THEN TC.[IDFkCodEmpresas] ELSE @PAR2 END 
										OR TC.[IDFkCodEmpresas] = 'A5E49ED6-EFDD-4C43-955F-7F3616E39F99')
		LEFT OUTER JOIN @TmpTCodxIdi AS CxI3			-- Detalle del Ambito de Aplicaci�n
			ON CxI1.[IDFkTCodAmbAplic] = CxI3.[IDFkTCodigos]
	  ORDER BY TU.[UsuAbr]

END


--
--DECLARE	@return_value int
--EXEC	@return_value = [dbo].[CUsuPUsuAgru]		-- Tabla 02 - [CDiccTCodigos] y [CDiccTCodxIdiomas], datos de las Empresas y sus agrupaciones
--			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--			,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment		
