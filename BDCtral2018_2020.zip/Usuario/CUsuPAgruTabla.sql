set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO

-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 25/08/2017
-- Description:	Muestra los distintos grupos (equipos, sectores, etc) de usuarios.
-- =============================================
ALTER PROCEDURE [dbo].[CUsuPAgruTabla]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 NVARCHAR(50) = NULL										-- Empresa
AS
BEGIN

--	DECLARE @PAR1 NVARCHAR(50)		-- Idioma elegido o por defecto = espa�ol
--	DECLARE @PAR2 NVARCHAR(50)		-- Empresa Seleccionada
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment

	DECLARE @PARInt1 NVARCHAR(50)								-- Ambito de Aplicaci�n elegido TUSUAGRUP = Tabla usuarios agrupaciones
	SET @PARInt1 = '528CEED9-D2B3-4CB5-8116-01BDAD455C83'		-- TUSUAGRUP = Tabla usuarios agrupaciones


	DECLARE @TmpTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1

	--	SELECT * FROM @TmpTCodxIdi WHERE [IDFkTCodigos] = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'

	-- Muestra las agrupaciones
	SELECT TC.[IDFkCodEmpresas]
		,CxI2.[Codigo] AS [EmpCod]
		,CxI2.[Descripcion] AS [EmpDesc]
		,CxI1.[IDFkTCodigos]
		,CxI1.[Codigo]
		,CxI1.[Descripcion]
		,CxI1.[IDFkTCodAmbAplic]
		,CxI1.[IDFkTIdioma]
		,CxI1.[CodIdioma]
		,CxI1.[DescIdioma]
	FROM @TmpTCodxIdi AS CxI1
		INNER JOIN [BDCtral].[dbo].[CDiccTCodigos] AS TC WITH(NOLOCK)
			ON CxI1.[IDFkTCodigos] = TC.[ID]
				INNER JOIN @TmpTCodxIdi AS CxI2
					ON TC.[IDFkCodEmpresas] = CxI2.[IDFkTCodigos]
						-- Trae el c�digo de la empresa seleccionada y el multiidioma
						AND (TC.[IDFkCodEmpresas] = CASE WHEN @PAR2 IS NULL THEN TC.[IDFkCodEmpresas] ELSE @PAR2 END 
								OR TC.[IDFkCodEmpresas] = 'A5E49ED6-EFDD-4C43-955F-7F3616E39F99')
	WHERE CxI1.[IDFkTCodAmbAplic] = @PARInt1		-- CASE WHEN @PARInt1 IS NULL THEN CxI.[IDFkTCodAmbAplic] ELSE @PARInt1 END
			AND CxI1.[IDFkTCodigos] <> CxI1.[IDFkTCodAmbAplic]		-- Elimina el Ambito de Aplicaci�n
	ORDER BY CxI1.[Codigo]

END


--DECLARE	@return_value int
--EXEC	@return_value = [dbo].[CUsuPAgruTabla]		-- Tabla 02 - [CDiccTCodigos] y [CDiccTCodxIdiomas], datos de las Empresas y sus agrupaciones
--			@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--			,@PAR2 = '56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'		-- BPM	Business Process Managment		
