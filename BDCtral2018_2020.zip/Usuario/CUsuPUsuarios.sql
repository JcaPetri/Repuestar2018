set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go
USE [BDCtral]
GO
-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 30/09/2018
-- Description:	Listado de Usuarios
-- =============================================
ALTER PROCEDURE [dbo].[CUsuPUsuarios]

AS
BEGIN

	-- Muestra los grupos de usuarios, esto surge de la Tabla: [CUsuTUsuarios]
	SELECT [ID]
		  ,[UsuCod]
		  ,[UsuAbr]
		  ,[UsuApellido]
		  ,[UsuNombre]
		  ,[UsuClave]
		  ,[UsuEmail]
	  FROM [BDCtral].[dbo].[CUsuTUsuarios]

END
