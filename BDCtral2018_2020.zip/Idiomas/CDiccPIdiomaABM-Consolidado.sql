-- ###############################################################################################################################3
--  GENERA LOS PROCEDIMIENTOS ALMACENADOS PARA HACER EL ALTA, MODIFICACION, BAJA O RECUPERO DE LOS IDIOMAS -- 
-- ###############################################################################################################################3

-- Define que se trabaja con al Base de Datos
USE [BDCtral]
GO
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Muestra la informacion de la tabla idioma
DECLARE	@return_value int
EXEC	@return_value = [dbo].[CDiccPIdioma]
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

---- Listado de Idiomas disponibles, con sus c�digos
--SELECT [ID]
--      ,[CodIdioma]
--      ,[DescIdioma]
--      ,[IDFkIdiEstados]
--  FROM [BDCtral].[dbo].[GDicTIdioma] AS TI WITH(NOLOCK)
--
--GO



SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para agregar un nuevo Idioma, se debe:
	-- Variables Etapa 1
	DECLARE @PAR1 AS VARCHAR(50)	-- Determina acci�na realizar 
		-- valores posibles: ALTA - MODIFICACION - BAJA - RECUPERO

	DECLARE @PAR2 AS VARCHAR(36)	-- valor ID, debe ser �nico
		-- Caso Alta: valor nuevo se genera con el NewID()
		-- Caso Modificaci�n: 
			-- con este valor ID se buscan los datos, luego si hay diferencias se modifica el valor
			-- Si la diferencia es en el estado es simple, solo se cambia.
			-- Si la diferencia es en el CodIdoma o DescIdioma, primero hay que verificar que ya no este usuado.
	DECLARE @PAR3 AS VARCHAR(50)	-- codigo del nuevo idioma, debe ser �nico
		-- Caso Alta: codigo del nuevo idioma, debe ser �nico
			-- Las claves ID son la combinacion del ID y CodIdioma, pero antes de agregar un registro debemos verificar
			-- que el CodIdioma y la DescIdioma no esten ya definidos
		-- Caso Modificaci�n:
			--  Codigo nuevo del idioma, no se debe haber utilizado, si es as� no se genera la modificaci�n
	DECLARE @PAR4 AS VARCHAR(250)	-- descripcion del idioma, debe ser �nico
		-- Caso Alta: 
			-- descripci�n del idioma, no se debe repetir, idem c�digo
		-- Caso Modificaci�n: 
			-- Descripci�n nueva del idioma, no se debe haber utilizado, si es as� no se genera la modificaci�n
	DECLARE @PAR5 AS VARCHAR(36) 	-- valor ID del estado del idioma (habilitado o deshabilitado), por defecto va habilitado
		-- Caso Alta:
			-- Es un c�digo ID con las distintas opciones, estas pueden ser. Habilitado, Deshabilitado, Eliminado.
		-- Caso Modificaci�n:
			-- Idem Alta.

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Seteo de las variables
--	SET @PAR1 = 'ALTA'		-- Que funci�n ejecuta
--	SET @PAR2 = NEWID()				-- ID del idioma, debe ser �nico
--	SET @PAR3 = 'jXP'				-- C�digo del idioma, debe ser �nico
--	SET @PAR4 = 'j�ol'			-- Descripcion del idioma
--	SET @PAR5 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'			-- ID del estado del Idioma		
----										 Deshabilitado = EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0
----										 Habilitado = C6FE2749-0CB8-49CD-97DF-03C299C0C6CF
----										 Baja = '3749D6D8-EF8F-4C37-893A-BE7209239810'
--
--	SET @PAR1 = 'MODIFICACION'		-- Que funci�n ejecuta
--	SET @PAR2 = '0038A8B9-6F76-4B7C-A72F-1AA50567557B'				-- ID del idioma, debe ser �nico
--	SET @PAR3 = 'FOP'				-- C�digo del idioma, debe ser �nico
--	SET @PAR4 = 'MMM'			-- Descripcion del idioma
--	SET @PAR5 = 'EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0'			-- ID del estado del Idioma		
----										 Deshabilitado = EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0
----										 Habilitado = C6FE2749-0CB8-49CD-97DF-03C299C0C6CF
----										 Baja = '3749D6D8-EF8F-4C37-893A-BE7209239810'
--
--	SET @PAR1 = 'BAJA'												-- Que funci�n ejecuta
--	SET @PAR2 = '0038A8B9-6F76-4B7C-A72F-1AA50567557B'				-- ID del idioma que se dar� de baja, debe ser �nico
--	SET @PAR3 = NULL				-- C�digo del idioma, debe ser �nico
--	SET @PAR4 = NULL			-- Descripcion del idioma
--	SET @PAR5 = '3749D6D8-EF8F-4C37-893A-BE7209239810'			-- ID del estado del Idioma		
----										 Deshabilitado = EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0
----										 Habilitado = C6FE2749-0CB8-49CD-97DF-03C299C0C6CF
----										 Baja = '3749D6D8-EF8F-4C37-893A-BE7209239810'
----
--	SET @PAR1 = 'RECUPERO'												-- Que funci�n ejecuta
--	SET @PAR2 = '0038A8B9-6F76-4B7C-A72F-1AA50567557B'				-- ID del idioma que se recuperar�, debe ser �nico
--	SET @PAR3 = NULL				-- C�digo del idioma, debe ser �nico
--	SET @PAR4 = NULL			-- Descripcion del idioma
--	SET @PAR5 = 'EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0'			-- ID del estado del Idioma, se recupera al estado deshabilitado
----										 Deshabilitado = EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0
----										 Habilitado = C6FE2749-0CB8-49CD-97DF-03C299C0C6CF
----										 Baja = '3749D6D8-EF8F-4C37-893A-BE7209239810'

IF @PAR1 = 'ALTA'
BEGIN
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- INICIO	-- ALTA DE IDIOMA
-- ##############################################################################################################################################

-- Etapa 1: verifica que el idioma que se quiere agregar ya no este creado
	SELECT @PAR2 = NULL		-- Si alguno de los valores son encontrados, la variable @PAR1 se pone a NULL
	  FROM [BDCtral].[dbo].[CDiccTIdioma] AS TI WITH(NOLOCK)
	WHERE [CodIdioma] = @PAR3 OR [DescIdioma] = @PAR4

--	SELECT @PAR2

-- Etapa 2: Si el idioma no esta creado lo hace
	IF @PAR2 IS NULL
		-- No hace nada, ya que el Codigo del idioma que esta queriendo usar ya esta creado.
		SELECT @PAR2 = @PAR2
	ELSE
		-- Inserta el Idioma
		INSERT INTO [BDCtral].[dbo].[CDiccTIdioma]
				   ([ID]
				   ,[CodIdioma]
				   ,[DescIdioma]
				   ,[IDFkIdiEstados])
			 SELECT 
					@PAR2,	-- ID idioma
					@PAR3,	-- Codigo 
					@PAR4,	-- Descripcion
					@PAR5	-- Estado
END
-- ##############################################################################################################################################
-- FINAL -- ALTA DE IDIOMA
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

ELSE 
IF @PAR1 = 'MODIFICACION'
BEGIN
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- INICIO	-- MODIFICACION DE IDIOMA
-- ##############################################################################################################################################
	DECLARE @PAR3Actual AS VARCHAR(50)		-- C�digo del idioma Actual, debe ser �nico
	DECLARE @PAR4Actual AS VARCHAR(250)		-- Descripcion del idioma Actual
	DECLARE @PAR5Actual AS VARCHAR(36)		-- ID del estado del Idioma	Actual

-- Etapa 1: toma la informacion del codigo ID a modificar
	SELECT @PAR3Actual = [CodIdioma]
		  ,@PAR4Actual = [DescIdioma]
		  ,@PAR5Actual = [IDFkIdiEstados]
	  FROM [BDCtral].[dbo].[CDiccTIdioma] AS TI WITH(NOLOCK)
	WHERE [ID] = @PAR2

	-- SELECT @PAR2, @PAR3, @PAR3Actual, @PAR4, @PAR4Actual, @PAR5, @PAR5Actual

-- Etapa 2: Si primero verifica si se puede ejecutar el cambio, Validamos el CodIdioma y DescIdioma, que son claves y no se pueden repetir en la tabla
	-- Antes de modificar el idioma, se debe determinar si los nuevos valores ya estan utilizados, 
	-- en otro registro que no sea el que se va a modificar
	SELECT @PAR2 = NULL		-- Si alguno de los valores son encontrados, la variable @PAR1 se pone a NULL
	  FROM [BDCtral].[dbo].[CDiccTIdioma] AS TI WITH(NOLOCK)
	WHERE [ID] <> @PAR2 AND ([CodIdioma] = @PAR3 OR [DescIdioma] = @PAR4)
	
--	SELECT @PAR2

-- Etapa 2: Si primero verifica el elemento que cambio
	IF @PAR2 IS NULL
		-- No hace nada, ya que no se viola una clave principal
		SELECT @PAR2 = @PAR2
	ELSE
		-- �qu� no se viola ninguna clave principal, por lo tanto se modifica el idioma
		IF @PAR3 <> @PAR3Actual OR @PAR4 <> @PAR4Actual OR @PAR5 <> @PAR5Actual
			-- Modifica el Idioma
			UPDATE [BDCtral].[dbo].[CDiccTIdioma]
			   SET [CodIdioma] = @PAR3
				  ,[DescIdioma] = @PAR4
				  ,[IDFkIdiEstados] = @PAR5
			 WHERE [ID] = @PAR2
		ELSE
			-- No hace nada, ya que no modifica el idioma
			SELECT @PAR2 = @PAR2
END
-- ##############################################################################################################################################
-- FINAL	-- MODIFICACION DE IDIOMA
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

ELSE
IF @PAR1 = 'BAJA'
BEGIN
-- ##############################################################################################################################################
-- INICIO	-- BAJA DE IDIOMA
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para eliminar un Idioma, en realidad lo que se hace es cambiar es estado a Eliminado
	-- Modifica el estado del Idioma a Baja y cambia el c�digo y la descripci�n poni�ndo la leyenda eliminado.
	-- esto es para que esos c�digos se puedan volver a utilizar.
	UPDATE [BDCtral].[dbo].[CDiccTIdioma]
	   SET [CodIdioma] = 'ELI-' + [CodIdioma]
			,[DescIdioma] = 'ELI-' + [DescIdioma]
			,[IDFkIdiEstados] = @PAR5		-- Generar c�digo de Eliminado
	 WHERE [ID] = @PAR2		-- Idioma a dar de baja
				-- Estado Habilitado, Solo se puede dar de baja un idioma en estado Habilitado o Deshabilitado.
			AND ([IDFkIdiEstados] = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF' OR [IDFkIdiEstados] = 'EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0')
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
END
-- ##############################################################################################################################################
-- FINAL	-- BAJA DE IDIOMA
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

ELSE
IF @PAR1 = 'RECUPERO'
BEGIN
-- ##############################################################################################################################################
-- INICIO	-- RECUPERO DE IDIOMA
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para eliminar un Idioma, en realidad lo que se hace es cambiar es estado a Eliminado
	-- Modifica el estado del Idioma a Baja y cambia el c�digo y la descripci�n poni�ndo la leyenda eliminado.
	-- esto es para que esos c�digos se puedan volver a utilizar.
	UPDATE [BDCtral].[dbo].[CDiccTIdioma]
	   SET [CodIdioma] = 'REC-' + SUBSTRING([CodIdioma], 5, LEN([CodIdioma])-4)
			,[DescIdioma] = 'REC-' + SUBSTRING([DescIdioma], 5, LEN([DescIdioma])-4)
			,[IDFkIdiEstados] = @PAR5		-- Generar c�digo de Eliminado
	 WHERE [ID] = @PAR2			-- C�digo del Idioma a Recuperar
			AND [IDFkIdiEstados] = '3749D6D8-EF8F-4C37-893A-BE7209239810'		-- Estado dado de Baja, Solo se puede recuperar un idioma dado de baja.
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
END
-- ##############################################################################################################################################
-- FINAL	-- RECUPERO DE IDIOMA
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^




-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Muestra la informacion de la tabla idioma
DECLARE	@return_value int
EXEC	@return_value = [dbo].[CDiccPIdioma]
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- ##############################################################################################################################################^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- El GO va al final del procedimiento
GO
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################








