-- ###############################################################################################################################3
--  GENERA LOS PROCEDIMIENTOS ALMACENADOS PARA HACER EL ALTA, BAJA O MODIFICACION DE LOS IDIOMAS -- 
-- ###############################################################################################################################3

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- ALTA DE IDIOMA		INICIO
-- ##############################################################################################################################################

-- Define que se trabaja con al Base de Datos
USE [BDCtral]
GO
--
---- Listado de Idiomas disponibles, con sus c�digos
--SELECT [ID]
--      ,[CodIdioma]
--      ,[DescIdioma]
--      ,[IDgdicTCodigos]
--  FROM [BDCtral].[dbo].[GDicTIdioma] AS TI WITH(NOLOCK)
--
--GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para agregar un nuevo Idioma, se debe:
	-- Variables Etapa 1
	DECLARE @PAR1 AS VARCHAR(50)	-- valor ID, debe ser �nico
	DECLARE @PAR2 AS VARCHAR(36)	-- codigo del nuevo idioma, debe ser �nico
	-- Las claves ID son la combinacion del ID y CodIdioma, pero antes de agregar un registro debemos verificar
	-- que el CodIdioma y la DescIdioma no esten ya definidos
	DECLARE @PAR3 AS VARCHAR(50)	-- descripcion del idioma, debe ser �nico
	DECLARE @PAR4 AS VARCHAR(36) 	-- valor ID del estado del idioma (habilitado o deshabilitado), por defecto va habilitado
	
	SET @PAR1 = NEWID()				-- ID del idioma, debe ser �nico
	SET @PAR2 = 'EXP'				-- C�digo del idioma, debe ser �nico
	SET @PAR3 = 'EspI�ol'			-- Descripcion del idioma
	SET @PAR4 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'			-- ID del estado del Idioma		
										-- Deshabilitado = EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0
										-- Habilitado = C6FE2749-0CB8-49CD-97DF-03C299C0C6CF

-- Etapa 1: verifica que el idioma que se quiere agregar ya no este creado
	SELECT @PAR1 = NULL		-- Si alguno de los valores son encontrados, la variable @PAR1 se pone a NULL
	  FROM [BDCtral].[dbo].[CDiccTIdioma] AS TI WITH(NOLOCK)
	WHERE [CodIdioma] = @PAR2 OR @PAR3 = [DescIdioma]

--	SELECT @PAR1

-- Etapa 2: Si el idioma no esta creado lo hace
	IF @PAR1 IS NULL
		-- No hace nada
		SELECT @PAR1 = @PAR1
	ELSE
		-- Inserta el Idioma
		INSERT INTO [BDCtral].[dbo].[CDiccTIdioma]
				   ([ID]
				   ,[CodIdioma]
				   ,[DescIdioma]
				   ,[IDgdicTCodigos])
			 SELECT 
					@PAR1,	-- ID idioma
					@PAR2,	-- Codigo 
					@PAR3,	-- Descripcion
					@PAR4	-- Estado
GO
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- Muestra la informacion de la tabla idioma
DECLARE	@return_value int
EXEC	@return_value = [dbo].[CDiccPIdioma]

GO
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- ALTA DE IDIOMA		FINAL
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^







-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- MODIFICACION DE IDIOMA		INICIO
-- ##############################################################################################################################################

-- Define que se trabaja con al Base de Datos
USE [BDCtral]
GO
--
---- Listado de Idiomas disponibles, con sus c�digos
--SELECT [ID]
--      ,[CodIdioma]
--      ,[DescIdioma]
--      ,[IDgdicTCodigos]
--  FROM [BDCtral].[dbo].[GDicTIdioma] AS TI WITH(NOLOCK)
--
--GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para modificar un Idioma, se debe determinar primero si se quiere modificar:
			--	el codigo o 
			--	su descripcion que son valores claves y unicos 
			--	o solo el estado.

	-- Variables Etapa 1
	DECLARE @PAR1 AS VARCHAR(50)	-- valor ID, debe ser �nico
	-- con este valor ID se buscan los datos, luego si hay diferencias se modifica el valor
	-- Si la diferencia es en el estado es simple, solo se cambia.
	-- Si la diferencia es en el CodIdoma o DescIdioma, primero hay que verificar que ya no este usuado.

	DECLARE @PAR2 AS VARCHAR(36)	-- codigo del nuevo idioma que se desea modificar
	DECLARE @PAR3 AS VARCHAR(50)	-- descripcion del idioma, debe ser �nico
	DECLARE @PAR4 AS VARCHAR(36) 	-- valor ID del estado del idioma (habilitado o deshabilitado), por defecto va habilitado


	DECLARE @PAR2Act AS VARCHAR(36) 	-- codigo actual
	DECLARE @PAR3Act AS VARCHAR(36) 	-- descripcion actual
	DECLARE @PAR4Act AS VARCHAR(36) 	-- estado actual del idioma (habilitado o deshabilitado), por defecto va habilitado

	
	SET @PAR1 = 'B97BEB5E-7B5B-4DF3-8FF5-D5DF1EFA1C55'				-- ID del idioma a modificar

	SET @PAR2 = 'EjP'										-- C�digo del idioma, nuevo, debe ser �nico
	SET @PAR3 = 'Otros'									-- Descripcion del idioma, nueva.
	SET @PAR4 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'			-- ID del estado del Idioma, nuevo		
										-- Deshabilitado = EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0
										-- Habilitado = C6FE2749-0CB8-49CD-97DF-03C299C0C6CF

-- Etapa 1: toma la informacion del codigo ID a modificar
	SELECT @PAR2Act = [CodIdioma]
		  ,@PAR3Act = [DescIdioma]
		  ,@PAR4Act = [IDgdicTCodigos]
	  FROM [BDCtral].[dbo].[CDiccTIdioma] AS TI WITH(NOLOCK)
	WHERE [ID] = @PAR1

	-- SELECT @PAR1, @PAR2, @PAR2Act, @PAR3, @PAR3Act, @PAR4, @PAR4Act

-- Etapa 2: Si primero verifica si se puede ejecutar el cambio, Validamos el CodIdioma y DescIdioma, que son claves y no se pueden repetir en la tabla
	-- Antes de modificar el idioma, se debe determinar si los nuevos valores ya estan utilizados, 
	-- en otro registro que no sea el que se va a modificar
	SELECT @PAR1 = NULL		-- Si alguno de los valores son encontrados, la variable @PAR1 se pone a NULL
	  FROM [BDCtral].[dbo].[CDiccTIdioma] AS TI WITH(NOLOCK)
	WHERE [ID] <> @PAR1 AND ([CodIdioma] = @PAR2 OR [DescIdioma] = @PAR3)
	
--	SELECT @PAR1	

-- Etapa 2: Si primero verifica el elemento que cambio
	IF @PAR1 IS NULL
		-- No hace nada, ya que no se viola una clave principal
		SELECT @PAR1 = @PAR1
	ELSE
		-- �qu� no se viola ninguna clave principal, por lo tanto se modifica el idioma
		IF @PAR2 <> @PAR2Act OR @PAR3 <> @PAR3Act OR @PAR4 <> @PAR4Act
			-- Modifica el Idioma
			UPDATE [BDCtral].[dbo].[CDiccTIdioma]
			   SET [CodIdioma] = @PAR2
				  ,[DescIdioma] = @PAR3
				  ,[IDgdicTCodigos] = @PAR4
			 WHERE [ID] = @PAR1
		ELSE
			-- No hace nada, ya que no modifica el idioma
			SELECT @PAR1 = @PAR1
GO
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- Muestra la informacion de la tabla idioma
DECLARE	@return_value int
EXEC	@return_value = [dbo].[CDiccPIdioma]

GO
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- MODIFICACION DE IDIOMA		FINAL
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^









-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- ELIMINACI�N DE IDIOMA		INICIO
-- ##############################################################################################################################################

-- Define que se trabaja con al Base de Datos
USE [BDCtral]
GO
--
---- Listado de Idiomas disponibles, con sus c�digos
--SELECT [ID]
--      ,[CodIdioma]
--      ,[DescIdioma]
--      ,[IDgdicTCodigos]
--  FROM [BDCtral].[dbo].[GDicTIdioma] AS TI WITH(NOLOCK)
--
--GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para eliminar un Idioma, en realidad lo que se hace es cambiar es estado a Eliminado

	-- Variables Etapa 1
	DECLARE @PAR1 AS VARCHAR(50)	-- valor ID, debe ser �nico
	-- con este ID se deben eliminar todos los registros de todas las tablas donde esta vinculado

	SET @PAR1 = 'B97BEB5E-7B5B-4DF3-8FF5-D5DF1EFA1C55'				-- ID del idioma a eliminar

	-- Modifica el Idioma
	UPDATE [BDCtral].[dbo].[CDiccTIdioma]
	   SET [IDgdicTCodigos] = '3749D6D8-EF8F-4C37-893A-BE7209239810'		-- Generar c�digo de Eliminado
	 WHERE [ID] = @PAR1
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- Muestra la informacion de la tabla idioma
DECLARE	@return_value int
EXEC	@return_value = [dbo].[CDiccPIdioma]

GO
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- ELIMINACI�N DE IDIOMA		FINAL
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

