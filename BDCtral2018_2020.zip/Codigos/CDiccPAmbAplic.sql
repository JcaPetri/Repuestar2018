set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- Determina la base de datos donde se trabajar�
USE [BDCtral]
GO

-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 22/07/2017
-- Description:	Detalle de los c�digos ID, para el idioma elegido o el por defecto = espa�ol
-- =============================================
ALTER PROCEDURE [dbo].[CDiccPAmbAplic]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 NVARCHAR(50) = NULL										-- Ambito de Aplicaci�n elegido o por defecto = NULL
	,@PAR3 NVARCHAR(50) = NULL										-- Empresa
AS
BEGIN

--	DECLARE @PAR1 NVARCHAR(50) 
--	DECLARE @PAR2 NVARCHAR(50) 
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR2 = NULL										-- Ambito de Aplicaci�n elegido o por defecto = NULL

	DECLARE @TmpTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)

	-- Inserta en la tabla temporal la informaci�n de los c�digos seg�n el idioma elegido
	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1

	-- Muestra los c�digos con su descripci�n por cada idioma
	SELECT Cod.[IDFkCodEmpresas]
			, MIN(Cd03.[Codigo]) AS [CodigoEmpresa]
			, MIN(Cd03.[Descripcion]) AS [CodDescEmpresa]
			, Cd01.[IDFkTCodAmbAplic]
			, MIN(Cd02.[Codigo]) AS [CodigoAmbitoAplic]
			, MIN(Cd02.[Descripcion]) AS [CodDescAmbitoAplic]
--			, [ID] AS [IDFkTCodigos]
--			, Cd01.[Codigo]
--			, Cd01.[Descripcion]
		    , MIN(CAST(Cd01.[IDFkTIdioma] AS VARCHAR(36))) AS [IDFkTIdioma]
			, MIN(Cd01.CodIdioma) AS [IdiomaCod]
			, MIN(Cd01.DescIdioma) AS [IdiomaDesc]
	FROM [BDCtral].[dbo].[CDiccTCodigos] AS Cod WITH (NOLOCK)
		INNER JOIN @TmpTCodxIdi AS Cd01			-- Detalle del C�digo
			ON Cod.[ID] = Cd01.[IDFkTCodigos]
		INNER JOIN @TmpTCodxIdi AS Cd02			-- Detalle del Ambito de Aplicaci�n
			ON Cd01.[IDFkTCodAmbAplic] = Cd02.[IDFkTCodigos]
		INNER JOIN @TmpTCodxIdi AS Cd03			-- Empresa Asignada
			ON Cod.[IDFkCodEmpresas] = Cd03.[IDFkTCodigos]
	WHERE Cd01.[IDFkTCodAmbAplic] = CASE WHEN @PAR2 IS NULL THEN Cd01.[IDFkTCodAmbAplic] ELSE @PAR2 END		-- Ambito de Aplicaci�n
			AND Cod.[IDFkCodEmpresas] = CASE WHEN @PAR3 IS NULL THEN Cod.[IDFkCodEmpresas] ELSE @PAR3 END		-- Empresa
	GROUP BY Cod.[IDFkCodEmpresas], Cd01.[IDFkTCodAmbAplic]
	ORDER BY Cod.[IDFkCodEmpresas], MIN(Cd02.[Codigo])

END


--DECLARE	@return_value int
--EXEC	@return_value = [dbo].[CDiccPAmbAplic] 
--		@PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'			-- Idioma elegido o por defecto = espa�ol
--		,@PAR2 = NULL	--	'69752B6B-9B31-402B-83DC-4E945DF7879C'	-- CPerfTAgrup	tabla perfiles agrupados
--		,@PAR3 = NULL	--	'56FA3B2F-2AEB-43B2-88EA-2A6E0AFBB981'	-- BPM	Business Process Managment












