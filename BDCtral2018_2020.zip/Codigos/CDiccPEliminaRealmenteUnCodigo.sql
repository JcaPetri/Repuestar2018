-- Define que se trabaja con al Base de Datos
USE [BDCtral]
GO

-- Revisar, se deben eliminar todos los registros que tengan clave primaria asociada a la Tabla CDiccTCodigos


DECLARE @PAR01 AS VARCHAR(36)
SET @PAR01 = 'AA437864-CBEF-4430-AF1E-7BD177E9193F'

-- Tablas CDicc
DELETE FROM [BDCtral].[dbo].[CDiccTCodigos]				-- Tabla de Codigos
	WHERE ID = @PAR01

DELETE FROM [BDCtral].[dbo].[CDiccTCodxIdiomas]			-- Tabla de Idiomas
	WHERE IDFkTCodigos = @PAR01

DELETE FROM [BDCtral].[dbo].[CDiccTCyDClas]				-- Tabla de Clasificci�n de Codigos
	WHERE IDgdicTCodigos = @PAR01

DELETE FROM [BDCtral].[dbo].[CDiccTIdioma]				-- Tabla de Idiomas
	WHERE ID = @PAR01

--DELETE FROM [BDCtral].[dbo].[CDiccTCodArbol]			-- Tabla de Arbol
--	WHERE IDFkTCodigos = @PAR01

-- Tablas CPrGe
DELETE FROM [BDCtral].[dbo].[CPrGeTGestion]				-- Tabla de Procesos Gestion
      WHERE [IDFKTCodEtaMot] = @PAR01

DELETE FROM [BDCtral].[dbo].[CPrGeTLogAut]				-- Tabla Logica Automatica
	  WHERE [IDFkTCodProPer] = @PAR01	
	
DELETE FROM [BDCtral].[dbo].[CPrGeTLogAutAcciones]		-- Tabla Logica Autm�tica Acciones
      WHERE [IDFkTCodProLogAut] = @PAR01

DELETE FROM [BDCtral].[dbo].[CPrGeTLogAutValidacion]		-- Tabla Logica Autm�tica Validaciones
      WHERE [IDFkTCodProLogAut] = @PAR01 OR [IDFkTCodProLogAutVali] = @PAR01

DELETE FROM [BDCtral].[dbo].[CPrGeTLogica]				-- Tabla Logica Autm�tica Validaciones
      WHERE [IDFkTCodProLog] = @PAR01 OR [IDFkTCodEtaMotOri] = @PAR01 OR [IDFkTCodEtaMotDes] = @PAR01 OR [IDFkGDicTCodEst] = @PAR01

DELETE FROM [BDCtral].[dbo].[CPrGeTProcesos]			-- Tabla de Procesos
      WHERE [IDFkGDicTCodProc] = @PAR01 OR [IDFkGDicTCodEst] = @PAR01

DELETE FROM [BDCtral].[dbo].[CPrGeTProcPerf]			-- Tabla de Perfiles de Processo
      WHERE [IDFkTCodProPer] = @PAR01 OR [IDFkTCodPrGe] = @PAR01 OR [IDFkTCodPerUsu] = @PAR01 OR [IDFkTCodRelac] = @PAR01

-- Tablas CUsu
DELETE FROM [BDCtral].[dbo].[CPerfTPerAgru]				-- Tabla de Perfiles Agrupados
      WHERE [IDFkTPerfil] = @PAR01 OR [IDFkTPerfAgrup] = @PAR01

DELETE FROM [BDCtral].[dbo].[CUsuPerTIng]				-- Tabla de Perfiles de Ingreso
      WHERE [IDFkTPerfil] = @PAR01

DELETE FROM [BDCtral].[dbo].[CUsuTAgruPerfAgru]				-- Tabla de Usuarios Agrupados
      WHERE [IDFkTPerAgrup] = @PAR01 OR [IDFkTUsuAgrup] = @PAR01

DELETE FROM [BDCtral].[dbo].[CUsuTUsuAgru]
      WHERE IDFkTGUsuTAgrup = @PAR01



-- Tablas CIntfTObjCod
DELETE FROM [BDCtral].[dbo].[CIntfTObjCod]					-- Tabla Objeto C�digos
	WHERE [IDFkTCodObjUbic] = @PAR01 OR [IDFkCodEstados] = @PAR01

DELETE FROM [BDCtral].[dbo].[CIntfTObjCodxIdio]				-- Tabla Objeto Codigos por Idiomas
	WHERE [IDFkTIdioma] = @PAR01 OR [IDFkTCodAmbAplic] = @PAR01 OR [IDFkCxIEstados] = @PAR01




-- #########################################################################################################################################
-- Elimina masivamente los cogidos de un ambito de aplicacion
-- #########################################################################################################################################
---- Elimina los cogidos de un ambito de aplicacion, sin eliminar ese ambito
--SELECT IDgdicTCodigos, IDFkTIdioma, IDFkTCodAmbAplic, Codigo, Descripcion, IdiCod, Idioma, IDFkCxIEstados
--FROM CDiccVCodigos
--WHERE (IDFkTCodAmbAplic = 'CF0EF997-B52A-42A2-BD70-E12EFB00A724') AND (IDgdicTCodigos <> 'CF0EF997-B52A-42A2-BD70-E12EFB00A724')
--
---- CF0EF997-B52A-42A2-BD70-E12EFB00A724			Tabla Motivos
--DELETE FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] WHERE (IDFkTCodAmbAplic = 'CF0EF997-B52A-42A2-BD70-E12EFB00A724') AND (IDFkTCodigos <> 'CF0EF997-B52A-42A2-BD70-E12EFB00A724')
--
---- Se asegura la integridad de la base de datos. 
--	-- No puede haber ning�n c�digo que no tenga su valor correspondiente en la Tabla CodxIdioma
--	DELETE FROM [BDCtral].[dbo].[CDiccTCodigos]
--	WHERE ID IN (
--				SELECT DISTINCT ID 
--				FROM [BDCtral].[dbo].[CDiccTCodigos] AS Cod
--					LEFT OUTER JOIN [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI
--						ON Cod.ID = CxI.IDFkTCodigos
--					WHERE CxI.IDFkTCodigos IS NULL
--				)
---- Se asegura la integridad de la base de datos. 
--	-- No puede haber ning�n c�digo que esta en la tabla CodxIdioma y no este en la tabla Codigos.
--	DELETE FROM [BDCtral].[dbo].[CDiccTCodxIdiomas]
--		WHERE IDFkTCodigos IN (
--								SELECT DISTINCT IDFkTCodigos
--								FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI
--									LEFT OUTER JOIN [BDCtral].[dbo].[CDiccTCodigos] AS Cod
--										ON CxI.IDFkTCodigos = Cod.ID
--								WHERE Cod.ID IS NULL
--								)
--
--
