set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

USE [BDCtral]
GO


	DECLARE @PAR1 NVARCHAR(50) 
	DECLARE @PAR2 NVARCHAR(50) 
	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	SET @PAR2 = NULL										-- Ambito de Aplicaci�n elegido o por defecto = NULL

	DECLARE @TmpTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)

	-- Inserta en la tabla temporal la informaci�n de los c�digos seg�n el idioma elegido
	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1
				AND
			  CxI.[IDFkTCodAmbAplic] = CASE WHEN @PAR2 IS NULL THEN CxI.[IDFkTCodAmbAplic] ELSE @PAR2 END

	-- Muestra los c�digos con su descripci�n por cada idioma
	SELECT Cd01.[IDFkTCodAmbAplic]
			, MIN(Cd02.[Codigo]) AS [CodigoAmbitoAplic]
			, MIN(Cd02.[Descripcion]) AS [CodDescAmbitoAplic]
--			, [ID] AS [IDFkTCodigos]
--			, Cd01.[Codigo]
--			, Cd01.[Descripcion]
			, MIN(CAST(Cd01.[IDFkTIdioma] AS VARCHAR(36))) AS [IDFkTIdioma]
			, MIN(Cd01.CodIdioma) AS [IdiomaCod]
			, MIN(Cd01.DescIdioma) AS [IdiomaDesc]
	FROM [BDCtral].[dbo].[CDiccTCodigos] AS Cod WITH (NOLOCK)
		INNER JOIN @TmpTCodxIdi AS Cd01			-- Detalle del C�digo
			ON Cod.[ID] = Cd01.[IDFkTCodigos]
		INNER JOIN @TmpTCodxIdi AS Cd02			-- Detalle del Ambito de Aplicaci�n
			ON Cd01.[IDFkTCodAmbAplic] = Cd02.[IDFkTCodigos]		-- Cuando es un ambito de Aplicaci�n el ID del C�digo y el ID del Ambito de Aplicaci�n es el mismo
	GROUP BY Cd01.[IDFkTCodAmbAplic]
	ORDER BY MIN(Cd02.[Descripcion])

GO