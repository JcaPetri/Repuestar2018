set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- Determina la base de datos donde se trabajar�
USE [BDCtral]
GO

-- =============================================
-- Author:		Juan Carlos Petri
-- Create date: 22/07/2017
-- Description:	Detalle de los c�digos ID, para el idioma elegido o el por defecto = espa�ol
-- =============================================
ALTER PROCEDURE [dbo].[CPrGePGestion]
	-- Add the parameters for the stored procedure here
	@PAR1 NVARCHAR(50) = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
	,@PAR2 NVARCHAR(50) = NULL										-- Ambito de Aplicaci�n elegido o por defecto = NULL
AS
BEGIN

--	DECLARE @PAR1 NVARCHAR(50) 
--	DECLARE @PAR2 NVARCHAR(50) 
--	SET @PAR1 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'		-- Idioma elegido o por defecto = espa�ol
--	SET @PAR2 = NULL										-- Ambito de Aplicaci�n elegido o por defecto = NULL

	DECLARE @TmpTCodxIdi TABLE	-- Tabla temporal para obtener la informaci�n de los c�digos en el idioma elegido
	(
		[IDFkTCodigos] [uniqueidentifier] NOT NULL,
		[IDFkTIdioma] [uniqueidentifier] NOT NULL,
		[IDFkTCodAmbAplic] [uniqueidentifier] NOT NULL,
		[Codigo] [varchar](50) COLLATE Modern_Spanish_CI_AS,	-- NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS, -- NOT NULL,
		[CodIdioma] [varchar](10) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[DescIdioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NOT NULL
	)

	-- Inserta en la tabla temporal la informaci�n de los c�digos seg�n el idioma elegido
	INSERT INTO @TmpTCodxIdi
		SELECT CxI.[IDFkTCodigos]
			  ,CxI.[IDFkTIdioma]
			  ,CxI.[IDFkTCodAmbAplic]
			  ,CxI.[Codigo]
			  ,CxI.[Descripcion]
			  ,Idi.[CodIdioma] AS IdiCod
			  ,Idi.[DescIdioma] AS Idioma
		  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS CxI WITH (NOLOCK) 
				INNER JOIN [BDCtral].[dbo].[CDiccTIdioma] AS Idi WITH (NOLOCK) 
					ON CxI.[IDFkTIdioma] = Idi.[ID]
		WHERE Idi.[ID] = @PAR1
				AND
			  CxI.[IDFkTCodAmbAplic] = CASE WHEN @PAR2 IS NULL THEN CxI.[IDFkTCodAmbAplic] ELSE @PAR2 END

	-- Muestra Procesos de Gestion
	SELECT CPG.[IDFkTCodProc]
			, Cd01.[Codigo]
			, Cd01.[Descripcion]
			, CPG.[IDFKTCodEtaMot]
			, Cd02.[Codigo]
			, Cd02.[Descripcion]
			, CPG.[IDFkTCodEtapa]
			, Cd03.[Codigo]
			, Cd03.[Descripcion]
			, CPG.[IDFkTCodMotivo]
			, Cd04.[Codigo]
			, Cd04.[Descripcion]
			, CPG.[IDFkTCodEst]
			, Cd05.[Codigo]
			, Cd05.[Descripcion]
			, CPG.[TGestionFechaModif]
	  FROM [BDCtral].[dbo].[CPrGeTGestion] AS CPG WITH (NOLOCK)
		INNER JOIN @TmpTCodxIdi AS Cd01			-- Proceso
			ON CPG.[IDFkTCodProc] = Cd01.[IDFkTCodigos]
		INNER JOIN @TmpTCodxIdi AS Cd02			-- EtapaMotivo
			ON CPG.[IDFKTCodEtaMot] = Cd02.[IDFkTCodigos]
		INNER JOIN @TmpTCodxIdi AS Cd03			-- Etapa
			ON CPG.[IDFkTCodEtapa] = Cd03.[IDFkTCodigos]
		INNER JOIN @TmpTCodxIdi AS Cd04			-- Motivo
			ON CPG.[IDFkTCodMotivo] = Cd04.[IDFkTCodigos]
		INNER JOIN @TmpTCodxIdi AS Cd05			-- Estado Gestion
			ON CPG.[IDFkTCodEst] = Cd05.[IDFkTCodigos]
END











