
-- ###############################################################################################################################3
--  CONSULTA TRAE TODOS LOS CODIGOS, PRIMERO PONE LOS AGRUPADOS Y LUEGO LOS PENDIENTES DE AGRUPAMIENTO
--
DECLARE @PAR1 AS VARCHAR(3)		-- Idioma
SET @PAR1 = 'ESP'

SELECT *
FROM (
	SELECT Cc01.[ID] AS ClasID
		  --,Cc01.[BOwnerIDClas]
		  ,Co01.[IdiCod] AS ClasIdioma
		  ,Co01.[Cod] AS ClasCod
		  ,Co01.[Descripcion] AS ClasDesc
		  ,Co02.[IdiCod] AS ItemIdioma
		  ,Cc01.[BOwnerIDCod] AS ItemID
		  ,Co02.[Cod] AS ItemCod
		  ,Co02.[Descripcion] AS ItemDesc
	  FROM [SPM].[dbo].[GRL012_ClasCod] AS Cc01 WITH(NOLOCK)
			INNER JOIN [SPM].[dbo].[GRL013_Cod] AS Co01
				ON Cc01.[BOwnerIDClas] = Co01.[ItemID]
			INNER JOIN [SPM].[dbo].[GRL013_Cod] AS Co02
				ON Cc01.[BOwnerIDCod] = Co02.[ItemID]
	WHERE Co01.[IdiCod] = @PAR1
		AND Co02.[IdiCod] = @PAR1
	UNION ALL
	SELECT NULL AS ClasID
		  ,Co01.[IdiCod] AS ClasIdioma
		  ,'SCL' AS ClasCod
		  ,'Sin Clasficar' AS ClasDesc
	      ,[IdiCod] AS ItemIdioma
		  ,[ItemID]	AS ItemID
		  ,[Cod] AS ItemCod
		  ,[Descripcion] AS ItemDesc
	--      ,[Idioma]
		FROM [SPM].[dbo].[GRL013_Cod] AS Co01
			LEFT OUTER JOIN [SPM].[dbo].[GRL012_ClasCod] AS Cc01 WITH(NOLOCK)
					ON Co01.[ItemID] = Cc01.[BOwnerIDCod] 
		WHERE Co01.[IdiCod] = @PAR1
			AND AND Cc01.[ID] IS NULL
	) AS CCC
--ORDER BY Idioma, ClasCod DESC, ItemCod
