USE SPM;  
GO  

	-- Etapa 1: Primero determino la cantidad de bucles que debe hacer el procedimiento
	DECLARE @PAR1 AS VARCHAR(36)	-- Idioma con el que se trabajar�	
	DECLARE @PAR2 AS VARCHAR(50)	-- C�digo del Padre que se trabajar
	DECLARE @PAR3 AS SMALLINT		-- Registra el tope de bucles
	DECLARE @PAR4 AS SMALLINT		-- Valor actual del Bucle

	SET @PAR1 = 'ESP'
	SET @PAR2 = 'VEH'
	
	-- Comienza el Bucle Padre - Hijo

	SELECT @PAR3 = MAX([ItemNivel]), @PAR4 = MIN([ItemNivel]), @PAR2 = MAX(CAST(Ca02.[ID] AS VARCHAR(36)))
	FROM [SPM].[dbo].[GRL015_CodArbIdio] AS Ca01
		 INNER JOIN (
					SELECT [ID]
					  FROM [SPM].[dbo].[GRL015_CodArbIdio]
						WHERE [IdiCod] = @PAR1
							AND [Cod] = @PAR2
					) AS Ca02
		ON Ca01.[PadreID] = Ca02.[ID]
	-- SELECT @PAR4, @PAR3

	-- Etapa 2: Realizo el bucle que forma el Arbol del Padre Elegido
	-- Genera una tabla temporaria para insertar las distintas consultas
	DECLARE @TempCodArb TABLE
	(
		[ID] [uniqueidentifier] NOT NULL,
		[PadreID] [uniqueidentifier] NULL,
		[ItemNivel] [smallint] NULL,
		[ItemOrd] [smallint] NULL,
		[ItemCod] [uniqueidentifier] NULL,
		[Cod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[IdiCod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Idioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL
	)

	WHILE @PAR4 <= @PAR3
	BEGIN  
		INSERT INTO 
			@TempCodArb
		SELECT [ID]
			  ,[PadreID]
			  ,[ItemNivel]
			  ,[ItemOrd]
			  ,[ItemCod]
			  ,[Cod]
			  ,[Descripcion]
			  ,[IdiCod]
			  ,[Idioma]
		  FROM [SPM].[dbo].[GRL015_CodArbIdio]
		WHERE [IdiCod] = @PAR1			-- Idioma
			AND [PadreID] = @PAR2		-- PadreID
			AND [ItemNivel] = @PAR4		-- Nivel

		SET @PAR4 = @PAR4 + 1

		-- Aqu� pregunta si ya incorpor� el Padre y sus Hijos
		IF @PAR4 > @PAR3
			-- Ya incorpor� los hijos, ahora debe verificar si cada uno de estos hijos tienen a su vez m�s hijos
			--SET @PAR2 = '2'
			SET @PAR2 = 'VEH'
			
			-- Comienza el Bucle Padre - Hijo
			SELECT @PAR3 = MAX([ItemNivel]), @PAR4 = MIN([ItemNivel]), @PAR2 = MAX(CAST(Ca02.[ID] AS VARCHAR(36)))
			FROM [SPM].[dbo].[GRL015_CodArbIdio] AS Ca01
				 INNER JOIN (
							SELECT [ID]
							  FROM [SPM].[dbo].[GRL015_CodArbIdio]
								WHERE [IdiCod] = @PAR1
									AND [Cod] = @PAR2
							) AS Ca02
				ON Ca01.[PadreID] = Ca02.[ID]
			-- SELECT @PAR4, @PAR3
			--BREAK  

		ELSE
			-- Falta incorporar los hijos  
			CONTINUE
	END  

	SELECT * 
	FROM @TempCodArb
	ORDER BY [PadreID]
			  ,[ItemNivel]
			  ,[ItemOrd]