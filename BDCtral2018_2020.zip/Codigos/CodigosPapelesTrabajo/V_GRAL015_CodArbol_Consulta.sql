	DECLARE @RC int
	DECLARE @PAR10 varchar(36)
	DECLARE @PAR20 varchar(72)

	-- TODO: Establezca los valores de los par�metros aqu�.
	SET @PAR10 = 'ESP'	-- @PAR1
	SET @PAR20 = 'VEH'

-- Resultado de la incorporaci�n
-- Genera una tabla temporaria para insertar los resultados
	DECLARE @TmpCodArb TABLE
	(
		[Arbol] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ArbolID] [uniqueidentifier] NULL,
		[ArbolDesc] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ID] [uniqueidentifier] NOT NULL,
		[PadreID] [uniqueidentifier] NULL,
		[ItemNivel] [smallint] NULL,
		[ItemOrd] [smallint] NULL,
		[ItemID] [uniqueidentifier] NULL,
		[Cod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[IdiCod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Idioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL
	)


	INSERT INTO @TmpCodArb EXECUTE @RC = [SPM].[dbo].[GRL015_CodArbolBucle] @PAR10, @PAR20

	SELECT [Arbol]
			,[ArbolDesc]
			,[ItemNivel]
			,[ItemOrd]
			,[Cod]
			,[Descripcion]
			,[IdiCod]
			,[Idioma]
	 FROM @TmpCodArb
	 ORDER BY [Arbol]