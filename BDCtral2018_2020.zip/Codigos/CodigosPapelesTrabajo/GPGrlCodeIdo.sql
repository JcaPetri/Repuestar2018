-- ###############################################################################################################################3
--  INSERTA UN NUEVO CODIGO -- 
-- ###############################################################################################################################3

-- Proc OK
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- El c�digo del item es �nico independientemente la lengua, esta clave ID esta en la Tabla GRL013_Codigos, 
-- Dentro del mismo idioma no puede tener c�digos iguales: ItemID, IdiomaID, Cod (cada c�digo dentro del idioma debe ser �nico)
-- ##############################################################################################################################################
--
---- Listado de Idiomas disponibles, con sus c�digos
--SELECT [ID]
--      ,[CodIdioma]
--      ,[DescIdioma]
--      ,[IDgdicTCodigos]
--  FROM [BDGral].[dbo].[GDicTIdioma]


-- Proc OK
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para agregar un nuevo C�digo, se debe:
	-- Variables Etapa 1
	DECLARE @PAR1 AS VARCHAR(36)	-- ID del nuevo idioma

	-- Variables Estapa 2
	DECLARE @PAR2 AS VARCHAR(50)	-- C�digo del idioma, debe ser �nico
	DECLARE @PAR3 AS VARCHAR(50)	-- C�digo del item
	DECLARE @PAR4 AS VARCHAR(250)	-- Descripci�n

	-- Idioma a seleccionar
	SET @PAR2 = 'ESP'				-- C�digo del idioma, debe ser �nico
	-- Datos a ingresar
	SET @PAR3 = 'tipo perf'				-- C�digo del item
	SET @PAR4 = 'tipos perfiles'			-- Descripci�n

-- Etapa 1: insertar el item en la tabla GDicTCodigos
	SET @PAR1 = NEWID()				-- ID del nuevo idioma

	INSERT INTO [BDGral].[dbo].[GDicTCodigos]
			([ID])
		 SELECT @PAR1

-- Etapa 2: insertar el c�digo y su descripci�n en la tabla GDicTCodIdiomas
	-- Toma el ID del Idioma elegido para la descripci�n
	SET @PAR2 = (SELECT [ID] FROM [BDGral].[dbo].[GDicTIdioma] WHERE [CodIdioma] = @PAR2)

	INSERT INTO [BDGral].[dbo].[GDicTCodIdiomas]
			   ([IDgdicTCodigos]
			   ,[IDgdicTIdioma]
			   ,[Codigo]
			   ,[Descripcion])
		 SELECT @PAR1, @PAR2, @PAR3, @PAR4
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

---- Por cada item la descripci�n de sus c�digos
DECLARE	@return_value int
EXEC	@return_value = [dbo].[GDicPCodxIdio] @PAR2

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


