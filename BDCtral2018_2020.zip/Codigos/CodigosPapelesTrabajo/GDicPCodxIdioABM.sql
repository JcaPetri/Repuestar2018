-- ###############################################################################################################################3
--  GENERA LOS PROCEDIMIENTOS ALMACENADOS PARA HACER EL ALTA, BAJA O MODIFICACION DE LOS CODIGOS -- 
-- ###############################################################################################################################3

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- ALTA DE CODIGO		INICIO
-- ##############################################################################################################################################

-- Define que se trabaja con al Base de Datos
USE [BDGral]
GO

-- Muestra los c�digos y sus descripciones en el idioma seleccionado o el por defecto
--DECLARE	@return_value int
--EXEC	@return_value = [dbo].[GDicPCodxIdio]
--GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para agregar un nuevo C�digo, se debe:
	-- Determinar si para ese idioma, ya existe el c�digo, que es clave.
	-- La clave de la tabla es, entorno o modulo, �dioma y c�digo, las descripciones pueden ser iguales, no importa.
	
	-- VERLO ########
	-- Se deber�a poner una combinaci�n m�s ID de entorno, por lo tanto para un idioma, puede haber dos c�digos iguales, pero cada uno para un entorno o m�dulo diferente.
	-- #############


	-- Variables Etapa 1
	DECLARE @PAR1 AS VARCHAR(50)	-- valor ID, debe ser �nico, este valor 
											-- primero se carga en la tabla GDicTCodigos y 
											-- luego en la tabla GDicTCodIdiomas.
	DECLARE @PAR2 AS VARCHAR(36)	-- codigo, debe ser �nico
				-- Las claves ID son la combinacion del ID del idioma, el ID del modulo y CodIdioma, pero antes de agregar un registro debemos verificar
				-- que el Codigo y la Descripcion no esten ya definidos
	DECLARE @PAR3 AS VARCHAR(50)	-- descripcion del codigo.
	DECLARE @PAR4 AS VARCHAR(36) 	-- valor ID del idioma
	DECLARE @PAR5 AS VARCHAR(36) 	-- valor ID del modulo o entorno de aplicaci�n del codigo


	
	SET @PAR1 = NEWID()				-- ID del codigo, debe ser �nico
	SET @PAR2 = 'GCIA'				-- C�digo, debe ser �nico
	SET @PAR3 = 'GERENCIA'			-- Descripcion del codigo
	SET @PAR4 = 'fb478ecc-85fe-4fc8-b792-caf8ecb921b1'			-- ID del Idioma		
		--						ee954f5d-ca27-48a9-a23b-010788b18631	ITA
		--						b1268278-4eb3-4a93-8f67-0d425b767c65	ENG
		--						a455281d-76f5-4bad-8dbb-201c5928aaf8	FRA
		--						1048c13b-1cc9-4154-8b8b-64ca9ac9fe12	POR
		--						fb478ecc-85fe-4fc8-b792-caf8ecb921b1	ESP
	SET @PAR5 = '50E6A111-D9BE-4CF7-9115-69A1294EACAB'					-- Si se pone que un valor inicial, este valor es igual al @PAR1

-- Etapa 1: verifica que el codigo que se quiere agregar ya no este creado, para ese idioma.
	SELECT @PAR1 = NULL		-- Si alguno de los valores son encontrados, la variable @PAR1 se pone a NULL
	  FROM [BDGral].[dbo].[GDicTCodIdiomas] AS CxI WITH(NOLOCK)
	WHERE [IDgdicTIdioma] = @PAR4 AND [Codigo] = @PAR2

--	SELECT @PAR1

-- Etapa 2: Si el idioma no esta creado lo hace
	IF @PAR1 IS NULL
		-- No hace nada
		SELECT @PAR1 = @PAR1
	ELSE
		-- Inserta el codigo en la tabla
		INSERT INTO [BDGral].[dbo].[GDicTCodigos]
				([ID])
			SELECT @PAR1

	IF @PAR1 IS NULL
		-- No hace nada
		SELECT @PAR1 = @PAR1
	ELSE
		-- Inserta el codigo en la tabla descripcion del c�digo
		INSERT INTO [BDGral].[dbo].[GDicTCodIdiomas]
				   ([IDgdicTCodigos]
				   ,[IDgdicTIdioma]
				   ,[IDgdicTCodigos_02]
				   ,[Codigo]
				   ,[Descripcion])
			 SELECT 
					@PAR1,	-- ID del codigo
					@PAR4,	-- ID del idioma
					CASE WHEN @PAR5 = 'INICIAL' THEN @PAR1 ELSE @PAR5 END,		-- ID del ambito de aplicaci�n del codigo
					@PAR2,	-- C�digo
					@PAR3	-- Descripci�n
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- Muestra la informacion de la tabla idioma
SET @PAR1 = @PAR4
DECLARE	@return_value int
EXEC	@return_value = [dbo].[GDicPCodxIdio] @PAR4

GO
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- ALTA DE CODIGO		FINAL
-- ##############################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

--
--
--
--
--
--
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- ##############################################################################################################################################
---- MODIFICACION DE CODIGO		INICIO
---- ##############################################################################################################################################
--
---- Define que se trabaja con al Base de Datos
--USE [BDGral]
--GO
----
------ Listado de Idiomas disponibles, con sus c�digos
----SELECT [ID]
----      ,[CodIdioma]
----      ,[DescIdioma]
----      ,[IDgdicTCodigos]
----  FROM [BDGral].[dbo].[GDicTIdioma] AS TI WITH(NOLOCK)
----
----GO
--
--set ANSI_NULLS ON
--set QUOTED_IDENTIFIER ON
--go
--
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- Para modificar un Idioma, se debe determinar primero si se quiere modificar:
--			--	el codigo o 
--			--	su descripcion que son valores claves y unicos 
--			--	o solo el estado.
--
--	-- Variables Etapa 1
--	DECLARE @PAR1 AS VARCHAR(50)	-- valor ID, debe ser �nico
--	-- con este valor ID se buscan los datos, luego si hay diferencias se modifica el valor
--	-- Si la diferencia es en el estado es simple, solo se cambia.
--	-- Si la diferencia es en el CodIdoma o DescIdioma, primero hay que verificar que ya no este usuado.
--
--	DECLARE @PAR2 AS VARCHAR(36)	-- codigo del nuevo idioma que se desea modificar
--	DECLARE @PAR3 AS VARCHAR(50)	-- descripcion del idioma, debe ser �nico
--	DECLARE @PAR4 AS VARCHAR(36) 	-- valor ID del estado del idioma (habilitado o deshabilitado), por defecto va habilitado
--
--
--	DECLARE @PAR2Act AS VARCHAR(36) 	-- codigo actual
--	DECLARE @PAR3Act AS VARCHAR(36) 	-- descripcion actual
--	DECLARE @PAR4Act AS VARCHAR(36) 	-- estado actual del idioma (habilitado o deshabilitado), por defecto va habilitado
--
--	
--	SET @PAR1 = 'B97BEB5E-7B5B-4DF3-8FF5-D5DF1EFA1C55'				-- ID del idioma a modificar
--
--	SET @PAR2 = 'EjP'										-- C�digo del idioma, nuevo, debe ser �nico
--	SET @PAR3 = 'Otros'									-- Descripcion del idioma, nueva.
--	SET @PAR4 = 'C6FE2749-0CB8-49CD-97DF-03C299C0C6CF'			-- ID del estado del Idioma, nuevo		
--										-- Deshabilitado = EBC17C2F-08D6-46A2-8D3B-3A37100BAEB0
--										-- Habilitado = C6FE2749-0CB8-49CD-97DF-03C299C0C6CF
--
---- Etapa 1: toma la informacion del codigo ID a modificar
--	SELECT @PAR2Act = [CodIdioma]
--		  ,@PAR3Act = [DescIdioma]
--		  ,@PAR4Act = [IDgdicTCodigos]
--	  FROM [BDGral].[dbo].[GDicTIdioma] AS TI WITH(NOLOCK)
--	WHERE [ID] = @PAR1
--
--	-- SELECT @PAR1, @PAR2, @PAR2Act, @PAR3, @PAR3Act, @PAR4, @PAR4Act
--
---- Etapa 2: Si primero verifica si se puede ejecutar el cambio, Validamos el CodIdioma y DescIdioma, que son claves y no se pueden repetir en la tabla
--	-- Antes de modificar el idioma, se debe determinar si los nuevos valores ya estan utilizados, 
--	-- en otro registro que no sea el que se va a modificar
--	SELECT @PAR1 = NULL		-- Si alguno de los valores son encontrados, la variable @PAR1 se pone a NULL
--	  FROM [BDGral].[dbo].[GDicTIdioma] AS TI WITH(NOLOCK)
--	WHERE [ID] <> @PAR1 AND ([CodIdioma] = @PAR2 OR [DescIdioma] = @PAR3)
--	
----	SELECT @PAR1	
--
---- Etapa 2: Si primero verifica el elemento que cambio
--	IF @PAR1 IS NULL
--		-- No hace nada, ya que no se viola una clave principal
--		SELECT @PAR1 = @PAR1
--	ELSE
--		-- �qu� no se viola ninguna clave principal, por lo tanto se modifica el idioma
--		IF @PAR2 <> @PAR2Act OR @PAR3 <> @PAR3Act OR @PAR4 <> @PAR4Act
--			-- Modifica el Idioma
--			UPDATE [BDGral].[dbo].[GDicTIdioma]
--			   SET [CodIdioma] = @PAR2
--				  ,[DescIdioma] = @PAR3
--				  ,[IDgdicTCodigos] = @PAR4
--			 WHERE [ID] = @PAR1
--		ELSE
--			-- No hace nada, ya que no modifica el idioma
--			SELECT @PAR1 = @PAR1
--GO
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--
---- Muestra la informacion de la tabla idioma
--DECLARE	@return_value int
--EXEC	@return_value = [dbo].[GDicPIdioma]
--
--GO
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- ##############################################################################################################################################
---- MODIFICACION DE CODIGO		FINAL
---- ##############################################################################################################################################
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--
--
--
--
--
--
--
--
--
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- ##############################################################################################################################################
---- ELIMINACI�N DE IDIOMA		INICIO
---- ##############################################################################################################################################
--
---- Define que se trabaja con al Base de Datos
--USE [BDGral]
--GO
----
------ Listado de Idiomas disponibles, con sus c�digos
----SELECT [ID]
----      ,[CodIdioma]
----      ,[DescIdioma]
----      ,[IDgdicTCodigos]
----  FROM [BDGral].[dbo].[GDicTIdioma] AS TI WITH(NOLOCK)
----
----GO
--
--set ANSI_NULLS ON
--set QUOTED_IDENTIFIER ON
--go
--
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- Para eliminar un Idioma, en realidad lo que se hace es cambiar es estado a Eliminado
--
--	-- Variables Etapa 1
--	DECLARE @PAR1 AS VARCHAR(50)	-- valor ID, debe ser �nico
--	-- con este ID se deben eliminar todos los registros de todas las tablas donde esta vinculado
--
--	SET @PAR1 = 'B97BEB5E-7B5B-4DF3-8FF5-D5DF1EFA1C55'				-- ID del idioma a eliminar
--
--	-- Modifica el Idioma
--	UPDATE [BDGral].[dbo].[GDicTIdioma]
--	   SET [IDgdicTCodigos] = ''		- Generar c�digo de Eliminado
--	 WHERE [ID] = @PAR1
--GO
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--
---- Muestra la informacion de la tabla idioma
--DECLARE	@return_value int
--EXEC	@return_value = [dbo].[GDicPIdioma]
--
--GO
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- ##############################################################################################################################################
---- ELIMINACI�N DE IDIOMA		FINAL
---- ##############################################################################################################################################
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--
