-- ###############################################################################################################################3
--  INSERTA UN NUEVO CODIGO -- 
-- ###############################################################################################################################3

-- Proc OK
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- El c�digo del item es �nico independientemente la lengua, esta clave ID esta en la Tabla GRL013_Codigos, 
-- Dentro del mismo idioma no puede tener c�digos iguales: ItemID, IdiomaID, Cod (cada c�digo dentro del idioma debe ser �nico)
-- ##############################################################################################################################################

-- Listado de Idiomas disponibles, con sus c�digos
SELECT [ItemID]
      ,[Cod]
      ,[Descripcion]
  FROM [SPM].[dbo].[GRL014_V_Idiomas]
ORDER BY [IdiomaOrd] ASC

-- Proc OK
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para agregar un nuevo C�digo, se debe:
	-- Variables Etapa 1
	DECLARE @PAR1 AS VARCHAR(36)	-- ID del nuevo idioma

	-- Variables Estapa 2
	DECLARE @PAR2 AS VARCHAR(50)	-- C�digo del idioma, debe ser �nico
	DECLARE @PAR3 AS VARCHAR(50)	-- C�digo del item
	DECLARE @PAR4 AS VARCHAR(250)	-- Descripci�n

	-- Idioma a ingresar
	SET @PAR2 = 'ESP'				-- C�digo del idioma, debe ser �nico
	SET @PAR3 = 'IDI'				-- C�digo del item
	SET @PAR4 = 'idiomas'			-- Descripci�n

-- Etapa 1: insertar el item en la tabla GRL013_Codigos
	SET @PAR1 = NEWID()				-- ID del nuevo idioma

	INSERT INTO [SPM].[dbo].[GRL013_Codigos]
			([ID])
		 SELECT @PAR1

-- Etapa 2: insetar el c�digo del idioma y su descripci�n en la tabla CodxIdioma
	-- Toma el ID del Idioma elegido para la descripci�n
	SET @PAR2 = (SELECT [ItemID] FROM [SPM].[dbo].[GRL014_V_Idiomas] WHERE [Cod] = @PAR2)

	INSERT INTO [SPM].[dbo].[GRL014_CodxIdioma]
			   ([ItemID]
			   ,[IdiomaID]
			   ,[Cod]
			   ,[Descripcion])
		 SELECT @PAR1, @PAR2, @PAR3, @PAR4
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

---- Por cada item la descripci�n de sus c�digos
SELECT [ID]
      ,[BOwnerID]
	  ,[Cod]
      ,[Descripcion]
  FROM [SPM].[dbo].[GRL011_Clasif] AS Cl01 WITH(NOLOCK)
	INNER JOIN [SPM].[dbo].[GRL013_CodESP] AS Ce01
		ON Cl01.[ID] = Ce01.[ItemID]
ORDER BY [Cod]
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
