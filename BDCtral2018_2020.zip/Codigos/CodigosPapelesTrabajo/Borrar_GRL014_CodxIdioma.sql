-- ###############################################################################################################################3
--  INSERTA UN NUEVO IDIOMA -- 
-- ###############################################################################################################################3

-- Proc OK
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- El c�digo del idioma es �nico independientemente la lengua, por lo tanto, 
-- no puede haber dos idiomas que tengan el mismo c�digo, la verificaci�n es: ItemID = IdiomaID, el Codigo deben ser distintos.
-- a su vez, dentro del mismo idioma no puede tener c�digos iguales: ItemID, IdiomaID, Cod (cada c�digo dentro del idioma debe ser �nico)
-- ##############################################################################################################################################

-- Listado de Idiomas disponibles, con sus c�digos
SELECT [ItemID]
      ,[Cod]
      ,[Descripcion]
  FROM [SPM].[dbo].[GRL014_V_Idiomas]
ORDER BY [IdiomaOrd] ASC

-- Por cada idioma la descripci�n de sus c�digos
DECLARE @PAR1 AS VARCHAR(50)	-- Variable para almacenar los idiomas
SET @PAR1 = 'ITA'

SELECT Ci01.[ItemID]
      ,Ci01.[IdiomaID]
      ,Ci01.[Cod]
      ,Ci01.[Descripcion]
  FROM [SPM].[dbo].[GRL014_CodxIdioma] AS Ci01 WITH(NOLOCK)
		INNER JOIN [SPM].[dbo].[GRL014_V_Idiomas] AS Vi01
			ON Ci01.[IdiomaID] = Vi01.[ItemID]
WHERE Vi01.[Cod] = @PAR1

-- Proc OK
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para agregar un nuevo idioma, se debe:
	-- Variables Etapa 1
	DECLARE @PAR1 AS VARCHAR(36)	-- ID del nuevo idioma
	DECLARE @PAR2 AS SMALLINT		-- Orden del idioma

	-- Variables Estapa 2
	DECLARE @PAR3 AS VARCHAR(50)	-- C�digo del idioma, debe ser �nico
	DECLARE @PAR4 AS VARCHAR(250)	-- Descripci�n
	DECLARE @PAR5 AS VARCHAR(36)	-- Verifica que no haya ning�n idioma con el c�digo de la variable @PAR3
	-- Idioma a ingresar
	SET @PAR3 = 'ITA'				-- C�digo del idioma, debe ser �nico
	SET @PAR4 = 'italiano'			-- Descripci�n

	-- Verifica si el c�digo de Idioma es permitido
	SET @PAR5 = (SELECT [ItemID] FROM [SPM].[dbo].[GRL014_V_Idiomas] WHERE [Cod] = @PAR3)	
	--SELECT @PAR5

-- Etapa 1: insertar el idioma en la tabla Idioma
	SET @PAR1 = NEWID()				-- ID del nuevo idioma
	SET @PAR2 = (SELECT MAX([IdiomaOrd]) FROM [SPM].[dbo].[GRL010_Idiomas])
	SELECT @PAR2 = ISNULL(@PAR2, 1) + 1

	INSERT INTO [SPM].[dbo].[GRL010_Idiomas]
			   ([ID]
			   ,[IdiomaOrd])
		 SELECT @PAR1, @PAR2
		 WHERE @PAR5 IS NULL

-- Etapa 2: insetar el c�digo del idioma y su descripci�n en la tabla CodxIdioma
	INSERT INTO [SPM].[dbo].[GRL014_CodxIdioma]
			   ([ItemID]
			   ,[IdiomaID]
			   ,[Cod]
			   ,[Descripcion])
		 SELECT @PAR1, @PAR1, @PAR3, @PAR4
		 WHERE @PAR5 IS NULL
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- ################################################################################################################################################
-- Este procedimiento es para poner la descripci�n de cada item en el idioma indicado.
-- Hacerle un repaso
-- Proc OK
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Ingresa el C�digo por Idioma en la Tabla CodxIdioma
-- Esto permite que cada item tenga el c�digo en el idioma elegido por el usuario
-- Para cada item e idioma solo puede haber un solo c�gido (m�ximo 50 caracteres), esto permitir�
-- que cuando elegimos un idioma distintos tambi�n la codificaci�n cambie y se adapte al idioma

-- Listado de Idiomas disponibles, con sus c�digos
SELECT [ItemID]
      ,[Cod]
      ,[Descripcion]
  FROM [SPM].[dbo].[GRL014_V_Idiomas]
ORDER BY [IdiomaOrd] ASC

	DECLARE @PAR1 AS VARCHAR(36)	-- ID del item que se agregar�
	DECLARE @PAR2 AS VARCHAR(36)	-- C�digo del Idioma elegido
	DECLARE @PAR3 AS VARCHAR(50)	-- C�digo del item
	DECLARE @PAR4 AS VARCHAR(250)	-- Descripci�n del ID
	DECLARE @PAR5 AS VARCHAR(36)	-- Variable para determinar si el idioma ya esta en la tabla

	-- Item a ingresar
	SET @PAR1 = 'POR'			-- ID del item que se agregar�

	-- Descripci�n a ingresar en el idioma elegido
	SET @PAR2 = 'ITA'			-- C�digo del Idioma elegido
	SET @PAR3 = 'POR'			-- C�digo del item
	SET @PAR4 = 'portoghese'		-- Descripci�n del ID

	-- Toma el ID del item que se incorporar� la descripci�n
	SET @PAR1 = (SELECT [ItemID] FROM [SPM].[dbo].[GRL014_V_Idiomas] WHERE [Cod] = @PAR1)
	
	-- Toma el ID del Idioma elegido para la descripci�n
	SET @PAR2 = (SELECT [ItemID] FROM [SPM].[dbo].[GRL014_V_Idiomas] WHERE [Cod] = @PAR2)

	-- SELECT @PAR1, @PAR2

	-- Verifica que el Item para ese idioma no este ya ingresado
	SET @PAR5 = (
				 SELECT [ItemID]
				  FROM [SPM].[dbo].[GRL014_CodxIdioma]
					WHERE [ItemID] = @PAR1 AND [IdiomaID] = @PAR2
				 )
	-- SELECT @PAR5

	-- Inserta un nuevo valor a la tabla
	INSERT INTO [SPM].[dbo].[GRL014_CodxIdioma]
			   ([ItemID]
			   ,[IdiomaID]
			   ,[Cod]
			   ,[Descripcion])
		 SELECT @PAR1, @PAR2, @PAR3, @PAR4
		 WHERE @PAR5 IS NULL
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
