-- ###############################################################################################################################3
--  INSERTA UNA NUEVA CLASIFICACI�N y CODIGO -- 
-- ###############################################################################################################################3

-- Proc OK
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- El c�digo del item es �nico independientemente la lengua, esta clave ID esta en la Tabla GRL013_Codigos, 
-- Dentro del mismo idioma no puede tener c�digos iguales: ItemID, IdiomaID, Cod (cada c�digo dentro del idioma debe ser �nico)
-- ##############################################################################################################################################

-- Proc OK
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para agregar un nuevo C�digo, se debe:
	DECLARE @PAR1 AS VARCHAR(36)	-- Idioma con el que se trabajar�	

	-- Variables Etapa 1
	DECLARE @PAR2 AS VARCHAR(36)	-- ID de la clasificaci�n

	-- Variables Estapa 2
	DECLARE @PAR3 AS VARCHAR(50)	-- ID del Item a clasificar
	
	DECLARE @PAR4 AS VARCHAR(50)	-- Determina si la combinaci�n ya esta cargada

	
	SET @PAR1 = 'ESP'				-- Idioma utilizado

	-- Etapa 1 - determina el Clasificador, para ello se debe verificar extraer el ID del C�digo
	SET @PAR2 = 'MAR'
	SET @PAR2 = (SELECT [ItemID] FROM [SPM].[dbo].[GRL013_Cod] WHERE [Cod] = @PAR2 AND [IdiCod] = @PAR1)
	--SELECT @PAR2

	-- Etapa 2 - determina el item que esta clasificado, para ello se debe extraer el ID del C�digo
	SET @PAR3 = 'FIA'
	SET @PAR3 = (SELECT [ItemID] FROM [SPM].[dbo].[GRL013_Cod] WHERE [Cod] = @PAR3 AND [IdiCod] = @PAR1)
	-- SELECT @PAR3

	SET @PAR4 = (SELECT [ID] FROM [SPM].[dbo].[GRL012_ClasCod] WHERE [BOwnerIDClas] = @PAR2 AND [BOwnerIDCod] = @PAR3)
		
	-- Inserta la nueva Clasificaci�n
	INSERT INTO [SPM].[dbo].[GRL012_ClasCod]
           ([ID]
		   ,[BOwnerIDClas]
           ,[BOwnerIDCod])
		SELECT NEWID()
				,@PAR2
				, @PAR3
		WHERE @PAR2 IS NOT NULL AND @PAR3 IS NOT NULL AND @PAR4 IS NULL
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

---- Por cada item la descripci�n de sus c�digos
----DECLARE @PAR1 AS VARCHAR(3)		-- Idioma
----SET @PAR1 = 'ESP'
--	SELECT Cc01.[ID] AS ClasID
--		  --,Cc01.[BOwnerIDClas]
--		  ,Co01.[IdiCod] AS Idioma
--		  ,Co01.[Cod] AS ClasCod
--		  ,Co01.[Descripcion] AS ClasDesc
--		  ,Cc01.[BOwnerIDCod] AS ItemID
--		  --,Co02.[IdiCod]
--		  ,Co02.[Cod] AS ItemCod
--		  ,Co02.[Descripcion] AS ItemDesc
--	  FROM [SPM].[dbo].[GRL012_ClasCod] AS Cc01 WITH(NOLOCK)
--			INNER JOIN [SPM].[dbo].[GRL013_Cod] AS Co01
--				ON Cc01.[BOwnerIDClas] = Co01.[ItemID]
--			INNER JOIN [SPM].[dbo].[GRL013_Cod] AS Co02
--				ON Cc01.[BOwnerIDCod] = Co02.[ItemID]
--	WHERE Co01.[IdiCod] = @PAR1
--		AND Co02.[IdiCod] = @PAR1
--	ORDER BY Co01.[IdiCod], Co01.[Cod], Co02.[IdiCod], Co02.[Cod]
--
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

SELECT [ClasID]
      ,[ClasIdioma]
      ,[ClasCod]
      ,[ClasDesc]
      ,[ItemIdioma]
      ,[ItemID]
      ,[ItemCod]
      ,[ItemDesc]
  FROM [SPM].[dbo].[GVGrlCodClas]
WHERE [ClasIdioma] = 'ESP' AND [ItemIdioma] = 'ESP'

