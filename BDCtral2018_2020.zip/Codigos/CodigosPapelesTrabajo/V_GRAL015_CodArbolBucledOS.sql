-- Genera una tabla temporaria para insertar las distintas consultas
	DECLARE @TempCodArb TABLE
	(
		[Arbol] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ArbolID] [uniqueidentifier] NULL,
		[ArbolDesc] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ID] [uniqueidentifier] NOT NULL,
		[PadreID] [uniqueidentifier] NULL,
		[ItemNivel] [smallint] NULL,
		[ItemOrd] [smallint] NULL,
		[ItemCod] [uniqueidentifier] NULL,
		[Cod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[IdiCod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Idioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL
	)

	-- Etapa 1: Primero determino la cantidad de bucles que debe hacer el procedimiento
	DECLARE @PAR1 AS VARCHAR(36)	-- Idioma con el que se trabajar�	
	DECLARE @PAR2 AS VARCHAR(50)	-- C�digo del Padre que se trabajar
	DECLARE @PAR3 AS SMALLINT		-- Registra el tope de bucles
	DECLARE @PAR4 AS SMALLINT		-- Valor actual del Bucle
	DECLARE @PAR5 AS VARCHAR(50)	-- Arbol
	DECLARE @PAR6 AS VARCHAR(50)	-- Arbol Nombre
	DECLARE @PAR7 SMALLINT

	SET @PAR1 = 'ESP'
	SET @PAR2 = 'VEH'
	
	SELECT @PAR2 = [ID], @PAR5 = [ItemNivel], @PAR6 = [Cod]
	  FROM [SPM].[dbo].[GRL015_CodArbIdio]
		WHERE [IdiCod] = @PAR1
			AND [Cod] = @PAR2
	-- SELECT @PAR2, @PAR5

	-- Arbol Nivel
	SET @PAR7 = 1
	SET @PAR5 = CAST(@PAR7 AS VARCHAR(10))
	-- Primero incorpora al Padre

--	INSERT INTO 
--			@TempCodArb
	SELECT @PAR5 AS [Arbol]
		  ,@PAR2 AS [ArbolID]
		  ,@PAR6 AS [ArbolDesc]
		  ,[ID]
		  ,[PadreID]
		  ,[ItemNivel]
		  ,[ItemOrd]
		  ,[ItemCod]
		  ,[Cod]
		  ,[Descripcion]
		  ,[IdiCod]
		  ,[Idioma]
	  FROM [SPM].[dbo].[GRL015_CodArbIdio]
	WHERE [IdiCod] = @PAR1			-- Idioma
		AND [PadreID] = @PAR2		-- PadreID
		AND [ID] = @PAR2			-- HijoID
	ORDER BY [ItemNivel]
		  ,[ItemOrd]

-- Primer Hijo
	SET @PAR7 = @PAR7 + 1
	SET @PAR5 = @PAR5 + '.' + CAST(@PAR7 AS VARCHAR(10))

--	INSERT INTO 
--			@TempCodArb
	SELECT @PAR5 AS [Arbol]
		  ,@PAR2 AS [ArbolID]
		  ,@PAR6 AS [ArbolDesc]
		  ,[ID]
		  ,[PadreID]
		  ,[ItemNivel]
		  ,[ItemOrd]
		  ,[ItemCod]
		  ,[Cod]
		  ,[Descripcion]
		  ,[IdiCod]
		  ,[Idioma]
	  FROM [SPM].[dbo].[GRL015_CodArbIdio]
	WHERE [IdiCod] = @PAR1			-- Idioma
		AND ([PadreID] = @PAR2		-- PadreID
		AND [ID] <> @PAR2)			-- HijoID
	ORDER BY [ItemNivel]
		  ,[ItemOrd]

--		SELECT [ID]
--			  FROM [SPM].[dbo].[GRL015_CodArbIdio]
--			WHERE [IdiCod] = @PAR1			-- Idioma
--				AND ([PadreID] = @PAR2		-- PadreID
--					  AND [ID] <> @PAR2)			-- Hijos, son distintos a los Padres, exepto el primero


	DECLARE @ID AS VARCHAR(36)
	DECLARE MY_CURSOR CURSOR 
	  LOCAL STATIC READ_ONLY FORWARD_ONLY
	FOR 
		-- Consulta que ejecuta el bucle, dentro de esta bucle siempre tiene el mismo nivel
			SELECT [ID]
			  FROM [SPM].[dbo].[GRL015_CodArbIdio]
			WHERE [IdiCod] = @PAR1			-- Idioma
				AND ([PadreID] = @PAR2		-- PadreID
					  AND [ID] <> @PAR2)	-- Hijos, son distintos a los Padres, exepto el primero
	SET @PAR5 = @PAR5 + '.'
	SET @PAR7 = 0
	OPEN MY_CURSOR
	FETCH NEXT FROM MY_CURSOR INTO @ID
	WHILE @@FETCH_STATUS = 0
	BEGIN 
	-- Nivel Arbol - Agrega un nivel
		SET @PAR7 = @PAR7 + 1
		SET @PAR5 = @PAR5 + CAST(@PAR7 AS VARCHAR(10))

--			INSERT INTO 
--					@TempCodArb
			SELECT @PAR5 AS [Arbol]
				  ,@PAR2 AS [ArbolID]
				  ,@PAR6 AS [ArbolDesc]
				  ,[ID]
				  ,[PadreID]
				  ,[ItemNivel]
				  ,[ItemOrd]
				  ,[ItemCod]
				  ,[Cod]
				  ,[Descripcion]
				  ,[IdiCod]
				  ,[Idioma]
			  FROM [SPM].[dbo].[GRL015_CodArbIdio]
			WHERE [IdiCod] = @PAR1			-- Idioma
				AND ([PadreID] = @ID		-- PadreID
					  AND [ID] <> @ID)		-- Hijos, son distintos a los Padres, exepto el primero
			ORDER BY [ItemNivel]
				  ,[ItemOrd]

		--Do something with Id here
	--    PRINT @PractitionerId
		FETCH NEXT FROM MY_CURSOR INTO @ID
	END
	CLOSE MY_CURSOR
	DEALLOCATE MY_CURSOR

	SELECT * 
	FROM @TempCodArb
	ORDER BY [ArbolID]
--			  ,[PadreID]
			  ,[ItemNivel]
			  ,[ItemOrd]