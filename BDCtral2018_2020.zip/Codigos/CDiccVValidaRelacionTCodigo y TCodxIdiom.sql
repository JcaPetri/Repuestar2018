SELECT [ID]
      ,[IDFkCodEstados]
      ,[TCodigosFechaModif]
  FROM [BDCtral].[dbo].[CDiccTCodigos] AS TC WITH(NOLOCK)
	LEFT OUTER JOIN [BDCtral].[dbo].[CDiccTCodxIdiomas] AS TCI WITH(NOLOCK)
		ON TC.[ID] = TCI.[IDFkTCodigos]
WHERE TCI.[IDFkTCodigos] IS NULL

SELECT [IDFkTCodigos]
      ,[IDFkTIdioma]
      ,[IDFkTCodAmbAplic]
      ,[Codigo]
      ,[Descripcion]
      ,[IDFkCxIEstados]
      ,[TCodxIdioFechaModif]
  FROM [BDCtral].[dbo].[CDiccTCodxIdiomas] AS TCI WITH(NOLOCK)
	LEFT OUTER JOIN [BDCtral].[dbo].[CDiccTCodigos] AS TC WITH(NOLOCK)
		ON TCI.[IDFkTCodigos] = TC.[ID]
WHERE TC.[ID] IS NULL
