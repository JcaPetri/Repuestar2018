-- ###############################################################################################################################3
-- VEHICULOS - BUSCA LA PLACA OVAL  -- CBT -- Codigo Busqueda Tecnico
-- ###############################################################################################################################3

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para agregar un nuevo C�digo, se debe:
	DECLARE @PAR1 AS VARCHAR(36)	-- Idioma con el que se trabajar�	
	DECLARE @PAR2 AS VARCHAR(100)	-- Valor Buscado
	DECLARE @PAR3 AS VARCHAR(36)	-- Codigo del Padre del Arbol de Partes
	DECLARE @PAR4 AS VARCHAR(36)	-- Codigo del Vehiculo

	SET @PAR1 = 'ESP'					-- Idioma utilizado
	SET @PAR2 = '93YHSR1M5DJ697505'				-- AA545XE	OKA716	93YHSRA95HJ439720
		
	-- Toma el ID del Idioma elegido para la descripci�n
	SET @PAR1 = (SELECT [ItemID] FROM [SPM].[dbo].[GVGrlIdiomas] WHERE [Cod] = @PAR1)
	-- SELECT @PAR1

-- Siempre busca el primero que el valor que se puede cargar en la variable @PAR4
--	SELECT [CBT]
--			, [IDArbPar]		-- Codigo Busqueda Tecnico
--			, ATVC.[IDVeh]		-- Codigo Busqueda Tecnico
--			, @PAR2 AS [PAR2]
	SELECT @PAR3 = IDArbPar		-- Codigo Busqueda Tecnico
			, @PAR4 = ATVC.[IDVeh]	-- Codigo del Veh�culo
	FROM [SPM].[dbo].[ATVehTermBasComp] AS ATVC WITH(NOLOCK)
		INNER JOIN (
					SELECT [ItemID]
					FROM (
							SELECT [ItemID]
								  ,[IdiomaID]
								  ,REVERSE(SUBSTRING(REVERSE([CodBusq]), 1, LEN(@PAR2))) AS [CodBusqR]
							  FROM [SPM].[dbo].[ATVehCodBusq] WITH(NOLOCK)
							WHERE [IdiomaID] = @PAR1
						  ) AS CB 
					WHERE [CodBusqR] = @PAR2
					) AS CBU 
			ON ATVC.[IDVeh] = CBU.[ItemID]
		INNER JOIN [SPM].[dbo].[ATVehTermVincPar] AS VVP WITH(NOLOCK)
			ON ATVC.[IDVeh] = VVP.[IDVehTerm]

--	SELECT @PAR1 AS [Idioma_ID], @PAR2 AS [BusqClie], @PAR3 AS [CBT_ID], @PAR4 AS [Veh_ID]

-- LISTA LOS VEH�CULOS QUE COINCIDEN CON LA B�SQUEDA DEL USUARIO
	SELECT ATV.*, ATVC.*
	FROM [SPM].[dbo].[ATVehTermBas] AS ATV WITH(NOLOCK)
		INNER JOIN [SPM].[dbo].[ATVehTermBasComp] AS ATVC WITH(NOLOCK)
			ON ATV.[ID] = ATVC.[IDVeh]
	WHERE ATV.[ID] = @PAR4

-- Ya tiene los c�digos, ahora busca todos los datos
-- Genera una tabla temporaria para insertar los resultados
	DECLARE @TmpCodArb TABLE
	(
		[Arbol] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ArbolID] [uniqueidentifier] NULL,
		[ArbolDesc] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ID] [uniqueidentifier] NOT NULL,
		[PadreID] [uniqueidentifier] NULL,
		[ItemNivel] [smallint] NULL,
		[ItemOrd] [smallint] NULL,
		[ItemID] [uniqueidentifier] NULL,
		[Cod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[IdiCod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Idioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL
	)
	DECLARE @RC int		-- Determina si la consulta tiene valores

	-- Ejecuta el procedimiento almacenado
	INSERT INTO @TmpCodArb EXECUTE @RC = [SPM].[dbo].[APParCodArbBucleID] @PAR1, @PAR3
	-- SELECT @RC

	SELECT AP.[Arbol]
			,AP.[ArbolDesc]
			,AP.[ItemNivel]
			,AP.[ItemOrd]
--			,AP.[PadreID]
			,AP.[Cod]
			,AP.[Descripcion]
			,AP.[IdiCod]
			,AP.[Idioma]
			,AP.[ID]
			,PR.[PiezaCod]
		    ,PR.[PiezaDesc]
		    ,PR.[PiezaCant]
			,PR.[ID]
	 FROM @TmpCodArb AS AP
		LEFT OUTER JOIN [SPM].[dbo].[AVParPiezas] AS PR
			ON AP.[ID] = PR.[CAID]
--	 WHERE PR.[PiezaCod] IS NOT NULL
	 ORDER BY [Arbol]



--
--SELECT     IDVehTerm, IDArbPar
--FROM         ATVehTermVincPar

-- SELECT TOP 100 * FROM [SPM].[dbo].[ATVehTermBasComp] AS ATVC WITH(NOLOCK)
--SELECT [ID]
--      ,[TipoVehiculo]
--      ,[TipoCarroceria]
--      ,[Vehiculo]
--      ,[FaseProduccion]
--      ,[CombCajaMotor]
--      ,[NumFabricacion]
--      ,[NivelEquipamiento]
--      ,[EdicionLimitada]
--      ,[EdicionLimitadaCompl]
--      ,[ColorCarroceria]
--      ,[Tapicer�a]
--      ,[ArmoniaInterior]
--      ,[ParticularidadesTecnicas]
--      ,[SuspClimaCalefPrefiltro]
--      ,[Suspensi�n]
--      ,[Clima]
--      ,[Calefaccion]
--      ,[Prefiltro]
--      ,[DirecAmortAlturaAntibloque]
--      ,[Direccion]
--      ,[Amortiguacion]
--      ,[Altura]
--      ,[Antibloqueo]
--      ,[MotorIndice]
--      ,[CajaIndice]
--      ,[PPV]
--      ,[CBT]
--  FROM [SPM].[dbo].[ATVehTermBasComp]