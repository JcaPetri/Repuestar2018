DECLARE @RC int
DECLARE @PAR1 varchar(36)
DECLARE @PAR3 varchar(50)

-- TODO: Establezca los valores de los par�metros aqu�.
SET @PAR1 = 'ESP'	
SET @PAR3 = '01 Carr'				-- 01 Carr		Siniestro	SinTra		LargTrasIzq

-- si no encuentra da error
EXECUTE @RC = [SPM].[dbo].[APParCodArbBucle] 
   @PAR1
  ,@PAR3