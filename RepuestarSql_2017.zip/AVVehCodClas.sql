-- ###############################################################################################################################3
--  CONSULTA TRAE TODOS LOS CODIGOS, PRIMERO PONE LOS AGRUPADOS Y LUEGO LOS PENDIENTES DE AGRUPAMIENTO

SELECT Cc01.ID AS ClasID
	, Co01.IdiCod AS ClasIdioma
	, Co01.Cod AS ClasCod
	, Co01.Descripcion AS ClasDesc
	, Co02.IdiCod AS ItemIdioma
	, Cc01.BOwnerIDCod AS ItemID
	, Co02.Cod AS ItemCod
	, Co02.Descripcion AS ItemDesc
FROM [SPM].[dbo].[ATVehCodClas] AS Cc01 WITH (NOLOCK) 
	INNER JOIN [SPM].[dbo].[AVVehCodigos] AS Co01 
		ON Cc01.BOwnerIDClas = Co01.ItemID 
	INNER JOIN [SPM].[dbo].[AVVehCodigos] AS Co02 
		ON Cc01.BOwnerIDCod = Co02.ItemID
UNION ALL
SELECT NULL AS ClasID
	, Co01.IdiCod AS ClasIdioma
	, 'SCL' AS ClasCod
	, 'Sin Clasficar' AS ClasDesc
	, Co01.IdiCod AS ItemIdioma
	, Co01.ItemID
	, Co01.Cod AS ItemCod
	, Co01.Descripcion AS ItemDesc
FROM [SPM].[dbo].[AVVehCodigos] AS Co01 
	LEFT OUTER JOIN [SPM].[dbo].[ATVehCodClas] AS Cc01 WITH (NOLOCK) 
		ON Co01.ItemID = Cc01.BOwnerIDCod
WHERE (Cc01.ID IS NULL)
