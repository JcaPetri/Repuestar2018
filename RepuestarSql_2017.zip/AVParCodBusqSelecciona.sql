-- ###############################################################################################################################3
-- PARTES - BUSCA LAS PIEZAS SEG�N LA SELECCI�N DEL USUARIO  -- 
-- ###############################################################################################################################3

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	DECLARE @PAR1 AS VARCHAR(36)	-- Idioma con el que se trabajar�	
	DECLARE @PAR2 AS VARCHAR(100)	-- Valor Buscado
	DECLARE @PAR3 AS VARCHAR(36)	-- Codigo del Padre del Arbol de Partes
	DECLARE @PAR4 AS VARCHAR(200)	-- Codigo del Vehiculo

	SET @PAR1 = 'ESP'					-- Idioma utilizado
	SET @PAR2 = 'SinTra'					-- piso, 511121058R, travesa�o, etc
		
	-- Toma el ID del Idioma elegido para la descripci�n
	SET @PAR1 = (SELECT [ItemID] FROM [SPM].[dbo].[GVGrlIdiomas] WHERE [Cod] = @PAR1)
--	SELECT @PAR1 AS [Idioma_ID], @PAR2 AS [BusqClie]

-- Toma el ID del Arbol de partes a buscar, los agrega en una Tabla temporaria
-- ya que seg�n la elecci�n de usuario puede tener m�s de una resultado y en las variable convencionales solo se puede poner uno
-- en esta tabla va agregando los distintos arboles
		DECLARE @TmpParBusq TABLE
			(
				[IDBusqArb] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL, 
				[CodBusqCli] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
				[ItemNivel] [smallint] NULL,
				[ItemOrd] [smallint] NULL
			)
	-- Con el idioma y la Busqueda del Cliente, busca en la tabla [ATParCodBusq] los ID �nicos del CodArbol
		INSERT INTO @TmpParBusq
			([IDBusqArb]
			 ,[CodBusqCli]
			 ,[ItemNivel]
			 ,[ItemOrd])
			SELECT [IDBusq], MIN([CodBusq]), MIN([ItemNivel]), MIN([ItemOrd])
				--, [IdiomaID], [CodBusq]
			FROM [SPM].[dbo].[ATParCodBusq]
			WHERE [IdiomaID] = @PAR1 AND [CodBusq] LIKE '%' + @PAR2 + '%'
			GROUP BY [IDBusq], [CodBusq], [ItemNivel], [ItemOrd]
			ORDER BY [ItemNivel], [ItemOrd]
			-- Como resultado puede haber m�s de un ID
			-- Muestra los Rtados ID de las coincidencias
			--SELECT [IDBusqArb], [CodBusqCli] FROM @TmpParBusq

-- Ya teniendo los valores en una Tabla Temporaria, busca en el Arbol de Productos
-- Genera una tabla temporaria para insertar los resultados
	DECLARE @TmpCodArb TABLE
	(
		[Arbol] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ArbolID] [uniqueidentifier] NULL,
		[ArbolDesc] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ID] [uniqueidentifier] NOT NULL,
		[PadreID] [uniqueidentifier] NULL,
		[ItemNivel] [smallint] NULL,
		[ItemOrd] [smallint] NULL,
		[ItemID] [uniqueidentifier] NULL,
		[Cod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[IdiCod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Idioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[ItemCant] [numeric] (18, 4) NULL
	)

	DECLARE @RC int		-- Determina si la consulta tiene valores

	-- Etapa 1: Primero determino la cantidad de bucles que debe hacer el procedimiento
	DECLARE @PARI1 AS VARCHAR(72)	-- C�digo ID del valor a relevar
	DECLARE @PARI2 AS SMALLINT		-- Cantidad de datos a buscar
	DECLARE @VALINC AS VARCHAR(250)		-- Variable que guarda si el IDBuscado ya est� dentro de la estructura arbol

	SELECT @PARI1 = [IDBusqArb] FROM @TmpParBusq ORDER BY [ItemNivel], [ItemOrd]
	
	-- SELECT * FROM @TmpParBusq ORDER BY [ItemNivel], [ItemOrd]

	-- Si no trae ning�n registro sale del procedimiento 
	IF @PARI1 IS NULL
		BEGIN
			-- Finaliza el Procedimiento Almacenado
			PRINT 'No se encuentra la pieza buscada'
			RETURN
		END
	ELSE
		BEGIN
			-- Comienza a relevar los datos
			DECLARE @ID AS VARCHAR(36)			-- Variable para almacenar la clave ID del cursor

			-- Genera el cursor para el bucle
			DECLARE MI_CURSOR CURSOR 
				LOCAL STATIC READ_ONLY FORWARD_ONLY
			FOR 
				-- Consulta la tabla @TempDatRelev donde estan los datos que hay que buscar
				SELECT [IDBusqArb] AS [ID] FROM @TmpParBusq ORDER BY [ItemNivel], [ItemOrd]
			OPEN MI_CURSOR		-- Abre el cursor, con el valor ID como clave
			FETCH NEXT FROM MI_CURSOR INTO @ID		-- Busca el primer registro a buscar
			WHILE @@FETCH_STATUS = 0
				BEGIN 
					-- SELECT [ID] FROM @TmpCodArb AS TT WHERE TT.[ID] = @ID
					SELECT @VALINC = TT.[ID] FROM @TmpCodArb AS TT WHERE TT.[ID] = @ID
					-- SELECT @VALINC, @ID
					IF @VALINC IS NULL
						BEGIN
							-- Ejecuta el procedimiento almacenado, inserta los datos en la Tabla Temporaria
							-- @PAR1 = Idioma
							-- @ID = ID es el valor buscado, codigo del Arbol
							INSERT INTO @TmpCodArb EXECUTE @RC = [SPM].[dbo].[APParCodArbBucleID] @PAR1, @ID
							UPDATE @TmpCodArb SET TCA.[Arbol] = CA.[Arbol], TCA.[ItemNivel] = CA.[ItemNivel], TCA.[ItemOrd] = CA.[ItemOrd] FROM @TmpCodArb AS TCA INNER JOIN [SPM].[dbo].[ATParCodArblBusqTbl] AS CA ON TCA.[ID] = CA.[ID]
							--SELECT * FROM [SPM].[dbo].[ATParCodArblBusqTbl] WHERE [IdiID] = @PAR1 AND 
	
							-- SELECT @RC
							-- Pasa a otro registro
							FETCH NEXT FROM MI_CURSOR INTO @ID
						END
					ELSE
					-- Pasa a otro registro
					FETCH NEXT FROM MI_CURSOR INTO @ID
				END

			CLOSE MI_CURSOR
			DEALLOCATE MI_CURSOR
		END

--SELECT * FROM @TmpCodArb
-- Muestra el resultado
	SELECT APB.[ArbolID]
			,AP.[Arbol]
			,AP.[ArbolDesc]
			,AP.[ItemNivel]
			,AP.[ItemOrd]
			,AP.[PadreID]
			,AP.[Cod]
			,AP.[Descripcion]
			,AP.[ItemCant]
			,AP.[IdiCod]
			,AP.[Idioma]
			,AP.[ID]
	 FROM @TmpCodArb AS AP
		INNER JOIN [SPM].[dbo].[ATParCodArblBusqTbl] AS APB WITH(NOLOCK)
			ON AP.[ID] = APB.[ID]
	 ORDER BY [Arbol]

-- ###########################################################################################################################################3
-- Busca los Vehiculos que coinciden con las piezas buscadas -- 
-- ###########################################################################################################################################3
	DECLARE @TmpVehCodArb TABLE
	(
		[Arbol] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ArbolID] [uniqueidentifier] NULL,
		[ArbolDesc] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ID] [uniqueidentifier] NOT NULL,
		[PadreID] [uniqueidentifier] NULL,
		[ItemNivel] [smallint] NULL,
		[ItemOrd] [smallint] NULL,
		[ItemID] [uniqueidentifier] NULL,
		[Cod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[IdiCod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Idioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[IdiID] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL
	)

SET @PAR1 = 'ESP'																	-- Idioma utilizado
SET @PAR2 = (
			 SELECT APB.[ArbolID]
			 FROM @TmpCodArb AS AP
				INNER JOIN [SPM].[dbo].[ATParCodArblBusqTbl] AS APB WITH(NOLOCK)
					ON AP.[ID] = APB.[ID]
			 GROUP BY APB.[ArbolID]	
			) 
INSERT INTO @TmpVehCodArb EXECUTE @RC = [SPM].[dbo].[APVehCodArbInverso] @PAR1, @PAR2

SELECT 
		[Arbol]
--		,[ArbolID]
--		,[ArbolDesc]
--		,[ID]
--		,[PadreID]
--		,[ItemID]
		,[Cod]
		,[Descripcion]
		,[ItemNivel]
		,[ItemOrd]
		,[IdiCod]
		,[Idioma]
--		,[IdiID]
 FROM @TmpVehCodArb
ORDER BY [Arbol]

--
--SELECT [ID]
--      ,[PadreID]
--      ,[ItemNivel]
--      ,[ItemOrd]
--      ,[ItemCod]
--      ,[Cod]
--      ,[Descripcion]
--      ,[IdiCod]
--      ,[Idioma]
--FROM [SPM].[dbo].[AVVehCodArbIdi] AS VCA WITH(NOLOCK)
--	INNER JOIN (
--				SELECT [IDArbVeh]
--				FROM [SPM].[dbo].[ATVehParVinculo] AS VyP WITH(NOLOCK)
--				WHERE IDArbPar IN (
--									SELECT APB.[ArbolID]
--										 FROM @TmpCodArb AS AP
--											INNER JOIN [SPM].[dbo].[ATParCodArblBusqTbl] AS APB WITH(NOLOCK)
--												ON AP.[ID] = APB.[ID]
--									GROUP BY APB.[ArbolID]	
--									)
--				) AS PAV
--		ON VCA.[ID] = PAV.[IDArbVeh]
--
----SELECT [ID]
----      ,[PadreID]
----      ,[ItemNivel]
----      ,[ItemOrd]
----      ,[ItemCod]
----      ,[Cod]
----      ,[Descripcion]
----      ,[IdiCod]
----      ,[Idioma]
----  FROM [SPM].[dbo].[AVVehCodArbIdi]