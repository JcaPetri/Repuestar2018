-- ##########################################################################################################################################
-- Carga una nueva pieza a un arbol
-- ##########################################################################################################################################
DECLARE @PAR1 AS VARCHAR(36)	-- Idioma
DECLARE @PAR2 AS VARCHAR(36)	-- El ID �nico
DECLARE @PAR3 AS VARCHAR(50)	-- C�digo de Arbol a asignar
DECLARE @PAR4 AS VARCHAR(50)	-- Pieza a incorporar
DECLARE @PAR5 AS NUMERIC(18, 4)	-- Cantidad de Piezas
DECLARE @PAR6 AS VARCHAR(50)	-- Verif Duplicidad

SET @PAR1 = 'ESP'
SET @PAR2 = NEWID()
SET @PAR3 = 'GancAnilRemTras'
SET @PAR4 = '745611491R'
SET @PAR5 = 1


-- Selecciona la pieza a incorporar
SET @PAR4 = (SELECT [ItemID] FROM [SPM].[dbo].[AVParCodxIdi] WHERE [IdiCod] = @PAR1 AND [Cod] = @PAR4)


-- Selecciona el ID del c�digo Arbol
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Resultado de la incorporaci�n
-- Genera una tabla temporaria para insertar los resultados
	DECLARE @TmpCodArb TABLE
	(
		[Arbol] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ArbolID] [uniqueidentifier] NULL,
		[ArbolDesc] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ID] [uniqueidentifier] NOT NULL,
		[PadreID] [uniqueidentifier] NULL,
		[ItemNivel] [smallint] NULL,
		[ItemOrd] [smallint] NULL,
		[ItemID] [uniqueidentifier] NULL,
		[Cod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[IdiCod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Idioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL
	)
	DECLARE @RC int
	DECLARE @PAR9 varchar(36)
	DECLARE @PAR10 varchar(72)

	-- TODO: Establezca los valores de los par�metros aqu�.
--	SET @PAR9 = @PAR1		-- Idioma
--	SET @PAR10 = @PAR2		-- Cod Padre
--	SELECT @PAR9, @PAR10

	SET @PAR9 = @PAR1
	SET @PAR10 = '01 Carr'
	-- Si no trae nada la consulta da error

	INSERT INTO @TmpCodArb EXECUTE @RC = [SPM].[dbo].[APParCodArbBucle] @PAR9, @PAR10

--	SELECT [Arbol]
--			,[ArbolDesc]
--			,[ItemNivel]
--			,[ItemOrd]
--			,[PadreID]
--			,[Cod]
--			,[Descripcion]
--			,[IdiCod]
--			,[Idioma]
SET @PAR3 = (SELECT [ID]
	 FROM @TmpCodArb
	WHERE [Cod] = @PAR3)

-- Verifica que la combinaci�n de CodArbID y CodPiezID ya esta en la tabla
SET @PAR6 = (SELECT [ID] FROM [SPM].[dbo].[ATParPiezas] WHERE [ParCodArbID] = @PAR3 AND [PiezaCodID] = @PAR4)

-- SELECT @PAR6

INSERT INTO [SPM].[dbo].[ATParPiezas]
           ([ID]
           ,[ParCodArbID]
           ,[PiezaCodID]
           ,[PiezaCant])
	SELECT
			@PAR2 AS NuevoID
			, @PAR3 AS CodArbID
			, @PAR4 AS CodPiezID
			, @PAR5	AS Cant
		WHERE @PAR6 IS NULL

-- Consulta de los datos agregados
-- Datos de la Tabla
SELECT PP.[ID]
--      ,PP.[ParCodArbID]
	  ,CA.[Cod]
	  ,CA.[Descripcion]
--      ,PP.[PiezaCodID] AS [PiezaID]
	  ,PC.[Cod] AS [PiezaCod]
      ,PC.[Descripcion] AS [PiezaDesc]
      ,PP.[PiezaCant] AS [PiezaCant]
  FROM [SPM].[dbo].[ATParPiezas] AS PP WITH(NOLOCK)
	INNER JOIN [SPM].[dbo].[AVParCodxIdi] AS PC
		ON PP.[PiezaCodID] = PC.[ItemID]
				AND
		   'ESP' = PC.[IdiCod]
	INNER JOIN [SPM].[dbo].[AVParCodArbIdi] AS CA
		ON PP.[ParCodArbID] = CA.[ID]
				AND
		   'ESP' = CA.[IdiCod]
ORDER BY CA.[Cod], PC.[Cod]

