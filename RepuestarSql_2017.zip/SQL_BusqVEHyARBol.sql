-- ###############################################################################################################################3
-- VEHICULOS - BUSCA LA PLACA OVAL  -- CBT -- Codigo Busqueda Tecnico
-- ###############################################################################################################################3

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	DECLARE @PAR1 AS VARCHAR(36)	-- Idioma con el que se trabajar�	
	DECLARE @PAR2 AS VARCHAR(100)	-- Valor Buscado
	DECLARE @PAR3 AS VARCHAR(36)	-- Codigo del Padre del Arbol de Partes
	DECLARE @PAR4 AS VARCHAR(200)	-- Codigo del Vehiculo

	SET @PAR1 = 'ESP'					-- Idioma utilizado
	SET @PAR2 = 'AA545XE'				-- AA545XE	OKA716	93YHSRA95HJ439720
		
	-- Toma el ID del Idioma elegido para la descripci�n
	SET @PAR1 = (SELECT [ItemID] FROM [SPM].[dbo].[GVGrlIdiomas] WHERE [Cod] = @PAR1)
--	SELECT @PAR1 AS [Idioma_ID], @PAR2 AS [BusqClie]

--	Lista el resultado de los Vehiculos y el ID de Arbol de Partes
--	SELECT VVP.[IDArbPar], ATV.[ID]
--	FROM [SPM].[dbo].[ATVehTermBas] AS ATV WITH(NOLOCK)
--		INNER JOIN [SPM].[dbo].[ATVehTermBasComp] AS ATVC WITH(NOLOCK)
--			ON ATV.[ID] = ATVC.[IDVeh]
--		INNER JOIN [SPM].[dbo].[ATVehTermVincPar] AS VVP WITH(NOLOCK)
--			ON ATV.[ID] = VVP.[IDVehTerm]
--	WHERE ATV.[ID] IN (
----						SELECT @PAR3 = IDArbPar		-- Codigo Busqueda Tecnico
----								, @PAR4 = ATVC.[IDVeh]	-- Codigo del Veh�culo
--						SELECT ATVC.[IDVeh]	-- Codigo del Veh�culo
--						FROM [SPM].[dbo].[ATVehTermBasComp] AS ATVC WITH(NOLOCK)
--							INNER JOIN (
--										SELECT [ItemID]
--										FROM (
--												SELECT [ItemID]
--													  ,[IdiomaID]
--													  ,REVERSE(SUBSTRING(REVERSE([CodBusq]), 1, LEN(@PAR2))) AS [CodBusqR]
--												  FROM [SPM].[dbo].[ATVehCodBusq] WITH(NOLOCK)
--												WHERE [IdiomaID] = @PAR1
--											  ) AS CB 
--										WHERE [CodBusqR] = @PAR2
--										) AS CBU 
--											ON ATVC.[IDVeh] = CBU.[ItemID]
----							INNER JOIN [SPM].[dbo].[ATVehTermVincPar] 
----								AS VVP WITH(NOLOCK)
----									ON ATVC.[IDVeh] = VVP.[IDVehTerm]
--					   ) 
--		GROUP BY VVP.[IDArbPar], ATV.[ID]
--

-- Toma el valor de Veh�culo y del Arbol de productos, los agrega en una Tabla temporaria
-- ya que seg�n la elecci�n de usuario puede tener m�s de una resultado y en las variable convencionales solo se puede poner uno
		DECLARE @TmpVeh TABLE
			(
				[ArbID] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL, 
				[VehID] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL
			)

		INSERT INTO @TmpVeh
		SELECT VVP.IDArbPar		-- Codigo Busqueda Tecnico
										, ATVC.[IDVeh]	-- Codigo del Veh�culo
		--						SELECT ATVC.[IDVeh]	-- Codigo del Veh�culo
								FROM [SPM].[dbo].[ATVehTermBasComp] AS ATVC WITH(NOLOCK)
									INNER JOIN (
												SELECT [ItemID]
												FROM (
														SELECT [ItemID]
															  ,[IdiomaID]
															  ,REVERSE(SUBSTRING(REVERSE([CodBusq]), 1, LEN(@PAR2))) AS [CodBusqR]
														  FROM [SPM].[dbo].[ATVehCodBusq] WITH(NOLOCK)
														WHERE [IdiomaID] = @PAR1
													  ) AS CB 
												WHERE [CodBusqR] = @PAR2
												) AS CBU 
													ON ATVC.[IDVeh] = CBU.[ItemID]
									INNER JOIN [SPM].[dbo].[ATVehTermVincPar] 
										AS VVP WITH(NOLOCK)
											ON ATVC.[IDVeh] = VVP.[IDVehTerm]

-- SELECT [ArbID], [VehID] FROM @TmpVeh


-- LISTA LOS VEH�CULOS QUE COINCIDEN CON LA B�SQUEDA DEL USUARIO
	SELECT ATV.*, ATVC.*
	FROM [SPM].[dbo].[ATVehTermBas] AS ATV WITH(NOLOCK)
		INNER JOIN [SPM].[dbo].[ATVehTermBasComp] AS ATVC WITH(NOLOCK)
			ON ATV.[ID] = ATVC.[IDVeh]
	WHERE ATV.[ID] IN (
						SELECT [VehID] FROM @TmpVeh GROUP BY [VehID]
						)

-- Ya tiene los c�digos, ahora busca todos los datos
-- Genera una tabla temporaria para insertar los resultados
	DECLARE @TmpCodArb TABLE
	(
		[Arbol] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ArbolID] [uniqueidentifier] NULL,
		[ArbolDesc] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ID] [uniqueidentifier] NOT NULL,
		[PadreID] [uniqueidentifier] NULL,
		[ItemNivel] [smallint] NULL,
		[ItemOrd] [smallint] NULL,
		[ItemID] [uniqueidentifier] NULL,
		[Cod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[IdiCod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Idioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL
	)

	DECLARE @RC int		-- Determina si la consulta tiene valores

	-- Etapa 1: Primero determino la cantidad de bucles que debe hacer el procedimiento
	DECLARE @PARI1 AS VARCHAR(72)	-- C�digo ID del valor a relevar
	DECLARE @PARI2 AS SMALLINT		-- Cantidad de datos a buscar

	SELECT @PARI1 = [ArbID] FROM @TmpVeh GROUP BY [ArbID]

	-- Si no trae ning�n registro sale del procedimiento 
	IF @PAR1 IS NULL
		BEGIN
			-- Finaliza el Procedimiento Almacenado
			PRINT 'No se encuentra la pieza buscada'
			RETURN
		END
	ELSE
		BEGIN
			-- Comienza a relevar los datos
			DECLARE @ID AS VARCHAR(36)			-- Variable para almacenar la clave ID del cursor

			-- Genera el cursor para el bucle
			DECLARE MI_CURSOR CURSOR 
				LOCAL STATIC READ_ONLY FORWARD_ONLY
			FOR 
				-- Consulta la tabla @TempDatRelev donde estan los datos que hay que buscar
				SELECT [ArbID] AS [ID] FROM @TmpVeh GROUP BY [ArbID]
			OPEN MI_CURSOR		-- Abre el cursor, con el valor ID como clave
			FETCH NEXT FROM MI_CURSOR INTO @ID		-- Busca el primer registro a buscar
			WHILE @@FETCH_STATUS = 0
				BEGIN 

					-- Ejecuta el procedimiento almacenado, inserta los datos en la Tabla Temporaria
					-- @PAR1 = Idioma
					-- @ID = ID es el valor buscado, codigo del Arbol
					INSERT INTO @TmpCodArb EXECUTE @RC = [SPM].[dbo].[APParCodArbBucleID] @PAR1, @ID
					-- SELECT @RC

					-- Pasa a otro registro
					FETCH NEXT FROM MI_CURSOR INTO @ID
				END

			CLOSE MI_CURSOR
			DEALLOCATE MI_CURSOR
		END

--SELECT * FROM @TmpCodArb
-- Muestra el resultado
	SELECT AP.[Arbol]
			,AP.[ArbolDesc]
			,AP.[ItemNivel]
			,AP.[ItemOrd]
--			,AP.[PadreID]
			,AP.[Cod]
			,AP.[Descripcion]
			,AP.[IdiCod]
			,AP.[Idioma]
			,AP.[ID]
			,PR.[PiezaCod]
			,PR.[PiezaDesc]
			,PR.[PiezaCant]
			,PR.[ID]
	 FROM @TmpCodArb AS AP
		LEFT OUTER JOIN [SPM].[dbo].[AVParPiezas] AS PR
			ON AP.[ID] = PR.[CAID]
--	 WHERE PR.[PiezaCod] IS NOT NULL
	 ORDER BY [Arbol]


