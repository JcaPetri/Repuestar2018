-- ###############################################################################################################################3
-- VEHICULOS - ARMA EL ARBOL EN FORMA INVERSA  -- 
-- parte desde el valor que surge de la tabla ATVehParVinculo hasta el Padre Inicial
-- ###############################################################################################################################3

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- Detalle de los ID posibles
--SELECT VP.[IDArbVeh]
--	  ,VP.[IDArbPar]
----	  ,AV.[ID]
----      ,AV.[PadreID]
--      ,AV.[ItemNivel]
--      ,AV.[ItemOrd]
----      ,AV.[ItemCod]
--      ,AV.[Cod]
--      ,AV.[Descripcion]
--      ,AV.[IdiCod]
----      ,AV.[Idioma]
----      ,AV.[IdiID]
--FROM (
--		SELECT [IDArbVeh]
--			  ,[IDArbPar]
--		  FROM [SPM].[dbo].[ATVehParVinculo] WITH(NOLOCK)
--		GROUP BY [IDArbVeh]
--			  ,[IDArbPar]
--	 ) AS VP 
--		INNER JOIN [SPM].[dbo].[AVVehCodArbIdi] AS AV WITH(NOLOCK)
--			ON VP.[IDArbVeh] = AV.[ID]
--WHERE AV.[IdiID] = 'FB478ECC-85FE-4FC8-B792-CAF8ECB921B1'
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	DECLARE @PAR1 AS VARCHAR(36)	-- Idioma con el que se trabajar�	
	DECLARE @PAR2 AS VARCHAR(36)	-- Valor Buscado es el �ltimo valor que se relaciona con el inicio de los arboles de piezas
	DECLARE @PAR3 AS VARCHAR(36)	-- Codigo del Padre del Arbol de Partes
	DECLARE @PAR4 AS VARCHAR(200)	-- Codigo del Vehiculo

	SET @PAR1 = 'ESP'					-- Idioma utilizado
	SET @PAR2 = '2B007600-6F22-4BCA-9ED9-6244EAF59D3D'					-- Origen de la pieza que se vincula con el Vehiculo
		
	-- Toma el ID del Idioma elegido para la descripci�n
	SET @PAR1 = (SELECT [ItemID] FROM [SPM].[dbo].[GVGrlIdiomas] WHERE [Cod] = @PAR1)
	-- SELECT @PAR1 AS [Idioma_ID], @PAR2 AS [BusqClie]

	-- Toma el ID de Partes, Busca en la tabla VehParVinculos, los agrega en una Tabla temporaria de Veh�culos
	-- ya que seg�n la elecci�n de usuario, y el c�digo de partes puede tener m�s de un veh�culo relacionado y en las variable convencionales solo se puede poner uno
	-- en esta tabla va agregando los distintos arboles
		DECLARE @TmpVehBusq TABLE
			(
				[IDArbVeh] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL
			)
	-- Con el ID de partes, busca en la tabla [ATVehParVinculo] los ID �nicos de los Veh�culos relacionados
		INSERT INTO @TmpVehBusq
			([IDArbVeh])
			SELECT [IDArbVeh]
			  FROM [SPM].[dbo].[ATVehParVinculo]
			WHERE [IDArbPar] = @PAR2
			-- Como resultado puede haber m�s de un ID
			-- Muestra los Rtados ID de las coincidencias
			-- SELECT [IDArbVeh] FROM @TmpVehBusq

	-- Ya teniendo los valores en una Tabla Temporaria, busca en el Arbol de Vehiculos
	-- Genera una tabla temporaria para insertar los resultados
	DECLARE @TmpCodArb TABLE
	(
		[Arbol] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ArbolID] [uniqueidentifier] NULL,
		[ArbolDesc] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ID] [uniqueidentifier] NOT NULL,
		[PadreID] [uniqueidentifier] NULL,
		[ItemNivel] [smallint] NULL,
		[ItemOrd] [smallint] NULL,
		[ItemID] [uniqueidentifier] NULL,
		[Cod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[IdiCod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Idioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[IdiID] [varchar](36) COLLATE Modern_Spanish_CI_AS NULL
	)

	DECLARE @RC int				-- Determina si la consulta tiene valores

	-- Etapa 1: Primero determino la cantidad de bucles que debe hacer el procedimiento
	DECLARE @PARI1 AS VARCHAR(72)		-- C�digo ID del valor a relevar
	DECLARE @PARI2 AS SMALLINT			-- Cantidad de datos a buscar
	DECLARE @VALINC AS VARCHAR(250)		-- Variable que guarda si el IDBuscado ya est� dentro de la estructura arbol

	SELECT @PARI1 = [IDArbVeh] FROM @TmpVehBusq
	
	-- SELECT [IDArbVeh] FROM @TmpVehBusq

	-- Si no trae ning�n registro sale del procedimiento 
	IF @PARI1 IS NULL
		BEGIN
			-- Finaliza el Procedimiento Almacenado
			PRINT 'No se encuentra el Veh�culo buscado'
			RETURN
		END
	ELSE
		BEGIN
			-- Comienza a relevar los datos
			DECLARE @ID AS VARCHAR(36)			-- Variable para almacenar la clave ID del cursor
			DECLARE @PadreID as VARCHAR(36)		-- Variable para guardar los PadreID, de la elecci�n del usuario

			-- Genera el cursor para el bucle
			DECLARE MI_CURSOR CURSOR 
				LOCAL STATIC READ_ONLY FORWARD_ONLY
				--  LOCAL DYNAMIC OPTIMISTIC
			FOR 
				-- Consulta la tabla @TempDatRelev donde estan los datos que hay que buscar
				SELECT [IDArbVeh] AS [ID] FROM @TmpVehBusq
			OPEN MI_CURSOR		-- Abre el cursor, con el valor ID como clave
			FETCH NEXT FROM MI_CURSOR INTO @ID		-- Busca el primer registro a buscar
			WHILE @@FETCH_STATUS = 0
				BEGIN 
					-- Si el ID del veh�culo ya est� incorporado en la tabla, no lo incorpora
					-- SELECT [ID] FROM @TmpCodArb AS TT WHERE TT.[ID] = @ID
					SELECT @VALINC = TT.[ID] FROM @TmpCodArb AS TT WHERE TT.[ID] = @ID
					-- SELECT @VALINC, @ID
					IF @VALINC IS NULL
						BEGIN
							-- Busca en la Tabla CodArbol el valor inicial, inserta los datos en la Tabla Temporaria
							-- @PAR1 = Idioma
							-- @ID = ID es el valor buscado, codigo del Arbol
							INSERT INTO @TmpCodArb SELECT * FROM [SPM].[dbo].[ATVehCodArblTbl] WHERE [IdiID] = @PAR1 AND [ID] = @ID
							SET @PadreID = (SELECT [PadreID] FROM [SPM].[dbo].[ATVehCodArblTbl] WHERE [IdiID] = @PAR1 AND [ID] = @ID)
							--SELECT @PadreID
							-- Hace un bucle y por cada PadreID lo inserta en la tabla, si todav�a no se insert�
							-- luego vuelve a buscar otro padre
							WHILE (SELECT [PadreID] FROM [SPM].[dbo].[ATVehCodArblTbl] WHERE [ID] = @PadreID) <> @PadreID
							BEGIN
								-- Inserta el valor del Padre
								INSERT INTO @TmpCodArb SELECT VH.* FROM [SPM].[dbo].[ATVehCodArblTbl] AS VH WITH(NOLOCK) LEFT OUTER JOIN @TmpCodArb AS TVH ON VH.[ID] = TVH.[ID] WHERE VH.[IdiID] = @PAR1 AND VH.[ID] = @PadreID AND TVH.[ID] IS NULL
								-- Pone en la variable @PadreID, el padre de este nuevo valor
								SET @PadreID = (SELECT [PadreID] FROM [SPM].[dbo].[ATVehCodArblTbl] WHERE [IdiID] = @PAR1 AND [ID] = @PadreID)
								IF (SELECT [PadreID] FROM [SPM].[dbo].[ATVehCodArblTbl] WHERE [ID] = @PadreID) = @PadreID
									BREAK
								ELSE
									CONTINUE
							END
							-- Inserta el Padre Inicial
							INSERT INTO @TmpCodArb SELECT VH.* FROM [SPM].[dbo].[ATVehCodArblTbl] AS VH WITH(NOLOCK) LEFT OUTER JOIN @TmpCodArb AS TVH ON VH.[ID] = TVH.[ID] WHERE VH.[IdiID] = @PAR1 AND VH.[ID] = @PadreID AND TVH.[ID] IS NULL
							-- Pasa a otro registro
							FETCH NEXT FROM MI_CURSOR INTO @ID
						END
					ELSE
					-- Pasa a otro registro
					FETCH NEXT FROM MI_CURSOR INTO @ID
				END

			CLOSE MI_CURSOR
			DEALLOCATE MI_CURSOR
		END

--SELECT * FROM @TmpCodArb
-- Muestra el resultado
--	SELECT AP.[Arbol]
--			,AP.[ArbolDesc]
--			,AP.[ItemNivel]
--			,AP.[ItemOrd]
--			,AP.[PadreID]
--			,AP.[Cod]
--			,AP.[Descripcion]
--			,AP.[IdiCod]
--			,AP.[Idioma]
--			,AP.[ID]
--			,AP.[ArbolID]
	SELECT *
	 FROM @TmpCodArb AS AP
	 ORDER BY [Arbol]
