-- ###############################################################################################################################3
-- PARTES - Carga la Tabla con la estructura de un Padre.
-- ###############################################################################################################################3

--^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- Lista los padres posibles
--SELECT [PadreID], [ItemNivel], [ItemOrd], [Cod]
--      ,[Descripcion] --, [ItemCod], [ItemCant]
--FROM [SPM].[dbo].[ATParCodArbl] AS CA WITH(NOLOCK)
--	INNER JOIN [SPM].[dbo].[AVParCodxIdi] AS CXI WITH(NOLOCK)
--		ON CA.[ItemCod] = CXI.[ItemID]
--WHERE [ID] = [PadreID] 
--		AND [IdiCod] = 'ESP'
--ORDER BY [ItemNivel], [ItemOrd]
--^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	DECLARE @PAR1 AS VARCHAR(36)	-- Idioma con el que se trabajar�	
	DECLARE @PAR2 AS VARCHAR(36)	-- Valor Buscado, es el ID del Padre
	DECLARE @PAR3 AS VARCHAR(36)	-- Codigo del Padre del Arbol de Partes
	DECLARE @PAR4 AS VARCHAR(200)	-- Codigo del Vehiculo

	SET @PAR1 = 'ESP'						-- Idioma utilizado
	SET @PAR2 = '8D29EC41-5174-43E4-B33E-7CF021B5FCEA'					-- 2B007600-6F22-4BCA-9ED9-6244EAF59D3D = 01 Carr - carrocer�a
																		-- 8D29EC41-5174-43E4-B33E-7CF021B5FCEA = Siniestro = Siniestro Total
	-- Toma el ID del Idioma elegido para la descripci�n
	SET @PAR1 = (SELECT [ItemID] FROM [SPM].[dbo].[GVGrlIdiomas] WHERE [Cod] = @PAR1)
	-- SELECT @PAR1 AS [Idioma_ID], @PAR2 AS [BusqClie]

-- Genera una tabla temporaria para insertar los resultados
	DECLARE @TmpCodArb TABLE
	(
		[Arbol] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ArbolID] [uniqueidentifier] NULL,
		[ArbolDesc] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ID] [uniqueidentifier] NOT NULL,
		[PadreID] [uniqueidentifier] NULL,
		[ItemNivel] [smallint] NULL,
		[ItemOrd] [smallint] NULL,
		[ItemID] [uniqueidentifier] NULL,
		[Cod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[IdiCod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Idioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[ItemCant] [numeric] (18, 4) NULL
	)

	DECLARE @RC int		-- Determina si la consulta tiene valores

	-- Ejecuta el procedimiento almacenado, inserta los datos en la Tabla Temporaria
	-- @PAR1 = Idioma
	-- @ID = ID es el valor buscado, codigo del Arbol
	INSERT INTO @TmpCodArb EXECUTE @RC = [SPM].[dbo].[APParCodArbBucleID] @PAR1, @PAR2
	-- SELECT @RC

-- Elimina el ID que se insertar�
DELETE FROM [SPM].[dbo].[ATParCodArblBusqTbl] WHERE [ArbolID] = @PAR2

-- Inserta el Resultado en la Tabla Arbol donde est� el resultado de las relaciones
INSERT INTO [SPM].[dbo].[ATParCodArblBusqTbl]
           ([Arbol]
           ,[ArbolID]
           ,[ArbolDesc]
           ,[ID]
           ,[PadreID]
           ,[ItemNivel]
           ,[ItemOrd]
           ,[ItemID]
           ,[Cod]
           ,[Descripcion]
           ,[ItemCant]
           ,[IdiCod]
           ,[Idioma]
           ,[IdiID])
	SELECT AP.[Arbol]
			,AP.[ArbolID]
			,AP.[ArbolDesc]
			,AP.[ID]
			,AP.[PadreID]
			,AP.[ItemNivel]
			,AP.[ItemOrd]
			,AP.[ItemID]
			,AP.[Cod]
			,AP.[Descripcion]
			,AP.[ItemCant]
			,AP.[IdiCod]
			,AP.[Idioma]
			,@PAR1 AS [IdiID]
	 FROM @TmpCodArb AS AP
	 ORDER BY [Arbol]


-- Resultado de la Tabla
SELECT [Arbol]
      ,[ArbolID]
      ,[ArbolDesc]
      ,[ID]
      ,[PadreID]
      ,[ItemNivel]
      ,[ItemOrd]
      ,[ItemID]
      ,[Cod]
      ,[Descripcion]
      ,[ItemCant]
      ,[IdiCod]
      ,[Idioma]
      ,[IdiID]
  FROM [SPM].[dbo].[ATParCodArblBusqTbl]
WHERE [IdiID] = @PAR1
	AND [ArbolID] = @PAR2
