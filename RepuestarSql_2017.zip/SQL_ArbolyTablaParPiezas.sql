-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--
-- Resultado de la incorporaci�n
-- Genera una tabla temporaria para insertar los resultados
	DECLARE @TmpCodArb TABLE
	(
		[Arbol] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ArbolID] [uniqueidentifier] NULL,
		[ArbolDesc] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ID] [uniqueidentifier] NOT NULL,
		[PadreID] [uniqueidentifier] NULL,
		[ItemNivel] [smallint] NULL,
		[ItemOrd] [smallint] NULL,
		[ItemID] [uniqueidentifier] NULL,
		[Cod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[IdiCod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Idioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[ItemCant] [numeric] (18, 4) NULL
	)
	DECLARE @RC int
	DECLARE @PAR1 varchar(36)
	DECLARE @PAR3 varchar(72)
	DECLARE @PAR4 int		-- Nivel Hasta inclu�do

	SET @PAR1 = 'ESP'
	SET @PAR3 = 'Siniestro'			--	01 Carr		Siniestro
	SET @PAR4 = 3			-- Nivel Hasta inclu�do
	-- Si no trae nada la consulta da error

	INSERT INTO @TmpCodArb EXECUTE @RC = [SPM].[dbo].[APParCodArbBucle] @PAR1, @PAR3

	-- Muestra los resultados
	SELECT AP.[Arbol]
			,AP.[ArbolDesc]
			,AP.[ItemNivel]
			,AP.[ItemOrd]
--			,AP.[PadreID]
			,AP.[Cod]
			,AP.[Descripcion]
			,AP.[IdiCod]
			,AP.[Idioma]
			,AP.[ID]
			,AP.[ItemCant]
--			,PR.[PiezaCod]
--		    ,PR.[PiezaDesc]
--		    ,PR.[PiezaCant]
--			,PR.[ID]
	 FROM @TmpCodArb AS AP
--		LEFT OUTER JOIN [SPM].[dbo].[AVParPiezas] AS PR
--			ON AP.[ID] = PR.[CAID]
--	 WHERE PR.[PiezaCod] IS NOT NULL
	 WHERE AP.[ItemNivel] <= @PAR4
	 ORDER BY [Arbol]
