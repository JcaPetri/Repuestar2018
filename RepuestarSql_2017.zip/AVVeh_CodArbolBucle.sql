-- Variables que van arriba del procedimiento almacenado
	DECLARE @PAR1 AS VARCHAR(36)	-- Idioma con el que se trabajar�	
	DECLARE @PAR3 AS VARCHAR(50)	-- C�digo del Padre que a trabajar

	-- Setea las variables iniciales
	SET @PAR1 = 'ESP'
	SET @PAR3 = 'MAR'


-- Genera la tabla temporaria donde estar�n los datos que se deber�n buscar en el bucle
	-- aqu� se deben insertar los datos a buscar
	DECLARE @TempDatRelev TABLE
	(
		[ID] [uniqueidentifier] NULL,
		[PadreID] [uniqueidentifier] NULL,
		[Nivel] [smallint] NULL,
		[NivelDesc] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL
	)

-- Genera una tabla temporaria para insertar los resultados
	DECLARE @TempCodArb TABLE
	(
		[Arbol] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ArbolID] [uniqueidentifier] NULL,
		[ArbolDesc] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[ID] [uniqueidentifier] NOT NULL,
		[PadreID] [uniqueidentifier] NULL,
		[ItemNivel] [smallint] NULL,
		[ItemOrd] [smallint] NULL,
		[ItemID] [uniqueidentifier] NULL,
		[Cod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Descripcion] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL,
		[IdiCod] [varchar](50) COLLATE Modern_Spanish_CI_AS NOT NULL,
		[Idioma] [varchar](250) COLLATE Modern_Spanish_CI_AS NULL
	)

	-- Etapa 1: Primero determino la cantidad de bucles que debe hacer el procedimiento

	DECLARE @PAR2 AS VARCHAR(72)	-- C�digo ID del valor a relevar

	DECLARE @PAR4 AS SMALLINT		-- La tabla @TempDatRelev tiene datos a relevar
	DECLARE @PAR5 AS SMALLINT		-- NivelNum
	DECLARE @PAR6 AS VARCHAR(50)	-- NivelDesc
	DECLARE @PAR7 AS VARCHAR(36)	-- Arbol ID
	DECLARE @PAR8 AS VARCHAR(50)	-- Arbol Nombre

	DECLARE @PAR9 AS SMALLINT		-- Valor actual del Bucle
	
	
	SELECT @PAR2 = [ID]				-- C�digo ID
			, @PAR3 = [PadreID]		-- C�digo del Padre que se trabajar
			, @PAR5 = 1				-- NivelNum, como es el primero inicia en 1
			, @PAR6 = 'Niv-1'		-- NivelDesc, como es el primero inicia en 1
			, @PAR7 = [ID]			-- Arbol ID, no cambia en todos el procedimiento
			, @PAR8 = [Cod]			-- Arbol Nombre, no cambia en todos el procedimiento
	  FROM [SPM].[dbo].[AVVehCodArbIdi]
		WHERE [IdiCod] = @PAR1
			AND [Cod] = @PAR3
	ORDER BY [ItemNivel]
		  ,[ItemOrd]
	-- SELECT @PAR1, @PAR2, @PAR3, @PAR4, @PAR5, @PAR6, @PAR7, @PAR8
	
	-- Inserta los valores en la Tabla temporal, que servira para llevar un control de los Padres a relevar
	INSERT INTO 
		@TempDatRelev
	SELECT @PAR2		-- Valor ID
		, @PAR3			-- PadreID
		, @PAR5			-- NIvelNum, como es el primero inicia en 1
		, @PAR6			-- NIvelDesc, como es el primero inicia en 1
	-- SELECT * FROM @TempDatRelev

	-- Ingresa el valor del Padre, primer item, ya que el ID = PadreID, es el �nico caso
	INSERT INTO 
			@TempCodArb
	SELECT 'Niv-' + CASE WHEN @PAR5 < 9 THEN '0' ELSE '' END + CAST(@PAR5 AS VARCHAR(2)) AS [Arbol]
		  ,@PAR7 AS [ArbolID]
		  ,@PAR8 AS [ArbolDesc]
		  ,[ID]
		  ,[PadreID]
		  ,@PAR5 AS [ItemNivel]			-- Aqu� siempre es 1 ya que es el originador del procedimiento
		  ,ROW_NUMBER() OVER(PARTITION BY [PadreID] ORDER BY [ItemNivel], [ItemOrd]) AS [ItemOrd]
		  ,[ItemCod]
		  ,[Cod]
		  ,[Descripcion]
		  ,[IdiCod]
		  ,[Idioma]
	  FROM [SPM].[dbo].[AVVehCodArbIdi]
	WHERE [IdiCod] = @PAR1			-- Idioma
		AND [ID] = @PAR2			-- HijoID
		AND [PadreID] = @PAR3		-- PadreID
	--ORDER BY [ItemNivel], [ItemOrd]	--, [ID] DESC
	-- SELECT [Arbol], [ArbolDesc], [ItemNivel], [ItemOrd], [Cod], [Descripcion], [IdiCod], [Idioma] FROM @TempCodArb

	-- Mientras haya valores en la tabla, la sigue ejecutando
	-- SELECT [ID], [PadreID], [Nivel], [NivelDesc] FROM @TempDatRelev
	SET @PAR4 = (SELECT COUNT(*) FROM @TempDatRelev)
	-- SELECT @PAR4

	-- Comienza a relevar los datos
	SET @PAR9 = 0
	DECLARE @ID AS VARCHAR(36)		-- Variable spara almacenar la clave ID del cursos
	WHILE @PAR4 > 0
	BEGIN
		-- Genera el cursor para el bucle
		DECLARE MY_CURSOR CURSOR 
		  LOCAL STATIC READ_ONLY FORWARD_ONLY
		FOR 
			-- Consulta la tabla @TempDatRelev donde estan los datos Padre
			SELECT [ID] FROM @TempDatRelev
			SET @PAR9 = @PAR9 + 1	-- Le agrega un nivel
		OPEN MY_CURSOR		-- Abre el cursor, con el valor ID como clave
		FETCH NEXT FROM MY_CURSOR INTO @ID		-- Busca el primer Padre
		WHILE @@FETCH_STATUS = 0
		BEGIN 
			-- Etapa 1: Inserta los datos de los hijos en la Tabla @TempCodArb
				-- Toma las variables seg�n el valor @ID
				SET @PAR2 = @ID

				SET @PAR6 = (SELECT [Arbol] FROM @TempCodArb WHERE [ID] = @ID)
				-- Inserta los datos en la Tabla @TempCodArb
				INSERT INTO 
						@TempCodArb
				SELECT @PAR6 + CASE WHEN ROW_NUMBER() OVER(PARTITION BY [PadreID] ORDER BY [ItemNivel], [ItemOrd]) <= 9 THEN '0' ELSE '' END + CAST(ROW_NUMBER() OVER(PARTITION BY [PadreID] ORDER BY [ItemNivel], [ItemOrd]) AS VARCHAR(5)) AS [Arbol]			-- Este valor cambia
					  ,@PAR7 AS [ArbolID]		-- Fijo todo el procediento
					  ,@PAR8 AS [ArbolDesc]		-- Fijo todo el procediento
					  ,[ID]
					  ,[PadreID]
					  ,@PAR5 + @PAR9 AS [ItemNivel]
					  ,ROW_NUMBER() OVER(PARTITION BY [PadreID] ORDER BY [ItemNivel], [ItemOrd]) AS [ItemOrd]
					  ,[ItemCod]
					  ,[Cod]
					  ,[Descripcion]
					  ,[IdiCod]
					  ,[Idioma]
				  FROM [SPM].[dbo].[AVVehCodArbIdi]
				WHERE [IdiCod] = @PAR1							-- Idioma
					AND ([PadreID] = @PAR2 AND [ID] <> @PAR2) 	-- PadreID e HijoID son distintos
--				ORDER BY [ItemNivel]
--					  ,[ItemOrd]

			-- Etapa 2: elimina el Padre ya relevado de la Tabla @TempDatRelev
				DELETE FROM @TempDatRelev WHERE [ID] = @PAR2 

			-- Etapa 3: Inserta los datos de los hijos en la Tabla @TempDatRelev
				-- esto es para que no se quede sin registros y se corte el bucle
				-- mientras tenga datos de Padres el bucle contin�a
				INSERT INTO 
					@TempDatRelev
				SELECT [ID]
					, [PadreID]
					, @PAR5 + 1
					, @PAR6 + '.'
				  FROM [SPM].[dbo].[AVVehCodArbIdi]
				WHERE [IdiCod] = @PAR1							-- Idioma
					AND ([PadreID] = @PAR2 AND [ID] <> @PAR2) 	-- PadreID e HijoID son distintos
--				ORDER BY [ItemNivel]
--					  ,[ItemOrd]
			-- Pasa a otro registro
			FETCH NEXT FROM MY_CURSOR INTO @ID
		END
		CLOSE MY_CURSOR
		DEALLOCATE MY_CURSOR

		-- Determina si sale del bucle, si la Matriz de Datos a Relevar se quedo sin registros
		SET @PAR4 = (SELECT COUNT(*) FROM @TempDatRelev)
		IF @PAR4 = 0
			BREAK  
		ELSE
			CONTINUE
	END  

--	SELECT [Arbol], [ArbolDesc], [ItemNivel], [ItemOrd], [Cod], [Descripcion], [IdiCod], [Idioma]
	SELECT *
	FROM @TempCodArb
	ORDER BY [Arbol]
