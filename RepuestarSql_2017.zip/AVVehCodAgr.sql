SELECT Ca01.ID
	, Ca01.PadreID
	, Ca01.ItemNivel
	, Ca01.ItemOrd
	, Ca01.ItemCod
	, Co01.Cod
	, Co01.Descripcion
	, Co01.IdiCod
	, Co01.Idioma
FROM [SPM].[dbo].[ATVehCodAgr] AS Ca01 WITH (NOLOCK) 
		INNER JOIN [SPM].[dbo].[GVGrlCodigos] AS Co01 
			ON Ca01.ItemCod = Co01.ItemID