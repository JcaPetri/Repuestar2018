-- ###############################################################################################################################3
-- PARTES - INSERTA UN NUEVO CODIGO y SU DESCRIPCI�N POR IDIOMA
-- ###############################################################################################################################3

-- Falta asegurar que no se carguen duplicado

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- El c�digo del item es �nico independientemente la lengua, esta clave ID esta en la Tabla GRL013_Codigos, 
-- Dentro del mismo idioma no puede tener c�digos iguales: ItemID, IdiomaID, Cod (cada c�digo dentro del idioma debe ser �nico)
-- ##############################################################################################################################################

---- Listado de Idiomas disponibles, con sus c�digos
--SELECT [ItemID]
--      ,[Cod]
--      ,[Descripcion]
--  FROM [SPM].[dbo].[GVGrlIdiomas]
--ORDER BY [ItemOrd] ASC

-- Proc OK
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para agregar un nuevo C�digo, se debe:
	-- Variables Etapa 1
	DECLARE @PAR1 AS VARCHAR(36)	-- ID del nuevo idioma

	-- Variables Estapa 2
	DECLARE @PAR2 AS VARCHAR(50)	-- C�digo del idioma, debe ser �nico
	DECLARE @PAR3 AS VARCHAR(50)	-- C�digo del item
	DECLARE @PAR4 AS VARCHAR(250)	-- Descripci�n

	-- Idioma a seleccionar
	SET @PAR2 = 'ESP'				-- C�digo del idioma, debe ser �nico
	-- Datos a ingresar
	SET @PAR3 = 'SinLatDerTra'				-- C�digo del item
	SET @PAR4 = 'Siniestro Lateral Derecho Trasero'			-- Descripci�n

-- Etapa 1: insertar el item en la tabla ATVehCodigos
	SET @PAR1 = NEWID()				-- ID del nuevo idioma

	INSERT INTO [SPM].[dbo].[ATParCodigos]
			([ID])
		 SELECT @PAR1

-- Etapa 2: insertar el c�digo y su descripci�n en la tabla GTGrlCodxIdi
	-- Toma el ID del Idioma elegido para la descripci�n
	SET @PAR2 = (SELECT [ItemID] FROM [SPM].[dbo].[GVGrlIdiomas] WHERE [Cod] = @PAR2)

	INSERT INTO [SPM].[dbo].[ATParCodxIdi]
			   ([ItemID]
			   ,[IdiomaID]
			   ,[Cod]
			   ,[Descripcion])
		 SELECT @PAR1, @PAR2, @PAR3, @PAR4
	
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

---- Por cada item la descripci�n de sus c�digos
SELECT [ItemID]
      ,[Cod]
      ,[Descripcion]
--      ,[IdiCod]
--      ,[Idioma]
  FROM [SPM].[dbo].[AVParCodxIdi]
ORDER BY [Cod]
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

--
---- ###############################################################################################################################3
---- PARTES - ELIMINA UN CODIGO y SUS DESCRIPCIONES POR IDIOMA EN FORMA COMPLETO DE LA TABLA
---- ###############################################################################################################################3
--	-- Variables Etapa 1	-- Idioma a seleccionar
--	DECLARE @PAR1 AS VARCHAR(36)	-- C�digo del item a eliminar
--	SET @PAR1 = '56308FC4-A770-4EB7-B0D8-F4CCE218B565'		-- ID a eliminar
--
--	-- Elimina de la tabla ATVehCodigos
--	DELETE FROM [SPM].[dbo].[ATParCodigos]
--		  WHERE ID = @PAR1
--
--	-- Elimina de la tabla ATVehCodxIdi
--	DELETE FROM [SPM].[dbo].[ATParCodxIdi]
--		  WHERE [ItemID] = @PAR1
----
--
---- ###############################################################################################################################3
---- PARTES - ELIMINA SOLO LAS DESCRIPCIONES DE UN CODIGO y PARA UN IDIOMA
---- ###############################################################################################################################3
--
--	-- Variables Etapa 1	-- Idioma a seleccionar
--	DECLARE @PAR1 AS VARCHAR(36)	-- C�digo del idioma, debe ser �nico
--	
--	SET @PAR1 = 'ESP'				-- C�digo del idioma, debe ser �nico
--
--	-- Toma el ID del Idioma elegido para la descripci�n
--	SET @PAR1 = (SELECT [ItemID] FROM [SPM].[dbo].[GVGrlIdiomas] WHERE [Cod] = @PAR1)
----	SELECT @PAR1
--
--	-- Variables Estapa 2	-- Item a eliminar
--	DECLARE @PAR2 AS VARCHAR(50)	-- C�digo del item a eliminar, con este c�digo toma el Item ID y lo elimina
--	
--	-- Datos a ingresar
--	SET @PAR2 = 'PSM9 K4M:842 JR5:052'				-- C�digo del item
--	
---- falta finalizarlo
--
--
