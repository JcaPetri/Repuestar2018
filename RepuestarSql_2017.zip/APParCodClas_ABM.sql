-- ###############################################################################################################################3
-- PARTES - INSERTA UNA NUEVA CLASIFICACI�N y CODIGO -- 
-- ###############################################################################################################################3

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- El c�digo del item es �nico independientemente la lengua, esta clave ID esta en la Tabla GRL013_Codigos, 
-- Dentro del mismo idioma no puede tener c�digos iguales: ItemID, IdiomaID, Cod (cada c�digo dentro del idioma debe ser �nico)
-- ##############################################################################################################################################

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para agregar un nuevo C�digo, se debe:
	DECLARE @PAR1 AS VARCHAR(36)	-- Idioma con el que se trabajar�	

	-- Variables Etapa 1
	DECLARE @PAR2 AS VARCHAR(36)	-- ID de la clasificaci�n

	-- Variables Estapa 2
	DECLARE @PAR3 AS VARCHAR(50)	-- ID del Item a clasificar
	
	DECLARE @PAR4 AS VARCHAR(50)	-- Determina si la combinaci�n ya esta cargada

	
	SET @PAR1 = 'ESP'				-- Idioma utilizado

	-- Etapa 1 - determina el Clasificador, para ello se debe verificar y extraer el ID del C�digo
	SET @PAR2 = 'piezas'
	SET @PAR2 = (SELECT [ItemID] FROM [SPM].[dbo].[AVParCodigos] WHERE [Cod] = @PAR2 AND [IdiCod] = @PAR1)
	-- SELECT @PAR2

	-- Etapa 2 - determina el item que esta clasificado, para ello se debe extraer el ID del C�digo
	SET @PAR3 = '745611491R'
	SET @PAR3 = (SELECT [ItemID] FROM [SPM].[dbo].[AVParCodigos] WHERE [Cod] = @PAR3 AND [IdiCod] = @PAR1)
	-- SELECT @PAR3


	SET @PAR4 = (SELECT [ID] FROM [SPM].[dbo].[ATParCodClas] WHERE [BOwnerIDClas] = @PAR2 AND [BOwnerIDCod] = @PAR3)
		
	-- Inserta la nueva Clasificaci�n
	INSERT INTO [SPM].[dbo].[ATParCodClas]
           ([ID]
		   ,[BOwnerIDClas]
           ,[BOwnerIDCod])
		SELECT NEWID()
				,@PAR2
				, @PAR3
		WHERE @PAR2 IS NOT NULL AND @PAR3 IS NOT NULL AND @PAR4 IS NULL
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Muestra los resultados del cambio
SELECT [ClasID]
      ,[ClasIdioma]
      ,[ClasCod]
      ,[ClasDesc]
      ,[ItemIdioma]
      ,[ItemID]
      ,[ItemCod]
      ,[ItemDesc]
  FROM [SPM].[dbo].[AVParCodClas]
WHERE [ClasIdioma] = 'ESP' AND [ItemIdioma] = 'ESP'
ORDER BY [ClasIdioma], [ClasCod], [ItemCod]
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

--
--
---- ###############################################################################################################################3
---- PARTES - MODIFICA UNA CLASIFICACI�N y CODIGO -- 
---- ###############################################################################################################################3
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
---- Para agregar un nuevo C�digo, se debe:
--	DECLARE @PAR1 AS VARCHAR(36)	-- Idioma con el que se trabajar�	
--
--	-- Variables Estapa 1
--	DECLARE @PAR2 AS VARCHAR(50)	-- ID del Item a clasificar
--
--	-- Variables Etapa 1
--	DECLARE @PAR3 AS VARCHAR(36)	-- ID de la clasificaci�n actual
--	DECLARE @PAR4 AS VARCHAR(50)	-- ID de la clasificaci�n nueva
--
--	SET @PAR1 = 'ESP'				-- Idioma utilizado
--	-- Etapa 1 - determina el item que esta clasificado, para ello se debe extraer el ID del C�digo
--	SET @PAR2 = 'MAR'
--	SET @PAR2 = (SELECT [ItemID] FROM [SPM].[dbo].[AVParCodigos] WHERE [Cod] = @PAR2 AND [IdiCod] = @PAR1)
--	-- SELECT @PAR2
--
--	-- Etapa 2 - determina como est� clasificado el ItemID, para ello toma el CodID ItemID
--	SET @PAR3 = 'VEH'
--	SET @PAR3 = (SELECT [ItemID] FROM [SPM].[dbo].[AVParCodigos] WHERE [Cod] = @PAR3 AND [IdiCod] = @PAR1)
--	-- SELECT @PAR3
--
--	SET @PAR4 = 'MAR'
--	SET @PAR4 = (SELECT [ItemID] FROM [SPM].[dbo].[AVParCodigos] WHERE [Cod] = @PAR4 AND [IdiCod] = @PAR1)
--	-- SELECT @PAR2, @PAR3, @PAR4
--
--	-- Actualiza a la nueva clasificaci�n
--	UPDATE [SPM].[dbo].[ATParCodClas]
--	   SET [BOwnerIDClas] = @PAR4
--	 WHERE [BOwnerIDCod] = @PAR2 AND [BOwnerIDClas] = @PAR3
--
---- Muestra los resultados del cambio
--SELECT [ClasID]
--      ,[ClasIdioma]
--      ,[ClasCod]
--      ,[ClasDesc]
--      ,[ItemIdioma]
--      ,[ItemID]
--      ,[ItemCod]
--      ,[ItemDesc]
--  FROM [SPM].[dbo].[AVParCodClas]
--WHERE [ClasIdioma] = 'ESP' AND [ItemIdioma] = 'ESP'
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
