SELECT     TOP (100) PERCENT PP.ID, CA.ID AS CAID, CA.Cod, CA.Descripcion, PC.Cod AS PiezaCod, PC.Descripcion AS PiezaDesc, PP.PiezaCant
FROM dbo.ATParPiezas AS PP WITH (NOLOCK) 
	INNER JOIN dbo.AVParCodxIdi AS PC 
		ON PP.PiezaCodID = PC.ItemID 
			AND 'ESP' = PC.IdiCod 
	INNER JOIN dbo.AVParCodArbIdi AS CA 
		ON PP.ParCodArbID = CA.ID 
			AND 'ESP' = CA.IdiCod
WHERE CA.ID = '75a67156-8ac2-4e61-be2e-19dea48ff8c4'
ORDER BY CA.Cod, PiezaCod