-- ###############################################################################################################################3
-- PARTES - INSERTA UNA NUEVA BUSQUEDA PARA UN C�DIGO -- 
-- ###############################################################################################################################3

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- El c�digo del item es �nico independientemente la lengua, esta clave ID esta en la Tabla ATParCodigos, 
-- Dentro del mismo idioma no puede tener c�digos iguales: ItemID, IdiomaID, Cod (cada c�digo dentro del idioma debe ser �nico)
-- ##############################################################################################################################################

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para agregar un nuevo C�digo, se debe:
	DECLARE @PAR1 AS VARCHAR(36)	-- Idioma con el que se trabajar�	

	-- Variables Etapa 1
	DECLARE @PAR2 AS VARCHAR(36)	-- ID del Item que se cargar� un tipo busqueda

	-- Variables Estapa 2
	DECLARE @PAR3 AS VARCHAR(50)	-- Tipo descripci�n de busqueda
	
	DECLARE @PAR4 AS VARCHAR(50)	-- Determina si la combinaci�n ya esta cargada

	-- Toma el ID del Idioma elegido para la descripci�n
	SET @PAR1 = 'ESP'				-- Idioma utilizado
	SET @PAR1 = (SELECT [ItemID] FROM [SPM].[dbo].[GVGrlIdiomas] WHERE [Cod] = @PAR1)
--	 SELECT @PAR1

	-- Etapa 1 - determina el item que se buscar�, para ello se debe extraer el ID del C�digo
	SET @PAR2 = '01 Carr'
	SET @PAR2 = (SELECT [ItemID] FROM [SPM].[dbo].[AVParCodigos] WHERE [Cod] = @PAR2 AND [IdiID] = @PAR1)
--	 SELECT @PAR2
--	SET @PAR2 = 'B3CB126B-BAE0-41D9-831D-393D8A1ECB55'		-- ESTO ES SI YA TENGO EL CODIGO ID

	-- Etapa 2 - descripci�n de como se va a buscar el item
	SET @PAR3 = '511121058R'

	-- Verifica que ese tipo de busqueda para la clasificaci�n no este ya cargada
	SET @PAR4 = (SELECT [IDBusq] FROM [SPM].[dbo].[ATParCodBusq] WHERE [IDBusq] = @PAR2 AND [IdiomaID] = @PAR1 AND [CodBusq] = @PAR3)
		
	-- Inserta la nueva Clasificaci�n
	INSERT INTO [SPM].[dbo].[ATParCodBusq]
			   ([IDBusq]
			   ,[IdiomaID]
			   ,[CodBusq])
		SELECT @PAR2
				, @PAR1
				, @PAR3
		WHERE @PAR2 IS NOT NULL AND @PAR3 IS NOT NULL AND @PAR4 IS NULL

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Muestra los resultados del cambio
SELECT CB.[IDBusq]
      ,CB.[IdiomaID]
      ,CB.[CodBusq]
	  ,Idio.[Cod]
	  ,Idio.[Descripcion]
  FROM [SPM].[dbo].[ATParCodBusq] AS CB WITH (NOLOCK) 
		INNER JOIN [SPM].[dbo].[GVGrlIdiomas] AS Idio 
			ON CB.[IdiomaID] = Idio.[ItemID]

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- ###############################################################################################################################3
-- PARTES - INSERTA MASIVAMENTE UNA NUEVA BUSQUEDA PARA UNOS C�DIGOS -- 
-- ###############################################################################################################################3

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ##############################################################################################################################################
-- El c�digo del item es �nico independientemente la lengua, esta clave ID esta en la Tabla ATParCodigos, 
-- Dentro del mismo idioma no puede tener c�digos iguales: ItemID, IdiomaID, Cod (cada c�digo dentro del idioma debe ser �nico)
-- ##############################################################################################################################################

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Inserta de la vista [AVParCodArbIdi] los c�digos que no estan. 
-- esta vista a medida que cargamos codigos en la estructura arbol van apareciendo
-- inserta valores masivos por codbusq
INSERT INTO [SPM].[dbo].[ATParCodBusq]
           ([IDBusq]
           ,[IdiomaID]
           ,[CodBusq]
           ,[ItemNivel]
           ,[ItemOrd])
			SELECT AB.[ID]
				  ,AB.[IdiID]
				  ,AB.[Cod]
				  ,AB.[ItemNivel]
				  ,AB.[ItemOrd]
			  FROM [SPM].[dbo].[AVParCodArbIdi] AS AB WITH(NOLOCK)
				LEFT OUTER JOIN [SPM].[dbo].[ATParCodBusq] AS CB WITH(NOLOCK)
					ON AB.[ID] = CB.[IDBusq]
							AND
					   AB.[IdiID] = CB.[IdiomaID]
							AND
					   AB.[Cod] = CB.[CodBusq]
				WHERE CB.[IDBusq] IS NULL

-- inserta valores masivos por descripci�n
INSERT INTO [SPM].[dbo].[ATParCodBusq]
           ([IDBusq]
           ,[IdiomaID]
           ,[CodBusq]
           ,[ItemNivel]
           ,[ItemOrd])
			SELECT AB.[ID]
				  ,AB.[IdiID]
				  ,[Descripcion]
				  ,AB.[ItemNivel]
				  ,AB.[ItemOrd]
			  FROM [SPM].[dbo].[AVParCodArbIdi] AS AB WITH(NOLOCK)
				LEFT OUTER JOIN [SPM].[dbo].[ATParCodBusq] AS CB WITH(NOLOCK)
					ON AB.[ID] = CB.[IDBusq]
							AND
					   AB.[IdiID] = CB.[IdiomaID]
							AND
					   AB.[Descripcion] = CB.[CodBusq]
				WHERE CB.[IDBusq] IS NULL


